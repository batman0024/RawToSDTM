"""
ui/helpers.py
=============
Shared helper functions used across all page modules.
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
import threading
from pathlib import Path

import pandas as pd
import streamlit as st

# ── path setup ────────────────────────────────────────────────────────────
APP_DIR = Path(__file__).parent.parent.resolve()
SRC_DIR = APP_DIR / "src"
sys.path.insert(0, str(SRC_DIR))
sys.path.insert(0, str(APP_DIR))

def save_upload(uploaded_file, dest_dir):
    """Save a Streamlit UploadedFile to dest_dir; return Path."""
    dest = Path(dest_dir) / uploaded_file.name
    dest.write_bytes(uploaded_file.getbuffer())
    return dest


def bytes_to_upload_mock(content_bytes, filename, dest_dir):
    """Write raw bytes to a file; return Path."""
    dest = Path(dest_dir) / filename
    dest.write_bytes(content_bytes)
    return dest


def _bytes_to_file(name_bytes_tuple):
    """Wrap cached (name, bytes) tuple as a file-like object for uploaders that expect files."""
    import io as _io
    if name_bytes_tuple is None:
        return None
    name, bdata = name_bytes_tuple
    buf = _io.BytesIO(bdata)
    buf.name = name
    return buf


def metric_html(val, label, color=""):
    cls = "val " + color if color else "val"
    return (
        '<div class="metric-pill">'
        f'<div class="{cls}">{val}</div>'
        f'<div class="lbl">{label}</div>'
        '</div>'
    )


def log_html(lines):
    inner = "\n".join(lines[-120:])
    uid = "logbox_" + str(abs(hash(inner)) % 99999)
    # Auto-scroll to bottom using a tiny inline script
    scroll_js = f"""<script>
(function(){{
  var el=document.getElementById('{uid}');
  if(el){{el.scrollTop=el.scrollHeight;}}
  setTimeout(function(){{var e=document.getElementById('{uid}');if(e)e.scrollTop=e.scrollHeight;}},80);
}})();
</script>"""
    return f'<div class="log-box" id="{uid}">{inner}</div>{scroll_js}'



def _render_xai_bar(xai_str: str) -> str:
    """Convert a SCORE_BREAKDOWN string to a compact HTML score bar."""
    import ast
    try:
        if not xai_str or str(xai_str).lower() in ("", "nan", "{}"):
            return ""
        d = ast.literal_eval(str(xai_str))
        if not d:
            return ""
        # Use raw signal values (0-1) scaled to % of total for bar width
        # Fall back to weighted values if raw not available
        name_e  = float(d.get("name_exact",  d.get("w_name_exact",  0)) or 0)
        name_f  = float(d.get("name_fuzzy",  d.get("w_name_fuzzy",  0)) or 0)
        lbl_t   = float(d.get("label_tfidf", d.get("w_label_tfidf", 0)) or 0)
        hist    = float(d.get("master_freq", d.get("w_master_freq", 0)) or 0)
        total   = float(d.get("composite",   0) or 0)

        signals = [
            ("Exact Match",    name_e,  "#58a6ff"),
            ("Fuzzy Name",     name_f,  "#bc8cff"),
            ("Label Semantic", lbl_t,   "#e3b341"),
            ("History/Freq",   hist,    "#3fb950"),
        ]
        bars = ""
        for name, val, color in signals:
            pct = min(max(float(val) * 100, 0), 100)
            bars += (
                f'<div style="display:flex;align-items:center;gap:6px;margin:3px 0">'
                f'<span style="width:90px;font-size:10px;color:#8b949e;flex-shrink:0">{name}</span>'
                f'<div style="flex:1;background:#21262d;border-radius:3px;height:10px">'
                f'<div style="width:{pct:.0f}%;background:{color};height:10px;border-radius:3px;min-width:{2 if pct>0 else 0}px"></div>'
                f'</div>'
                f'<span style="width:38px;font-size:10px;color:{color};text-align:right;font-family:monospace">{val:.2f}</span>'
                f'</div>'
            )
        color_t = "#3fb950" if total >= 0.82 else "#e3b341" if total >= 0.55 else "#f85149"
        return (
            f'<div style="font-size:11px;color:{color_t};font-weight:700;margin-bottom:6px">'
            f'Score: {total:.3f}</div>' + bars
        )
    except Exception:
        return ""


def excel_download_button(df_dict, filename, label="Download Excel"):
    """Create an in-memory Excel workbook and return a download button."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in df_dict.items():
            if df is not None and not df.empty:
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    buf.seek(0)
    st.download_button(
        label=label,
        data=buf.read(),
        file_name=filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def file_download_button(path, label="Download File"):
    """Offer a file for download by path."""
    with open(path, "rb") as f:
        data = f.read()
    ext  = Path(path).suffix.lower()
    mime = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if ext in (".xlsx", ".xlsm") else "application/octet-stream"
    )
    st.download_button(label=label, data=data,
                       file_name=Path(path).name, mime=mime)


# ---------------------------------------------------------------------------
# Progress-aware wrapper for build_master_mapping
# ---------------------------------------------------------------------------

def run_build_with_progress(spec_paths, sponsor_paths, existing_master,
                             out_path, config_path, study_dates):
    """
    Wrap build_master_mapping with real-time Streamlit progress feedback.
    Yields (pct, message) via st.progress + st.status updates.
    """
    import master_builder as mb

    log_lines = []
    progress   = st.progress(0, text="Starting master build...")
    status_box = st.empty()

    steps = []
    if existing_master:
        steps.append(("Loading existing master", 5))
    for sp in spec_paths:
        steps.append((f"Reading study spec: {Path(sp).name}", 15))
    for sp in (sponsor_paths or []):
        steps.append((f"Reading sponsor spec: {Path(sp).name}", 15))
    steps.append(("Consolidating groups & confidence scores", 20))
    steps.append(("Writing master_mapping.xlsx", 10))

    total_weight = sum(w for _, w in steps)
    cumulative   = 0

    def tick(msg, weight):
        nonlocal cumulative
        cumulative += weight
        pct = min(int(cumulative / total_weight * 100), 99)
        progress.progress(pct, text=msg)
        log_lines.append(f"  {msg}")
        status_box.markdown(log_html(log_lines), unsafe_allow_html=True)
        time.sleep(0.05)

    # Patch the module's logger to capture output
    import logging, io as _io

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg = self.format(record)
            # strip timestamp prefix
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        tick("Initialising...", 0)

        orig_process = mb.process_spec_file
        proc_count   = [0]

        def patched_process(spec_path, cfg, study_date, is_sponsor, log):
            proc_count[0] += 1
            prefix = "Sponsor std" if is_sponsor else f"Study {proc_count[0]}"
            tick(f"{prefix}: {Path(spec_path).name}", 15)
            return orig_process(spec_path, cfg, study_date, is_sponsor, log)

        mb.process_spec_file = patched_process

        master_df = mb.build_master_mapping(
            spec_paths=spec_paths,
            sponsor_paths=sponsor_paths,
            existing_master=existing_master,
            out_path=out_path,
            config_path=config_path,
            study_dates=study_dates,
        )

        mb.process_spec_file = orig_process
        tick("Complete!", 10)
        progress.progress(100, text="Master mapping built successfully")
        return master_df, log_lines

    except Exception as exc:
        mb.process_spec_file = orig_process
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_map_with_progress(master_path, raw_path, spec_path,
                           out_path, config_path):
    """Wrap mapper.run with real-time progress."""
    import mapper as mp
    import logging

    log_lines = []
    progress   = st.progress(0, text="Starting variable mapping...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    # Patch run_mapping to emit per-domain progress
    orig_run_mapping = mp.run_mapping
    domains_seen = [0]

    def patched_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log):
        total_vars = len(sdtm_vars_df)
        pct_per_var = 60 / max(total_vars, 1)

        orig_find = mp.find_best_group
        var_count = [0]

        def patched_find(sdtm_var, domain, *args, **kwargs):
            var_count[0] += 1
            pct = 20 + int(var_count[0] * pct_per_var)
            progress.progress(
                min(pct, 80),
                text=f"Mapping {domain}.{sdtm_var}  [{var_count[0]}/{total_vars}]",
            )
            return orig_find(sdtm_var, domain, *args, **kwargs)

        mp.find_best_group = patched_find
        result = orig_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log)
        mp.find_best_group = orig_find
        return result

    mp.run_mapping = patched_run_mapping

    try:
        progress.progress(5,  text="Loading master mapping...")
        time.sleep(0.1)
        progress.progress(10, text="Loading raw catalog...")
        time.sleep(0.1)
        progress.progress(15, text="Building TF-IDF label index...")

        results = mp.run(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=str(spec_path) if spec_path else None,
            out_path=out_path,
            config_path=config_path,
        )

        mp.run_mapping = orig_run_mapping
        progress.progress(90, text="Writing results Excel...")
        time.sleep(0.2)
        progress.progress(100, text="Mapping complete!")
        return results, log_lines

    except Exception as exc:
        mp.run_mapping = orig_run_mapping
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_writeback_with_progress(spec_path, results_path, out_path,
                                 highlight_review, populate_origin,
                                 populate_action, dry_run, config_path):
    """Wrap spec_writeback.write_back with progress."""
    import spec_writeback as sw
    import logging

    log_lines = []
    progress   = st.progress(0, text="Preparing write-back...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        progress.progress(10, text="Loading mapping results...")
        time.sleep(0.1)
        progress.progress(25, text="Opening spec workbook...")
        time.sleep(0.1)
        progress.progress(35, text="Writing Input Variables, Origin, Mapping Action...")

        wb_result = sw.write_back(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
            highlight_review=highlight_review,
            populate_origin=populate_origin,
            populate_action=populate_action,
            dry_run=dry_run,
            config_path=str(config_path),
        )
        # write_back now returns (path, validation_report)
        if isinstance(wb_result, tuple):
            result_path, validation_report = wb_result
        else:
            result_path, validation_report = wb_result, None

        progress.progress(90, text="Running post-writeback validation...")
        time.sleep(0.15)
        progress.progress(100, text="Write-back complete!")
        return result_path, validation_report, log_lines

    except Exception as exc:
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


# ---------------------------------------------------------------------------
# Coverage chart (pure matplotlib -> PNG bytes)
# ---------------------------------------------------------------------------

def coverage_chart_bytes(coverage_df):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        domains = coverage_df["DOMAIN"].tolist()
        direct  = coverage_df["DIRECT"].astype(int).tolist()
        review  = coverage_df["REVIEW"].astype(int).tolist()
        unres   = coverage_df["UNRESOLVED"].astype(int).tolist()

        x     = range(len(domains))
        width = 0.25

        fig, ax = plt.subplots(figsize=(max(7, len(domains) * 1.2), 4), facecolor="#0d1117")
        ax.set_facecolor("#161b22")

        bars_d = ax.bar([i - width for i in x], direct,  width, label="Direct",     color="#3fb950", alpha=0.9)
        bars_r = ax.bar([i         for i in x], review,  width, label="Review",     color="#e3b341", alpha=0.9)
        bars_u = ax.bar([i + width for i in x], unres,   width, label="Unresolved", color="#f85149", alpha=0.9)

        ax.set_xticks(list(x))
        ax.set_xticklabels(domains, color="#e6edf3", fontsize=11)
        ax.tick_params(colors="#8b949e")
        ax.spines["bottom"].set_color("#30363d")
        ax.spines["left"].set_color("#30363d")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_ylabel("Variables", color="#8b949e", fontsize=10)
        ax.set_title("Mapping Coverage by Domain", color="#e6edf3", fontsize=12, pad=10)
        ax.yaxis.label.set_color("#8b949e")
        ax.tick_params(axis="y", colors="#8b949e")
        ax.grid(axis="y", color="#30363d", linewidth=0.5, linestyle="--")

        legend = ax.legend(
            facecolor="#161b22", edgecolor="#30363d",
            labelcolor="#e6edf3", fontsize=9,
        )

        # Value labels on bars
        for bars in (bars_d, bars_r, bars_u):
            for bar in bars:
                h = bar.get_height()
                if h > 0:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2, h + 0.1,
                        str(int(h)), ha="center", va="bottom",
                        color="#e6edf3", fontsize=8,
                    )

        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                    facecolor="#0d1117")
        plt.close(fig)
        buf.seek(0)
        return buf.read()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown(
        '<div class="main-header"><h1>SDTM Mapper</h1>'
        '<p>Master Mapping System v4</p></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-section">Navigation</div>', unsafe_allow_html=True)

    page = st.radio(
        "Select phase",
        options=["Build Master", "Map New Study", "Review & Approve",
                 "Write Back to Spec", "Compare Specs", "CDM Variable Filter",
                 "View Master", "Help"],
        label_visibility="collapsed",
    )

    st.markdown('<div class="sidebar-section">Settings</div>', unsafe_allow_html=True)

    cfg_path_input = st.text_input(
        "config.yaml path",
        value=str(APP_DIR / "src" / "config.yaml"),
        help="Path to config.yaml. Edit thresholds and weights there.",
    )

    # ---- Reset controls (raw + writeback only) ----
    st.markdown('<div class="sidebar-section">Reset</div>', unsafe_allow_html=True)
    st.caption("Phase 1 & 2 master mapping is preserved across resets.")
    _rcol1, _rcol2 = st.columns(2)
    with _rcol1:
        if st.button("🗑 Raw Data", help="Clear raw catalog and mapping results"):
            for _k in ("results_xlsx_bytes", "map_done"):
                st.session_state.pop(_k, None)
            st.success("Cleared.")
    with _rcol2:
        if st.button("🗑 Writeback", help="Clear write-back spec data"):
            for _k in ("wb_spec_bytes",):
                st.session_state.pop(_k, None)
            st.success("Cleared.")

    st.markdown('<div class="sidebar-section">About</div>', unsafe_allow_html=True)
    st.caption(
        "Each completed study fed into Build Master improves "
        "matching accuracy for all future studies."
    )


# ---------------------------------------------------------------------------
# Main header
# ---------------------------------------------------------------------------

st.markdown(
    '<div class="main-header">'
    '<h1>SDTM Master Mapping System v4</h1>'
    '<p>Build a cross-study master mapping knowledge base from completed SDTM specs, '
    'then automatically map new study raw variables to SDTM with confidence-scored '
    'outputs and direct spec write-back.</p>'
    '</div>',
    unsafe_allow_html=True,
)


# ===========================================================================
# PAGE: Build Master
# ===========================================================================

# ---------------------------------------------------------------------------
# Session state init
# ---------------------------------------------------------------------------

if "cdm_filter_dict" not in st.session_state:
    from cdm_filter import DEFAULT_CDM_VARIABLES, DEFAULT_CDM_DATASETS, DEFAULT_CDM_SUFFIXES
    st.session_state["cdm_filter_dict"] = {
        "cdm_variables":   sorted(DEFAULT_CDM_VARIABLES),
        "cdm_datasets":    sorted(DEFAULT_CDM_DATASETS),
        "cdm_suffixes":    list(DEFAULT_CDM_SUFFIXES),
        "custom_patterns": [],
    }

# ---------------------------------------------------------------------------
# Auto-update master mapping when watched spec folder has new/changed files
# ---------------------------------------------------------------------------

def _file_hash(path):
    """Return SHA1 hex of a file for change detection."""
    try:
        return hashlib.sha1(Path(path).read_bytes()).hexdigest()
    except Exception:
        return ""

def _scan_watch_folder(folder):
    """Return {filename: hash} for all xlsx/xlsm files in folder."""
    result = {}
    try:
        for p in Path(folder).glob("*.xls*"):
            result[p.name] = _file_hash(p)
    except Exception:
        pass
    return result

# ---------------------------------------------------------------------------
# Persistent session state init
# All upload bytes are cached here so tab switches / download clicks
# do NOT reset the uploaded files. The UI file_uploader widgets use
# these cached bytes if the widget itself is empty after a re-run.
# ---------------------------------------------------------------------------
_SS_DEFAULTS = {
    "watch_hashes":          {},
    "watch_folder":          "",
    "auto_update_log":       [],
    # Phase 1
    "master_xlsx_bytes":     None,
    "master_built":          False,
    # Phase 2
    "raw_bytes":             None,
    "spec_bytes":            None,
    "results_xlsx_bytes":    None,
    "map_done":              False,
    # Phase 3 / Write Back
    "wb_spec_bytes":         None,
    "wb_results_bytes":      None,
    # Compare
    "cmp_orig_bytes":        None,
    "cmp_mapped_bytes":      None,
    # Validation
    "last_val_report":       None,
    "last_val_report_excel": None,
}
for _k, _v in _SS_DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v





# ---------------------------------------------------------------------------
# Review & Approve panel
# ---------------------------------------------------------------------------
def _render_review_panel():
    """Interactive mapping review panel - tick to approve or drop each mapping."""
    direct_cache = st.session_state.get("direct_df_cache", [])
    review_cache = st.session_state.get("review_df_cache", [])

    if not direct_cache and not review_cache:
        st.info("Run Phase 2 mapping first to see results here.")
        return

    st.markdown("### 🔍 Review & Approve Mappings")
    st.caption(
        "Approve (✅) or Drop (❌) each proposed mapping. "
        "Approved rows go to Write Back; dropped rows are excluded."
    )

    # Filters
    fc1, fc2, fc3, fc4 = st.columns([2, 2, 2, 2])
    with fc1:
        filt_domain = st.text_input("Filter Domain", placeholder="e.g. DM, AE", key="rv_dom")
    with fc2:
        filt_var    = st.text_input("Filter Variable", placeholder="e.g. USUBJID", key="rv_var")
    with fc3:
        filt_tier   = st.multiselect("Tier", ["AUTO", "REVIEW"], default=["AUTO", "REVIEW"], key="rv_tier")
    with fc4:
        filt_score_min = st.slider("Min Score", 0.0, 1.0, 0.0, 0.01, key="rv_sc")

    all_rows = []
    for r in direct_cache:
        r2 = dict(r); r2["_tier_label"] = "AUTO"; all_rows.append(r2)
    for r in review_cache:
        r2 = dict(r); r2["_tier_label"] = "REVIEW"; all_rows.append(r2)

    def _matches(r):
        dom = str(r.get("DOMAIN","")).upper()
        var = str(r.get("SDTM_VARIABLE","")).upper()
        sc  = float(r.get("COMPOSITE_SCORE", 0) or 0)
        if filt_domain and filt_domain.upper() not in dom:   return False
        if filt_var    and filt_var.upper()    not in var:   return False
        if r.get("_tier_label") not in filt_tier:            return False
        if sc < filt_score_min:                              return False
        return True

    filtered = [r for r in all_rows if _matches(r)]
    st.caption(f"Showing {len(filtered)} of {len(all_rows)} mappings")

    if not filtered:
        st.info("No mappings match the current filters.")
        return

    if "mapping_approvals" not in st.session_state:
        st.session_state["mapping_approvals"] = {}

    bc1, bc2, _ = st.columns([1, 1, 4])
    with bc1:
        if st.button("✅ Approve All Shown", key="rv_approve_all"):
            for r in filtered:
                k = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
                st.session_state["mapping_approvals"][k] = "approve"
    with bc2:
        if st.button("❌ Drop All Shown", key="rv_drop_all"):
            for r in filtered:
                k = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
                st.session_state["mapping_approvals"][k] = "drop"

    approved_count = dropped_count = 0
    st.markdown('<hr style="margin:4px 0;border-color:#30363d">', unsafe_allow_html=True)

    for i, r in enumerate(filtered[:200]):
        key = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
        current = st.session_state["mapping_approvals"].get(key, "approve")
        sc_val  = float(r.get("COMPOSITE_SCORE", 0) or 0)
        sc_col  = "#3fb950" if sc_val >= 0.82 else "#e3b341" if sc_val >= 0.55 else "#f85149"

        raw_assigned = str(r.get("RAW_VARIABLES_ASSIGNED","") or "")
        first_tok = raw_assigned.split(",")[0].strip()
        pts = first_tok.split(".")
        raw_ds  = pts[-2] if len(pts) >= 2 else ""
        raw_var = pts[-1] if pts else ""

        cols = st.columns([2, 1.5, 1.5, 3, 1, 1])
        tier_icon = "🟢" if r.get("_tier_label") == "AUTO" else "🟡"
        cols[0].caption(f"{tier_icon} **{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}**")
        cols[1].caption(raw_ds[:20])
        cols[2].caption(raw_var[:20])
        cols[3].caption(str(r.get("SDTM_LABEL",""))[:55])
        cols[4].markdown(
            f"<span style='color:{sc_col};font-family:monospace;font-size:12px'>{sc_val:.3f}</span>",
            unsafe_allow_html=True
        )
        decision = cols[5].radio(
            f"dec_{i}", ["✅", "❌"],
            index=0 if current == "approve" else 1,
            horizontal=True,
            label_visibility="collapsed",
            key=f"rv_dec_{i}_{key}",
        )
        st.session_state["mapping_approvals"][key] = "approve" if decision == "✅" else "drop"
        if decision == "✅": approved_count += 1
        else:                dropped_count  += 1

    st.markdown(f"**{approved_count} approved · {dropped_count} dropped**")
    if len(filtered) > 200:
        st.caption(f"Showing first 200 of {len(filtered)} — use filters to narrow down.")
    st.info("After reviewing, go to **Write Back to Spec** — only approved mappings will be written.")


if page == "Build Master":
    st.markdown("## Phase 1 - Build Master Mapping")
    st.info(
        "Upload completed study spec Excel files. Each study added improves "
        "accuracy for future mappings. Sponsor standard specs get a confidence "
        "priority boost and supersede conflicting study mappings.",
    )

    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Completed Study Specs</div>', unsafe_allow_html=True)
        study_files = st.file_uploader(
            "Upload one or more completed study spec Excel files",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="study_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Sponsor Standard Specs (optional)</div>', unsafe_allow_html=True)
        sponsor_files = st.file_uploader(
            "Upload sponsor standard / template spec(s). These take priority over study mappings.",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="sponsor_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Existing Master (Append Mode)</div>', unsafe_allow_html=True)
        existing_master_file = st.file_uploader(
            "Optional: upload an existing master_mapping.xlsx to append new studies",
            type=["xlsx"],
            key="existing_master",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Study Dates (optional)</div>', unsafe_allow_html=True)
        st.caption("Older studies get a recency decay. Format: filename=YYYY-MM-DD (one per line)")
        dates_text = st.text_area(
            "Study dates",
            placeholder="study_a.xlsx=2022-06-01\nstudy_b.xlsx=2023-11-15\nsponsor_std.xlsx=2024-01-01",
            height=120,
            label_visibility="collapsed",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Conflict Strategy</div>', unsafe_allow_html=True)
        conflict_strategy = st.selectbox(
            "How to resolve conflicting mappings across studies",
            options=["sponsor_priority", "most_frequent"],
            index=0,
            help="sponsor_priority: sponsor standard wins. most_frequent: highest N_STUDIES wins.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">SDTMIG Version & Therapeutic Area</div>', unsafe_allow_html=True)
        st.caption(
            "Auto-detected from each spec Study tab. Override here if needed. "
            "Version-matched studies get higher confidence weight in the master."
        )
        target_ig_version = st.selectbox(
            "Target SDTMIG Version (for this master)",
            options=["Auto-detect from specs", "3.4", "3.3", "3.2", "3.1.3", "3.1.2"],
            index=0,
            help="Studies from the same SDTMIG version get full weight. Older versions are down-weighted.",
        )
        target_ta = st.multiselect(
            "Therapeutic Area filter (leave empty = all TAs pooled)",
            options=[
                "ONCOLOGY", "CARDIOLOGY", "NEUROLOGY", "RESPIRATORY",
                "IMMUNOLOGY", "RHEUMATOLOGY", "NEPHROLOGY", "OPHTHALMOLOGY",
                "HEMATOLOGY", "ENDOCRINOLOGY", "INFECTIOUS_DISEASE",
                "DERMATOLOGY", "GASTROENTEROLOGY", "MUSCULOSKELETAL",
            ],
            default=[],
            help="If selected, only studies matching these TAs are used for scoring that domain.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    run_build = st.button(
        "Build Master Mapping",
        disabled=(not study_files and not sponsor_files),
    )

    if run_build:
        try:
            import yaml, re
            with open(cfg_path_input) as f:
                cfg_data = yaml.safe_load(f)
            cfg_data["master_build"]["conflict_strategy"] = conflict_strategy
            # Write temp config
            tmp_cfg = Path(tempfile.mkdtemp()) / "config.yaml"
            import yaml as _yaml
            with open(tmp_cfg, "w") as f:
                _yaml.dump(cfg_data, f, default_flow_style=False, allow_unicode=False)

            tmpdir = _make_tmpdir()
            spec_paths    = [save_upload(f, tmpdir) for f in (study_files or [])]
            sponsor_paths = [save_upload(f, tmpdir) for f in (sponsor_files or [])]
            existing_path = None
            if existing_master_file:
                existing_path = save_upload(existing_master_file, tmpdir)

            study_dates = {}
            for line in dates_text.strip().splitlines():
                line = line.strip()
                if "=" in line:
                    fn, date = line.split("=", 1)
                    study_dates[fn.strip()] = date.strip()

            out_master = Path(tmpdir) / "master_mapping.xlsx"

            st.markdown("### Building...")
            master_df, log_lines = run_build_with_progress(
                spec_paths=spec_paths,
                sponsor_paths=sponsor_paths,
                existing_master=existing_path,
                out_path=out_master,
                config_path=tmp_cfg,
                study_dates=study_dates,
            )

            if master_df is not None and not master_df.empty:
                st.success(
                    f"Master mapping built: {len(master_df):,} rows | "
                    f"{master_df['SDTM_VARIABLE'].nunique()} SDTM variables | "
                    f"{master_df['DOMAIN'].nunique()} domains"
                )

                # Metrics
                top_df = master_df[master_df["IS_TOP_GROUP"]]
                high_n = int((top_df["MASTER_CONFIDENCE"] >= 0.82).sum())
                mid_n  = int(((top_df["MASTER_CONFIDENCE"] >= 0.55) & (top_df["MASTER_CONFIDENCE"] < 0.82)).sum())
                low_n  = int((top_df["MASTER_CONFIDENCE"] < 0.55).sum())

                pills = (
                    '<div class="metric-row">'
                    + metric_html(master_df["SDTM_VARIABLE"].nunique(), "SDTM Variables")
                    + metric_html(master_df["DOMAIN"].nunique(), "Domains", "")
                    + metric_html(int((master_df["IS_SPONSOR_STD"] == True).sum()), "Sponsor-Std Rows", "purple")
                    + metric_html(high_n, "High Conf (>=82%)", "green")
                    + metric_html(mid_n,  "Medium Conf",       "amber")
                    + metric_html(low_n,  "Low Conf (<55%)",   "red")
                    + '</div>'
                )
                st.markdown(pills, unsafe_allow_html=True)

                # Domain summary table
                st.markdown("#### Domain Summary")
                dom_sum = (
                    top_df.groupby("DOMAIN")
                    .agg(
                        SDTM_VARS=("SDTM_VARIABLE", "nunique"),
                        AVG_CONF=("MASTER_CONFIDENCE", "mean"),
                        HIGH_CONF=("MASTER_CONFIDENCE", lambda x: int((x >= 0.82).sum())),
                    )
                    .reset_index()
                    .round({"AVG_CONF": 3})
                )
                st.dataframe(dom_sum, use_container_width=True, hide_index=True)

                # Download
                st.markdown("#### Download")
                file_download_button(out_master, "Download master_mapping.xlsx")

                # Store in session state for next phase
                st.session_state["master_xlsx_bytes"] = out_master.read_bytes()
                st.session_state["master_built"]      = True

        except Exception as exc:
            st.error(f"Build failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)

    # ---- Auto-update watcher UI ----
    st.markdown("---")
    st.markdown("#### Auto-Update: Watch Folder for New/Changed Specs")
    st.caption(
        "Point to a local folder. When a spec Excel file changes or a new one appears, "
        "the master mapping is automatically rebuilt and session state is updated."
    )
    watch_folder = st.text_input(
        "Watch folder path (leave blank to disable)",
        value=st.session_state.get("watch_folder", ""),
        placeholder="/path/to/completed_specs/",
        key="watch_folder_input",
    )
    wcol1, wcol2 = st.columns([1, 3])
    with wcol1:
        check_now = st.button("Check for Changes")
    with wcol2:
        if st.session_state.get("auto_update_log"):
            st.caption("Last auto-update: " + st.session_state["auto_update_log"][-1])

    if watch_folder and (check_now or st.session_state.get("watch_folder") != watch_folder):
        st.session_state["watch_folder"] = watch_folder
        current_hashes = _scan_watch_folder(watch_folder)
        old_hashes     = st.session_state.get("watch_hashes", {})
        changed = [fn for fn, h in current_hashes.items() if old_hashes.get(fn) != h]
        if changed and st.session_state.get("master_built"):
            st.warning(f"Changes detected in: {', '.join(changed)} — rebuilding master...")
            try:
                import yaml as _yw
                with open(cfg_path_input) as _fw:
                    _cfw = _yw.safe_load(_fw)
                _tmpd = _make_tmpdir()
                _spec_paths = [Path(watch_folder) / fn for fn in current_hashes]
                _out = Path(_tmpd) / "master_mapping.xlsx"
                _existing = None
                if st.session_state.get("master_built"):
                    _existing = Path(_tmpd) / "existing_master.xlsx"
                    _existing.write_bytes(st.session_state["master_xlsx_bytes"])
                _cfg_tmp = Path(_tmpd) / "config.yaml"
                with open(_cfg_tmp, "w") as _f:
                    _yw.dump(_cfw, _f)
                _mdf, _ll = run_build_with_progress(
                    spec_paths=_spec_paths, sponsor_paths=[],
                    existing_master=_existing, out_path=_out,
                    config_path=_cfg_tmp, study_dates={},
                )
                if _mdf is not None:
                    st.session_state["master_xlsx_bytes"] = _out.read_bytes()
                    st.session_state["master_built"] = True
                    _msg = f"{dt.datetime.now():%H:%M:%S} — auto-rebuilt from {len(changed)} changed file(s)"
                    st.session_state["auto_update_log"].append(_msg)
                    st.success(f"Master auto-updated: {_msg}")
                _rm_tmpdir(_tmpd)
            except Exception as _e:
                st.error(f"Auto-update failed: {_e}")
        elif changed:
            st.info(f"Changed files detected ({', '.join(changed)}) — run Build Master first to create initial master.")
        else:
            st.success("No changes detected in watch folder.")
        st.session_state["watch_hashes"] = current_hashes


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================
