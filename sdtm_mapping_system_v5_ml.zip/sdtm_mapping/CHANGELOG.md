# Changelog

All notable changes to the SDTM Master Mapping System.

---

## v3.0 (current)

### New Features

- **Streamlit dark-mode UI** (`app.py`) with five pages:
  Build Master, Map New Study, Write Back to Spec, View Master, Help
- **Real-time progress bars** -- per-variable granularity on the mapper phase
- **Group-aware master index** -- `build_index()` stores `GROUP_TOKENS` so the
  mapper retrieves all tokens of the best group atomically
- **Partial-group scoring** -- `score_group_against_raw()` penalises groups
  where only a fraction of tokens are found in the new raw catalog
- **Dry-run mode** in `spec_writeback.py` -- preview all changes without
  writing any file; shows old/new values per cell in the log
- **Coverage var-class breakdown** -- coverage report now includes N_DERIVED,
  N_IDENTIFIER, N_TIMING, N_RESULT, N_CODELIST, N_GENERAL per domain
- **Centralised logging** via `logger.py` -- all modules write to a single
  Python logger; optional log file configured in `config.yaml`
- **Integration test suite** -- 20 tests covering all modules and end-to-end

### Improvements

- `read_toc_active_domains()` recognises 10 TOC sheet name variants and
  14 Active column name variants; handles status values like "In Scope",
  "Planned", "Produce" etc.
- Two-layer trial domain exclusion: TOC layer + sheet-name layer
- NaN guard in `agg_group()` for extraction_log reload in append mode
- Origin priority: CRF(1) > Derived(2) > Protocol(3) > eDT(4) > Assigned(5)
  -- an existing Origin only overwritten by higher-priority value
- All source files confirmed 100% clean ASCII (zero non-ASCII bytes)

---

## v2.0

### New Features

- **Group-aware storage** in master mapping -- multi-token Input Variable
  cells stored with GROUP_SIG, GROUP_POSITION, GROUP_COUNT, GROUP_TOKENS
- **TOC-first filtering** -- `_read_toc_active_domains()` function with
  two-layer trial domain exclusion
- **Sponsor versioning** -- sponsor standard specs take priority over study
  mappings via `IS_TOP_GROUP` flag and `IS_SPONSOR_STD` sorting
- **Append/incremental mode** -- add new studies without full rebuild

### Improvements

- Composite scorer upgraded to 4 signals (name exact + fuzzy + TF-IDF + freq)
- TF-IDF label index with `expand_sdtm_label()` abbreviation expansion
- `normalize_action()` maps 35 free-text action variants to 9 canonical tokens
- Per-domain threshold overrides in `config.yaml`
- Variable class modifiers applied to composite score
- `spec_writeback.py`: change-log sheet, SDTM.* token preservation

---

## v1.0

- Initial implementation: `rawtosdtm_18.py`, `spec_stream_02.py`, `eval_06.py`
- Single SequenceMatcher threshold (0.92)
- Flat master_mapping structure (one row per raw token, no group concept)
- No TOC filtering; no logging; no progress feedback
