"""
logger.py
=========
Centralised logging for the SDTM mapping pipeline.
Writes to both console and an optional log file.
All output is plain ASCII; no Unicode box-drawing characters.
"""

import logging
import sys
from pathlib import Path


_LOGGER_NAME = "sdtm_pipeline"
_configured  = False


def get_logger(log_file="", level="INFO"):
    """
    Return the pipeline logger. Configures it on first call.
    Subsequent calls return the already-configured logger.

    Args:
        log_file: path to log file; empty string = console only
        level:    DEBUG | INFO | WARNING
    """
    global _configured
    logger = logging.getLogger(_LOGGER_NAME)

    if _configured:
        return logger

    level_map = {
        "DEBUG":   logging.DEBUG,
        "INFO":    logging.INFO,
        "WARNING": logging.WARNING,
    }
    log_level = level_map.get(str(level).upper(), logging.INFO)
    logger.setLevel(log_level)

    fmt = logging.Formatter(
        fmt="%(asctime)s  %(levelname)-7s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(log_level)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File handler (optional)
    if log_file:
        try:
            fh = logging.FileHandler(log_file, encoding="ascii", errors="replace")
            fh.setLevel(log_level)
            fh.setFormatter(fmt)
            logger.addHandler(fh)
        except Exception as exc:
            logger.warning("Cannot open log file %s: %s", log_file, exc)

    _configured = True
    return logger
