"""
sdtm_knowledge.py
=================
SDTM structural knowledge base.
Pure domain logic: no file I/O, no external dependencies beyond stdlib.
All strings use straight ASCII quotes. No Unicode decorators.
"""

import re
import math


# ---------------------------------------------------------------------------
# Variable class rules - first match wins
# ---------------------------------------------------------------------------

VAR_CLASS_RULES = [
    ("identifier", [
        r"^STUDYID$", r"^DOMAIN$", r"^USUBJID$", r"^SUBJID$",
        r"^SITEID$",  r"^INVID$",  r"^POOLID$",
    ]),
    ("sequence", [
        r"SEQ$",
    ]),
    ("timing", [
        r"(ST|EN|OC|DC|RF)(DT|TM|DTC|DTM)$",
        r"^(RFSTDTC|RFENDTC|RFICDTC|RFPENDTC|RFXSTDTC|RFXENDTC)$",
        r"DY$",
        r"^VISITNUM$", r"^VISITDY$", r"^EPOCH$",
        r"(START|END)(DATE|TIME|DT|TM|DTC)$",
    ]),
    ("result", [
        r"ORRES(U?)$", r"STRESC$", r"STRESN$", r"STRESU$",
        r"TESTCD$",    r"^TEST$",  r"NRLO$",   r"NRHI$",
    ]),
    ("flag", [
        r"FL$", r"IND$",
    ]),
    ("derived", [
        r"CHG$",  r"PCHG$", r"^BASE$", r"SHIFT$",
        r"ANRIND$", r"BNRIND$", r"ANL\d+FL$",
        r"^(TRTP|TRTA|TRTPN|TRTAN)$",
    ]),
    ("codelist", [
        r"SEV$",  r"SCAT$", r"REAS$", r"ACN$",  r"REL$",
        r"OUT$",  r"TOXGR$", r"GRADE$", r"STAT$",
        r"REASND$", r"DTHFL$", r"DCSREAS$",
    ]),
    ("free_text", [
        r"DECOD$", r"MODIFY$", r"VERBATIM$", r"OTH$",
        r"SPEC$",  r"DTHCAUS$",
    ]),
]

# Variables sourced from study protocol (no raw data source)
PROTOCOL_VARS = frozenset({
    "STUDYID", "DOMAIN", "ARM",    "ACTARM",  "ARMCD",  "ACTARMCD",
    "EPOCH",   "TRTPN",  "TRTAN",  "TRTP",    "TRTA",
    "RFSTDTC", "RFENDTC", "RFICDTC", "RFPENDTC",
})

# Variables that are always derived (no raw source expected)
ALWAYS_DERIVED = frozenset({
    "USUBJID", "AGE", "AGEU",
    "AESEQ",  "CMSEQ",  "LBSEQ",  "VSSEQ",  "EXSEQ",
    "MHSEQ",  "DSSEQ",  "EGSEQ",  "PESEQ",  "PCSEQ",  "SUSEQ",
    "VISITNUM", "ADY", "AEDUR",
})

# Abbreviation expansion table used for label-similarity boosting
SDTM_ABBREV = {
    "AE": "adverse event",
    "CM": "concomitant medication",
    "DM": "demographics",
    "DS": "disposition",
    "EX": "exposure",
    "LB": "laboratory",
    "MH": "medical history",
    "PE": "physical examination",
    "VS": "vital signs",
    "EG": "electrocardiogram",
    "PC": "pharmacokinetics",
    "SU": "substance use",
    "DT": "date",
    "TM": "time",
    "DTC": "datetime",
    "ST": "start",
    "EN": "end",
    "OR": "original",
    "STR": "standard",
    "STRES": "standard result",
    "ORRES": "original result",
    "DECOD": "decoded",
    "SEV": "severity",
    "SER": "serious",
    "REL": "relationship",
    "ACN": "action",
    "OUT": "outcome",
    "REAS": "reason",
    "VERBATIM": "verbatim",
    "TERM": "term",
    "BODSYS": "body system",
    "HLT": "high level term",
    "LLT": "low level term",
    "SOC": "system organ class",
    "PT": "preferred term",
    "SEQ": "sequence",
    "FL": "flag",
    "IND": "indicator",
    "CHG": "change",
    "BASE": "baseline",
    "PCHG": "percent change",
    "STAT": "status",
    "GRAD": "grade",
    "TOX": "toxicity",
}

# Raw dataset prefixes that indicate electronic data transfer origin
EDT_PREFIXES = frozenset({"LB", "EG", "PC", "PE", "VS", "MB", "MS", "PF"})

# Standard sort keys per domain (SDTMIG)
DOMAIN_SORT_KEYS = {
    "DM": ["STUDYID", "USUBJID"],
    "AE": ["STUDYID", "USUBJID", "AESEQ"],
    "CM": ["STUDYID", "USUBJID", "CMSEQ"],
    "LB": ["STUDYID", "USUBJID", "LBSEQ"],
    "VS": ["STUDYID", "USUBJID", "VSSEQ"],
    "EX": ["STUDYID", "USUBJID", "EXSEQ"],
    "MH": ["STUDYID", "USUBJID", "MHSEQ"],
    "DS": ["STUDYID", "USUBJID", "DSSEQ"],
    "EG": ["STUDYID", "USUBJID", "EGSEQ"],
    "PC": ["STUDYID", "USUBJID", "PCSEQ"],
    "SU": ["STUDYID", "USUBJID", "SUSEQ"],
}

# Parameterised domains: domain -> TESTCD variable name
PARAM_DOMAINS = {
    "LB": "LBTESTCD",
    "VS": "VSTESTCD",
    "EG": "EGTESTCD",
    "PC": "PCTESTCD",
    "PE": "PETESTCD",
    "MB": "MBTESTCD",
    "MS": "MSTESTCD",
}


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def classify_variable(sdtm_var, domain=""):
    """Return the variable class name string for a given SDTM variable."""
    v = sdtm_var.upper().strip()
    for class_name, patterns in VAR_CLASS_RULES:
        for pat in patterns:
            if re.search(pat, v):
                return class_name
    return "general"


def expand_sdtm_label(sdtm_var, domain=""):
    """
    Expand a SDTM variable name into human-readable tokens using known
    abbreviations. Used to boost label-based matching.
    Example: AESTDTC -> 'adverse event start datetime'
    """
    v   = sdtm_var.upper().strip()
    dom = domain.upper().strip()
    stem = v[len(dom):] if (dom and v.startswith(dom)) else v

    tokens    = []
    remaining = stem
    abbrevs   = sorted(SDTM_ABBREV.keys(), key=len, reverse=True)

    while remaining:
        matched = False
        for abbr in abbrevs:
            if remaining.startswith(abbr):
                tokens.append(SDTM_ABBREV[abbr])
                remaining = remaining[len(abbr):]
                matched   = True
                break
        if not matched:
            tokens.append(remaining[0].lower())
            remaining = remaining[1:]

    domain_exp = SDTM_ABBREV.get(dom, dom.lower())
    return (domain_exp + " " + " ".join(tokens)).strip()


def is_date_variable(sdtm_var):
    """Return True if variable name ends in a date/datetime suffix."""
    return bool(re.search(r"(DT|DTC|DTM)$", sdtm_var.upper()))


def infer_origin(sdtm_var, domain, mapping_action,
                 raw_inputs, crf_var_set, als_var_set, raw_dataset_set):
    """
    Return (origin_value, confidence) using priority chain:
    CRF -> Derived -> Protocol -> eDT -> Assigned
    """
    v      = sdtm_var.upper().strip()
    action = str(mapping_action).upper().strip() if mapping_action else ""

    # Extract bare variable names from RAW.DATASET.VARIABLE tokens
    raw_basenames = set()
    for tok in (raw_inputs or []):
        parts = str(tok).upper().split(".")
        raw_basenames.add(parts[-1])

    # Priority 1: CRF
    if raw_basenames & (crf_var_set | als_var_set):
        conf = 0.95 if (raw_basenames & crf_var_set) else 0.85
        return ("CRF", conf)

    # Priority 2: Derived
    derive_kws = {
        "COMPUTE", "CALCULATE", "DERIVE", "ISO8601", "CONCATENATE",
        "BASE", "CHG", "PCHG", "SEQNUM", "LOOKUP", "ISO 8601",
    }
    var_class = classify_variable(v, domain)
    if (var_class in ("derived", "flag", "sequence")
            or any(kw in action for kw in derive_kws)
            or v in ALWAYS_DERIVED):
        return ("Derived", 0.90)

    # Priority 3: Protocol
    if v in PROTOCOL_VARS or var_class == "identifier":
        return ("Protocol", 0.92)

    # Priority 4: eDT
    ds_prefixes = {ds[:2].upper() for ds in raw_dataset_set if ds}
    if ds_prefixes & EDT_PREFIXES:
        return ("eDT", 0.75)

    # Priority 5: Assigned
    assigned_actions = {"ASSIGN", "HARDCODE", "HARD CODE", "CDISC CT"}
    conf = 0.88 if action in assigned_actions or action.startswith('"') else 0.55
    return ("Assigned", conf)


def normalize_action(raw_action):
    """Map free-text mapping action to controlled vocabulary token."""
    if not raw_action:
        return ""
    if isinstance(raw_action, float) and math.isnan(raw_action):
        return ""
    t = re.sub(r"\s+", " ", str(raw_action).strip()).upper()

    mapping = {
        "ASSIGN":           ["ASSIGN", "DIRECT", "AS IS", "COPY", "TRANSFER", "VERBATIM"],
        "DROP":             ["DROP", "NOT APPLICABLE", "N/A", "EXCLUDE", "NOT USED",
                             "NOT MAPPED", "NA"],
        "DERIVE":           ["DERIVE", "DERIVED", "COMPUTE", "CALCULATE", "COMPUTED",
                             "ALGORITHM", "LOGIC"],
        "ISO8601_DATETIME": ["ISO8601", "ISO 8601", "DATETIME", "DATE TIME", "DATE/TIME"],
        "ISO8601_DATE":     ["ISO8601 DATE", "ISO 8601 DATE", "DATE CONVERT", "DATE FORMAT"],
        "CONCATENATE":      ["CONCAT", "CONCATENATE", "JOIN", "COMBINE", "CAT"],
        "HARDCODE":         ["HARD CODE", "HARDCODE", "CONSTANT", "FIXED", "LITERAL"],
        "CODELIST_MAP":     ["DECODE", "RECODE", "MAP", "LOOKUP", "CT", "CDISC CT",
                             "CONTROLLED TERM"],
        "SEQNUM":           ["SEQ", "SEQUENCE", "COUNTER", "SEQUENTIAL"],
    }
    for canonical, variants in mapping.items():
        for v in variants:
            if v in t:
                return canonical
    return t
