"""
api/dependencies.py
===================
FastAPI dependency injection: auth, settings, job store.
"""
from __future__ import annotations

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from config.settings import settings
from auth.magic_link import MagicLinkService, RateLimiter
from auth.session_store import get_token_store
from auth.email_sender import build_email_sender
from exceptions.domain_exceptions import InvalidJWTError

_bearer = HTTPBearer(auto_error=True)

# ── Singletons built once at startup ─────────────────────────────────────────
_rate_limiter = RateLimiter(
    max_requests=settings.MAGIC_LINK_RATE_LIMIT,
    window_minutes=settings.MAGIC_LINK_RATE_WINDOW_MINUTES,
)

_magic_link_service: MagicLinkService | None = None


def get_magic_link_service() -> MagicLinkService:
    global _magic_link_service
    if _magic_link_service is None:
        _magic_link_service = MagicLinkService(
            store=get_token_store(),
            jwt_secret=settings.JWT_SECRET,
            jwt_expiry_hours=settings.JWT_EXPIRY_HOURS,
            ttl_minutes=settings.MAGIC_LINK_TTL_MINUTES,
            allowed_domains=settings.ALLOWED_EMAIL_DOMAINS,
            base_url=settings.BASE_URL,
            rate_limiter=_rate_limiter,
        )
    return _magic_link_service


def get_email_sender():
    return build_email_sender(settings)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
    svc: MagicLinkService = Depends(get_magic_link_service),
) -> str:
    """FastAPI dependency: validate Bearer JWT, return email."""
    try:
        return svc.decode_jwt(credentials.credentials)
    except InvalidJWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=exc.message,
            headers={"WWW-Authenticate": "Bearer"},
        )
