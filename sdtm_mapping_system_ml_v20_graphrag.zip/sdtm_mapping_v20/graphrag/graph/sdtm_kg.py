"""
graphrag/graph/sdtm_kg.py
==========================
SDTMKnowledgeGraph — NetworkX-based knowledge graph for raw-to-SDTM mapping.

Node kinds:
  raw_var        RAW::AE.AETERM        dataset, variable, label, format, type
  sdtm_var       SDTM::AE::AETERM      domain, variable, label, core, var_class
  raw_dataset    RAW_DS::AE            dataset_name, study_count
  sdtm_domain    DOM::AE               domain, domain_class
  mapping_group  GROUP::sig123         group_sig, action, confidence, n_studies
  study          STUDY::study_a        filename, study_date

Edge types:
  MAPS_TO        raw_var  → sdtm_var       score, tier, match_path
  IN_GROUP       raw_var  → mapping_group  position
  GOVERNS        mapping_group → sdtm_var  confidence, action
  MEMBER_OF_RAW  raw_var  → raw_dataset
  MEMBER_OF_DOM  sdtm_var → sdtm_domain
  SEEN_IN        mapping_group → study     weight = freq_weight
  CO_MAPPED_WITH raw_var ↔ raw_var         co-occurrence count
  SAME_CLASS     sdtm_var ↔ sdtm_var       same variable class
"""
from __future__ import annotations

import itertools
import math
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

try:
    import networkx as nx
except ImportError:
    raise ImportError("networkx is required for GraphRAG. Install with: pip install networkx")


class SDTMKnowledgeGraph:
    """Knowledge graph for raw-to-SDTM mapping lineage and exploration."""

    def __init__(self) -> None:
        self.G: nx.MultiDiGraph = nx.MultiDiGraph()

    # ── Node adders ───────────────────────────────────────────────────────────

    def add_raw_var(self, dataset: str, variable: str,
                    label: str = "", fmt: str = "", var_type: str = "") -> str:
        nid = f"RAW::{dataset.upper()}.{variable.upper()}"
        if not self.G.has_node(nid):
            self.G.add_node(nid,
                kind="raw_var",
                dataset=dataset.upper(),
                variable=variable.upper(),
                label=label,
                format=fmt,
                var_type=var_type,
                label_display=f"{dataset}.{variable}",
            )
        self._ensure_raw_ds(dataset)
        self._add_edge_once(nid, f"RAW_DS::{dataset.upper()}", "MEMBER_OF_RAW")
        return nid

    def add_sdtm_var(self, domain: str, variable: str,
                     label: str = "", core: str = "", var_class: str = "") -> str:
        nid = f"SDTM::{domain.upper()}::{variable.upper()}"
        if not self.G.has_node(nid):
            self.G.add_node(nid,
                kind="sdtm_var",
                domain=domain.upper(),
                variable=variable.upper(),
                label=label or f"{domain}.{variable}",
                core=core,
                var_class=var_class,
                label_display=f"{domain}.{variable}",
            )
        self._ensure_sdtm_domain(domain)
        self._add_edge_once(nid, f"DOM::{domain.upper()}", "MEMBER_OF_DOM")
        return nid

    def add_mapping_group(self, group_sig: str, sdtm_domain: str,
                          sdtm_var: str, mapping_action: str,
                          confidence: float, n_studies: int,
                          is_sponsor_std: bool = False) -> str:
        nid = f"GROUP::{group_sig[:16]}"
        if not self.G.has_node(nid):
            self.G.add_node(nid,
                kind="mapping_group",
                group_sig=group_sig,
                sdtm_domain=sdtm_domain.upper(),
                sdtm_var=sdtm_var.upper(),
                mapping_action=mapping_action,
                confidence=round(confidence, 4),
                n_studies=n_studies,
                is_sponsor_std=is_sponsor_std,
                label_display=f"{mapping_action}→{sdtm_domain}.{sdtm_var}",
            )
        return nid

    def add_study(self, study_id: str, study_date: str = "") -> str:
        nid = f"STUDY::{study_id}"
        if not self.G.has_node(nid):
            self.G.add_node(nid,
                kind="study",
                study_id=study_id,
                study_date=study_date,
                label_display=study_id,
            )
        return nid

    def _ensure_raw_ds(self, dataset: str) -> None:
        nid = f"RAW_DS::{dataset.upper()}"
        if not self.G.has_node(nid):
            self.G.add_node(nid, kind="raw_dataset",
                            dataset=dataset.upper(),
                            label_display=dataset.upper(),
                            study_count=0)

    def _ensure_sdtm_domain(self, domain: str) -> None:
        from graphrag.mapping.sdtm_rules import DOMAIN_CLASS
        nid = f"DOM::{domain.upper()}"
        if not self.G.has_node(nid):
            dom_class = DOMAIN_CLASS.get(domain.upper(), "Special")
            self.G.add_node(nid, kind="sdtm_domain",
                            domain=domain.upper(),
                            domain_class=dom_class,
                            label_display=f"{domain.upper()} ({dom_class})")

    # ── Edge helper ───────────────────────────────────────────────────────────

    def _add_edge_once(self, src: str, dst: str, etype: str,
                       weight: float = 1.0, **attrs) -> None:
        for u, v, d in self.G.edges(data=True):
            if u == src and v == dst and d.get("type") == etype:
                return
        self.G.add_edge(src, dst, type=etype, weight=weight, **attrs)

    def add_edge(self, src: str, dst: str, etype: str,
                 weight: float = 1.0, **attrs) -> None:
        self.G.add_edge(src, dst, type=etype, weight=weight, **attrs)

    # ── Population from master mapping ────────────────────────────────────────

    def populate_from_master(self, master_df) -> None:
        """
        Populate the graph from master_mapping.xlsx DataFrame.
        Adds raw_var, sdtm_var, mapping_group nodes and all edges.
        """
        import pandas as pd
        from graphrag.mapping.sdtm_rules import classify_sdtm_var

        # Collect co-mapping pairs per group for CO_MAPPED_WITH edges
        co_map: dict[str, list[str]] = {}

        for _, row in master_df.iterrows():
            domain   = str(row.get("DOMAIN",         "") or "").strip().upper()
            sdtm_v   = str(row.get("SDTM_VARIABLE",  "") or "").strip().upper()
            raw_tok  = str(row.get("RAW_VARIABLE",   "") or "").strip()
            group_sig= str(row.get("GROUP_SIG",      "") or "").strip()
            g_toks   = str(row.get("GROUP_TOKENS",   "") or "").strip()
            g_pos    = int(row.get("GROUP_POSITION",  0)  or 0)
            action   = str(row.get("MAPPING_ACTION", "") or "").strip()
            conf     = float(row.get("MASTER_CONFIDENCE", 0) or 0)
            n_stud   = int(row.get("N_STUDIES",      1)  or 1)
            is_spon  = bool(row.get("IS_SPONSOR_STD", False))
            label    = str(row.get("SDTM_LABEL",     "") or "").strip()
            core     = str(row.get("CORE",           "") or "").strip()

            if not domain or not sdtm_v:
                continue

            # SDTM var node
            var_class = classify_sdtm_var(sdtm_v, domain)
            sv_nid = self.add_sdtm_var(domain, sdtm_v, label, core, var_class)

            # Mapping group node
            if group_sig:
                grp_nid = self.add_mapping_group(
                    group_sig, domain, sdtm_v, action, conf, n_stud, is_spon
                )
                self._add_edge_once(grp_nid, sv_nid, "GOVERNS",
                                    weight=conf,
                                    action=action,
                                    n_studies=n_stud)

            # Raw variable node (if present)
            if raw_tok and raw_tok.upper() not in ("", "NAN", "NONE"):
                parts = raw_tok.upper().split(".")
                if len(parts) >= 2:
                    raw_ds, raw_var = parts[-2], parts[-1]
                else:
                    raw_ds, raw_var = domain, parts[0]

                if raw_var:
                    rv_nid = self.add_raw_var(raw_ds, raw_var)

                    # MAPS_TO edge (direct historical mapping)
                    self._add_edge_once(rv_nid, sv_nid, "MAPS_TO",
                                        weight=conf,
                                        score=conf,
                                        action=action,
                                        n_studies=n_stud,
                                        is_sponsor_std=is_spon)

                    # IN_GROUP edge
                    if group_sig:
                        self._add_edge_once(rv_nid, grp_nid, "IN_GROUP",
                                            weight=1.0, position=g_pos)

                    # Accumulate group tokens for CO_MAPPED_WITH
                    if group_sig:
                        co_map.setdefault(group_sig, [])
                        if rv_nid not in co_map[group_sig]:
                            co_map[group_sig].append(rv_nid)

        # Add CO_MAPPED_WITH edges for all variables in the same group
        for group_sig, raw_nodes in co_map.items():
            for ra, rb in itertools.combinations(raw_nodes, 2):
                self._add_edge_once(ra, rb, "CO_MAPPED_WITH", weight=0.6)
                self._add_edge_once(rb, ra, "CO_MAPPED_WITH", weight=0.6)

    def populate_from_mapping_results(self, results: dict) -> None:
        """
        Overlay mapping results (from mapper.run_mapping) onto the graph.
        Adds MAPS_TO edges with score and tier from a fresh mapping run.
        """
        import pandas as pd
        tier_weight = {"direct": 1.0, "review": 0.65,
                       "cross_dataset_match": 0.5, "unresolved": 0.0}

        for tier, df in results.items():
            if tier not in tier_weight or not isinstance(df, pd.DataFrame) or df.empty:
                continue
            w = tier_weight[tier]
            for _, row in df.iterrows():
                domain  = str(row.get("DOMAIN", "") or "").strip().upper()
                sdtm_v  = str(row.get("SDTM_VARIABLE", "") or "").strip().upper()
                raw_str = str(row.get("RAW_VARIABLES_ASSIGNED", "") or "").strip()
                score   = float(row.get("COMPOSITE_SCORE", 0) or 0)
                action  = str(row.get("MAPPING_ACTION", "") or "").strip()

                if not domain or not sdtm_v:
                    continue

                sv_nid = self.add_sdtm_var(domain, sdtm_v)

                for tok in raw_str.split(","):
                    tok = tok.strip()
                    if not tok:
                        continue
                    parts = tok.upper().replace("RAW.", "").split(".")
                    if len(parts) >= 2:
                        raw_ds, raw_var = parts[-2], parts[-1]
                    else:
                        raw_ds, raw_var = domain, parts[0]
                    if raw_var:
                        rv_nid = self.add_raw_var(raw_ds, raw_var)
                        self._add_edge_once(rv_nid, sv_nid, "MAPS_TO",
                                            weight=score * w,
                                            score=score,
                                            tier=tier,
                                            action=action)

    # ── Query methods ─────────────────────────────────────────────────────────

    def get_mapping_chain(self, raw_dataset: str, raw_variable: str) -> Dict[str, Any]:
        """Return full mapping lineage for a raw variable."""
        nid = f"RAW::{raw_dataset.upper()}.{raw_variable.upper()}"
        if not self.G.has_node(nid):
            return {"error": f"Raw variable {raw_dataset}.{raw_variable} not in graph"}

        sdtm_targets, groups, co_vars = [], [], []
        for u, v, d in self.G.edges(data=True):
            if u == nid:
                et = d.get("type", "")
                if et == "MAPS_TO":
                    nd = self.G.nodes.get(v, {})
                    sdtm_targets.append({
                        "node": v,
                        "domain": nd.get("domain", ""),
                        "variable": nd.get("variable", ""),
                        "score": d.get("score", 0),
                        "tier": d.get("tier", ""),
                        "action": d.get("action", ""),
                        "n_studies": d.get("n_studies", 0),
                    })
                elif et == "IN_GROUP":
                    groups.append(v)
                elif et == "CO_MAPPED_WITH":
                    nd = self.G.nodes.get(v, {})
                    co_vars.append(f"{nd.get('dataset','')}.{nd.get('variable','')}")

        sdtm_targets.sort(key=lambda x: x["score"], reverse=True)
        return {
            "raw_dataset": raw_dataset.upper(),
            "raw_variable": raw_variable.upper(),
            "sdtm_targets": sdtm_targets,
            "mapping_groups": groups,
            "co_mapped_vars": co_vars,
            "node_data": dict(self.G.nodes.get(nid, {})),
        }

    def get_sdtm_sources(self, domain: str, variable: str) -> Dict[str, Any]:
        """Return all raw variables that have ever mapped to this SDTM variable."""
        nid = f"SDTM::{domain.upper()}::{variable.upper()}"
        if not self.G.has_node(nid):
            return {"error": f"SDTM variable {domain}.{variable} not in graph"}

        sources = []
        for u, v, d in self.G.edges(data=True):
            if v == nid and d.get("type") == "MAPS_TO":
                nd = self.G.nodes.get(u, {})
                sources.append({
                    "node": u,
                    "dataset": nd.get("dataset", ""),
                    "variable": nd.get("variable", ""),
                    "score": d.get("score", 0),
                    "n_studies": d.get("n_studies", 0),
                    "is_sponsor_std": d.get("is_sponsor_std", False),
                })
        sources.sort(key=lambda x: (x["n_studies"], x["score"]), reverse=True)
        return {
            "domain": domain.upper(),
            "variable": variable.upper(),
            "raw_sources": sources,
            "source_count": len(sources),
            "node_data": dict(self.G.nodes.get(nid, {})),
        }

    def get_unmapped_sdtm_vars(self) -> List[Dict]:
        """Return SDTM variables with no incoming MAPS_TO edges."""
        result = []
        for nid, data in self.G.nodes(data=True):
            if data.get("kind") != "sdtm_var":
                continue
            has_mapping = any(
                d.get("type") == "MAPS_TO"
                for _, v, d in self.G.edges(nid, data=True)
                if False  # outgoing check
            )
            # Check incoming edges
            has_incoming = any(
                d.get("type") == "MAPS_TO"
                for u, v, d in self.G.in_edges(nid, data=True)
            )
            if not has_incoming:
                result.append({
                    "domain": data.get("domain", ""),
                    "variable": data.get("variable", ""),
                    "var_class": data.get("var_class", ""),
                    "core": data.get("core", ""),
                })
        return sorted(result, key=lambda x: (x["domain"], x["variable"]))

    def get_high_confidence_mappings(self, min_score: float = 0.82) -> List[Dict]:
        """Return all MAPS_TO edges above a confidence threshold."""
        result = []
        for u, v, d in self.G.edges(data=True):
            if d.get("type") == "MAPS_TO" and d.get("score", 0) >= min_score:
                un = self.G.nodes.get(u, {})
                vn = self.G.nodes.get(v, {})
                result.append({
                    "raw_dataset": un.get("dataset", ""),
                    "raw_var": un.get("variable", ""),
                    "sdtm_domain": vn.get("domain", ""),
                    "sdtm_var": vn.get("variable", ""),
                    "score": d.get("score", 0),
                    "action": d.get("action", ""),
                    "n_studies": d.get("n_studies", 0),
                })
        result.sort(key=lambda x: x["score"], reverse=True)
        return result

    def stats(self) -> Dict[str, Any]:
        nk, et = {}, {}
        for _, d in self.G.nodes(data=True):
            k = d.get("kind", "unknown")
            nk[k] = nk.get(k, 0) + 1
        for _, _, d in self.G.edges(data=True):
            t = d.get("type", "unknown")
            et[t] = et.get(t, 0) + 1
        return {
            "total_nodes": self.G.number_of_nodes(),
            "total_edges": self.G.number_of_edges(),
            "node_kinds": nk,
            "edge_types": et,
        }

    def to_json(self) -> Dict[str, Any]:
        nodes, links = [], []
        for nid, data in self.G.nodes(data=True):
            nodes.append({"id": nid, **data})
        for u, v, d in self.G.edges(data=True):
            links.append({"source": u, "target": v, **d})
        return {"nodes": nodes, "links": links}

    def get_subgraph_for_domain(self, domain: str) -> "SDTMKnowledgeGraph":
        """Return a sub-graph containing only nodes related to a SDTM domain."""
        domain = domain.upper()
        relevant: set[str] = {f"DOM::{domain}"}
        for nid, data in self.G.nodes(data=True):
            if data.get("domain", "") == domain:
                relevant.add(nid)
            if data.get("sdtm_domain", "") == domain:
                relevant.add(nid)
        sub = SDTMKnowledgeGraph()
        sub.G = self.G.subgraph(relevant).copy()
        return sub
