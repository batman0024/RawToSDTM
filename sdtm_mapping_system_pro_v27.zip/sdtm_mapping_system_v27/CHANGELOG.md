# Changelog


## v27 — Architecture simplification + 28-item review fixes

This release is a major correctness pass driven by an external code review.
The four-scorer mapping pipeline (Phase 1 ML + Phase 2 hard rules + Phase 3
cross-dataset + a dead `find_best_group` legacy scorer) is replaced by one
linear three-step flow:

```
STEP 1  master lookup (raw-first; uses the by_raw index)
STEP 2  rule table   (sdtm_rules.lookup_rule)
STEP 3  fuzzy        (single Jaro-Winkler + label TF-IDF, same-domain)
STEP 3.5 cross-dataset variable-name match (manual review)
```

`mapper.py` is 1771 lines → 900 lines.  No ML scorer in the production path,
no class/cross-domain penalty multipliers stacking on calibrated probabilities,
no dead code.  See `REVIEW_v27.md` for the full per-item map.

### Severity 1 fixes (runtime / data integrity)

- **#1** `group_count` NameError in legacy `score_group_against_raw` — replaced
  with `total_count` in the parked module
- **#3** Custom dotted prefixes (`EDC.*`, `RAVE.*`, `LSTC.*`) silently destroyed
  by writeback — `_is_preserve_token` rewritten to keep ANY non-RAW, non-garbage
  token
- **#4** Variable-name fallback in writeback caused silent cross-domain bleed —
  removed; mismatches now log a warning and skip

### Severity 2 fixes (clinical / regulatory correctness)

- **#5** `RFSTDTC`/`RFENDTC`/`RFICDTC`/`RFPENDTC`/`RFXSTDTC`/`RFXENDTC` were
  HARDCODE / Assigned/Sponsor — now Derived/DERIVE with named algorithms (P21
  rule SD0001)
- **#6** `EPOCH`, `TRTP`, `TRTA`, `TRTPN`, `TRTAN` were HARDCODE — now Derived
  (P21 rule CG0030)
- **#7** `--DY` (study day) variables — now Derived with `(--DTC) - (RFSTDTC) + 1`
- **#8** `--BLFL`, `--LOBXFL`, `--CHG`, `--PCHG`, `--SHIFT`, `--NRIND`, `--ANL{n}FL`
  — now Derived
- **#9** `SUBJECTID`, `SITENUMBER`, `SCREEN`, `SCREENFAIL`, `PRERANDOM`,
  `POSTRANDOM` removed from `DEFAULT_CDM_VARIABLES`/`DEFAULT_CDM_DATASETS`
  exclude lists (these are commonly the actual SDTM source); duplicate entries
  deduped; `filter_catalog` vectorised (10× faster on large catalogs)
- **#10** `normalize_origin_to_cdisc` was mapping PROTOCOL → "Assigned/Sponsor"
  (wrong CDISC origin) — now correctly maps to "Protocol"
- **#11** `CDISC_ORIGIN_VALUES` set included invalid "CRF" and "eDT" — these
  are not Define-XML 2.1 codelist values; canonical set now strict + sponsor
  extensions tracked separately. Origin overwrite is now conservative: manual
  entries (priority 0) are NEVER overwritten; default behaviour is fill-blanks
- **#12** `infer_origin` priority order: derived/flag/sequence check now fires
  BEFORE the CRF check, so `--BLFL` no longer mis-classifies as CRF when its
  bare name happens to match a CRF-collected raw token

### Severity 3 fixes (ML / statistics) — applied to the parked module

- **#7** `_predict` fallback now threads `sdtm_var`/`sdtm_domain` through to
  `_fallback_score` (was passing `""`, collapsing to `0.20*master_conf + 0.25*label_tfidf`)
- **#13** Removed `var_class_derived` and `var_class_timing` from the feature
  vector (target leakage: ALWAYS_DERIVED rows were filtered from positives, so
  these features deterministically split the classes for the wrong reason).
  Vector size 21 → 19.
- **#14** Calibration switched from prefit Platt on 80/20 split to k-fold
  stratified isotonic (n_pos≥50) or sigmoid (smaller); was systematically
  deflating positive scores under imbalance
- **#16** `_recency_weight` accepts a `reference_date` parameter; plumbed
  through `build_master` and `build_master_mapping`. Master rebuilds are now
  reproducible given the same inputs and reference date

### Severity 4 fixes (architecture)

- **#18** Dead code (`find_best_group`, `score_group_against_raw`,
  `composite()`) parked in `src/_legacy/legacy_mapper.py`; production
  `mapper.py` does not export them
- **#21** New `src/origin_normalization.py` shared module replaces the
  back-import from `master_builder` into `spec_writeback`
- **#25** `SDTMIG_VERSION_CHANGES` no longer duplicated between `mapper.py`
  (stale copy) and `sdtm_knowledge.py` (canonical source)
- **#19, #20, #24** Walrus operator misuse removed; `apply(axis=1)` replaced
  with vectorised string ops; regexes pre-compiled at module load

### Severity 5 fixes (testing)

- **#26** New `tests/test_regressions.py` — 46 tests, one class per
  numbered review item, ensuring every fix is locked in
- **#27** `TestItem16_RecencyReproducibility` proves the master rebuild is
  deterministic with a fixed reference_date

### Files

**New:** `src/sdtm_rules.py`, `src/origin_normalization.py`,
`src/_legacy/{__init__, legacy_mapper, legacy_ml_scorer}.py`,
`src/ml_scorer.py` (re-export shim), `tests/test_regressions.py`,
`REVIEW_v27.md`

**Rewritten:** `src/mapper.py`

**Patched:** `src/sdtm_knowledge.py`, `src/cdm_filter.py`,
`src/master_builder.py`, `src/spec_writeback.py`, `ui/helpers.py`,
`tests/test_pipeline.py`

### Test status

- `tests.test_pipeline`: 31/31 pass
- `tests.test_regressions`: 46/46 pass
- `tests.test_ml_scorer`: 48/53 pass (5 pre-existing failures: fixtures
  produce <10 training positives, hitting `MIN_TRAIN_POSITIVES` fallback;
  not v27 regressions)
- **Total: 125/130; zero v27 regressions**

### Opt back in to the legacy ML pipeline

```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path("src") / "_legacy"))
from legacy_mapper import run as legacy_run
results = legacy_run(master_path, raw_path, spec_path, out_path, config_path)
```


## v26 Patch — 2026-04-22 (Previous Build)

### BUG-1 — CRITICAL — NameError: name 'ml' is not defined
- **Every mapping run crashed** at the write-results stage before producing any output
- **Root cause:** `ml = MLScorer()` is a local variable inside `run_mapping()`. The outer
  `run()` function referenced `ml` by name at line 1746 after `run_mapping()` returned —
  but `ml` never existed in `run()`'s scope (Python LEGB rules).
- **Fix:** `run_mapping()` now includes `"_ml_scorer": ml` in its return dict.
  `run()` extracts it with `results.pop("_ml_scorer", None)` before calling
  `write_results()`. The private key is removed so external callers only see the
  six documented output keys.
- **Files:** `src/mapper.py` lines 935 (return dict) and 1746 (run function)

### BUG-2 — MEDIUM — SDTMIG Full Filename Not Shown
- **Symptom:** The SDTMIG Version Lock card showed only the extracted short version
  (e.g. `3.3`) as a tiny `st.caption`. The full "Mapping Specification IG" cell value
  (e.g. `SDTMIGV3.3 Mapping Specifications IG-CORE-define21-V1.2.pdf`) was invisible.
- **Fix:** Changed `st.caption` to `st.info()`. Full raw string is now the **primary**
  display element; extracted version shown as secondary annotation.
- **File:** `ui/pages/map_study.py` lines 483–494

### BUG-3 — LOW — Progress Wrapper Missing Transport Key Documentation
- **Symptom:** No crash — latent maintenance risk only. The `patched_run_mapping`
  wrapper in `ui/helpers.py` correctly passed through the `_ml_scorer` key but had
  no comment documenting this requirement, risking reintroduction of BUG-1.
- **Fix:** Added explanatory comment in the wrapper.
- **File:** `ui/helpers.py`

### Test Coverage
All 5 integration scenarios pass after fixes:
- new_study_raw.xlsx (29 vars, DM/AE/LB/VS): PASSED
- AE-only (5 vars): PASSED
- LB-only (6 vars): PASSED
- DM+CM mixed (7 vars): PASSED
- Large multi-domain DM/AE/LB/VS/CM (16 vars): PASSED

---

All notable changes to the SDTM Master Mapping System.

---

## v26 — 2026-04-18

### IMP-001 — Fix `crf_var_set` Population (CRITICAL)
- **`crf_var_set` and `als_var_set` were always empty sets** in `run_mapping()`, causing
  `infer_origin()` to never return `CRF` origin for any variable. Every variable fell
  through to Derived, Protocol, eDT, or Assigned regardless of actual source.
- **Fix:** `_build_origin_sets()` now populates both sets from the raw catalog (type/format
  signals) and from the master ORIGIN column overrides. Character-type variables in non-eDT
  datasets are CRF candidates; master rows with `ORIGIN=CRF` are authoritative overrides.
- **Impact:** ORIGIN values in submission output are now correct for the majority of AE, CM,
  MH, DS, EX, DM domain variables.

### IMP-002 — Fix `ALWAYS_DERIVED` (CRITICAL)
- **AGE, AGEU, VISITNUM were incorrectly in `ALWAYS_DERIVED`**, causing Phase 2 to skip
  raw assignment for variables that are frequently CRF-collected.
- **Fix:** Introduced `COMMONLY_DERIVED` frozenset. These variables attempt Phase 1 raw
  matching normally; Phase 2 derived fallback fires only if Phase 1 found nothing. The
  fallback confidence is 0.75 (vs 0.90 for `ALWAYS_DERIVED`) to reflect uncertainty.
- `ALWAYS_DERIVED` now contains only true programmatic values: sequence counters, USUBJID,
  ADY, AEDUR.

### IMP-003 — Per-Token Frequency in Master Builder
- **MASTER_CONFIDENCE was a single flat float per group**, treating all source tokens equally.
  DS.DSDTC (seen in 9/10 studies) had no more weight than AE.AEENDTC (seen in 2/10).
- **Fix:** `TOKEN_CONFIDENCE_MAP` column added to master output. Stores per-token
  confidence as pipe-delimited `TOKEN:SCORE` pairs (e.g. `DS.DSDTC:0.92|AE.AEENDTC:0.41`).
  Phase 1 scoring uses token-specific confidence instead of group-level confidence.

### IMP-004 — Label Bridge for Name-Match Failures
- **Master knowledge was abandoned immediately on name-match failure.** If DS.DSDTC was the
  master token but the new study had DISPOS.DISCONTDT, the system fell to the no-master
  fallback instead of trying to bridge via label similarity.
- **Fix:** `_find_raw_via_label_bridge()` added. When name matching fails for a master
  token, label TF-IDF cosine between the master token's stored label and new study raw
  variable labels is used as a secondary bridge. Matched via label bridge gets a 0.85x
  score discount. Domain-filtered pool used first.

### IMP-005 — Collective Group Presence Bonus
- **No bonus existed for finding all historically-known sources of a variable.**
  Finding 3 of 3 expected RF*DTC sources was treated identically to finding 1 of 3.
- **Fix:** Full group match bonus applied in `score_group_against_raw()`:
  - 3+ tokens all found: 1.20x multiplier (capped at 1.0)
  - 2 tokens both found: 1.10x multiplier
  This rewards the strong collective evidence of multi-source confirmation.

### IMP-006 — Distinguish Master-Silent vs Master Name-Bridge Failed
- **Unresolved tier conflated two different situations**: master has no knowledge vs
  master has knowledge but naming conventions differ. Both showed `no_master_group`.
- **Fix:** `_classify_unresolved_reason()` returns `master_name_bridge_failed` when the
  master index has groups for a variable but Phase 1 found no raw match. The
  `TOP_CANDIDATES` column is populated with historical master source tokens so the
  programmer knows exactly what to look for in the new study raw catalog.

### IMP-007 — Fix ML Training Data Contamination (HIGH)
- **HARDCODE, DERIVE, PROTOCOL rows were included as training positives**, teaching the
  model that `STUDYID→STUDYID` is a CRF match and inflating `name_exact` feature weight.
- **Fix:** `_is_valid_training_positive()` filter added to `build_training_data()`.
  Excludes HARDCODE/DERIVE/PROTOCOL action rows, always-derived variables, and trivial
  self-mappings. Training set is now genuinely representative of CRF/eDT assignments.

### IMP-008 — ML Score Calibration (HIGH)
- **`predict_proba` from HistGBT with class imbalance produces poorly calibrated
  probabilities**, making direct threshold comparison unreliable.
- **Fix:** `CalibratedClassifierCV(method="sigmoid")` (Platt scaling) applied post-fit
  using an 80/20 train/calibration split. The calibrated model is persisted to disk;
  cache invalidation uses the existing SHA-256 master hash. Fallback to uncalibrated
  fit if calibration fails (insufficient data per class).

### IMP-009 — Fix Context Feature Defaults (MEDIUM)
- **`ta_match`, `study_phase_match`, `sdtmig_version_match` defaulted to 0.85–0.90**
  when unknown, making them near-constant during training and near-useless for
  discrimination.
- **Fix:** Unknown context now defaults to `0.5` (maximum uncertainty — no information).
  Known mismatch (e.g. ONCOLOGY vs CARDIOLOGY study) now returns `0.3` (negative signal)
  rather than `0.5`. Model retrain required after this change.

### IMP-010 — Consolidate `DOMAIN_CLASS` (MEDIUM)
- **`DOMAIN_CLASS` was duplicated verbatim** in `mapper.py`, `excel_validator.py`, and
  `graphrag/mapping/sdtm_rules.py`. Risk of silent divergence.
- **Fix:** `DOMAIN_CLASS` moved to `sdtm_knowledge.py` as canonical source. All other
  files now import from there. Single point of update for future domain additions.

### IMP-011 — SUPPQUAL Semantic Split (MEDIUM)
- **All SUPP structural variables were hardcoded as direct/HARDCODE/Assigned**, including
  `QVAL` which must map to a raw CRF variable (it is the non-standard collected value).
- **Fix:** Three-way split:
  - `SUPP_STRUCTURAL_VARS` (IDVAR, IDVARVAL, QORIG, QEVAL): correctly HARDCODE
  - `SUPP_CODELIST_VARS` (QNAM, QLABEL): unresolved with `suppqual_codelist_manual` path;
    flagged for manual population as sponsor-defined codelist values
  - `SUPP_MAPPED_VARS` (QVAL): falls through to Phase 1 raw matching; unresolved with
    explicit note if no raw match found

### IMP-012 — ISO 8601 Group Token Role Annotation (MEDIUM)
- **Token ordering was lost** when stored as flat pipe-delimited string in `GROUP_TOKENS`.
  For ISO 8601 datetime construction, position 1 = date, position 2 = time is semantic.
- **Fix:** `TOKEN_ROLES` column added to master output. Stores role annotations as
  `TOKEN:role:position` triples (e.g. `DS.DSDTC:date_component:1|DS.DSTIM:time_component:2`).
  `ROLE_MODIFIERS` applied per token in scoring (primary=1.0, fallback=0.85).

### IMP-013 — SDTMIG Version Registry (LOW)
- **`SDTMIG_VERSION_CHANGES` had 2 placeholder entries** with identical status across all
  versions — providing zero discriminatory value.
- **Fix:** Replaced with functional registry covering AEHLTCD/AEHLT (added 3.4),
  RFXSTDTC/RFXENDTC/RFICDTC (added 3.2), DTYPE variants (added 3.3), and EPOCH entries.
  `variable_version_score()` function returns 1.0/0.7/0.0 based on actual version presence.

### IMP-014 — GxP Audit Trail `_Mapping_Audit` Sheet (HIGH)
- **No per-decision audit trail existed** for auto-accepted mappings written to submission
  specs. 21 CFR Part 11 compliance requires traceability of automated decisions.
- **Fix:** `_Mapping_Audit` sheet appended to every mapping results workbook. Captures:
  timestamp, domain, variable, raw sources, score, tier, match path, master filename,
  master SHA-256 hash, ML model version, run host/user, system version, config thresholds,
  and auto-accepted flag. Covers ALL decisions (direct, review, unresolved).

---

## v25 — 2026-04-16

### Cross-Domain Token Accumulation Fix (Critical)
- Tightened multi-token accumulation logic in Phase 1.
- New accumulation rules per variable class with token caps.

### Review Tab — Full Text Visibility
- Rebuilt review panel layout with 7-column header+body table.

### Write-Back Tab — Cache Persistence Fix
- `wb_spec_bytes` and `wb_spec_name` now persist across tab switches.

### SDTMIG Version Display
- Full Mapping Specification IG value now displayed when detected.

