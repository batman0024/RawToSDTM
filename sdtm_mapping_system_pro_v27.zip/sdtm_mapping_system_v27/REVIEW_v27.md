# SDTM Mapping System v27 — Review & Fix Log

This document maps every numbered item in the v26 code review to the v27
fix location and its regression test.  Each row says: where the bug was,
what file fixed it, and which test will catch it if it ever comes back.

The architecture changed in v27.  The four-scorer v25/v26 pipeline (Phase 1
ML + Phase 2 hard rules + Phase 3 cross-dataset + the dead `find_best_group`
legacy scorer) is replaced by one linear three-step flow:

```
STEP 1  master lookup (raw-first; uses the by_raw index)
STEP 2  rule table   (sdtm_rules.lookup_rule)
STEP 3  fuzzy        (single Jaro-Winkler + label TF-IDF, same-domain)
STEP 3.5 cross-dataset variable-name match (manual review)
```

The ML scorer is parked at `src/_legacy/legacy_ml_scorer.py` and the old
mapper at `src/_legacy/legacy_mapper.py`.  Both retain their public APIs
through re-export shims so opt-in callers and existing tests keep working.

---

## Severity 1 — runtime / data-integrity bugs

| # | Title | Fix location | Test |
|---|---|---|---|
| 1 | `group_count` NameError in legacy `score_group_against_raw` | `src/_legacy/legacy_mapper.py` lines ~556–569 — replaced undefined `group_count` with `total_count` | `TestItem01_GroupCountNameError` |
| 2 | (n/a — same bug as #1) | | |
| 3 | Custom dotted prefixes (EDC.\*, RAVE.\*, LSTC.\*) silently destroyed by writeback | `src/spec_writeback.py` `_is_preserve_token` rewritten to keep ANY non-RAW, non-garbage token | `TestItem03_PreserveCustomTokens` |
| 4 | Variable-name fallback in writeback caused silent cross-domain bleed | `src/spec_writeback.py` removed the `next((k for k in mapping if k[1]==var))` fallback; mismatches now log a warning and skip | `TestItem04_StrictDomainVarMatch` |

## Severity 2 — clinical / regulatory correctness

| # | Title | Fix location | Test |
|---|---|---|---|
| 5 | `RFSTDTC` etc. assigned origin = "Assigned/Sponsor", action HARDCODE | `src/sdtm_rules.py` EXACT_RULES — all six `RF*DTC` variables map to Derived/DERIVE with named algorithms | `TestItem05_RFSTDTCisDerived` |
| 6 | `EPOCH` treated as PROTOCOL → HARDCODE | `src/sdtm_rules.py` VARIABLE_RULES — EPOCH, TRTP, TRTA, TRTPN, TRTAN all Derived | `TestItem06_EPOCHisDerived` |
| 7 | `--DY` (study day) not recognised as derived | `src/sdtm_rules.py` PATTERN_RULES — `^.+DY$` → Derived with `(--DTC) - (RFSTDTC) + 1` algorithm | `TestItem07_StudyDayIsDerived` |
| 8 | `--BLFL`, `--LOBXFL`, `--CHG`, `--PCHG`, `--SHIFT`, `--NRIND` not flagged as derived | `src/sdtm_rules.py` PATTERN_RULES | `TestItem08_BaselineFlagsAreDerived` |
| 9 | CDM filter excluded `SUBJECTID`, `SITENUMBER`, `SCREEN`, `SCREENFAIL`, etc. | `src/cdm_filter.py` removed from defaults; deduped duplicate entries; vectorised `filter_catalog` | `TestItem09_CdmFilterDefaults` |
| 10 | `normalize_origin_to_cdisc` mapped PROTOCOL → "Assigned/Sponsor" | `src/origin_normalization.py` — new shared module; signature has `("PROTOCOL", ["protocol"], "Protocol")` | `TestItem10_ProtocolOrigin` |
| 11 | `CDISC_ORIGIN_VALUES` included invalid "CRF" and "eDT" Define-XML 2.1 values | `src/origin_normalization.py` — `CDISC_CANONICAL_ORIGINS` is the strict CT codelist; sponsor extensions in `CDISC_SPONSOR_EXTENSIONS` | `TestItem11_CdiscOriginValues` |
| 12 | `infer_origin` priority — derived check happened after CRF | `src/sdtm_knowledge.py` `infer_origin` — derived/flag/sequence priority moved to position 1 | `TestItem12_InferOriginPriority` |

Bonus: review item 11 also covers conservative origin overwrite — manual
entries (priority 0) are never overwritten. See
`TestItem11_ConservativeOriginOverwrite`.

## Severity 3 — ML / statistical issues

| # | Title | Fix location | Test |
|---|---|---|---|
| 13 | Target leakage on `var_class_derived` / `var_class_timing` features | `src/_legacy/legacy_ml_scorer.py` — both features removed from FEATURE_NAMES and feature_vector array; vector size 21 → 19 | `TestItem13_FeatureLeakageFix` |
| 14 | Platt calibration on 80/20 split with prefit was systematically deflating positive scores | `src/_legacy/legacy_ml_scorer.py` — switched to k-fold stratified, isotonic for n_pos>=50 else sigmoid | (smoke-tested in `TestItem13`) |
| 15 | Negative sampling missed cross-domain similar-name confusions | not changed in v27 (now mostly moot — production path no longer ranks by ML) | — |
| 16 | Recency weight used wall-clock time → master non-reproducible | `src/master_builder.py` — `_recency_weight`, `build_master`, `build_master_mapping` all accept `reference_date` parameter | `TestItem16_RecencyReproducibility` |
| 17 | Composite score calls `class_mod` and cross-domain multiplier on calibrated probability | resolved by architecture: production mapper uses a heuristic composite (`pair_score`); audit column documents the decision path explicitly via `MATCH_PATH` | `TestPipelineEndToEnd::test_match_path_records_decision` |

## Severity 4 — code-quality & architecture

| # | Title | Fix location | Test |
|---|---|---|---|
| 18 | Dead code: `find_best_group`, `score_group_against_raw`, `composite()` | parked in `src/_legacy/legacy_mapper.py`; production `mapper.py` does not export them | `TestItem18_DeadCodeRemoved` |
| 19 | Walrus operator misuse | resolved by full mapper rewrite; new `mapper.py` has no walrus | `TestItem19_NoWalrusInCriticalPath` |
| 20 | `pandas.apply(axis=1)` on hot paths | `src/cdm_filter.py` `filter_catalog` vectorised (mask via `.isin` + `.str.endswith` + `.str.contains`) | `TestItem09_CdmFilterDefaults::test_filter_catalog_is_vectorised` |
| 21 | `read_origin_values_from_spec` back-imported from master_builder | new `src/origin_normalization.py` shared by master_builder and spec_writeback | `TestItem21_OriginModuleIsShared` |
| 22 | `pd.read_excel` opens whole workbook on hot path | not addressed in this iteration (acceptable on typical spec sizes; flagged for future work) | — |
| 23 | `enumerate(iterrows())` redundant tuple unpack | tidied during mapper rewrite; new mapper uses `enumerate(... .iterrows())` consistently | — |
| 24 | `re.compile` per call | `src/sdtm_rules.py` uses module-level `_COMPILED_PATTERNS`; mapper.py uses `_TOKEN_SPLIT_RE` and `_WB_LOG_PATTERN` at module scope | — |
| 25 | `SDTMIG_VERSION_CHANGES` defined twice (mapper.py copy was stale) | mapper.py copy removed; sdtm_knowledge.py is canonical | `TestItem25_NoDuplicatedConstants` |

## Severity 5 — testing & reproducibility

| # | Title | Fix location | Test |
|---|---|---|---|
| 26 | No regression tests for v25/v26 fixes | `tests/test_regressions.py` — 46 tests, one class per review item | the file itself |
| 27 | No determinism test on master rebuild | `TestItem16_RecencyReproducibility::test_same_reference_date_gives_same_confidence` | covered |
| 28 | ML training data not version-pinned beyond SHA256 | not changed (production path is rule-based; ML path retains SHA256 cache key) | — |

---

## Files changed

**New:**
- `src/sdtm_rules.py` — canonical SDTM rule table (EXACT_RULES + VARIABLE_RULES + PATTERN_RULES, regex precompiled)
- `src/origin_normalization.py` — shared Define-XML 2.1 origin helpers, replaces back-import from master_builder
- `src/_legacy/__init__.py`, `src/_legacy/legacy_mapper.py`, `src/_legacy/legacy_ml_scorer.py` — parked old code with bug fixes applied
- `src/ml_scorer.py` — thin re-export shim of the parked module
- `tests/test_regressions.py` — 46-test regression suite

**Rewritten:**
- `src/mapper.py` — 1771 lines → 900 lines, three explicit steps, no ML, no penalty multipliers, no dead code

**Patched in place:**
- `src/sdtm_knowledge.py` — `infer_origin` priority order
- `src/cdm_filter.py` — defaults trimmed, deduped, `filter_catalog` vectorised
- `src/master_builder.py` — `reference_date` plumbed through; replaced own origin code with re-export
- `src/spec_writeback.py` — token preservation, strict domain-match, conservative origin overwrite
- `ui/helpers.py` — progress hook attaches to `pair_score` (the new pipeline's per-pair function)
- `tests/test_pipeline.py` — `test_changelog_sheet_appended` updated to v25+ separate-workbook contract

## Test-suite status

```
tests.test_pipeline    : 31 / 31 pass
tests.test_regressions : 46 / 46 pass
tests.test_ml_scorer   : 48 / 53 pass  (5 pre-existing, fixture has <10 positives)
                       --------------
Total                  : 125 / 130 pass; 0 v27 regressions
```

The 5 ml_scorer failures are not v27 regressions: they happen because the
fixture builds a master with only 5 non-trivial training positives (most
rows are `XXX → XXX` self-mappings, which `_is_valid_training_positive`
correctly excludes), and `MIN_TRAIN_POSITIVES = 10` triggers fallback
mode.  These tests were already failing in v26 (same root cause) and one
of them — `test_score_batch_matches_individual_scores` — actually started
passing in v27 because we fixed the broken `_predict` fallback path
(review item 7).

## How to opt back into the legacy ML pipeline

If a future study needs to A/B test the parked ML scorer:

```python
# In your run script:
import sys
from pathlib import Path
sys.path.insert(0, str(Path('src') / '_legacy'))
from legacy_mapper import run as legacy_run

results = legacy_run(master_path, raw_path, spec_path, out_path, config_path)
```

The legacy mapper retains its `_ml_scorer` key in the result dict, the
audit sheet contract, and all the bug fixes applied during this review.
The only thing that's parked is the architecture, not the code quality.
