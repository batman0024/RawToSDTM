"""
ml_scorer.py  (v27 shim)
========================
The full ML scorer has been parked at src/_legacy/ml_scorer.py because the
default mapping pipeline no longer depends on it.  See REVIEW_v27.md and
the simplified mapper.py for the rationale (review items 13-17 and the
overall architecture critique).

This shim re-exports the parked implementation so that:

  * Tests in tests/test_ml_scorer.py keep passing.
  * The legacy `find_best_group` + `score_group_against_raw` paths in the
    legacy mapper retain backwards compatibility.
  * Anyone wanting to A/B test the new rule-based pipeline against the
    old ML pipeline can do so by setting `matching.use_ml_scorer: true`
    in config.yaml and re-importing.

For the main production path, mapper.py uses build_feature_vector and
jaro_winkler directly from this shim (the underlying primitives are sound
and worth keeping).  It does NOT instantiate MLScorer.

Bug fixes applied to the legacy module (still relevant if the model is
re-enabled):
  * #6  Calibration switched from prefit Platt to k-fold stratified
        isotonic/sigmoid (auto by n_pos).
  * #7  _predict fallback now threads sdtm_var/sdtm_domain so name
        similarity contributes when the model is in fallback mode.
  * #13 var_class_derived/var_class_timing features removed (target leakage).
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path

# Make the parked module importable
_LEGACY_DIR = _Path(__file__).parent / "_legacy"
if str(_LEGACY_DIR) not in _sys.path:
    _sys.path.insert(0, str(_LEGACY_DIR))

# Re-export the public API of the parked implementation.
# The "noqa" markers tell linters this is intentional re-export.
from legacy_ml_scorer import (  # type: ignore  # noqa: F401
    MLScorer,
    jaro_winkler,
    char_ngram_sim,
    prefix_match,
    token_set_overlap,
    build_feature_vector,
    build_training_data,
    FEATURE_NAMES,
    _N_FEATURES,
    save_model,
    load_model,
    _master_sha256,
    _model_cache_paths,
    _is_valid_training_positive,
    TRAINING_EXCLUDE_ACTIONS,
)
