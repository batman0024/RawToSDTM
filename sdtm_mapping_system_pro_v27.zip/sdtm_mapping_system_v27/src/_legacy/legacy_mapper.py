"""
mapper.py
=========
Map a new study raw variable catalog to SDTM variables using
the master mapping knowledge base.

Key improvements over previous version:
  - Group-aware index: build_index() stores GROUP_TOKENS so the mapper
    retrieves all tokens of the best group, not individual tokens
  - Partial-group scoring: if group has N tokens and only K are found
    in the raw catalog, confidence is penalised proportionally
  - SUPPQUAL handling: QNAM/QLABEL variables get special triplet logic
  - Coverage breakdown includes var-class split (CRF vs Derived vs Protocol)
  - All strings are plain ASCII; no Unicode

4-signal composite scorer:
  1. name_exact   exact slug match between SDTM var and raw var
  2. name_fuzzy   best of seq_ratio / token_sort / token_set similarity
  3. label_tfidf  TF-IDF cosine on lowercased variable labels
  4. master_freq  MASTER_CONFIDENCE from master_mapping

Three-tier output:
  direct      score >= auto_accept  -> written to spec immediately
  review      score >= review       -> amber-flagged for human check
  unresolved  score < review        -> top-5 candidates listed only

Usage:
    python mapper.py \\
        --master master_mapping.xlsx \\
        --raw    new_study_raw.xlsx \\
        --spec   new_study_spec.xlsx \\
        --out    mapping_results.xlsx \\
        --config config.yaml
"""

from __future__ import annotations

import re
import sys
import math
import warnings
import datetime as dt
import argparse
from pathlib import Path
from difflib import SequenceMatcher
from typing import Optional

import numpy as np
import pandas as pd
import yaml
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from ml_scorer import MLScorer, jaro_winkler, char_ngram_sim
from utils import _norm, _slug
from sdtm_knowledge import (
    classify_variable,
    expand_sdtm_label,
    infer_origin,
    is_date_variable,
    PROTOCOL_VARS,
    ALWAYS_DERIVED,
    COMMONLY_DERIVED,
    RF_TIMING_VARS,
    DOMAIN_CLASS,
    SUPP_STRUCTURAL_VARS,
    SUPP_CODELIST_VARS,
    SUPP_MAPPED_VARS,
    CRF_DATASET_PREFIXES,
    EDT_PREFIXES,
)
from logger import get_logger

# IMP-010: DOMAIN_CLASS imported from sdtm_knowledge (canonical single source)

# SDTMIG version change-detection: variables that changed Core status between versions
# Format: (variable, domain) -> {version: core_status}
SDTMIG_VERSION_CHANGES: dict[tuple, dict] = {
    ("EPOCH",  "AE"): {"3.2": "O", "3.3": "O", "3.4": "O"},
    ("AESLIFE","AE"): {"3.2": "O", "3.3": "O", "3.4": "O"},
}


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

def _token_set(s):
    return set(re.split(r"[^A-Z0-9]+", _slug(s))) - {""}


def seq_ratio(a, b):
    a, b = _slug(a), _slug(b)
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def token_sort(a, b):
    def ts(s):
        return " ".join(sorted(_token_set(s)))
    return SequenceMatcher(None, ts(a), ts(b)).ratio()


def token_set_sim(a, b):
    sa, sb = _token_set(a), _token_set(b)
    if not sa or not sb:
        return 0.0
    inter = " ".join(sorted(sa & sb))
    ra    = " ".join(sorted(sa - sb))
    rb    = " ".join(sorted(sb - sa))
    t1    = (inter + " " + ra).strip()
    t2    = (inter + " " + rb).strip()
    return max(
        SequenceMatcher(None, inter, t1).ratio(),
        SequenceMatcher(None, inter, t2).ratio(),
        SequenceMatcher(None, t1, t2).ratio(),
    )


def name_sim(a, b):
    return max(seq_ratio(a, b), token_sort(a, b), token_set_sim(a, b))


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def load_cfg(p):
    # If the given path does not exist, try resolving relative to this module
    p = Path(p)
    if not p.exists():
        module_dir = Path(__file__).parent
        candidate  = module_dir / p.name
        if candidate.exists():
            p = candidate
    with open(p) as f:
        return yaml.safe_load(f)


def get_thresholds(cfg, domain):
    m    = cfg.get("matching", {})
    th   = m.get("thresholds", {})
    auto = th.get("auto_accept", 0.82)
    rev  = th.get("review", 0.55)
    ov   = m.get("domain_overrides", {}).get(domain.upper(), {})
    return ov.get("auto_accept", auto), ov.get("review", rev)


def get_weights(cfg):
    dfl = {"name_exact": 0.35, "name_fuzzy": 0.20, "label_tfidf": 0.25, "master_freq": 0.20}
    w   = cfg.get("matching", {}).get("weights", dfl)
    tot = sum(w.values())
    return {k: v / tot for k, v in w.items()} if tot else dfl


def class_mod(cfg, vc):
    return cfg.get("matching", {}).get("class_modifiers", {}).get(vc, 1.0)


def partial_group_penalty(cfg):
    return cfg.get("matching", {}).get("partial_group_penalty", 0.70)


# ---------------------------------------------------------------------------
# Raw catalog reader
# ---------------------------------------------------------------------------

def read_sas_files(sas_paths, log):
    """
    Read one or more SAS datasets (.xpt or .sas7bdat) directly.
    Extracts variable names, labels, formats, and types.
    Each file becomes one RAW_DATASET entry (named from the file stem).
    Returns a catalog DataFrame in the same format as read_raw_catalog().
    """
    rows = []
    for p in sas_paths:
        p = Path(p)
        dataset_name = p.stem.upper()
        ext = p.suffix.lower()
        try:
            if ext == ".xpt":
                df_sas = pd.read_sas(str(p), format="xport", encoding="latin-1")
            elif ext in (".sas7bdat", ".sas"):
                df_sas = pd.read_sas(str(p), format="sas7bdat", encoding="latin-1")
            else:
                log.warning("Unsupported SAS file type: %s", p.name)
                continue

            # Extract metadata from column attributes
            for col in df_sas.columns:
                label  = getattr(df_sas[col], "label",  "") or ""
                fmt    = getattr(df_sas[col], "format", "") or ""
                dtype  = str(df_sas[col].dtype)
                var_type = "Num" if "float" in dtype or "int" in dtype else "Char"
                rows.append({
                    "RAW_DATASET": dataset_name,
                    "VARIABLE":    col.upper(),
                    "LABEL":       str(label).strip(),
                    "FORMAT":      str(fmt).strip(),
                    "TYPE":        var_type,
                })
            log.info("  SAS file %s: %d variables", p.name, len(df_sas.columns))
        except Exception as exc:
            log.error("  Cannot read SAS file %s: %s", p.name, exc)

    if not rows:
        return pd.DataFrame(columns=["RAW_DATASET","VARIABLE","LABEL","FORMAT","TYPE","RAW_KEY","VAR_SLUG"])

    out = pd.DataFrame(rows)
    out["VARIABLE"]  = out["VARIABLE"].apply(_norm)
    out["RAW_KEY"]   = out["RAW_DATASET"] + "." + out["VARIABLE"]
    out["VAR_SLUG"]  = out["VARIABLE"].apply(_slug)
    out = out[out["VARIABLE"] != ""].drop_duplicates("RAW_KEY").reset_index(drop=True)
    return out


def read_raw_catalog(raw_path, cfg, log):
    """
    Read the new study raw variable catalog.
    Accepts: CSV, Excel (PROC CONTENTS output or variable registry),
             or SAS XPT / SAS7BDAT files directly.
    Returns DataFrame with: RAW_DATASET, VARIABLE, LABEL, FORMAT, TYPE
    """
    aliases = cfg.get("raw_catalog", {}).get("column_aliases", {})
    ext = raw_path.suffix.lower()

    # Route SAS files to dedicated reader
    if ext in (".xpt", ".sas7bdat", ".sas"):
        out = read_sas_files([raw_path], log)
        if not out.empty:
            log.info(
                "  Raw catalog (SAS): %d variables in %d datasets",
                len(out), out["RAW_DATASET"].nunique(),
            )
        return out

    def rc(df, key):
        lc = {c.lower(): c for c in df.columns}
        for a in aliases.get(key, [key]):
            if a.lower() in lc:
                return lc[a.lower()]
        for a in aliases.get(key, [key]):
            for col_l, col_o in lc.items():
                if a.lower() in col_l:
                    return col_o
        return None

    if ext == ".csv":
        df = pd.read_csv(raw_path, dtype=object)
    else:
        xl    = pd.ExcelFile(raw_path, engine="openpyxl")
        sheet = xl.sheet_names[0]
        for sn in xl.sheet_names:
            if any(k in sn.lower() for k in ["var", "col", "catalog", "field", "contents", "proc"]):
                sheet = sn
                break
        df = xl.parse(sheet, dtype=object)

    var_col = rc(df, "variable")
    if var_col is None:
        raise ValueError(
            "Cannot find variable column in %s. Expected: %s"
            % (raw_path.name, aliases.get("variable", ["NAME"]))
        )

    ds_col  = rc(df, "dataset")
    lbl_col = rc(df, "label")
    fmt_col = rc(df, "format")
    typ_col = rc(df, "type")

    out = pd.DataFrame()
    out["VARIABLE"]    = df[var_col].apply(_norm)
    out["RAW_DATASET"] = df[ds_col].apply(_norm)  if ds_col  else "UNKNOWN"
    out["LABEL"]       = df[lbl_col].apply(_norm) if lbl_col else ""
    out["FORMAT"]      = df[fmt_col].apply(_norm) if fmt_col else ""
    out["TYPE"]        = df[typ_col].apply(_norm) if typ_col else ""
    out["RAW_KEY"]     = out["RAW_DATASET"] + "." + out["VARIABLE"]
    out["VAR_SLUG"]    = out["VARIABLE"].apply(_slug)
    out = (
        out[out["VARIABLE"] != ""]
        .drop_duplicates("RAW_KEY")
        .reset_index(drop=True)
    )

    log.info(
        "  Raw catalog: %d variables in %d datasets",
        len(out), out["RAW_DATASET"].nunique(),
    )
    return out


# ---------------------------------------------------------------------------
# TF-IDF label index
# ---------------------------------------------------------------------------

class LabelIndex:
    """
    TF-IDF cosine similarity over raw variable labels.
    Operates on lowercased labels so that the standard word tokenizer works.
    Gracefully disabled when fewer than 3 labeled variables are present.
    """

    def __init__(self, raw_df):
        self._ok = False
        labeled  = raw_df[raw_df["LABEL"].str.strip() != ""].copy()
        if len(labeled) < 3:
            return
        self._keys = labeled["RAW_KEY"].tolist()
        corpus     = labeled["LABEL"].str.lower().tolist()
        try:
            self._vec    = TfidfVectorizer(
                analyzer="word",
                ngram_range=(1, 2),
                min_df=1,
                sublinear_tf=True,
            )
            self._matrix = self._vec.fit_transform(corpus)
            self._ok     = True
        except Exception:
            pass

    @property
    def is_enabled(self) -> bool:
        """Public accessor for whether the TF-IDF index is operational."""
        return self._ok

    def scores(self, query, keys):
        """Return {raw_key: cosine_score} for the requested keys."""
        if not self._ok or not (query or "").strip():
            return {k: 0.0 for k in keys}
        try:
            q_vec  = self._vec.transform([query.lower()])
            ki     = {k: i for i, k in enumerate(self._keys)}
            result = {}
            for k in keys:
                if k in ki:
                    result[k] = float(
                        cosine_similarity(q_vec, self._matrix[ki[k]])[0][0]
                    )
                else:
                    result[k] = 0.0
            return result
        except Exception:
            return {k: 0.0 for k in keys}


# ---------------------------------------------------------------------------
# Composite scorer
# ---------------------------------------------------------------------------

def composite(sdtm_var, sdtm_label_exp, raw_key, raw_var,
              master_conf, label_sim, weights, modifier):
    """
    Compute composite match score (0-1) for one (SDTM_VAR, RAW_KEY) pair.
    Returns (score, xai_breakdown_dict).
    """
    raw_bare  = raw_key.split(".")[-1] if "." in raw_key else raw_key
    exact     = 1.0 if _slug(sdtm_var) == _slug(raw_bare) else 0.0
    fuzzy     = name_sim(sdtm_var, raw_bare)
    raw_score = (
        weights["name_exact"]  * exact
        + weights["name_fuzzy"]  * fuzzy
        + weights["label_tfidf"] * label_sim
        + weights["master_freq"] * master_conf
    )
    score = min(raw_score * modifier, 1.0)
    xai = {
        "name_exact":   round(exact, 3),
        "name_fuzzy":   round(fuzzy, 3),
        "label_tfidf":  round(label_sim, 3),
        "master_freq":  round(master_conf, 3),
        "modifier":     round(modifier, 3),
        "composite":    round(score, 4),
        "w_name_exact":  round(weights["name_exact"]  * exact * modifier, 4),
        "w_name_fuzzy":  round(weights["name_fuzzy"]  * fuzzy * modifier, 4),
        "w_label_tfidf": round(weights["label_tfidf"] * label_sim * modifier, 4),
        "w_master_freq": round(weights["master_freq"] * master_conf * modifier, 4),
    }
    return score, xai


# ---------------------------------------------------------------------------
# Group-aware master index
# ---------------------------------------------------------------------------

def build_index(master_df):
    """
    Build lookup structures from master_mapping for fast candidate retrieval.

    Structures:
        by_sdtm:  {(DOMAIN, SDTM_VARIABLE): list of group dicts}
                  Each group dict contains GROUP_SIG, GROUP_TOKENS,
                  GROUP_COUNT, MASTER_CONFIDENCE etc.
                  One entry per unique GROUP_SIG (not per raw token row).
        by_raw:   {bare_var_slug: [(DOMAIN, SDTM_VAR, confidence, group_dict)]}
    """
    by_sdtm  = {}
    by_raw   = {}
    seen_groups = set()  # (DOMAIN, SDTM_VARIABLE, GROUP_SIG) already added

    for _, r in master_df.iterrows():
        domain   = str(r.get("DOMAIN",         "")).strip()
        var      = str(r.get("SDTM_VARIABLE",  "")).strip()
        group_sig= str(r.get("GROUP_SIG",       "")).strip()
        conf     = float(r.get("MASTER_CONFIDENCE", 0.0))

        group_key = (domain, var, group_sig)
        if group_key not in seen_groups:
            seen_groups.add(group_key)
            entry = {
                "DOMAIN":            domain,
                "SDTM_VARIABLE":     var,
                "SDTM_LABEL":        str(r.get("SDTM_LABEL",        "") or ""),
                "GROUP_SIG":         group_sig,
                "GROUP_TOKENS":      str(r.get("GROUP_TOKENS",       "") or ""),
                "GROUP_COUNT":       int(r.get("GROUP_COUNT",  0)   or 0),
                "MAPPING_ACTION":    str(r.get("MAPPING_ACTION",     "") or ""),
                "MASTER_CONFIDENCE": conf,
                "IS_SPONSOR_STD":    bool(r.get("IS_SPONSOR_STD", False)),
                "SOURCE_FILES":      str(r.get("SOURCE_FILES",       "") or ""),
            }
            by_sdtm.setdefault((domain, var), []).append(entry)

            # Index each token in the group for reverse lookup
            for tok in (entry["GROUP_TOKENS"] or "").split("|"):
                if not tok:
                    continue
                bare_slug = _slug(tok.split(".")[-1])
                # Skip blank slugs (NaN tokens, empty input vars)
                if not bare_slug or bare_slug == "NAN":
                    continue
                by_raw.setdefault(bare_slug, []).append(
                    (domain, var, conf, entry)
                )

    # Build 4-char suffix index for O(1) partial-slug fallback in Phase 1
    by_raw_suffix4: dict[str, list] = {}
    for sl, entries in by_raw.items():
        if len(sl) >= 4:
            bucket = by_raw_suffix4.setdefault(sl[-4:], [])
            for entry in entries:
                if id(entry) not in {id(e) for e in bucket}:
                    bucket.append(entry)

    return {"by_sdtm": by_sdtm, "by_raw": by_raw, "by_raw_suffix4": by_raw_suffix4}


# ---------------------------------------------------------------------------
# Partial-group scorer
# ---------------------------------------------------------------------------

def score_group_against_raw(group_entry, raw_df, sdtm_var, sdtm_label_exp,
                             label_idx, weights, modifier, penalty):
    """
    Score a master group against the new study raw catalog.

    For each token in the group, find its best match in raw_df.
    Partial group present (some tokens found, some not) applies
    the partial_group_penalty multiplier.

    Returns:
        best_score       float
        resolved_tokens  list of (raw_dataset, raw_variable) in group order
        found_fraction   float (tokens_found / group_count)
        label_sims_avg   float
    """
    group_tokens = [t for t in (group_entry["GROUP_TOKENS"] or "").split("|") if t]
    if not group_tokens:
        return 0.0, [], 0.0, 0.0

    resolved   = []
    token_scores = []

    for tok in group_tokens:
        bare_var  = tok.split(".")[-1] if "." in tok else tok
        hint_ds   = tok.split(".")[-2] if tok.count(".") >= 1 else ""
        bare_slug = _slug(bare_var)

        # Exact slug match in raw catalog
        hits = raw_df[raw_df["VAR_SLUG"] == bare_slug]

        if hits.empty:
            # Fuzzy fallback: best name similarity in domain-filtered pool
            ds_pool = raw_df[
                raw_df["RAW_DATASET"].apply(
                    lambda d: (
                        _slug(hint_ds)[:2] == _slug(d)[:2]
                        if hint_ds else False
                    )
                )
            ] if hint_ds else pd.DataFrame()

            if ds_pool.empty:
                ds_pool = raw_df

            best_sim = 0.0
            best_row = None
            for _, rr in ds_pool.iterrows():
                sim = name_sim(bare_var, rr["VARIABLE"])
                if sim > best_sim:
                    best_sim, best_row = sim, rr

            if best_row is not None and best_sim >= 0.60:
                rk = best_row["RAW_KEY"]
                ls = label_idx.scores(sdtm_label_exp, [rk]).get(rk, 0.0)
                sc, _xai = composite(
                    sdtm_var, sdtm_label_exp, rk, best_row["VARIABLE"],
                    group_entry["MASTER_CONFIDENCE"], ls, weights, modifier,
                )
                resolved.append((best_row["RAW_DATASET"], best_row["VARIABLE"], sc))
                token_scores.append(sc)
            else:
                resolved.append(("", "", 0.0))
                token_scores.append(0.0)
        else:
            # Prefer dataset matching the domain hint
            if hint_ds:
                hint_hits = hits[
                    hits["RAW_DATASET"].apply(
                        lambda d: _slug(hint_ds)[:2] == _slug(d)[:2]
                    )
                ]
                if not hint_hits.empty:
                    hits = hint_hits

            batch_keys = hits["RAW_KEY"].tolist()
            lbl_sims   = label_idx.scores(sdtm_label_exp, batch_keys)

            best_sc  = 0.0
            best_rk  = None
            best_hit = None
            for _, rr in hits.iterrows():
                rk = rr["RAW_KEY"]
                sc, _xai = composite(
                    sdtm_var, sdtm_label_exp, rk, rr["VARIABLE"],
                    group_entry["MASTER_CONFIDENCE"],
                    lbl_sims.get(rk, 0.0),
                    weights, modifier,
                )
                if sc > best_sc:
                    best_sc, best_rk, best_hit = sc, rk, rr

            if best_hit is not None:
                resolved.append((best_hit["RAW_DATASET"], best_hit["VARIABLE"], best_sc))
                token_scores.append(best_sc)
            else:
                resolved.append(("", "", 0.0))
                token_scores.append(0.0)

    found_count   = sum(1 for _, _, sc in resolved if sc > 0.0)
    total_count   = len(group_tokens)
    found_fraction = found_count / total_count if total_count else 0.0

    if not token_scores:
        return 0.0, resolved, 0.0, 0.0

    avg_score  = float(np.mean(token_scores))
    full_score = avg_score

    # IMP-005 (v27 fix): use total_count, not undefined `group_count`
    if found_fraction < 1.0:
        full_score = full_score * (penalty + (1.0 - penalty) * found_fraction)
    elif total_count >= 3 and found_fraction == 1.0:
        full_score = min(full_score * 1.20, 1.0)   # all 3+ sources found — strong signal
    elif total_count == 2 and found_fraction == 1.0:
        full_score = min(full_score * 1.10, 1.0)   # both date+time found — confident

    return full_score, resolved, found_fraction, float(np.mean(
        [sc for _, _, sc in resolved if sc > 0.0] or [0.0]
    ))


# ---------------------------------------------------------------------------
# Candidate finder (group-level)
# ---------------------------------------------------------------------------

def find_best_group(sdtm_var, domain, sdtm_label_exp,
                    raw_df, idx, label_idx, cfg, weights, modifier):
    """
    Find the best-scoring group from the master index for a given SDTM variable.

    Returns:
        best_group_result dict or None
        alt_summaries     list of short string summaries for top-3 alternates
    """
    penalty  = partial_group_penalty(cfg)
    min_sc   = cfg.get("matching", {}).get("candidate_min_score", 0.35)
    top_k    = cfg.get("matching", {}).get("top_k_candidates", 5)

    master_groups = idx["by_sdtm"].get((domain, sdtm_var), [])

    # Also look up by individual raw token reverse-index
    # Use id-set for O(1) deduplication instead of O(n) list membership
    extra_groups = []
    _seen_group_ids = {id(g) for g in master_groups}
    for bare_slug, entries in idx["by_raw"].items():
        if name_sim(sdtm_var, bare_slug) >= min_sc:
            for (dom, var, conf, entry) in entries:
                if (dom, var) != (domain, sdtm_var):
                    continue
                if id(entry) not in _seen_group_ids:
                    _seen_group_ids.add(id(entry))
                    extra_groups.append(entry)

    all_groups = master_groups + extra_groups

    # Score every group
    scored = []
    for ge in all_groups:
        sc, resolved, frac, avg_ls = score_group_against_raw(
            ge, raw_df, sdtm_var, sdtm_label_exp,
            label_idx, weights, modifier, penalty,
        )
        if sc >= min_sc:
            scored.append({
                "group":     ge,
                "score":     sc,
                "resolved":  resolved,
                "frac":      frac,
                "avg_ls":    avg_ls,
            })

    # Apply cross-domain penalty: raw vars from a different dataset domain
    # get a 0.35x score multiplier. Same-domain matches always take precedence.
    # This prevents e.g. CM.SUBJID being mapped to AE.USUBJID when AE.SUBJID exists.
    CROSS_DOMAIN_PENALTY = 0.35
    penalised_scored = []
    for item in scored:
        # Check each resolved token's dataset against the SDTM domain
        resolved = item["resolved"]
        adjusted_sc = item["score"]
        if resolved:
            rds_list = [rds for rds, rv, sc2 in resolved if rds and rds.strip()]
            if rds_list:
                # If ANY resolved dataset matches the SDTM domain prefix -> no penalty
                dom_slug = _slug(domain)[:2]
                same_domain = any(
                    _slug(rds)[:2] == dom_slug
                    for rds in rds_list
                )
                if not same_domain:
                    adjusted_sc = adjusted_sc * CROSS_DOMAIN_PENALTY
        penalised_scored.append({**item, "score": adjusted_sc})

    # Re-sort after penalty
    scored = sorted(penalised_scored, key=lambda x: -x["score"])

    # Fallback: global fuzzy if no master groups found
    if not scored:
        # Try same-domain raw datasets first
        ds_pool = raw_df[
            raw_df["RAW_DATASET"].apply(
                lambda d: _slug(domain)[:2] == _slug(d)[:2]
                         or _slug(domain) in _slug(d)
            )
        ]
        if ds_pool.empty:
            ds_pool = raw_df

        lbl_sims = label_idx.scores(sdtm_label_exp, ds_pool["RAW_KEY"].tolist())
        cands = []
        for _, rr in ds_pool.iterrows():
            rk = rr["RAW_KEY"]
            sc, _xai = composite(
                sdtm_var, sdtm_label_exp, rk, rr["VARIABLE"],
                0.0, lbl_sims.get(rk, 0.0), weights, modifier,
            )
            if sc >= min_sc:
                cands.append((rk, rr["RAW_DATASET"], rr["VARIABLE"], sc))

        cands.sort(key=lambda x: -x[3])
        for rk, rds, rv, sc in cands[:top_k]:
            pseudo_group = {
                "DOMAIN":            domain,
                "SDTM_VARIABLE":     sdtm_var,
                "SDTM_LABEL":        sdtm_label_exp,
                "GROUP_SIG":         "",
                "GROUP_TOKENS":      rds + "." + rv,
                "GROUP_COUNT":       1,
                "MAPPING_ACTION":    "",
                "MASTER_CONFIDENCE": 0.0,
                "IS_SPONSOR_STD":    False,
                "SOURCE_FILES":      "",
            }
            scored.append({
                "group":    pseudo_group,
                "score":    sc,
                "resolved": [(rds, rv, sc)],
                "frac":     1.0,
                "avg_ls":   lbl_sims.get(rk, 0.0),
            })

    if not scored:
        return None, []

    scored.sort(key=lambda x: -x["score"])
    best   = scored[0]
    alts   = [
        "%s.%s:%.3f" % (r["group"]["DOMAIN"], r["group"]["SDTM_VARIABLE"], r["score"])
        for r in scored[1:4]
    ]

    # Build resolved token strings
    raw_tokens = []
    for rds, rv, sc in best["resolved"]:
        if rds and rv and sc > 0.0:
            raw_tokens.append("RAW." + rds + "." + rv)

    return {
        "raw_tokens":        raw_tokens,
        "score":             best["score"],
        "frac":              best["frac"],
        "master_conf":       best["group"]["MASTER_CONFIDENCE"],
        "label_sim":         best["avg_ls"],
        "match_path":        "master_guided" if best["group"]["GROUP_SIG"] else "global_fuzzy",
        "group_count":       best["group"]["GROUP_COUNT"],
        "mapping_action":    best["group"]["MAPPING_ACTION"],
        "is_sponsor_std":    best["group"]["IS_SPONSOR_STD"],
    }, alts


# ---------------------------------------------------------------------------
# Spec variable reader
# ---------------------------------------------------------------------------

def read_spec_variables(spec_path, cfg, log):
    """
    Read the new study SDTM spec to get the list of variables to map.
    Returns DataFrame with: DOMAIN, SDTM_VARIABLE, SDTM_LABEL, MAPPING_ACTION, CORE
    """
    bc         = cfg.get("master_build", {})
    aliases    = bc.get("column_aliases", {})
    skip_lower = {s.lower() for s in bc.get("skip_sheets", [])}
    excl       = {d.upper() for d in bc.get("exclude_domains", [])}

    def rc(df, key):
        lc = {c.lower(): c for c in df.columns}
        for a in aliases.get(key, [key]):
            if a.lower() in lc:
                return lc[a.lower()]
        return None

    xl     = pd.ExcelFile(spec_path, engine="openpyxl")
    frames = []

    import re as _re_sv
    # Patterns to always exclude from spec variable reading:
    # - standard non-domain sheets (TOC, Study, Standards, etc.)
    # - change-log sheets appended by write-back (_Writeback_YYYYMMDD_HHMM)
    _NON_DOMAIN_LOWER = {
        "study", "standards", "toc", "<ds>", "ta", "te", "ti", "tv", "ts", "td",
        "ta-data", "te-data", "ti-data", "tv-data", "ts-data", "td-data",
        "maintenance", "valuelist", "value list", "history of revisions",
        "cover", "index", "readme",
    }
    for sn in xl.sheet_names:
        if sn.lower() in skip_lower or sn.upper() in excl:
            continue
        # Skip non-domain sheets
        if sn.strip().lower() in _NON_DOMAIN_LOWER:
            continue
        # Skip write-back change-log sheets
        if _re_sv.match(r"_Writeback_[0-9]{8}_[0-9]{4}$", sn.strip()):
            continue
        try:
            df = xl.parse(sn, dtype=object)
            if df.empty:
                continue
            var_al_lower = [a.lower() for a in aliases.get("variable", ["variable"])]
            col_l        = [str(c).strip().lower() for c in df.columns]
            if any(a in col_l for a in var_al_lower):
                hdr = 0
            else:
                hdr = None
                for i in range(min(15, len(df))):
                    rv = [str(v).strip().lower() for v in df.iloc[i].values if pd.notna(v)]
                    if any(a in rv for a in var_al_lower):
                        hdr = i
                        break
            if hdr is None:
                continue
            if hdr > 0:
                df = xl.parse(sn, header=hdr, dtype=object)

            var_c  = rc(df, "variable")
            ds_c   = rc(df, "dataset")
            lbl_c  = rc(df, "label")
            act_c  = rc(df, "mapping_action")
            core_c = rc(df, "core")
            if var_c is None:
                continue

            for _, r in df.iterrows():
                var = _norm(r.get(var_c))
                if not var:
                    continue
                dom = _norm(r.get(ds_c)) if ds_c else sn.upper()
                if not dom:
                    dom = sn.upper()
                if dom in excl:
                    continue
                frames.append({
                    "DOMAIN":         dom,
                    "SDTM_VARIABLE":  var,
                    "SDTM_LABEL":     _norm(r.get(lbl_c)) if lbl_c else "",
                    "MAPPING_ACTION": _norm(r.get(act_c)) if act_c else "",
                    "CORE":           _norm(r.get(core_c)) if core_c else "",
                })
        except Exception as exc:
            log.warning("  Sheet '%s': %s", sn, exc)

    if not frames:
        return pd.DataFrame()
    return (
        pd.DataFrame(frames)
        .drop_duplicates(["DOMAIN", "SDTM_VARIABLE"])
        .reset_index(drop=True)
    )


# ---------------------------------------------------------------------------
# Main mapping loop
# ---------------------------------------------------------------------------

def _make_row(base, raw_assigned, mapping_action, origin, oconf,
              score, tier, match_path, group_count,
              master_conf, label_sim, partial_frac, top_candidates, xai_str=""):
    """Build a standardised result row dict."""
    return dict(
        base,
        RAW_VARIABLES_ASSIGNED = raw_assigned,
        MAPPING_ACTION         = mapping_action,
        ORIGIN                 = origin,
        ORIGIN_CONFIDENCE      = round(float(oconf or 0), 3),
        COMPOSITE_SCORE        = round(float(score  or 0), 4),
        MATCH_TIER             = tier,
        MATCH_PATH             = match_path,
        GROUP_COUNT            = group_count or 0,
        MASTER_CONF            = round(float(master_conf or 0), 4) if master_conf != "" else "",
        LABEL_SIM              = round(float(label_sim   or 0), 4) if label_sim   != "" else "",
        PARTIAL_FRAC           = round(float(partial_frac or 0), 3) if partial_frac != "" else "",
        TOP_CANDIDATES         = top_candidates or "",
        SCORE_BREAKDOWN        = xai_str or "",
    )



def _find_raw_via_label_bridge(
    master_token_label, raw_df, label_idx, domain_hint, min_label_sim=0.45
):
    """
    IMP-004/IMP-006: When name-based matching fails for a master token, attempt
    to find a semantically equivalent raw variable via label TF-IDF similarity.
    Returns (raw_key, score) or ("", 0.0).
    """
    if not master_token_label or not label_idx.is_enabled:
        return "", 0.0
    dom_prefix = _slug(domain_hint)[:2]
    same_dom_pool = raw_df[
        raw_df["RAW_DATASET"].apply(lambda d: _slug(str(d))[:2] == dom_prefix)
    ]
    search_pool = same_dom_pool if not same_dom_pool.empty else raw_df
    candidate_keys = search_pool["RAW_KEY"].tolist()
    if not candidate_keys:
        return "", 0.0
    label_scores = label_idx.scores(master_token_label, candidate_keys)
    best_key, best_score = "", 0.0
    for key, score in label_scores.items():
        if score > best_score:
            best_score, best_key = score, key
    return (best_key, best_score) if best_score >= min_label_sim else ("", 0.0)


def _classify_unresolved_reason(domain, var, idx):
    """
    IMP-006: Distinguish 'master has no knowledge' from 'master name bridge failed'.
    Returns (match_path, hint_message).
    """
    master_groups = idx["by_sdtm"].get((domain, var), [])
    if not master_groups:
        return "no_master_group", ""
    all_known_tokens = []
    for g in master_groups:
        for tok in (g.get("GROUP_TOKENS", "") or "").split("|"):
            if tok and tok.strip():
                all_known_tokens.append(tok.strip())
    unique_tokens = list(dict.fromkeys(all_known_tokens))[:8]
    hint = (
        "Master has historical sources for this variable: "
        + ", ".join(unique_tokens)
        + ". Check if equivalent raw variables exist in the new study catalog."
    )
    return "master_name_bridge_failed", hint


def run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log, master_path=None):
    """
    RAW-FIRST, MASTER-GUIDED mapping.

    Correct direction:
      For each raw variable in the new study catalog:
        -> look it up in the master by_raw index (keyed by bare variable slug)
        -> retrieve the SDTM (DOMAIN, VARIABLE) it historically mapped to
        -> score the match using composite scorer
        -> apply domain penalty if raw dataset prefix != SDTM domain
        -> assign the raw variable to the best-scoring SDTM target

    Then for each SDTM variable in the spec:
        -> if it received a raw match above -> use that result
        -> if it has no raw match but is Protocol/Derived -> mark direct (no raw needed)
        -> otherwise -> unresolved

    This approach NEVER does free fuzzy matching outside master knowledge.
    The fallback (when no master group exists for a SDTM var) is:
      -> only try variables whose raw dataset prefix matches the SDTM domain prefix
      -> score against label similarity only (not arbitrary name fuzzy matching)
    """
    weights  = get_weights(cfg)
    auto_t_default = cfg.get("matching", {}).get("thresholds", {}).get("auto_accept", 0.82)
    rev_t_default  = cfg.get("matching", {}).get("thresholds", {}).get("review",      0.55)
    CROSS_DOMAIN_PENALTY = 0.20   # class-based in Phase 1; this is the Phase 2 fallback
    MIN_SC = cfg.get("matching", {}).get("candidate_min_score", 0.35)

    log.info("[MAP] Building group-aware master index...")
    idx = build_index(master_df)

    log.info("[MAP] Building TF-IDF label index...")
    lbl_idx = LabelIndex(raw_df)
    log.info("  Label TF-IDF: %s", "enabled" if lbl_idx.is_enabled else "disabled (no labels)")

    log.info("[MAP] Training ML scorer on master mapping data...")
    ml = MLScorer()
    # NOTE: lbl_idx intentionally NOT passed -- it is built from new-study raw
    # labels, and passing it into training would leak new-study vocabulary into
    # the feature matrix (data leakage fix, v20).  label_tfidf is set to 0.0
    # during training; at inference time the true similarity is supplied per-pair.
    ml.train(master_df, log_=log, master_path=master_path)
    log.info("  MLScorer: %s", "HistGBT trained" if ml.is_trained else "fallback mode")

    raw_ds_set  = set(raw_df["RAW_DATASET"].tolist())

    # IMP-001: Populate crf_var_set and als_var_set from raw catalog + master origin
    def _build_origin_sets(rdf, mdf):
        crf_vars = set()
        als_vars = set()
        CRF_EXCLUDE_FORMATS = {"DATE", "DATETIME", "TIME", "YYMMDD", "DDMMYY", "TOD"}
        for _, rr in rdf.iterrows():
            raw_ds  = str(rr.get("RAW_DATASET", "")).strip().upper()
            raw_var = str(rr.get("VARIABLE", "")).strip().upper()
            fmt     = str(rr.get("FORMAT", "") or "").upper()
            typ     = str(rr.get("TYPE", "") or "").upper()
            ds_prefix = raw_ds[:2] if len(raw_ds) >= 2 else raw_ds
            is_edt    = ds_prefix in EDT_PREFIXES
            is_date_f = any(x in fmt for x in CRF_EXCLUDE_FORMATS)
            is_char   = typ in ("C", "CHAR", "CHARACTER", "TEXT", "STRING")
            if not is_edt and is_char and not is_date_f:
                crf_vars.add(raw_var)
        if "ORIGIN" in mdf.columns:
            for _, mr in mdf.iterrows():
                raw_tok = str(mr.get("RAW_VARIABLE", "") or "").strip().upper()
                origin  = str(mr.get("ORIGIN", "") or "").strip().upper()
                bare    = raw_tok.split(".")[-1] if "." in raw_tok else raw_tok
                if not bare or bare == "NAN":
                    continue
                if origin == "CRF":
                    crf_vars.add(bare)
                elif origin in ("ASSIGNED", "PROTOCOL", "ASSIGNED/SPONSOR"):
                    als_vars.add(bare)
        return crf_vars, als_vars

    crf_var_set, als_var_set = _build_origin_sets(raw_df, master_df)
    log.info("  Origin sets: %d CRF vars, %d ALS vars", len(crf_var_set), len(als_var_set))

    # Build a lookup: (DOMAIN, SDTM_VARIABLE) -> row from sdtm_vars_df
    spec_var_lookup = {}
    for _, sv in sdtm_vars_df.iterrows():
        dom = str(sv.get("DOMAIN", "")).strip()
        var = str(sv.get("SDTM_VARIABLE", "")).strip()
        if dom and var:
            spec_var_lookup[(dom, var)] = sv

    # ----------------------------------------------------------------
    # PHASE 1: RAW-FIRST PASS
    # For each raw variable, find its SDTM target via master by_raw index
    # ----------------------------------------------------------------
    log.info("[MAP] Phase 1: raw-first master-guided matching (%d raw vars)...", len(raw_df))

    # raw_key -> best assignment
    # sdtm_key -> list of raw tokens assigned to it
    sdtm_assignments = {}   # (domain, sdtm_var) -> {"raw_tokens", "score", "group", "label_sim", "frac"}

    total_raw = len(raw_df)
    for ri, (_, rr) in enumerate(raw_df.iterrows()):
        if (ri + 1) % 50 == 0 or (ri + 1) == total_raw:
            log.info("  Phase 1: [%d/%d] raw vars processed", ri + 1, total_raw)

        raw_ds   = str(rr["RAW_DATASET"]).strip()
        raw_var  = str(rr["VARIABLE"]).strip()
        raw_key  = str(rr["RAW_KEY"]).strip()
        raw_lbl  = str(rr.get("LABEL", "") or "").strip()
        raw_slug = _slug(raw_var)

        if not raw_var or not raw_slug:
            continue

        # Look up this raw variable in the master by_raw index
        # by_raw is keyed by bare variable slug (no dataset prefix)
        candidate_groups = idx["by_raw"].get(raw_slug, [])

        # Partial slug fallback using pre-built suffix4 index (O(1) vs O(n))
        if not candidate_groups and len(raw_slug) >= 4:
            suffix_key = raw_slug[-4:]
            candidate_groups = idx["by_raw_suffix4"].get(suffix_key, [])

        best_score = 0.0
        best_key   = None
        best_info  = {}

        for (sdtm_dom, sdtm_var, master_conf, group_entry) in candidate_groups:
            # Only consider SDTM vars that are in the spec (if spec was provided)
            if spec_var_lookup and (sdtm_dom, sdtm_var) not in spec_var_lookup:
                continue

            vc  = classify_variable(sdtm_var, sdtm_dom)
            mod = class_mod(cfg, vc)

            sdtm_lbl_exp = expand_sdtm_label(sdtm_var, sdtm_dom)
            lbl_sim = lbl_idx.scores(sdtm_lbl_exp, [raw_key]).get(raw_key, 0.0)

            sc = ml.score(
                raw_var      = raw_var,
                raw_dataset  = raw_ds,
                raw_label    = rr.get("LABEL", "") or "",
                raw_format   = rr.get("FORMAT", "") or "",
                raw_type     = rr.get("TYPE", "") or "",
                sdtm_var     = sdtm_var,
                sdtm_domain  = sdtm_dom,
                sdtm_label   = group_entry.get("SDTM_LABEL", "") or "",
                master_conf  = master_conf,
                is_sponsor_std = group_entry.get("IS_SPONSOR_STD", False),
                in_master    = True,
                label_tfidf_score = lbl_sim,
            )

            # Domain penalty: class-aware cross-domain suppression
            # Use DOMAIN_CLASS to determine semantic distance, not just prefix match
            raw_dom_slug  = _slug(raw_ds)[:2].upper()
            sdtm_dom_slug = _slug(sdtm_dom)[:2].upper()
            if raw_dom_slug != sdtm_dom_slug:
                raw_class  = DOMAIN_CLASS.get(raw_dom_slug,  "Unknown")
                sdtm_class = DOMAIN_CLASS.get(sdtm_dom_slug, "Unknown")

                # Date/timing variables (ending DT/DTC/DTM) are routinely
                # collected from multiple raw datasets across different domains
                # (e.g. DM.RFPENDTC sourced from raw.ae, raw.pk, raw.cm).
                # Apply a softer penalty so they survive the MIN_SC threshold.
                is_timing = is_date_variable(sdtm_var)

                if is_timing:
                    # Timing vars: very mild cross-domain penalty
                    if raw_class == sdtm_class:
                        sc = sc * 0.85
                    elif {raw_class, sdtm_class} & {"Unknown"}:
                        sc = sc * 0.65
                    else:
                        sc = sc * 0.50
                elif raw_class == sdtm_class:
                    # Same semantic class, different prefix → mild penalty
                    sc = sc * 0.60
                elif {raw_class, sdtm_class} & {"Unknown"}:
                    # One side unknown → moderate penalty
                    sc = sc * 0.35
                else:
                    # Different semantic classes (e.g. Events raw → Findings SDTM)
                    # Very strong penalty — almost never correct
                    sc = sc * 0.20

            if sc > best_score and sc >= MIN_SC:
                best_score = sc
                best_key   = (sdtm_dom, sdtm_var)
                best_info  = {
                    "master_conf": master_conf,
                    "label_sim":   lbl_sim,
                    "group":       group_entry,
                    "raw_tok":     "RAW." + raw_ds + "." + raw_var,
                    "vc":          vc,
                    "xai": {
                        "name_exact":  1.0 if _slug(sdtm_var)==_slug(raw_var) else 0.0,
                        "name_fuzzy":  round(name_sim(sdtm_var, raw_var), 3),
                        "label_tfidf": round(lbl_sim, 3),
                        "master_freq": round(master_conf, 3),
                        "composite":   round(sc, 4),
                    },
                }

        if best_key:
            existing = sdtm_assignments.get(best_key)
            if existing is None or best_score > existing["score"]:
                # New best match for this SDTM variable.
                # Preserve any extra tokens already collected from other raw datasets.
                prev_extras = []
                if existing is not None:
                    for et in existing["raw_tokens"]:
                        if et != best_info["raw_tok"] and et not in prev_extras:
                            prev_extras.append(et)
                sdtm_assignments[best_key] = {
                    "score":             best_score,
                    "master_conf":       best_info["master_conf"],
                    "label_sim":         best_info["label_sim"],
                    "group":             best_info["group"],
                    "raw_tokens":        [best_info["raw_tok"]] + prev_extras,
                    "raw_token_scores":  {best_info["raw_tok"]: best_score},
                    "vc":                best_info["vc"],
                    "xai":               best_info.get("xai", {}),
                }
            else:
                # Additional raw variable also maps to the same SDTM variable.
                # Only accumulate extra tokens when the variable type warrants it:
                #   - Timing/date variables (RF*DTC, RFSTDTC etc.) are legitimately
                #     sourced from multiple raw datasets → allow cross-domain tokens
                #   - Identifier variables (USUBJID, SUBJID) are similarly cross-domain
                #   - All other variable classes → only accept same-domain raw tokens
                #     to prevent noise accumulation (the DM.RFPENDTC 28-token problem)
                raw_tok       = "RAW." + raw_ds + "." + raw_var
                sdtm_var_key  = best_key[1]   # e.g. "RFPENDTC"
                sdtm_dom_key  = best_key[0]   # e.g. "DM"
                _vc_extra     = classify_variable(sdtm_var_key, sdtm_dom_key)
                _is_timing_v  = is_date_variable(sdtm_var_key)
                _is_id_v      = _vc_extra in ("identifier",)
                _same_dom     = _slug(raw_ds)[:2] == _slug(sdtm_dom_key)[:2]

                # Accept the token when:
                #   a) It's a timing/date variable (always multi-source legitimate), OR
                #   b) It's an identifier variable AND comes from same domain OR DM
                #      (USUBJID is canonical in DM; other identifiers should be same-domain)
                #   c) It comes from the same raw dataset domain as the SDTM domain
                _dm_like      = _slug(raw_ds)[:2].upper() in ("DM", "EN")  # ENROLL is common DM-like source
                _accept_extra = (
                    _is_timing_v
                    or (_is_id_v and (_same_dom or _dm_like))
                    or (_not_id_not_timing := (not _is_timing_v and not _is_id_v) and _same_dom)
                )

                # Also require the extra token to score above a meaningful threshold
                # (not just MIN_SC) to avoid low-quality noise tokens
                _extra_sc_threshold = max(MIN_SC, 0.45)

                if (raw_tok not in existing["raw_tokens"]
                        and best_score >= _extra_sc_threshold
                        and _accept_extra):
                    existing["raw_tokens"].append(raw_tok)
                    existing.setdefault("raw_token_scores", {})[raw_tok] = best_score
                    # Cap at 6 tokens for non-timing, 12 for timing/identifier
                    _tok_cap = 12 if (_is_timing_v or _is_id_v) else 6
                    if len(existing["raw_tokens"]) > _tok_cap:
                        ts = existing.get("raw_token_scores", {})
                        ranked = sorted(
                            existing["raw_tokens"],
                            key=lambda t: ts.get(t, 0.0),
                            reverse=True,
                        )
                        existing["raw_tokens"] = ranked[:_tok_cap]

    log.info("  Phase 1 complete: %d SDTM variables received raw assignments",
             len(sdtm_assignments))

    # ----------------------------------------------------------------
    # PHASE 2: SDTM-FIRST PASS
    # Walk every SDTM variable in the spec and produce the final result
    # ----------------------------------------------------------------
    log.info("[MAP] Phase 2: resolving %d SDTM spec variables...", len(sdtm_vars_df))

    direct_rows = []
    review_rows = []
    unres_rows  = []
    mapped_raw_keys = set()

    total = len(sdtm_vars_df)
    for i, (_, sv) in enumerate(sdtm_vars_df.iterrows()):
        if (i + 1) % 50 == 0 or (i + 1) == total:
            log.info("  Phase 2: [%4d/%d]  direct=%d  review=%d  unres=%d",
                     i + 1, total, len(direct_rows), len(review_rows), len(unres_rows))

        domain = str(sv.get("DOMAIN",         "")).strip()
        var    = str(sv.get("SDTM_VARIABLE",  "")).strip()
        label  = str(sv.get("SDTM_LABEL",     "")).strip()
        action = str(sv.get("MAPPING_ACTION", "")).strip()

        if not domain or not var:
            continue

        auto_t, rev_t = get_thresholds(cfg, domain)
        vc  = classify_variable(var, domain)
        mod = class_mod(cfg, vc)

        base = {
            "DOMAIN":        domain,
            "SDTM_VARIABLE": var,
            "SDTM_LABEL":    label,
            "VAR_CLASS":     vc,
        }

        # ----------------------------------------------------------------
        # Priority: raw assignment from Phase 1 ALWAYS wins over any
        # hard-coded rule (protocol, derived, timing).
        # Hard rules apply only as fallback when Phase 1 found nothing.
        # ----------------------------------------------------------------
        assignment = sdtm_assignments.get((domain, var))

        if assignment:
            # Raw assignment found — use it regardless of var class
            raw_tokens   = assignment["raw_tokens"]
            score        = assignment["score"]
            master_conf  = assignment["master_conf"]
            label_sim    = assignment["label_sim"]
            raw_assigned = ", ".join(raw_tokens)

            # Register mapped raw keys so they appear in unmapped report
            for tok in raw_tokens:
                parts = tok.split(".")
                if len(parts) >= 3:
                    mapped_raw_keys.add(parts[-2] + "." + parts[-1])

            origin, oconf = infer_origin(
                var, domain, action, raw_tokens,
                crf_var_set, als_var_set, raw_ds_set,
            )

            if score >= auto_t:
                tier = "direct"
            elif score >= rev_t:
                tier = "review"
            else:
                tier = "unresolved"
                raw_tokens   = []
                raw_assigned = ""

            mapped_action = action or assignment["group"].get("MAPPING_ACTION") or ("ASSIGN" if raw_tokens else "DERIVE")
            _xai_str = str(assignment.get("xai", {}))
            row = _make_row(base, raw_assigned, mapped_action, origin, oconf,
                            score, tier, "master_guided",
                            assignment["group"].get("GROUP_COUNT", 1),
                            master_conf, label_sim, 1.0, "", _xai_str)

            if tier == "direct":
                direct_rows.append(row)
            elif tier == "review":
                review_rows.append(row)
            else:
                unres_rows.append(row)
            continue

        # ----------------------------------------------------------------
        # No raw assignment from Phase 1 — apply fallback hard rules
        # ----------------------------------------------------------------

        # Hard rule: structural protocol vars (STUDYID, DOMAIN, ARM etc.)
        # RF*DTC timing vars are NOT in PROTOCOL_VARS — they only reach here
        # if Phase 1 found zero raw matches, which means no master knowledge.
        if var in PROTOCOL_VARS:
            direct_rows.append(_make_row(
                base, "", "HARDCODE", "Assigned/Sponsor", 0.92,
                1.0, "direct", "protocol_rule", 0, "", "", "", "",
            ))
            continue

        # Hard rule: RF*DTC timing vars with no master raw source
        if var in RF_TIMING_VARS:
            direct_rows.append(_make_row(
                base, "", "HARDCODE", "Assigned/Sponsor", 0.88,
                1.0, "direct", "rf_timing_no_raw", 0, "", "", "", "",
            ))
            continue

        # IMP-002: Hard rule: ALWAYS_DERIVED only (not COMMONLY_DERIVED)
        # COMMONLY_DERIVED (AGE, AGEU, VISITNUM) already attempted raw assignment in Phase 1
        if var in ALWAYS_DERIVED:
            direct_rows.append(_make_row(
                base, "", action or "DERIVE", "Derived", 0.90,
                1.0, "direct", "derived_rule", 0, "", "", "", "",
            ))
            continue
        # COMMONLY_DERIVED with no raw match — treat as derived but lower confidence
        if var in COMMONLY_DERIVED and not assignment:
            direct_rows.append(_make_row(
                base, "", action or "DERIVE", "Derived", 0.75,
                0.80, "direct", "commonly_derived_rule", 0, "", "", "", "",
            ))
            continue

        # IMP-011: SUPPQUAL semantic split
        _is_supp_domain = (domain.upper().startswith("SUPP") or domain.upper() == "SUPPQUAL")
        if _is_supp_domain:
            if var in SUPP_STRUCTURAL_VARS:
                direct_rows.append(_make_row(
                    base, "", "HARDCODE", "Assigned/Sponsor", 0.88,
                    1.0, "direct", "suppqual_structural", 0, "", "", "", "",
                ))
                continue
            elif var in SUPP_CODELIST_VARS:
                unres_rows.append(_make_row(
                    base, "", "CODELIST_MAP", "Assigned/Sponsor", 0.70,
                    0.0, "unresolved", "suppqual_codelist_manual",
                    0, "", "", "",
                    "QNAM/QLABEL are sponsor-defined codelist values — manual population required.",
                ))
                continue
            elif var in SUPP_MAPPED_VARS and not assignment:
                # QVAL needs a raw CRF source — if Phase 1 found nothing, flag explicitly
                unres_rows.append(_make_row(
                    base, "", "ASSIGN", "CRF", 0.0,
                    0.0, "unresolved", "suppqual_qval_no_raw",
                    0, "", "", "",
                    "QVAL requires a raw CRF source variable. Check raw catalog for non-standard collected field.",
                ))
                continue
            # else: QVAL with assignment, or other SUPP variable — fall through

        # ----------------------------------------------------------------
        # Last-resort fallback: no master knowledge at all for this var.
        # Try same-domain raw vars via label+name similarity only.
        # Strictly constrained to same domain prefix — no cross-domain here.
        # ----------------------------------------------------------------
        same_dom_raw = raw_df[
            raw_df["RAW_DATASET"].apply(
                lambda d: _slug(str(d))[:2] == _slug(domain)[:2]
            )
        ]
        best_sc  = 0.0
        best_tok = ""
        if not same_dom_raw.empty:
            sdtm_lbl_exp = (label + " " + expand_sdtm_label(var, domain)).strip()
            lbl_sims = lbl_idx.scores(sdtm_lbl_exp, same_dom_raw["RAW_KEY"].tolist())
            for _, rr in same_dom_raw.iterrows():
                ls = lbl_sims.get(rr["RAW_KEY"], 0.0)
                sc = ml.score(
                    raw_var=rr["VARIABLE"], raw_dataset=rr["RAW_DATASET"],
                    raw_label=rr.get("LABEL", "") or "",
                    raw_format=rr.get("FORMAT", "") or "",
                    raw_type=rr.get("TYPE", "") or "",
                    sdtm_var=var, sdtm_domain=domain,
                    sdtm_label=label,
                    master_conf=0.0, is_sponsor_std=False,
                    in_master=False, label_tfidf_score=ls,
                )
                if sc > best_sc:
                    best_sc  = sc
                    best_tok = "RAW." + rr["RAW_DATASET"] + "." + rr["VARIABLE"]

        if best_sc >= rev_t and best_tok:
            origin, oconf = infer_origin(var, domain, action, [best_tok],
                                         crf_var_set, als_var_set, raw_ds_set)
            tier = "direct" if best_sc >= auto_t else "review"
            mapped_action = action or "ASSIGN"
            row = _make_row(base, best_tok, mapped_action, origin, oconf,
                            best_sc, tier, "label_only_same_domain",
                            1, 0.0, best_sc, 1.0, "")
            if tier == "direct":
                direct_rows.append(row)
            else:
                review_rows.append(row)
            parts = best_tok.split(".")
            if len(parts) >= 3:
                mapped_raw_keys.add(parts[-2] + "." + parts[-1])
        else:
            # IMP-006: distinguish master-silent vs name-bridge-failed
            _unres_path, _unres_hint = _classify_unresolved_reason(domain, var, idx)
            unres_rows.append(_make_row(
                base, "", action, "", 0.0,
                0.0, "unresolved", _unres_path, 0, "", "", "", _unres_hint or "",
            ))

    # Unmapped raw variables
    unmapped = raw_df[~raw_df["RAW_KEY"].isin(mapped_raw_keys)].copy()
    unmapped = unmapped[["RAW_DATASET", "VARIABLE", "LABEL", "FORMAT"]].copy()
    unmapped.columns = ["RAW_DATASET", "RAW_VARIABLE", "LABEL", "FORMAT"]

    direct_df = pd.DataFrame(direct_rows)
    review_df = pd.DataFrame(review_rows)
    unres_df  = pd.DataFrame(unres_rows)

    # Coverage per domain
    cov_rows = []
    for dom in sdtm_vars_df["DOMAIN"].unique():
        dom_vars = sdtm_vars_df[sdtm_vars_df["DOMAIN"] == dom]
        tot = len(dom_vars)
        d_n = int((direct_df["DOMAIN"] == dom).sum()) if not direct_df.empty else 0
        r_n = int((review_df["DOMAIN"] == dom).sum()) if not review_df.empty else 0
        u_n = int((unres_df["DOMAIN"]  == dom).sum()) if not unres_df.empty  else 0
        all_dom = pd.concat([df for df in [direct_df, review_df, unres_df] if not df.empty])
        all_dom = all_dom[all_dom["DOMAIN"] == dom] if not all_dom.empty else pd.DataFrame()
        cc = (all_dom["VAR_CLASS"].value_counts().to_dict()
              if not all_dom.empty and "VAR_CLASS" in all_dom.columns else {})
        cov_rows.append({
            "DOMAIN":             dom,
            "TOTAL":              tot,
            "DIRECT":             d_n,
            "REVIEW":             r_n,
            "UNRESOLVED":         u_n,
            "AUTO_PCT":           round(d_n / tot * 100, 1) if tot else 0.0,
            "TOTAL_COVERAGE_PCT": round((d_n + r_n) / tot * 100, 1) if tot else 0.0,
            "N_DERIVED":          cc.get("derived", 0) + cc.get("sequence", 0),
            "N_IDENTIFIER":       cc.get("identifier", 0),
            "N_TIMING":           cc.get("timing", 0),
            "N_RESULT":           cc.get("result", 0),
            "N_CODELIST":         cc.get("codelist", 0),
            "N_GENERAL":          cc.get("general", 0) + cc.get("free_text", 0),
        })

    coverage = pd.DataFrame(cov_rows).sort_values("DOMAIN").reset_index(drop=True)

    log.info("[MAP]  Direct: %d  |  Review: %d  |  Unresolved: %d  |  Unmapped raw: %d",
             len(direct_rows), len(review_rows), len(unres_rows), len(unmapped))

    # ----------------------------------------------------------------
    # PHASE 3: VARIABLE-LEVEL CROSS-DATASET MATCH
    # For unresolved SDTM variables, check if any raw variable in ANY
    # dataset has an identical (or near-identical) variable name match,
    # even if the raw dataset name is different (e.g. QSXXX -> QS domain).
    # These are flagged for manual review - they may be valid mappings
    # from studies with non-standard dataset naming conventions.
    # ----------------------------------------------------------------
    log.info("[MAP] Phase 3: variable-level cross-dataset match for %d unresolved vars...",
             len(unres_rows))

    # --- FAST vectorized approach ---
    # Pre-build a slug -> [(raw_ds, raw_var, raw_key, raw_lbl)] lookup from raw_df
    # so we only call name_sim() on candidates that share slug prefix overlap
    raw_slug_index: dict[str, list] = {}
    for _, rr in raw_df.iterrows():
        rv  = str(rr["VARIABLE"]).strip()
        rds = str(rr["RAW_DATASET"]).strip()
        rk  = str(rr.get("RAW_KEY", rds + "." + rv))
        rbl = str(rr.get("LABEL", "") or "").strip()
        sl  = _slug(rv)
        if sl:
            raw_slug_index.setdefault(sl, []).append((rds, rv, rk, rbl))

    # Also build a 4-char suffix bucket for near-miss lookup
    raw_suffix4: dict[str, list] = {}
    for sl, entries in raw_slug_index.items():
        if len(sl) >= 4:
            raw_suffix4.setdefault(sl[-4:], []).extend(entries)

    cross_dataset_rows = []
    unres_remaining    = []
    CROSS_MIN_SIM      = 0.72   # name-similarity floor for Phase 3 cross-dataset match

    for row in unres_rows:
        domain = str(row.get("DOMAIN", "")).strip()
        var    = str(row.get("SDTM_VARIABLE", "")).strip()
        label  = str(row.get("SDTM_LABEL", "")).strip()

        if not var:
            unres_remaining.append(row)
            continue

        var_slug = _slug(var)
        if not var_slug:
            unres_remaining.append(row)
            continue

        sdtm_class = DOMAIN_CLASS.get(domain.upper(), "Special")

        # Collect candidates: exact slug match OR 4-char suffix overlap
        candidates: list = list(raw_slug_index.get(var_slug, []))   # exact slugs first
        suffix_key = var_slug[-4:] if len(var_slug) >= 4 else ""
        if suffix_key:
            for entry in raw_suffix4.get(suffix_key, []):
                if entry not in candidates:
                    candidates.append(entry)

        if not candidates:
            unres_remaining.append(row)
            continue

        sdtm_lbl_exp = (label + " " + expand_sdtm_label(var, domain)).strip()

        best_sc  = 0.0
        best_tok = ""
        best_ds  = ""

        for (rds, rv, rk, rbl) in candidates:
            rv_slug = _slug(rv)
            if not rv_slug:
                continue

            # Exact slug match = 1.0, else fuzzy (fast because candidate set is small)
            nm_sc = 1.0 if var_slug == rv_slug else name_sim(var, rv)
            if nm_sc < CROSS_MIN_SIM:
                continue

            # --- Anti-hallucination: domain proximity penalty ---
            # If the raw dataset class is semantically distant from the SDTM domain class,
            # apply a penalty to reduce false cross-class matches.
            # E.g. a Lab (Findings) variable should not be matched into AE (Events)
            # unless it's a common identifier like USUBJID.
            rds_dom_prefix = _slug(rds)[:2]
            rds_sdtm_class = DOMAIN_CLASS.get(rds_dom_prefix.upper(), "Special")
            domain_proximity = 1.0
            if rds_sdtm_class != sdtm_class:
                # Cross-class: heavier penalty for semantically distant classes
                if {rds_sdtm_class, sdtm_class} <= {"Events", "Findings", "Interventions"}:
                    domain_proximity = 0.60   # within general observations: mild penalty
                else:
                    domain_proximity = 0.80   # cross to special/trial: moderate penalty

            # Label similarity bonus (only for candidates that passed name check)
            lbl_sim = lbl_idx.scores(sdtm_lbl_exp, [rk]).get(rk, 0.0)
            sc = (nm_sc * 0.70 + lbl_sim * 0.30) * domain_proximity

            if sc > best_sc:
                best_sc, best_tok, best_ds = sc, "RAW." + rds + "." + rv, rds

        if best_sc >= CROSS_MIN_SIM and best_tok:
            origin, _ = infer_origin(var, domain, "", [best_tok],
                                     crf_var_set, als_var_set, raw_ds_set)
            cross_row = dict(row)
            cross_row["RAW_VARIABLES_ASSIGNED"] = best_tok
            cross_row["COMPOSITE_SCORE"]        = round(best_sc, 4)
            cross_row["MATCH_TIER"]             = "cross_dataset_var_match"
            cross_row["ORIGIN"]                 = origin
            cross_row["MAPPING_ACTION"]         = "ASSIGN"
            cross_row["MATCH_NOTE"] = (
                f"Variable name match in dataset '{best_ds}' "
                f"(score={best_sc:.2f}). Dataset name differs from "
                f"SDTM domain prefix — MANUAL REVIEW REQUIRED."
            )
            cross_dataset_rows.append(cross_row)
        else:
            unres_remaining.append(row)

    unres_df    = pd.DataFrame(unres_remaining)
    cross_ds_df = pd.DataFrame(cross_dataset_rows)

    log.info("  Phase 3: %d cross-dataset variable matches (manual review), %d still unresolved",
             len(cross_dataset_rows), len(unres_remaining))

    return {
        "direct":              direct_df,
        "review":              review_df,
        "unresolved":          unres_df,
        "unmapped_raw":        unmapped,
        "coverage":            coverage,
        "cross_dataset_match": cross_ds_df,
        "_ml_scorer":          ml,   # FIX: expose ml so run() can pass it to write_results
    }


# ---------------------------------------------------------------------------
# Output writer
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# IMP-014: GxP Audit Trail
# ---------------------------------------------------------------------------

AUDIT_COLUMNS = [
    "AUDIT_TIMESTAMP", "DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL",
    "RAW_VARIABLES_ASSIGNED", "COMPOSITE_SCORE", "MATCH_TIER", "MATCH_PATH",
    "MASTER_FILE", "MASTER_SHA256", "ML_MODEL_VERSION", "RUN_HOST", "RUN_USER",
    "SYSTEM_VERSION", "CONFIG_AUTO_ACCEPT", "CONFIG_REVIEW", "AUTO_ACCEPTED",
]

SYSTEM_VERSION = "sdtm_mapping_system_v26"


def build_audit_sheet(direct_df, review_df, unres_df, master_path,
                      master_df, ml_scorer, cfg, run_timestamp):
    """Build _Mapping_Audit sheet for 21 CFR Part 11 / GxP traceability."""
    import platform, getpass, hashlib

    def _sha(mdf):
        cols = [c for c in ["DOMAIN","SDTM_VARIABLE","RAW_VARIABLE","MASTER_CONFIDENCE"]
                if c in mdf.columns]
        return hashlib.sha256(mdf[cols].to_csv(index=False).encode()).hexdigest()[:16]

    master_hash = _sha(master_df)
    model_id    = (f"HistGBT_calibrated_v26_{master_hash[:8]}"
                   if getattr(ml_scorer, "is_trained", False) else "fallback_weighted_sum")
    host        = platform.node()
    try:
        user = getpass.getuser()
    except Exception:
        user = "unknown"

    thresholds = cfg.get("matching", {}).get("thresholds", {})
    auto_t     = thresholds.get("auto_accept", 0.82)
    rev_t      = thresholds.get("review", 0.55)

    rows = []
    for df, is_auto in [(direct_df, True), (review_df, False), (unres_df, False)]:
        if df is None or df.empty:
            continue
        for _, row in df.iterrows():
            rows.append({
                "AUDIT_TIMESTAMP":        run_timestamp,
                "DOMAIN":                 row.get("DOMAIN", ""),
                "SDTM_VARIABLE":          row.get("SDTM_VARIABLE", ""),
                "SDTM_LABEL":             row.get("SDTM_LABEL", ""),
                "RAW_VARIABLES_ASSIGNED": row.get("RAW_VARIABLES_ASSIGNED", ""),
                "COMPOSITE_SCORE":        row.get("COMPOSITE_SCORE", 0.0),
                "MATCH_TIER":             row.get("MATCH_TIER", ""),
                "MATCH_PATH":             row.get("MATCH_PATH", ""),
                "MASTER_FILE":            getattr(master_path, "name", str(master_path) if master_path else ""),
                "MASTER_SHA256":          master_hash,
                "ML_MODEL_VERSION":       model_id,
                "RUN_HOST":               host,
                "RUN_USER":               user,
                "SYSTEM_VERSION":         SYSTEM_VERSION,
                "CONFIG_AUTO_ACCEPT":     auto_t,
                "CONFIG_REVIEW":          rev_t,
                "AUTO_ACCEPTED":          is_auto,
            })

    return pd.DataFrame(rows, columns=AUDIT_COLUMNS)

def write_results(results, out_path, log, master_path=None, master_df=None, ml_scorer=None, cfg=None):
    """Write all mapping results to a styled multi-sheet Excel workbook."""
    from openpyxl.styles import PatternFill, Font, Alignment
    from openpyxl.utils import get_column_letter

    fill_h     = PatternFill("solid", fgColor="1F3864")
    font_h     = Font(bold=True, color="FFFFFF", size=10)
    fill_green = PatternFill("solid", fgColor="E2EFDA")
    fill_amber = PatternFill("solid", fgColor="FFF2CC")
    fill_red   = PatternFill("solid", fgColor="FFE0E0")
    fill_blue  = PatternFill("solid", fgColor="DDEEFF")

    import datetime as _dt
    run_ts = _dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

    audit_df = pd.DataFrame()
    if master_df is not None and ml_scorer is not None and cfg is not None:
        try:
            audit_df = build_audit_sheet(
                results.get("direct"), results.get("review"), results.get("unresolved"),
                master_path, master_df, ml_scorer, cfg, run_ts,
            )
        except Exception as _ae:
            log.warning("  Could not build audit sheet: %s", _ae)

    sheets = [
        ("direct",               results["direct"],                       fill_green),
        ("review",               results["review"],                       fill_amber),
        ("cross_dataset_match",  results.get("cross_dataset_match", pd.DataFrame()), fill_amber),
        ("unresolved",           results["unresolved"],                   fill_red),
        ("unmapped_raw",         results["unmapped_raw"],                 fill_blue),
        ("coverage",             results["coverage"],                     None),
        ("_Mapping_Audit",       audit_df,                                None),
    ]

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        for sn, df, _ in sheets:
            data = df if (df is not None and not df.empty) else pd.DataFrame({"(empty)": []})
            data.to_excel(writer, sheet_name=sn, index=False)

        wb = writer.book
        for sn, df, row_fill in sheets:
            if sn not in wb.sheetnames:
                continue
            ws = wb[sn]
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = fill_h
                cell.font = font_h
                cell.alignment = Alignment(horizontal="center")

            if row_fill and sn in ("direct", "review") and df is not None and not df.empty:
                sci = next(
                    (i for i, c in enumerate(ws[1], 1) if str(c.value) == "COMPOSITE_SCORE"),
                    None,
                )
                if sci:
                    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
                        try:
                            v = float(row[sci - 1].value or 0)
                            f = fill_green if v >= 0.82 else fill_amber if v >= 0.55 else fill_red
                            for cell in row:
                                cell.fill = f
                        except (TypeError, ValueError):
                            pass

            for ci in range(1, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(ci)].width = min(
                    max(
                        10,
                        max(
                            (len(str(ws.cell(r, ci).value or ""))
                             for r in range(1, min(ws.max_row + 1, 200))),
                            default=8,
                        ) + 2,
                    ),
                    60,
                )

    log.info("  Results -> %s", out_path)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run(master_path, raw_path, spec_path=None, out_path=None, config_path=None):
    """Main callable API for the mapper."""
    cfg        = load_cfg(config_path or Path("config.yaml"))
    log_cfg    = cfg.get("logging", {})
    log        = get_logger(log_cfg.get("log_file", ""), log_cfg.get("level", "INFO"))
    out_path   = out_path or Path("mapping_results.xlsx")

    log.info("[MAP] Loading master: %s", master_path.name)
    master_df = pd.read_excel(
        master_path, sheet_name="master_all", engine="openpyxl", dtype=object,
    )
    master_df["MASTER_CONFIDENCE"] = pd.to_numeric(
        master_df.get("MASTER_CONFIDENCE", 0), errors="coerce",
    ).fillna(0.0)

    log.info("[MAP] Loading raw catalog: %s", raw_path.name)
    raw_df = read_raw_catalog(raw_path, cfg, log)

    sdtm_vars_df = None
    if spec_path and Path(spec_path).exists():
        log.info("[MAP] Loading SDTM spec: %s", Path(spec_path).name)
        sdtm_vars_df = read_spec_variables(Path(spec_path), cfg, log)
        if sdtm_vars_df is not None and not sdtm_vars_df.empty:
            log.info("  Spec variables to map: %d", len(sdtm_vars_df))

    if sdtm_vars_df is None or sdtm_vars_df.empty:
        log.info("[MAP] No spec provided - deriving variable list from master_top")
        sdtm_vars_df = pd.read_excel(
            master_path, sheet_name="master_top", engine="openpyxl", dtype=object,
        )
        sdtm_vars_df = (
            sdtm_vars_df[["DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL", "MAPPING_ACTION"]]
            .drop_duplicates(["DOMAIN", "SDTM_VARIABLE"])
            .reset_index(drop=True)
        )
        sdtm_vars_df["CORE"] = ""

    results = run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log, master_path=master_path)
    # FIX: ml is scoped inside run_mapping; retrieve it from the returned dict
    _ml = results.pop("_ml_scorer", None)
    write_results(results, out_path, log, master_path=master_path, master_df=master_df, ml_scorer=_ml, cfg=cfg)
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Map new study raw vars to SDTM.")
    ap.add_argument("--master", required=True)
    ap.add_argument("--raw",    required=True)
    ap.add_argument("--spec",   default=None)
    ap.add_argument("--out",    default="mapping_results.xlsx")
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()
    run(
        master_path=Path(args.master),
        raw_path=Path(args.raw),
        spec_path=args.spec,
        out_path=Path(args.out),
        config_path=Path(args.config),
    )
