"""
ml_scorer.py  —  v26
====================
ML-enhanced scoring for raw -> SDTM variable matching.

v26 changes:
  IMP-007  Training data contamination fix: exclude HARDCODE/DERIVE/PROTOCOL rows
           and trivial self-mappings from positive training pairs.
  IMP-008  Score calibration: Platt scaling (CalibratedClassifierCV) applied after
           model fit to align predict_proba output with true match frequency.
  IMP-009  Context feature defaults: ta_match / study_phase_match / sdtmig_version_match
           default to 0.5 (maximum uncertainty) instead of 0.85/0.90 when unknown.
           Known TA/phase mismatch now returns 0.3 (negative signal) not 0.5.
"""

from __future__ import annotations

import hashlib
import logging
import math
import pickle
import re
import warnings
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

from utils import _norm, _slug
from sdtm_knowledge import classify_variable, ALWAYS_DERIVED, PROTOCOL_VARS

log = logging.getLogger("sdtm_app.ml_scorer")

# ---------------------------------------------------------------------------
# String similarity primitives
# ---------------------------------------------------------------------------

def _jaro(s1: str, s2: str) -> float:
    if s1 == s2:
        return 1.0
    l1, l2 = len(s1), len(s2)
    if l1 == 0 or l2 == 0:
        return 0.0
    match_dist = max(l1, l2) // 2 - 1
    if match_dist < 0:
        match_dist = 0
    s1m = [False] * l1
    s2m = [False] * l2
    matches = 0
    for i in range(l1):
        lo = max(0, i - match_dist)
        hi = min(i + match_dist + 1, l2)
        for j in range(lo, hi):
            if s2m[j] or s1[i] != s2[j]:
                continue
            s1m[i] = s2m[j] = True
            matches += 1
            break
    if not matches:
        return 0.0
    k = t = 0
    for i in range(l1):
        if not s1m[i]:
            continue
        while not s2m[k]:
            k += 1
        if s1[i] != s2[k]:
            t += 1
        k += 1
    return (matches / l1 + matches / l2 + (matches - t / 2) / matches) / 3.0


def jaro_winkler(s1: str, s2: str, p: float = 0.1) -> float:
    j = _jaro(s1, s2)
    prefix = 0
    for c1, c2 in zip(s1[:4], s2[:4]):
        if c1 == c2:
            prefix += 1
        else:
            break
    return min(j + prefix * p * (1.0 - j), 1.0)


def char_ngram_sim(s1: str, s2: str, n: int = 3) -> float:
    g1 = {s1[i:i + n] for i in range(len(s1) - n + 1)}
    g2 = {s2[i:i + n] for i in range(len(s2) - n + 1)}
    if not g1 or not g2:
        return float(s1 == s2)
    return len(g1 & g2) / len(g1 | g2)


def prefix_match(s1: str, s2: str) -> float:
    if not s1 or not s2:
        return 0.0
    n = 0
    for a, b in zip(s1, s2):
        if a == b:
            n += 1
        else:
            break
    return n / min(len(s1), len(s2))


def token_set_overlap(s1: str, s2: str) -> float:
    def tokens(s):
        return set(re.findall(r"[A-Z]{2,}", s.upper()))
    t1, t2 = tokens(s1), tokens(s2)
    if not t1 or not t2:
        return 0.0
    return len(t1 & t2) / len(t1 | t2)


# ---------------------------------------------------------------------------
# Feature vector
# ---------------------------------------------------------------------------

FEATURE_NAMES = [
    "jaro_winkler", "char_3gram", "prefix_match", "token_set",
    "label_tfidf", "label_token_overlap",
    "format_is_date", "format_is_time", "type_num",
    "sdtm_is_timing", "sdtm_is_datetime",
    "domain_match_exact", "domain_match_prefix2",
    "master_conf", "is_sponsor_std", "in_master",
    # NOTE: var_class_derived / var_class_timing intentionally REMOVED
    # (target-side leakage; the training filter excludes ALWAYS_DERIVED
    # positives so these features deterministically split the classes
    # for the wrong reason). See REVIEW_v27.md item 13.
    "sdtmig_version_match", "ta_match", "study_phase_match",
]

_N_FEATURES = len(FEATURE_NAMES)


def build_feature_vector(
    raw_var: str, raw_dataset: str, raw_label: str,
    raw_format: str, raw_type: str,
    sdtm_var: str, sdtm_domain: str, sdtm_label: str,
    master_conf: float, is_sponsor_std: bool, in_master: bool,
    label_tfidf_score: float,
    study_sdtmig_version: str = "", study_ta: str = "", study_phase: str = "",
    master_sdtmig_version: str = "", master_ta: str = "", master_phase: str = "",
) -> np.ndarray:
    rv  = _slug(raw_var)
    sv  = _slug(sdtm_var)
    rl  = _norm(raw_label)
    sl  = _norm(sdtm_label)
    rds = _slug(raw_dataset)
    dom = _slug(sdtm_domain)
    fmt = _norm(raw_format).upper()
    typ = _norm(raw_type).upper()

    jw      = jaro_winkler(rv, sv)
    ng3     = char_ngram_sim(rv, sv, 3) if (len(rv) >= 3 and len(sv) >= 3) else float(rv == sv)
    pref    = prefix_match(rv, sv)
    tok_set = token_set_overlap(rv, sv)

    lbl_tov = token_set_overlap(rl, sl) if (rl and sl) else 0.0

    fmt_date = 1.0 if any(x in fmt for x in ("DATE", "YYMMDD", "DDMMYY", "DATETIME")) else 0.0
    fmt_time = 1.0 if any(x in fmt for x in ("TIME", "TOD", "HH")) else 0.0
    typ_num  = 1.0 if typ in ("N", "NUM", "NUMERIC", "FLOAT", "INTEGER") else 0.0

    sdtm_timing = 1.0 if re.search(r"(DT|TM|DTC|DTM)$", sv) else 0.0
    sdtm_dtm    = 1.0 if sv.endswith("DTC") or sv.endswith("DTM") else 0.0

    dom_exact  = 1.0 if rds == dom else 0.0
    dom_pref2  = 1.0 if (len(rds) >= 2 and len(dom) >= 2 and rds[:2] == dom[:2]) else 0.0

    mc   = float(master_conf) if master_conf else 0.0
    spon = 1.0 if is_sponsor_std else 0.0
    inm  = 1.0 if in_master else 0.0

    vc         = classify_variable(sdtm_var, sdtm_domain)
    # var_class_derived / var_class_timing removed — see FEATURE_NAMES note.
    # vc is computed only for parity with debug logging callers; not used here.
    _ = vc

    # IMP-009: Default to 0.5 (maximum uncertainty) when context is unknown.
    # Known mismatch = 0.3 (negative signal). Known match = 1.0.
    from study_metadata import version_weight
    if study_sdtmig_version and master_sdtmig_version:
        ver_match = version_weight(study_sdtmig_version, master_sdtmig_version)
    else:
        ver_match = 0.50   # was 0.90 — unknown means no information

    if study_ta and master_ta:
        ta_m = 1.0 if study_ta == master_ta else 0.30   # known mismatch = negative signal
    else:
        ta_m = 0.50   # was 0.85

    if study_phase and master_phase:
        ph_m = 1.0 if study_phase == master_phase else 0.30
    else:
        ph_m = 0.50   # was 0.85

    result = np.array([
        jw, ng3, pref, tok_set,
        label_tfidf_score, lbl_tov,
        fmt_date, fmt_time, typ_num,
        sdtm_timing, sdtm_dtm,
        dom_exact, dom_pref2,
        mc, spon, inm,
        ver_match, ta_m, ph_m,
    ], dtype=np.float32)

    assert len(result) == _N_FEATURES, (
        f"Feature vector length {len(result)} != {_N_FEATURES}. Update FEATURE_NAMES."
    )
    return result


# ---------------------------------------------------------------------------
# IMP-007: Training data filter
# ---------------------------------------------------------------------------

# Mapping actions that represent non-CRF assignments — exclude from ML positives
TRAINING_EXCLUDE_ACTIONS = frozenset({
    "HARDCODE", "HARD CODE", "PROTOCOL", "DERIVE", "DERIVED",
    "SEQNUM", "SEQUENCE", "DROP", "N/A", "NA", "NOT APPLICABLE",
    "NOT MAPPED", "EXCLUDE",
})


def _is_valid_training_positive(row: pd.Series) -> bool:
    """
    Return True if this master row represents a genuine CRF/eDT/Assigned
    mapping that the ML model should learn from.

    Excludes:
      - Hardcoded/protocol/derived actions
      - Always-derived variables (sequence counters etc.)
      - Trivial self-mappings where raw variable IS the SDTM variable
    """
    action   = str(row.get("MAPPING_ACTION", "") or "").strip().upper()
    raw_tok  = str(row.get("RAW_VARIABLE", "") or "").strip().upper()
    sdtm_var = str(row.get("SDTM_VARIABLE", "") or "").strip().upper()

    for excl in TRAINING_EXCLUDE_ACTIONS:
        if excl in action:
            return False

    bare_raw = raw_tok.split(".")[-1] if "." in raw_tok else raw_tok
    if _slug(bare_raw) == _slug(sdtm_var):
        return False   # trivial self-mapping teaches nothing

    if sdtm_var in ALWAYS_DERIVED:
        return False

    return True


# ---------------------------------------------------------------------------
# Training data builder
# ---------------------------------------------------------------------------

def build_training_data(master_df: pd.DataFrame) -> tuple:
    """
    Build feature matrix X and label vector y from master_mapping.
    Positive pairs: filtered by _is_valid_training_positive (IMP-007).
    Negative pairs: 2 cross-domain + 1 same-domain + 1 hard negative per positive.
    label_tfidf=0.0 for all training rows (no new-study leakage).
    """
    all_pos = master_df[
        master_df["RAW_VARIABLE"].notna()
        & (master_df["RAW_VARIABLE"].astype(str).str.strip() != "")
        & (master_df["RAW_VARIABLE"].astype(str).str.upper() != "NAN")
    ].copy()

    # IMP-007: filter out contaminating rows
    pos_rows = all_pos[all_pos.apply(_is_valid_training_positive, axis=1)]

    if pos_rows.empty:
        return np.zeros((0, _N_FEATURES)), np.array([])

    sdtm_entries = (
        master_df[["DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL"]]
        .drop_duplicates()
        .to_dict("records")
    )

    domain_buckets: dict[str, list] = {}
    for e in sdtm_entries:
        domain_buckets.setdefault(e["DOMAIN"], []).append(e)

    rng = np.random.default_rng(42)

    X_rows: list = []
    y_rows: list = []

    for _, row in pos_rows.iterrows():
        raw_tok   = str(row.get("RAW_VARIABLE", "") or "")
        raw_parts = raw_tok.split(".")
        raw_var   = raw_parts[-1] if raw_parts else raw_tok
        raw_ds    = raw_parts[-2] if len(raw_parts) >= 2 else raw_parts[0]
        sdtm_var  = str(row.get("SDTM_VARIABLE", "") or "")
        sdtm_dom  = str(row.get("DOMAIN", "") or "")
        sdtm_lbl  = str(row.get("SDTM_LABEL", "") or "")
        mc        = float(row.get("MASTER_CONFIDENCE", 0) or 0)
        spon      = bool(row.get("IS_SPONSOR_STD", False))

        if not raw_var or not sdtm_var:
            continue

        fv = build_feature_vector(
            raw_var, raw_ds, "", "", "",
            sdtm_var, sdtm_dom, sdtm_lbl,
            mc, spon, True, 0.0,
        )
        X_rows.append(fv)
        y_rows.append(1)

        negatives_added = 0

        cross_pool = [e for e in sdtm_entries if e["DOMAIN"] != sdtm_dom]
        if cross_pool:
            chosen = rng.choice(len(cross_pool), size=min(2, len(cross_pool)), replace=False)
            for idx in chosen:
                neg = cross_pool[int(idx)]
                fv_neg = build_feature_vector(
                    raw_var, raw_ds, "", "", "",
                    neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                    0.0, False, False, 0.0,
                )
                X_rows.append(fv_neg)
                y_rows.append(0)
                negatives_added += 1

        same_dom = [e for e in domain_buckets.get(sdtm_dom, [])
                    if e["SDTM_VARIABLE"] != sdtm_var]
        if same_dom:
            neg = same_dom[int(rng.integers(0, len(same_dom)))]
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "", "", "",
                neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            negatives_added += 1

        rv_slug = _slug(raw_var)
        hard_candidates = [
            e for e in domain_buckets.get(sdtm_dom, [])
            if e["SDTM_VARIABLE"] != sdtm_var
            and jaro_winkler(rv_slug, _slug(e["SDTM_VARIABLE"])) > 0.55
        ]
        if hard_candidates:
            neg = hard_candidates[int(rng.integers(0, len(hard_candidates)))]
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "", "", "",
                neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            negatives_added += 1

        while negatives_added < 4 and cross_pool:
            neg = cross_pool[int(rng.integers(0, len(cross_pool)))]
            if neg["SDTM_VARIABLE"] == sdtm_var:
                continue
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "", "", "",
                neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            negatives_added += 1

    if not X_rows:
        return np.zeros((0, _N_FEATURES)), np.array([])

    X = np.vstack(X_rows)
    y = np.array(y_rows, dtype=np.int32)
    return X, y


# ---------------------------------------------------------------------------
# Model persistence helpers
# ---------------------------------------------------------------------------

def _master_sha256(master_df: pd.DataFrame) -> str:
    key_cols = ["DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE", "MASTER_CONFIDENCE"]
    available = [c for c in key_cols if c in master_df.columns]
    return hashlib.sha256(
        master_df[available].to_csv(index=False).encode()
    ).hexdigest()[:16]


def _model_cache_paths(master_path: Path) -> tuple[Path, Path]:
    stem   = master_path.stem
    parent = master_path.parent
    return parent / f"{stem}_ml_model.pkl", parent / f"{stem}_ml_model.pkl.hash"


def save_model(model, master_df: pd.DataFrame, master_path: Path) -> None:
    pkl_path, hash_path = _model_cache_paths(master_path)
    try:
        with open(pkl_path, "wb") as f:
            pickle.dump(model, f, protocol=pickle.HIGHEST_PROTOCOL)
        hash_path.write_text(_master_sha256(master_df))
        log.info("MLScorer: model saved to %s", pkl_path.name)
    except Exception as exc:
        log.warning("MLScorer: could not save model (%s).", exc)


def load_model(master_df: pd.DataFrame, master_path: Path):
    pkl_path, hash_path = _model_cache_paths(master_path)
    if not pkl_path.exists() or not hash_path.exists():
        return None
    try:
        stored_hash  = hash_path.read_text().strip()
        current_hash = _master_sha256(master_df)
        if stored_hash != current_hash:
            log.info("MLScorer: master changed. Retraining.")
            return None
        with open(pkl_path, "rb") as f:
            model = pickle.load(f)
        log.info("MLScorer: loaded cached model from %s", pkl_path.name)
        return model
    except Exception as exc:
        log.warning("MLScorer: could not load cached model (%s). Retraining.", exc)
        return None


# ---------------------------------------------------------------------------
# ML Scorer class
# ---------------------------------------------------------------------------

class MLScorer:
    """
    HistGradientBoostingClassifier with Platt-scaling calibration.

    v26 changes:
      IMP-007  Training filtered: HARDCODE/DERIVE/PROTOCOL rows excluded
      IMP-008  CalibratedClassifierCV (sigmoid) applied post-fit
      IMP-009  Context feature defaults changed to 0.5 (uncertainty)
    """

    MIN_TRAIN_POSITIVES = 10

    def __init__(self):
        self._model   = None   # calibrated model (post IMP-008)
        self._trained = False
        self._n_pos   = 0
        self._fallback_weights = {
            "jaro_winkler": 0.35,
            "char_3gram":   0.10,
            "label_tfidf":  0.25,
            "master_conf":  0.20,
            "domain_match": 0.10,
        }

    def train(self, master_df: pd.DataFrame, log_=None,
              master_path: Optional[Path] = None) -> None:
        logger = log_ or log

        if master_path is not None:
            cached = load_model(master_df, master_path)
            if cached is not None:
                self._model   = cached
                self._trained = True
                return

        X, y = build_training_data(master_df)
        self._n_pos = int((y == 1).sum()) if len(y) > 0 else 0

        logger.info("  MLScorer: %d positive pairs (filtered), %d total training examples",
                    self._n_pos, len(y))

        if self._n_pos < self.MIN_TRAIN_POSITIVES:
            logger.warning("  MLScorer: insufficient training data (%d pos). Fallback mode.",
                           self._n_pos)
            self._trained = False
            return

        try:
            from sklearn.ensemble import HistGradientBoostingClassifier
            from sklearn.calibration import CalibratedClassifierCV
            from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
        except ImportError:
            logger.warning("  MLScorer: sklearn not available. Fallback mode.")
            self._trained = False
            return

        n_neg      = int((y == 0).sum())
        pos_weight = n_neg / max(self._n_pos, 1)

        base_model = HistGradientBoostingClassifier(
            max_iter=200,
            max_depth=5,
            learning_rate=0.08,
            min_samples_leaf=5,
            l2_regularization=0.1,
            class_weight={0: 1.0, 1: pos_weight},
            random_state=42,
        )

        # IMP-008 (v27 revision): Calibration via 5-fold stratified
        # cross-validation, isotonic when n_pos >= 50 (more robust to
        # imbalance + nonlinear calibration curves), sigmoid for smaller
        # samples. cv="prefit" with sigmoid was deflating positive scores
        # systematically because the calibrator ignored class_weight.
        try:
            min_class_n = min(self._n_pos, n_neg)
            cv_folds = min(5, max(2, min_class_n // 2))
            method = "isotonic" if self._n_pos >= 50 else "sigmoid"
            calibrated = CalibratedClassifierCV(
                base_model, method=method, cv=cv_folds,
            )
            calibrated.fit(X, y)
            self._model   = calibrated
            self._trained = True
            logger.info(
                "  MLScorer: HistGBT trained with %s calibration (cv=%d).",
                method, cv_folds,
            )
        except Exception as cal_err:
            # Fallback: fit on full data without calibration
            logger.warning("  MLScorer: calibration failed (%s). Fitting without.", cal_err)
            base_model.fit(X, y)
            self._model   = base_model
            self._trained = True

        # CV evaluation on full data
        n_splits = min(5, max(2, self._n_pos // 4))
        try:
            eval_model = HistGradientBoostingClassifier(
                max_iter=200, max_depth=5, learning_rate=0.08,
                min_samples_leaf=5, l2_regularization=0.1,
                class_weight={0: 1.0, 1: pos_weight}, random_state=42,
            )
            cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
            cv_results = cross_validate(
                eval_model, X, y, cv=cv,
                scoring=["roc_auc", "average_precision", "f1"],
                n_jobs=1,
            )
            logger.info(
                "  MLScorer: %d-fold CV | ROC-AUC=%.3f+/-%.3f | AP=%.3f+/-%.3f | "
                "F1=%.3f+/-%.3f | n_pos=%d | pos_weight=%.1f",
                n_splits,
                cv_results["test_roc_auc"].mean(), cv_results["test_roc_auc"].std() * 2,
                cv_results["test_average_precision"].mean(),
                cv_results["test_average_precision"].std() * 2,
                cv_results["test_f1"].mean(), cv_results["test_f1"].std() * 2,
                self._n_pos, pos_weight,
            )
        except Exception as cv_err:
            logger.info("  MLScorer: CV unavailable: %s", cv_err)

        # Feature importances (from base model inside calibrated wrapper)
        try:
            base = getattr(self._model, "estimator", self._model)
            importances = sorted(
                zip(FEATURE_NAMES, base.feature_importances_),
                key=lambda x: -x[1],
            )
            top5 = ", ".join(f"{n}={v:.3f}" for n, v in importances[:5])
            logger.info("  MLScorer: top-5 features: %s", top5)
        except Exception:
            pass

        if master_path is not None:
            save_model(self._model, master_df, master_path)

    def score(self, raw_var, raw_dataset, raw_label, raw_format, raw_type,
              sdtm_var, sdtm_domain, sdtm_label,
              master_conf, is_sponsor_std, in_master, label_tfidf_score) -> float:
        fv = build_feature_vector(
            raw_var, raw_dataset, raw_label, raw_format, raw_type,
            sdtm_var, sdtm_domain, sdtm_label,
            master_conf, is_sponsor_std, in_master, label_tfidf_score,
        )
        return self._predict(
            fv, raw_var, raw_dataset, sdtm_var, sdtm_domain,
            master_conf, label_tfidf_score,
        )

    def score_batch(self, raw_var, raw_dataset, raw_label, raw_format, raw_type,
                    candidates: list) -> list:
        if not candidates:
            return []
        fvs = [
            build_feature_vector(
                raw_var, raw_dataset, raw_label, raw_format, raw_type,
                c["sdtm_var"], c["sdtm_domain"], c.get("sdtm_label", ""),
                c.get("master_conf", 0.0), c.get("is_sponsor_std", False),
                c.get("in_master", False), c.get("label_tfidf_score", 0.0),
            )
            for c in candidates
        ]
        X = np.vstack(fvs)
        if self._trained and self._model is not None:
            probs = self._model.predict_proba(X)[:, 1]
            return [float(p) for p in probs]
        rv_slug  = _slug(raw_var)
        rds_slug = _slug(raw_dataset)
        return [
            self._fallback_score(rv_slug, rds_slug,
                                 c["sdtm_var"], c["sdtm_domain"],
                                 c.get("master_conf", 0.0),
                                 c.get("label_tfidf_score", 0.0))
            for c in candidates
        ]

    def _predict(self, fv, raw_var, raw_dataset, sdtm_var, sdtm_domain,
                 master_conf, label_tfidf_score) -> float:
        if self._trained and self._model is not None:
            return float(self._model.predict_proba(fv.reshape(1, -1))[0, 1])
        # FIX (review item 7): thread sdtm_var/sdtm_domain to fallback so
        # name similarity and domain match still contribute when the model
        # is in fallback mode. Previously these were "" and the score
        # collapsed to (0.20*master_conf + 0.25*label_tfidf).
        return self._fallback_score(
            _slug(raw_var), _slug(raw_dataset),
            sdtm_var, sdtm_domain,
            master_conf, label_tfidf_score,
        )

    def _fallback_score(self, rv_slug, rds_slug, sdtm_var, sdtm_domain,
                        master_conf, label_tfidf_score) -> float:
        sv  = _slug(sdtm_var)
        dom = _slug(sdtm_domain)
        jw  = jaro_winkler(rv_slug, sv)
        ng3 = char_ngram_sim(rv_slug, sv, 3) if (len(rv_slug) >= 3 and len(sv) >= 3) else float(rv_slug == sv)
        dom_m = 1.0 if (len(rds_slug) >= 2 and len(dom) >= 2 and rds_slug[:2] == dom[:2]) else 0.0
        mc    = float(master_conf or 0)
        lbl   = float(label_tfidf_score or 0)
        return min(0.35 * jw + 0.10 * ng3 + 0.20 * mc + 0.25 * lbl + 0.10 * dom_m, 1.0)

    @property
    def is_trained(self) -> bool:
        return self._trained

    def feature_names(self) -> list:
        return list(FEATURE_NAMES)
