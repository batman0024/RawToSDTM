"""
origin_normalization.py
=======================
Shared helpers for normalising mapper-inferred origin strings to the
Define-XML 2.1 controlled values used in spec workbooks.

Two callers consume this:
  * master_builder.py — when reading existing specs to learn from
  * spec_writeback.py — when populating Origin cells in the new study spec

Define-XML 2.1 origin codelist (the canonical set):
  Collected, Derived, Assigned, Protocol, Predecessor, Not Available

Sponsor specs commonly extend the canonical values with subcategories
separated by "/" or "|":
  Collected/Investigator, Collected/Subject, Collected/Vendor,
  Derived/Vendor, Derived/Sponsor,
  Assigned/Vendor, Assigned/Sponsor,
  Protocol/Sponsor

The mapper produces five inferred categories:
  CRF, Derived, Protocol, eDT, Assigned

Mapping order:
  1. If the spec workbook's Maintenance / Valuelist tab is loaded,
     prefer the closest-keyword value from that set.
  2. Otherwise return the canonical Define-XML value.

This module is import-safe: pure data + small functions, no I/O.
"""

from __future__ import annotations

from typing import Iterable, Optional


# ---------------------------------------------------------------------------
# Define-XML 2.1 canonical origin values (the only legal values
# at the level of the CDISC controlled terminology; sponsor extensions
# add slash-suffixes that we treat as valid extensions, not aliases).
# ---------------------------------------------------------------------------

CDISC_CANONICAL_ORIGINS: frozenset = frozenset({
    "Collected", "Derived", "Assigned", "Protocol",
    "Predecessor", "Not Available",
})

# Common sponsor extensions seen in Define-XML 2.1 specs.
# Used as the fallback pool when the spec's Maintenance tab is unavailable.
CDISC_SPONSOR_EXTENSIONS: frozenset = frozenset({
    "Collected/Investigator", "Collected/Subject", "Collected/Vendor",
    "Derived/Vendor", "Derived/Sponsor",
    "Assigned/Vendor", "Assigned/Sponsor",
    "Protocol/Sponsor",
})

CDISC_ORIGIN_VALUES: frozenset = CDISC_CANONICAL_ORIGINS | CDISC_SPONSOR_EXTENSIONS


# ---------------------------------------------------------------------------
# Inferred -> (search keywords, default canonical fallback) signatures
#
# Order matters: PROTOCOL must come before ASSIGNED so that a spec listing
# both "Protocol" and "Assigned/Sponsor" picks "Protocol" for protocol vars.
# ---------------------------------------------------------------------------

ORIGIN_SIGNATURES: list[tuple[str, list[str], str]] = [
    # (inferred_key, required_keywords, canonical_fallback)
    ("CRF",         ["collected", "investigator"], "Collected/Investigator"),
    ("DERIVED",     ["derived"],                   "Derived"),
    ("PROTOCOL",    ["protocol"],                  "Protocol"),
    ("EDT",         ["collected", "vendor"],       "Collected/Vendor"),
    ("EDTTRANSFER", ["collected", "vendor"],       "Collected/Vendor"),
    ("ASSIGNED",    ["assigned"],                  "Assigned"),
    # Synonyms
    ("COLLECTED",   ["collected", "investigator"], "Collected/Investigator"),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def normalize_origin_to_cdisc(
    raw_origin: str,
    valid_origins: Optional[Iterable[str]] = None,
) -> str:
    """
    Map an inferred origin string to the nearest valid Define-XML origin.

    Strategy:
      1. If raw_origin is already exactly in valid_origins (or in the canonical
         set), return it as-is.
      2. Otherwise look up its inferred-category signature and pick the best
         keyword match from valid_origins (sponsor extensions seen in spec).
      3. Fall back to the canonical default ("Protocol", "Derived", etc.).

    Args:
        raw_origin:    one of CRF, Derived, Protocol, eDT, Assigned, or any
                       canonical / sponsor-extension value already.
        valid_origins: optional iterable from the spec's Maintenance tab.

    Returns:
        A string suitable for writing into the Origin cell of the spec.
    """
    if not raw_origin:
        return raw_origin

    pool: set = set(valid_origins) if valid_origins else set(CDISC_ORIGIN_VALUES)
    ro_up = raw_origin.upper().strip()

    # 1. Direct hit — handle case-mismatch but exact-string match
    if raw_origin in pool:
        return raw_origin
    for v in pool:
        if v.upper() == ro_up:
            return v

    # 2. Find the matching signature
    matched_keywords = None
    matched_fallback = None
    for (key, keywords, fallback) in ORIGIN_SIGNATURES:
        if ro_up == key or ro_up.startswith(key):
            matched_keywords = keywords
            matched_fallback = fallback
            break

    if matched_keywords is None:
        # Not a recognised inferred key — return as-is so the user sees
        # the unexpected value in the cell rather than silent overwrite.
        return raw_origin

    # 3. Try to find best keyword match from the pool
    if pool:
        best_match = None
        best_score = 0
        for vo in pool:
            vo_norm = (
                vo.lower()
                  .replace("|", " ")
                  .replace("/", " ")
                  .replace("-", " ")
            )
            matches = sum(1 for kw in matched_keywords if kw in vo_norm)
            if matches > best_score:
                best_score = matches
                best_match = vo
        if best_match is not None and best_score > 0:
            return best_match

    return matched_fallback


def is_valid_origin(value: str, valid_origins: Optional[Iterable[str]] = None) -> bool:
    """True if value is in valid_origins (if provided) or the canonical set."""
    if not value:
        return False
    pool = set(valid_origins) if valid_origins else set(CDISC_ORIGIN_VALUES)
    if value in pool:
        return True
    vu = value.upper()
    return any(v.upper() == vu for v in pool)


# ---------------------------------------------------------------------------
# Origin priority — used by spec_writeback when deciding whether to
# overwrite an existing Origin cell.  Lower number = higher priority.
# Two values matter for safe writeback:
#   * Manual entries (anything outside the recognised set) get priority 0
#     so they are NEVER overwritten by an automated mapping.
#   * Within the recognised set, more-specific origins (CRF) win over
#     less-specific (Assigned), reflecting the Define-XML decision rule.
# ---------------------------------------------------------------------------

_ORIGIN_PRIORITY_TABLE: dict = {
    "COLLECTED":           1,
    "CRF":                 1,
    "COLLECTED/INVESTIGATOR": 1,
    "COLLECTED/SUBJECT":   1,
    "COLLECTED/VENDOR":    2,
    "EDT":                 2,
    "DERIVED":             3,
    "DERIVED/SPONSOR":     3,
    "DERIVED/VENDOR":      3,
    "PROTOCOL":            4,
    "PROTOCOL/SPONSOR":    4,
    "ASSIGNED":            5,
    "ASSIGNED/SPONSOR":    5,
    "ASSIGNED/VENDOR":     5,
    "PREDECESSOR":         6,
    "NOT AVAILABLE":       9,
}


def origin_priority(value: str) -> int:
    """
    Return numeric priority for an origin value.

    A return of 0 means "manual entry — do not overwrite".  Recognised
    canonical/sponsor values get 1..9.  Empty/blank returns 99 (lowest).
    """
    if not value:
        return 99
    v = str(value).upper().strip()
    if v in _ORIGIN_PRIORITY_TABLE:
        return _ORIGIN_PRIORITY_TABLE[v]
    # Unrecognised values: treat as manual entries — never overwrite
    return 0
