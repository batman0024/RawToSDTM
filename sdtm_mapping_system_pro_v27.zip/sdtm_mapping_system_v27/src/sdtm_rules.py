"""
sdtm_rules.py
=============
Canonical SDTM rule table — single source of truth for variables whose
origin and mapping action are determined by the SDTMIG, not by raw mapping.

Every entry says, for one SDTM variable (or pattern):
  origin     : Define-XML 2.1 origin value
  action     : controlled mapping action keyword
  needs_raw  : whether a raw CRF/eDT source is expected
  algorithm  : human-readable derivation note (for Derived variables)

Rule lookup order (mapper.py uses this):
  1. Exact (DOMAIN, VARIABLE) match
  2. Exact VARIABLE match (any domain)
  3. Pattern match (regex)
  4. None  -> variable is not rule-bound; mapper falls through to fuzzy fallback

Origin values follow Define-XML 2.1 controlled terminology:
  Collected, Derived, Assigned, Protocol, Predecessor, Not Available

The strings used here ("CRF", "eDT", "Assigned/Sponsor", etc.) are sponsor
spec extensions that get normalised in spec_writeback via the spec's own
Maintenance / Valuelist tab.  See origin_normalization.py.

This module is import-safe: pure data + small functions, no I/O.
"""

from __future__ import annotations

import re
from typing import Optional


# ---------------------------------------------------------------------------
# Rule schema
# ---------------------------------------------------------------------------

# Each rule is a dict with these keys (all strings; all optional except origin and action):
#   origin        Protocol | Derived | Assigned | Collected | Predecessor | Not Available
#   action        HARDCODE | DERIVE | ASSIGN | CODELIST_MAP | ISO8601_DATETIME | ...
#   needs_raw     True if the variable is expected to have a raw CRF/eDT source
#   algorithm     short narrative for Derived variables
#   confidence    [0..1] origin confidence reported in the audit


# ---------------------------------------------------------------------------
# 1.  Exact-match rules — keyed by (DOMAIN, VARIABLE)
#     (use this when the variable has different semantics in different domains)
# ---------------------------------------------------------------------------

EXACT_RULES: dict[tuple, dict] = {
    # DM identifiers / protocol-assigned values
    ("DM", "STUDYID"): {
        "origin": "Protocol", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Hardcoded sponsor study identifier", "confidence": 0.95,
    },
    ("DM", "DOMAIN"): {
        "origin": "Assigned", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Hardcoded domain abbreviation 'DM'", "confidence": 0.99,
    },
    # USUBJID is derived as STUDYID || '-' || SUBJID per SDTMIG
    ("DM", "USUBJID"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "STUDYID || '-' || SUBJID", "confidence": 0.95,
    },
    # ARM/ACTARM are assigned at randomisation (have a raw source: rand dataset)
    ("DM", "ARM"): {
        "origin": "Assigned", "action": "ASSIGN", "needs_raw": True,
        "algorithm": "Planned arm assigned at randomisation", "confidence": 0.85,
    },
    ("DM", "ACTARM"): {
        "origin": "Assigned", "action": "ASSIGN", "needs_raw": True,
        "algorithm": "Actual arm received", "confidence": 0.85,
    },
    ("DM", "ARMCD"): {
        "origin": "Assigned", "action": "ASSIGN", "needs_raw": True,
        "algorithm": "Planned arm code from randomisation", "confidence": 0.85,
    },
    ("DM", "ACTARMCD"): {
        "origin": "Assigned", "action": "ASSIGN", "needs_raw": True,
        "algorithm": "Actual arm code", "confidence": 0.85,
    },
    # RF*DTC reference dates — DERIVED, never hardcoded
    ("DM", "RFSTDTC"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "min(EX.EXSTDTC) per USUBJID, fallback to first study contact",
        "confidence": 0.90,
    },
    ("DM", "RFENDTC"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "max(EX.EXENDTC) per USUBJID, fallback to last study contact",
        "confidence": 0.90,
    },
    ("DM", "RFICDTC"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Earliest informed-consent date per subject",
        "confidence": 0.90,
    },
    ("DM", "RFPENDTC"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Date of end of subject participation",
        "confidence": 0.90,
    },
    ("DM", "RFXSTDTC"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Date/time of first study treatment exposure (min EX.EXSTDTC)",
        "confidence": 0.90,
    },
    ("DM", "RFXENDTC"): {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Date/time of last study treatment exposure (max EX.EXENDTC)",
        "confidence": 0.90,
    },
    # SUPPQUAL structural variables — hardcoded per SDTMIG
    ("SUPPQUAL", "RDOMAIN"): {
        "origin": "Assigned", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Source domain abbreviation", "confidence": 0.99,
    },
    ("SUPPQUAL", "IDVAR"): {
        "origin": "Assigned", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Source identifier variable name", "confidence": 0.99,
    },
    ("SUPPQUAL", "IDVARVAL"): {
        "origin": "Assigned", "action": "ASSIGN", "needs_raw": False,
        "algorithm": "Source identifier value, copied per row", "confidence": 0.95,
    },
    ("SUPPQUAL", "QORIG"): {
        "origin": "Assigned", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Origin of QVAL (CRF / Derived / etc.)", "confidence": 0.95,
    },
    ("SUPPQUAL", "QEVAL"): {
        "origin": "Assigned", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Evaluator (sponsor / investigator / vendor)", "confidence": 0.95,
    },
}


# ---------------------------------------------------------------------------
# 2.  Variable-name rules — keyed by VARIABLE (any domain)
# ---------------------------------------------------------------------------

VARIABLE_RULES: dict[str, dict] = {
    # Trial design / protocol values (always hardcoded)
    "STUDYID": {
        "origin": "Protocol", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Hardcoded sponsor study identifier", "confidence": 0.95,
    },
    "DOMAIN": {
        "origin": "Assigned", "action": "HARDCODE", "needs_raw": False,
        "algorithm": "Hardcoded domain abbreviation", "confidence": 0.99,
    },

    # USUBJID is always derived
    "USUBJID": {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "STUDYID || '-' || SUBJID", "confidence": 0.95,
    },

    # Treatment-period variables — derived from joins to TS / EX
    "EPOCH": {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Looked up against SE.SESTDTC/SEENDTC for record's --DTC",
        "confidence": 0.85,
    },
    "TRTP": {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Planned treatment per ARM at the record's epoch",
        "confidence": 0.85,
    },
    "TRTA": {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Actual treatment received at the record's epoch",
        "confidence": 0.85,
    },
    "TRTPN": {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Numeric coded planned treatment", "confidence": 0.85,
    },
    "TRTAN": {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Numeric coded actual treatment", "confidence": 0.85,
    },
}


# ---------------------------------------------------------------------------
# 3.  Pattern rules — regex on the variable name (any domain)
#     Order matters: first match wins.
# ---------------------------------------------------------------------------

PATTERN_RULES: list[tuple[str, dict]] = [
    # --SEQ : sequence counters are always derived (within-USUBJID record number)
    (r"^.+SEQ$", {
        "origin": "Derived", "action": "SEQNUM", "needs_raw": False,
        "algorithm": "Within-subject sequential counter", "confidence": 0.95,
    }),

    # --DY : study day = (--DTC) - (RFSTDTC) + 1, with day-zero adjustment
    (r"^.+DY$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "(--DTC) - (RFSTDTC) + 1, with no day-zero (subtract 1 if --DTC < RFSTDTC)",
        "confidence": 0.92,
    }),

    # Baseline / last-observation flags : derived from per-subject record selection
    (r"^.+BLFL$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Y for the last non-missing record on or before RFSTDTC per subject",
        "confidence": 0.88,
    }),
    (r"^.+LOBXFL$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Y for last record before treatment exposure per subject",
        "confidence": 0.88,
    }),

    # Change / percent change / shift — derived ADaM-style values
    (r"^.*CHG$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Change from baseline = result - baseline", "confidence": 0.88,
    }),
    (r"^.*PCHG$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Percent change from baseline", "confidence": 0.88,
    }),
    (r"^.*SHIFT$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Categorical shift from baseline", "confidence": 0.85,
    }),

    # Reference range indicators — derived from --STRESN vs --NRLO/--NRHI
    (r"^.+NRIND$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "L/N/H based on STRESN comparison to NRLO/NRHI",
        "confidence": 0.88,
    }),

    # ANL{n}FL — analysis flags
    (r"^.+ANL\d+FL$", {
        "origin": "Derived", "action": "DERIVE", "needs_raw": False,
        "algorithm": "Sponsor-defined analysis-population flag", "confidence": 0.85,
    }),
]


# ---------------------------------------------------------------------------
# Lookup function
# ---------------------------------------------------------------------------

# Pre-compile patterns once at module load
_COMPILED_PATTERNS: list[tuple] = [(re.compile(p), r) for (p, r) in PATTERN_RULES]


def lookup_rule(domain: str, variable: str) -> Optional[dict]:
    """
    Return the rule dict for a given (domain, variable) pair, or None.

    Lookup order:
      1. Exact (DOMAIN, VARIABLE)
      2. VARIABLE alone
      3. First matching pattern

    Domain and variable are matched case-insensitively (normalised to upper).
    The returned dict is a *copy* so callers may not accidentally mutate it.
    """
    if not variable:
        return None
    dom = (domain or "").strip().upper()
    var = variable.strip().upper()

    rule = EXACT_RULES.get((dom, var))
    if rule is not None:
        return dict(rule)

    rule = VARIABLE_RULES.get(var)
    if rule is not None:
        return dict(rule)

    for compiled, payload in _COMPILED_PATTERNS:
        if compiled.match(var):
            return dict(payload)

    return None


def is_rule_bound(domain: str, variable: str) -> bool:
    """True if the variable's origin is determined by the rule table."""
    return lookup_rule(domain, variable) is not None


def needs_raw_source(domain: str, variable: str) -> bool:
    """
    True if the rule expects a raw CRF/eDT source for this variable
    (e.g. ARM, ACTARM, QVAL).  Variables not in the rule table return False
    so the mapper continues with master/fuzzy lookup.
    """
    rule = lookup_rule(domain, variable)
    return bool(rule and rule.get("needs_raw", False))
