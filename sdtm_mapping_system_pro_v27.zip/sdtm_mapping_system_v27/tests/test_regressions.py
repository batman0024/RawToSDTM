"""
tests/test_regressions.py
=========================
Regression tests for every numbered item in REVIEW_v27.md.

Each test class corresponds to one bug from the v26 code review.  The
test name carries the review item number so failures are easy to map
back to the change that introduced them.

Run from the project root:
    python -m unittest tests.test_regressions -v
"""

from __future__ import annotations

import datetime as dt
import math
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd
from openpyxl import Workbook, load_workbook

# Add src to path
SRC_DIR = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(SRC_DIR))

CONFIG = SRC_DIR / "config.yaml"


# ===========================================================================
# Item 1: group_count NameError in legacy score_group_against_raw
# ===========================================================================

class TestItem01_GroupCountNameError(unittest.TestCase):
    """v26: NameError when all tokens of a master group were found in raw."""

    def test_all_tokens_found_no_crash(self):
        """Calling the parked legacy scorer with a fully-matched group must
        not raise NameError (which it did in v26)."""
        sys.path.insert(0, str(SRC_DIR / "_legacy"))
        from legacy_mapper import score_group_against_raw, LabelIndex, get_weights

        raw_df = pd.DataFrame([
            {"RAW_DATASET": "AE", "VARIABLE": "AESTDAT", "LABEL": "AE Start",
             "FORMAT": "", "TYPE": "C", "RAW_KEY": "AE.AESTDAT", "VAR_SLUG": "AESTDAT"},
            {"RAW_DATASET": "AE", "VARIABLE": "AESTTIM", "LABEL": "AE Time",
             "FORMAT": "", "TYPE": "C", "RAW_KEY": "AE.AESTTIM", "VAR_SLUG": "AESTTIM"},
        ])
        group_entry = {
            "GROUP_TOKENS":      "AE.AESTDAT|AE.AESTTIM",
            "MASTER_CONFIDENCE": 0.9,
            "GROUP_COUNT":       2,
            "SDTM_LABEL":        "Start Date",
            "IS_SPONSOR_STD":    False,
            "MAPPING_ACTION":    "",
            "GROUP_SIG":         "sig",
        }
        cfg = {"matching": {"weights": {
            "name_exact": 0.35, "name_fuzzy": 0.20,
            "label_tfidf": 0.25, "master_freq": 0.20,
        }}}
        weights = get_weights(cfg)
        lbl_idx = LabelIndex(raw_df)

        # Must not raise.  Score must be a float in [0, 1].
        score, resolved, frac, _ = score_group_against_raw(
            group_entry, raw_df, "AESTDTC", "adverse event start date",
            lbl_idx, weights, 1.0, 0.7,
        )
        self.assertIsInstance(score, float)
        self.assertGreaterEqual(score, 0.0)
        self.assertLessEqual(score, 1.0)
        self.assertEqual(frac, 1.0)
        self.assertEqual(len(resolved), 2)


# ===========================================================================
# Items 5, 6, 7, 8: SDTM rule correctness
# ===========================================================================

class TestItem05_RFSTDTCisDerived(unittest.TestCase):
    """v26: RFSTDTC was assigned action HARDCODE / origin Assigned/Sponsor.
    Per CDISC SDTMIG, RF*DTC reference dates are always derived."""

    def test_rfstdtc_rule_is_derived(self):
        from sdtm_rules import lookup_rule
        rule = lookup_rule("DM", "RFSTDTC")
        self.assertIsNotNone(rule)
        self.assertEqual(rule["origin"], "Derived")
        self.assertEqual(rule["action"], "DERIVE")
        self.assertFalse(rule["needs_raw"])
        self.assertIn("EXSTDTC", rule.get("algorithm", ""))

    def test_all_rf_timing_vars_are_derived(self):
        from sdtm_rules import lookup_rule
        for v in ("RFSTDTC", "RFENDTC", "RFICDTC", "RFPENDTC",
                  "RFXSTDTC", "RFXENDTC"):
            with self.subTest(var=v):
                rule = lookup_rule("DM", v)
                self.assertIsNotNone(rule, f"{v} should have a rule")
                self.assertEqual(rule["origin"], "Derived",
                                 f"{v} must be Derived, not {rule['origin']}")


class TestItem06_EPOCHisDerived(unittest.TestCase):
    """v26: EPOCH was in PROTOCOL_VARS -> HARDCODE.  Per CDISC, EPOCH is
    derived by looking up the record's --DTC against SE.SESTDTC/SEENDTC."""

    def test_epoch_rule_is_derived(self):
        from sdtm_rules import lookup_rule
        rule = lookup_rule("AE", "EPOCH")
        self.assertIsNotNone(rule)
        self.assertEqual(rule["origin"], "Derived")
        self.assertEqual(rule["action"], "DERIVE")
        self.assertIn("SE", rule.get("algorithm", ""))

    def test_trtp_trta_are_derived(self):
        from sdtm_rules import lookup_rule
        for v in ("TRTP", "TRTA", "TRTPN", "TRTAN"):
            with self.subTest(var=v):
                rule = lookup_rule("DM", v)
                self.assertIsNotNone(rule)
                self.assertEqual(rule["origin"], "Derived")


class TestItem07_StudyDayIsDerived(unittest.TestCase):
    """v26: --DY variables fell through to Assigned because is_date_variable
    only matched DT/DTC/DTM and classify_variable('LBDY') returned 'timing'.
    Study day is always derived: --DY = (--DTC) - (RFSTDTC) + 1."""

    def test_lbdy_rule_is_derived(self):
        from sdtm_rules import lookup_rule
        rule = lookup_rule("LB", "LBDY")
        self.assertIsNotNone(rule)
        self.assertEqual(rule["origin"], "Derived")
        self.assertIn("RFSTDTC", rule.get("algorithm", ""))

    def test_study_day_pattern_matches_all_domains(self):
        from sdtm_rules import lookup_rule
        for var in ("AESTDY", "CMSTDY", "EXSTDY", "VSDY", "EGDY", "PCDY"):
            with self.subTest(var=var):
                rule = lookup_rule("XX", var)
                self.assertIsNotNone(rule, f"{var} (--DY pattern) should have a rule")
                self.assertEqual(rule["origin"], "Derived")


class TestItem08_BaselineFlagsAreDerived(unittest.TestCase):
    """v26: --BLFL / --LOBXFL fell into VAR_CLASS_RULES 'flag' which routed
    to Assigned.  These are always derived per CDISC."""

    def test_blfl_is_derived(self):
        from sdtm_rules import lookup_rule
        for var in ("LBBLFL", "VSBLFL", "EGBLFL"):
            with self.subTest(var=var):
                rule = lookup_rule("XX", var)
                self.assertIsNotNone(rule, f"{var} should have a rule")
                self.assertEqual(rule["origin"], "Derived")

    def test_lobxfl_is_derived(self):
        from sdtm_rules import lookup_rule
        rule = lookup_rule("LB", "LBLOBXFL")
        self.assertIsNotNone(rule)
        self.assertEqual(rule["origin"], "Derived")

    def test_chg_pchg_shift_are_derived(self):
        from sdtm_rules import lookup_rule
        for var in ("LBCHG", "LBPCHG", "VSSHIFT"):
            with self.subTest(var=var):
                rule = lookup_rule("XX", var)
                self.assertIsNotNone(rule)
                self.assertEqual(rule["origin"], "Derived")


# ===========================================================================
# Item 9: CDM filter must not exclude SUBJECTID, SITENUMBER, SCREEN datasets
# ===========================================================================

class TestItem09_CdmFilterDefaults(unittest.TestCase):
    """v26: DEFAULT_CDM_VARIABLES contained SUBJECTID and SITENUMBER, the
    most common raw names for SDTM SUBJID/SITEID.  DEFAULT_CDM_DATASETS
    excluded SCREEN, SCREENFAIL etc. — often domain-equivalent CRF tables."""

    def test_subjectid_not_in_defaults(self):
        from cdm_filter import DEFAULT_CDM_VARIABLES
        self.assertNotIn("SUBJECTID", DEFAULT_CDM_VARIABLES,
                         "SUBJECTID is the canonical raw name for SDTM SUBJID")
        self.assertNotIn("SITENUMBER", DEFAULT_CDM_VARIABLES,
                         "SITENUMBER is the canonical raw name for SDTM SITEID")

    def test_screen_dataset_not_in_defaults(self):
        from cdm_filter import DEFAULT_CDM_DATASETS
        for ds in ("SCREEN", "SCREENFAIL", "PRERANDOM", "POSTRANDOM"):
            with self.subTest(dataset=ds):
                self.assertNotIn(ds, DEFAULT_CDM_DATASETS,
                                 f"{ds} often contains SDTM-mappable data")

    def test_real_cdm_vars_still_excluded(self):
        """Genuine EDC-internal fields must still be filtered."""
        from cdm_filter import CdmFilter
        f = CdmFilter()
        for v in ("CREATEDAT", "FORMOID", "STUDYOID", "QUERYID",
                  "WORKFLOWSTATE", "RECSTATUS"):
            with self.subTest(var=v):
                self.assertTrue(f.is_cdm_variable(v),
                                f"{v} should still be filtered as CDM")

    def test_subjectid_passes_filter(self):
        from cdm_filter import CdmFilter
        f = CdmFilter()
        self.assertFalse(f.is_cdm_variable("SUBJECTID"),
                         "SUBJECTID must reach the SDTM mapper")
        self.assertFalse(f.is_cdm_variable("SITENUMBER"),
                         "SITENUMBER must reach the SDTM mapper")

    def test_filter_catalog_is_vectorised(self):
        """The vectorised path returns the same result as before."""
        from cdm_filter import CdmFilter
        df = pd.DataFrame([
            {"RAW_DATASET": "AE",    "VARIABLE": "AETERM",    "LABEL": ""},
            {"RAW_DATASET": "AE",    "VARIABLE": "CREATEDAT", "LABEL": ""},
            {"RAW_DATASET": "AUDIT", "VARIABLE": "X",         "LABEL": ""},
            {"RAW_DATASET": "DM",    "VARIABLE": "SUBJECTID", "LABEL": ""},
        ])
        f = CdmFilter()
        usable, excluded = f.filter_catalog(df)
        self.assertEqual(set(usable["VARIABLE"]), {"AETERM", "SUBJECTID"})
        self.assertEqual(set(excluded["VARIABLE"]), {"CREATEDAT", "X"})


# ===========================================================================
# Item 10: PROTOCOL inference must map to "Protocol", not "Assigned/Sponsor"
# ===========================================================================

class TestItem10_ProtocolOrigin(unittest.TestCase):
    """v26: normalize_origin_to_cdisc had ('PROTOCOL', ['assigned','sponsor'],
    'Assigned/Sponsor') — wrong, conflated Protocol with Assigned/Sponsor."""

    def test_protocol_maps_to_protocol(self):
        from origin_normalization import normalize_origin_to_cdisc
        # No valid_origins constraint -> canonical fallback
        result = normalize_origin_to_cdisc("Protocol")
        self.assertEqual(result, "Protocol")

    def test_protocol_with_spec_pool_picks_protocol(self):
        """When the spec's Maintenance tab lists both Protocol and
        Assigned/Sponsor, PROTOCOL inference must pick Protocol."""
        from origin_normalization import normalize_origin_to_cdisc
        valid = {"Protocol", "Protocol/Sponsor", "Assigned/Sponsor",
                 "Collected/Investigator"}
        result = normalize_origin_to_cdisc("Protocol", valid)
        self.assertIn(result, ("Protocol", "Protocol/Sponsor"))

    def test_studyid_full_chain_returns_protocol(self):
        """End-to-end check: a STUDYID rule produces Protocol origin and
        the writeback normalises it to Protocol, not Assigned/Sponsor."""
        from sdtm_rules import lookup_rule
        from origin_normalization import normalize_origin_to_cdisc
        rule = lookup_rule("DM", "STUDYID")
        self.assertEqual(rule["origin"], "Protocol")
        normed = normalize_origin_to_cdisc(rule["origin"])
        self.assertEqual(normed, "Protocol")


# ===========================================================================
# Item 11: CDISC origin canonical set should not include 'CRF' or 'eDT'
# ===========================================================================

class TestItem11_CdiscOriginValues(unittest.TestCase):
    """v26: CDISC_ORIGIN_VALUES contained 'CRF' and 'eDT' as 'legacy SDTM 3.2'
    values.  These are not valid Define-XML 2.1 origin codelist values."""

    def test_canonical_values_correct(self):
        from origin_normalization import CDISC_CANONICAL_ORIGINS
        expected = {"Collected", "Derived", "Assigned", "Protocol",
                    "Predecessor", "Not Available"}
        self.assertEqual(CDISC_CANONICAL_ORIGINS, expected)

    def test_canonical_does_not_contain_crf(self):
        from origin_normalization import CDISC_CANONICAL_ORIGINS
        self.assertNotIn("CRF", CDISC_CANONICAL_ORIGINS)
        self.assertNotIn("eDT", CDISC_CANONICAL_ORIGINS)

    def test_master_builder_reexport_consistent(self):
        """master_builder must re-export the SAME CDISC_ORIGIN_VALUES."""
        from origin_normalization import CDISC_ORIGIN_VALUES as a
        from master_builder import CDISC_ORIGIN_VALUES as b
        self.assertEqual(a, b)


# ===========================================================================
# Item 12: infer_origin priority — derived class beats CRF
# ===========================================================================

class TestItem12_InferOriginPriority(unittest.TestCase):
    """v26: a derived variable (--BLFL, --SHIFT) whose bare name happened
    to match a CRF-collected raw token was misclassified as CRF.  Now the
    derived/flag/sequence class check fires first."""

    def test_blfl_with_crf_match_returns_derived(self):
        from sdtm_knowledge import infer_origin
        origin, _ = infer_origin(
            "AEBLFL", "AE", "",
            ["RAW.AE.AEBLFL"],
            crf_var_set={"AEBLFL"},  # the bug trigger
            als_var_set=set(),
            raw_dataset_set={"AE"},
        )
        self.assertEqual(origin, "Derived",
                         "Flag variables must be Derived even with name overlap")

    def test_aeseq_with_crf_match_returns_derived(self):
        from sdtm_knowledge import infer_origin
        origin, _ = infer_origin(
            "AESEQ", "AE", "SEQNUM",
            ["RAW.AE.AESEQ"],
            crf_var_set={"AESEQ"},
            als_var_set=set(),
            raw_dataset_set={"AE"},
        )
        self.assertEqual(origin, "Derived")

    def test_aeterm_still_correctly_crf(self):
        """Sanity: a real CRF variable still classifies as CRF."""
        from sdtm_knowledge import infer_origin
        origin, _ = infer_origin(
            "AETERM", "AE", "ASSIGN",
            ["RAW.AE.AETERM"],
            crf_var_set={"AETERM"},
            als_var_set=set(),
            raw_dataset_set={"AE"},
        )
        self.assertEqual(origin, "CRF")


# ===========================================================================
# Item 13: leaky var_class features removed from training vector
# ===========================================================================

class TestItem13_FeatureLeakageFix(unittest.TestCase):
    """v26: var_class_derived was 1 for ALWAYS_DERIVED targets but
    ALWAYS_DERIVED rows were filtered from positives, so the feature
    deterministically split classes for the wrong reason (target leakage)."""

    def test_var_class_features_removed(self):
        from ml_scorer import FEATURE_NAMES
        self.assertNotIn("var_class_derived", FEATURE_NAMES,
                         "Leaky feature removed in v27")
        self.assertNotIn("var_class_timing", FEATURE_NAMES,
                         "Leaky feature removed in v27")

    def test_feature_count_consistent(self):
        from ml_scorer import FEATURE_NAMES, _N_FEATURES
        self.assertEqual(len(FEATURE_NAMES), _N_FEATURES)

    def test_feature_vector_shape_matches(self):
        """build_feature_vector output length must equal FEATURE_NAMES length."""
        from ml_scorer import build_feature_vector, FEATURE_NAMES
        fv = build_feature_vector(
            "AETERM", "AE", "ae term", "", "C",
            "AETERM", "AE", "Adverse Event Term",
            0.9, True, True, 0.5,
        )
        self.assertEqual(len(fv), len(FEATURE_NAMES))


# ===========================================================================
# Item 7: parked _predict fallback now threads sdtm_var/sdtm_domain
# ===========================================================================

class TestItem07_FallbackPredictArgs(unittest.TestCase):
    """v26: _predict in fallback mode passed sdtm_var='' to _fallback_score,
    so name similarity and domain match collapsed to 0."""

    def test_fallback_uses_sdtm_var(self):
        """In fallback mode, identical raw_var and sdtm_var should
        produce a higher score than mismatched ones."""
        from ml_scorer import MLScorer
        m = MLScorer()
        # Force fallback: don't train
        same = m.score(
            "AETERM", "AE", "", "", "C",
            "AETERM", "AE", "Adverse Event Term",
            0.0, False, False, 0.0,
        )
        diff = m.score(
            "RANDOM", "XX", "", "", "C",
            "AETERM", "AE", "Adverse Event Term",
            0.0, False, False, 0.0,
        )
        self.assertGreater(same, diff,
                           "Fallback must use raw vs SDTM name similarity")


# ===========================================================================
# Item 16: master rebuild reproducible with reference_date
# ===========================================================================

class TestItem16_RecencyReproducibility(unittest.TestCase):
    """v26: _recency_weight used dt.datetime.now() so two runs with the same
    inputs on different days produced different MASTER_CONFIDENCE values."""

    def setUp(self):
        # Build a tiny raw_df with the columns build_master expects
        self.raw_df = pd.DataFrame([
            {"DOMAIN": "AE", "SDTM_VARIABLE": "AETERM",
             "GROUP_SIG": "ae_term", "GROUP_POSITION": 1, "GROUP_COUNT": 1,
             "RAW_VARIABLE": "AE.AETERM", "SDTM_LABEL": "AE Term",
             "MAPPING_ACTION": "ASSIGN", "ORIGIN": "CRF",
             "SOURCE_FILE": "study_a.xlsx", "STUDY_DATE": "2022-06-15",
             "IS_SPONSOR_STD": False},
            {"DOMAIN": "AE", "SDTM_VARIABLE": "AESTDTC",
             "GROUP_SIG": "ae_st", "GROUP_POSITION": 1, "GROUP_COUNT": 1,
             "RAW_VARIABLE": "AE.AESTDAT", "SDTM_LABEL": "AE Start Date",
             "MAPPING_ACTION": "ISO8601", "ORIGIN": "CRF",
             "SOURCE_FILE": "study_a.xlsx", "STUDY_DATE": "2022-06-15",
             "IS_SPONSOR_STD": False},
        ])
        self.cfg = {"master_build": {
            "conflict_strategy": "sponsor_priority",
            "recency_decay_years": 3,
            "recency_decay_factor": 0.85,
            "sponsor_boost_factor": 3.0,
        }}

    def test_same_reference_date_gives_same_confidence(self):
        from master_builder import build_master
        ref = dt.datetime(2026, 1, 1)
        m1 = build_master(self.raw_df, self.cfg, reference_date=ref)
        m2 = build_master(self.raw_df, self.cfg, reference_date=ref)
        self.assertTrue(m1["MASTER_CONFIDENCE"].equals(m2["MASTER_CONFIDENCE"]))

    def test_different_reference_dates_change_confidence(self):
        """Older runs should produce different recency weights, proving
        the parameter is actually plumbed through."""
        from master_builder import build_master
        m_2025 = build_master(self.raw_df, self.cfg,
                              reference_date=dt.datetime(2025, 1, 1))
        m_2030 = build_master(self.raw_df, self.cfg,
                              reference_date=dt.datetime(2030, 1, 1))
        # By 2030 the 2022 study is older; recency weight should be lower,
        # so MASTER_CONFIDENCE should differ.
        self.assertFalse(
            m_2025["MASTER_CONFIDENCE"].equals(m_2030["MASTER_CONFIDENCE"]),
            "reference_date must actually affect MASTER_CONFIDENCE",
        )


# ===========================================================================
# Item 3: writeback preserves custom dotted prefixes (EDC.*, RAVE.*)
# ===========================================================================

class TestItem03_PreserveCustomTokens(unittest.TestCase):
    """v26: _is_preserve_token only kept SDTM.*, WORK.*, plain identifiers.
    Custom sponsor-prefixed tokens like EDC.AESTDAT were silently dropped."""

    def test_preserves_edc_prefix(self):
        from spec_writeback import _is_preserve_token
        self.assertTrue(_is_preserve_token("EDC.AESTDAT"),
                        "Custom sponsor catalog references must be kept")
        self.assertTrue(_is_preserve_token("RAVE.AETERM"))
        self.assertTrue(_is_preserve_token("LSTC.LBTEST"))

    def test_still_preserves_known_prefixes(self):
        from spec_writeback import _is_preserve_token
        self.assertTrue(_is_preserve_token("SDTM.AESTDTC"))
        self.assertTrue(_is_preserve_token("WORK.TEMP_VAR"))
        self.assertTrue(_is_preserve_token("PLAIN_IDENTIFIER"))

    def test_still_drops_garbage_and_raw(self):
        from spec_writeback import _is_preserve_token
        self.assertFalse(_is_preserve_token("RAW.AE.AESTDAT"),
                         "RAW.* tokens are mapper output, not preserved")
        self.assertFalse(_is_preserve_token(""))
        self.assertFalse(_is_preserve_token("NaN"))
        self.assertFalse(_is_preserve_token("free text with spaces"))


# ===========================================================================
# Item 4: writeback no longer falls back to variable-name match
# ===========================================================================

class TestItem04_StrictDomainVarMatch(unittest.TestCase):
    """v26: if (dom, var) wasn't found, writeback fell back to first key
    with same var name — silent cross-domain bleed."""

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def _make_spec_with_domain_typo(self):
        """Spec lists EG.LBTESTCD (typo: LB.LBTESTCD intended)."""
        path = self.tmp / "spec.xlsx"
        wb = Workbook()
        ws_toc = wb.active
        ws_toc.title = "TOC"
        ws_toc.append(["Dataset", "Active"])
        ws_toc.append(["EG", "Y"])
        ws = wb.create_sheet("EG")
        ws.append(["Dataset", "Variable", "Label", "Input Variables",
                   "Mapping Action", "Origin", "Core"])
        # Typo: this should be LB.LBTESTCD, but the spec sheet says EG
        ws.append(["EG", "LBTESTCD", "Lab Test Code (typo)", "", "", "", "Required"])
        wb.save(path)
        return path

    def _make_results_with_lb_only(self):
        """Mapping result has LB.LBTESTCD, no EG.LBTESTCD."""
        path = self.tmp / "results.xlsx"
        df = pd.DataFrame([{
            "DOMAIN": "LB", "SDTM_VARIABLE": "LBTESTCD",
            "SDTM_LABEL": "Lab Test Code", "VAR_CLASS": "result",
            "RAW_VARIABLES_ASSIGNED": "RAW.LB.LBTEST",
            "MAPPING_ACTION": "ASSIGN", "ORIGIN": "CRF",
            "ORIGIN_CONFIDENCE": 0.95, "COMPOSITE_SCORE": 0.92,
            "MATCH_TIER": "direct", "MATCH_PATH": "master_lookup",
            "GROUP_COUNT": 1, "MASTER_CONF": 0.9, "LABEL_SIM": 0.7,
            "PARTIAL_FRAC": 1.0, "TOP_CANDIDATES": "",
        }])
        with pd.ExcelWriter(path, engine="openpyxl") as w:
            df.to_excel(w, sheet_name="direct", index=False)
            pd.DataFrame().to_excel(w, sheet_name="review", index=False)
            pd.DataFrame().to_excel(w, sheet_name="unresolved", index=False)
        return path

    def test_no_silent_cross_domain_bleed(self):
        """v27 must NOT populate EG.LBTESTCD's Input Variables from
        LB.LBTESTCD's mapping just because the var name matches."""
        from spec_writeback import write_back
        spec    = self._make_spec_with_domain_typo()
        results = self._make_results_with_lb_only()
        out     = self.tmp / "out.xlsx"

        write_back(spec, results, out, dry_run=False, config_path=str(CONFIG))

        df = pd.read_excel(out, sheet_name="EG", engine="openpyxl", dtype=object)
        eg_row = df[df["Variable"] == "LBTESTCD"]
        self.assertFalse(eg_row.empty)
        # The cell must remain empty — no silent cross-domain copy
        inp_value = eg_row.iloc[0]["Input Variables"]
        is_empty = (
            inp_value is None
            or (isinstance(inp_value, float) and math.isnan(inp_value))
            or str(inp_value).strip() == ""
        )
        self.assertTrue(
            is_empty,
            f"EG.LBTESTCD should NOT receive LB.LBTESTCD's mapping "
            f"(got: {inp_value!r})",
        )


# ===========================================================================
# Item 11: origin overwrite is conservative — manual entries protected
# ===========================================================================

class TestItem11_ConservativeOriginOverwrite(unittest.TestCase):
    """v26: a manually-set Origin (e.g. 'Protocol') was clobbered by an
    inferred lower-priority value (e.g. 'Derived'). v27: priority 0 for
    unrecognised values + fill-blanks-only by default."""

    def test_manual_value_priority_is_zero(self):
        from origin_normalization import origin_priority
        # An unrecognised manual entry gets priority 0 — meaning never overwrite
        self.assertEqual(origin_priority("Sponsor-Specific Custom"), 0)

    def test_recognised_value_has_nonzero_priority(self):
        from origin_normalization import origin_priority
        for v in ("CRF", "Collected/Investigator", "Derived", "Protocol",
                  "Assigned", "Predecessor"):
            with self.subTest(value=v):
                self.assertGreater(origin_priority(v), 0)

    def test_blank_has_lowest_priority(self):
        from origin_normalization import origin_priority
        self.assertEqual(origin_priority(""), 99)
        self.assertEqual(origin_priority(None), 99)

    def test_writeback_does_not_overwrite_manual_value(self):
        """End-to-end: a spec with a manually-set Origin = 'Some Custom Note'
        must NOT have it overwritten by the mapper's inferred 'CRF'."""
        from spec_writeback import write_back

        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            spec = tmp / "spec.xlsx"

            wb = Workbook()
            ws_toc = wb.active
            ws_toc.title = "TOC"
            ws_toc.append(["Dataset", "Active"])
            ws_toc.append(["AE", "Y"])
            ws = wb.create_sheet("AE")
            ws.append(["Dataset", "Variable", "Label", "Input Variables",
                       "Mapping Action", "Origin", "Core"])
            ws.append(["AE", "AETERM", "AE Term", "", "",
                       "Some Custom Note", "Required"])  # manual entry
            wb.save(spec)

            results = tmp / "results.xlsx"
            df = pd.DataFrame([{
                "DOMAIN": "AE", "SDTM_VARIABLE": "AETERM",
                "SDTM_LABEL": "AE Term", "VAR_CLASS": "free_text",
                "RAW_VARIABLES_ASSIGNED": "RAW.AE.AETERM",
                "MAPPING_ACTION": "ASSIGN", "ORIGIN": "CRF",
                "ORIGIN_CONFIDENCE": 0.95, "COMPOSITE_SCORE": 0.92,
                "MATCH_TIER": "direct", "MATCH_PATH": "master_lookup",
                "GROUP_COUNT": 1, "MASTER_CONF": 0.9, "LABEL_SIM": 0.7,
                "PARTIAL_FRAC": 1.0, "TOP_CANDIDATES": "",
            }])
            with pd.ExcelWriter(results, engine="openpyxl") as w:
                df.to_excel(w, sheet_name="direct", index=False)
                pd.DataFrame().to_excel(w, sheet_name="review", index=False)
                pd.DataFrame().to_excel(w, sheet_name="unresolved", index=False)

            out = tmp / "out.xlsx"
            write_back(spec, results, out, dry_run=False,
                       populate_origin=True, config_path=str(CONFIG))

            out_df = pd.read_excel(out, sheet_name="AE",
                                   engine="openpyxl", dtype=object)
            row = out_df[out_df["Variable"] == "AETERM"]
            self.assertFalse(row.empty)
            self.assertEqual(
                str(row.iloc[0]["Origin"]).strip(),
                "Some Custom Note",
                "Manual Origin entry must NOT be overwritten",
            )


# ===========================================================================
# Item 18: dead code — find_best_group no longer in production mapper
# ===========================================================================

class TestItem18_DeadCodeRemoved(unittest.TestCase):
    """v27: find_best_group, score_group_against_raw, and the legacy
    composite() function live ONLY in src/_legacy/legacy_mapper.py.
    The production mapper.py must not export them."""

    def test_production_mapper_has_no_legacy_scorers(self):
        import mapper
        self.assertFalse(hasattr(mapper, "find_best_group"),
                         "find_best_group is dead code; should be in _legacy only")
        self.assertFalse(hasattr(mapper, "score_group_against_raw"),
                         "score_group_against_raw is dead code")

    def test_legacy_scorers_still_accessible_when_needed(self):
        """The parked module is importable from _legacy."""
        sys.path.insert(0, str(SRC_DIR / "_legacy"))
        import legacy_mapper
        self.assertTrue(hasattr(legacy_mapper, "find_best_group"))
        self.assertTrue(hasattr(legacy_mapper, "score_group_against_raw"))


# ===========================================================================
# Item 19: walrus operator misuse in the cross-domain accumulation logic
# ===========================================================================

class TestItem19_NoWalrusInCriticalPath(unittest.TestCase):
    """v26 had `_not_id_not_timing := ...` walrus inside a boolean expr
    that was redundant.  v27's simplified mapper has no walrus operators
    in the accumulation logic."""

    def test_no_walrus_in_mapper(self):
        """Source-level check: mapper.py must not contain ':=' anywhere."""
        src = (SRC_DIR / "mapper.py").read_text()
        # Allow walrus in comments/strings if any (unlikely), but in this
        # codebase we don't use walrus at all in production.
        # We only flag non-comment lines.
        offenders = []
        for i, line in enumerate(src.splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if ":=" in line and '":="' not in line and "':='" not in line:
                offenders.append((i, line.strip()))
        self.assertEqual(offenders, [],
                         f"Walrus operators found in mapper.py: {offenders}")


# ===========================================================================
# Items 21, 22: shared origin module + master_builder back-import resolved
# ===========================================================================

class TestItem21_OriginModuleIsShared(unittest.TestCase):
    """v26: spec_writeback back-imported normalize_origin_to_cdisc from
    master_builder, dragging the entire build module's heavyweight imports.
    v27: a thin origin_normalization.py is the canonical module."""

    def test_origin_normalization_is_importable_alone(self):
        # No pandas/yaml/openpyxl required to import this module
        import origin_normalization
        self.assertTrue(hasattr(origin_normalization,
                                "normalize_origin_to_cdisc"))
        self.assertTrue(hasattr(origin_normalization, "origin_priority"))

    def test_master_builder_reexports_match(self):
        from master_builder import normalize_origin_to_cdisc as a
        from origin_normalization import normalize_origin_to_cdisc as b
        self.assertIs(a, b, "master_builder should re-export, not duplicate")


# ===========================================================================
# Item 25: SDTMIG_VERSION_CHANGES not duplicated between modules
# ===========================================================================

class TestItem25_NoDuplicatedConstants(unittest.TestCase):
    """v26 defined SDTMIG_VERSION_CHANGES in BOTH mapper.py and
    sdtm_knowledge.py with different contents (mapper's was stale)."""

    def test_sdtmig_version_changes_only_in_knowledge(self):
        import mapper, sdtm_knowledge
        # The canonical source is sdtm_knowledge
        self.assertTrue(hasattr(sdtm_knowledge, "SDTMIG_VERSION_CHANGES"))
        # mapper.py must not define its own copy
        # (it may still import it, but shouldn't have its own dict literal)
        self.assertFalse(
            hasattr(mapper, "SDTMIG_VERSION_CHANGES"),
            "mapper.py should not have its own SDTMIG_VERSION_CHANGES dict",
        )


# ===========================================================================
# End-to-end: the new three-step pipeline produces correct origins
# ===========================================================================

class TestPipelineEndToEnd(unittest.TestCase):
    """Full mapper.run for a synthetic study, asserting that all the rule
    fixes (#5, #6, #7, #8) flow through to the final output workbook."""

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def _make_master(self):
        """Minimal master_mapping.xlsx with master_all and master_top sheets."""
        path = self.tmp / "master.xlsx"
        rows = [
            # one CRF mapping per domain so the index is non-empty
            {"DOMAIN": "AE", "SDTM_VARIABLE": "AETERM", "SDTM_LABEL": "AE Term",
             "GROUP_SIG": "ae_term", "GROUP_TOKENS": "AE.AETERM",
             "GROUP_COUNT": 1, "MAPPING_ACTION": "ASSIGN", "ORIGIN": "CRF",
             "MASTER_CONFIDENCE": 0.9, "IS_SPONSOR_STD": True,
             "RAW_VARIABLE": "AE.AETERM", "SOURCE_FILES": "study_a.xlsx"},
        ]
        df = pd.DataFrame(rows)
        with pd.ExcelWriter(path, engine="openpyxl") as w:
            df.to_excel(w, sheet_name="master_all", index=False)
            df.to_excel(w, sheet_name="master_top", index=False)
        return path

    def _make_raw(self):
        path = self.tmp / "raw.xlsx"
        df = pd.DataFrame([
            {"MEMNAME": "AE", "NAME": "AETERM", "LABEL": "AE Term",
             "FORMAT": "", "TYPE": "C"},
            {"MEMNAME": "AE", "NAME": "AESTDAT", "LABEL": "Start Date",
             "FORMAT": "DATE9.", "TYPE": "N"},
        ])
        df.to_excel(path, sheet_name="proc_contents", index=False,
                    engine="openpyxl")
        return path

    def _make_spec(self):
        path = self.tmp / "spec.xlsx"
        wb = Workbook()
        ws_toc = wb.active
        ws_toc.title = "TOC"
        ws_toc.append(["Dataset", "Active"])
        for d in ("DM", "AE", "LB"):
            ws_toc.append([d, "Y"])

        rows = {
            "DM": [
                ["DM", "STUDYID",  "Study Identifier",       "", "", "", "Required"],
                ["DM", "DOMAIN",   "Domain",                 "", "", "", "Required"],
                ["DM", "USUBJID",  "Unique Subject Id",      "", "", "", "Required"],
                ["DM", "RFSTDTC",  "Subject Reference Start","", "", "", "Required"],
                ["DM", "RFENDTC",  "Subject Reference End",  "", "", "", "Required"],
            ],
            "AE": [
                ["AE", "AETERM",   "Reported Term",         "", "", "", "Required"],
                ["AE", "AESEQ",    "Sequence Number",       "", "", "", "Required"],
                ["AE", "EPOCH",    "Epoch",                 "", "", "", "Permissible"],
                ["AE", "AESTDY",   "Study Day of Start",    "", "", "", "Permissible"],
            ],
            "LB": [
                ["LB", "LBSEQ",    "Sequence Number",       "", "", "", "Required"],
                ["LB", "LBDY",     "Study Day",             "", "", "", "Permissible"],
                ["LB", "LBBLFL",   "Baseline Flag",         "", "", "", "Permissible"],
                ["LB", "LBLOBXFL", "Last Pre-Tx Flag",      "", "", "", "Permissible"],
                ["LB", "LBCHG",    "Change from Baseline",  "", "", "", "Permissible"],
            ],
        }
        for dom, sheet_rows in rows.items():
            ws = wb.create_sheet(dom)
            ws.append(["Dataset", "Variable", "Label", "Input Variables",
                       "Mapping Action", "Origin", "Core"])
            for r in sheet_rows:
                ws.append(r)
        wb.save(path)
        return path

    def test_rule_table_decisions_visible_in_output(self):
        from mapper import run
        master = self._make_master()
        raw    = self._make_raw()
        spec   = self._make_spec()
        out    = self.tmp / "results.xlsx"

        results = run(master, raw, spec_path=spec, out_path=out,
                      config_path=CONFIG)

        all_rows = pd.concat([
            results["direct"], results["review"], results["unresolved"]
        ], ignore_index=True)
        all_rows["KEY"] = all_rows["DOMAIN"] + "." + all_rows["SDTM_VARIABLE"]

        def origin_for(key):
            row = all_rows[all_rows["KEY"] == key]
            self.assertFalse(row.empty, f"{key} missing from output")
            return row.iloc[0]["ORIGIN"]

        # Item 5 fix: RFSTDTC must be Derived, not Assigned/Sponsor
        self.assertEqual(origin_for("DM.RFSTDTC"), "Derived",
                         "RFSTDTC must be Derived (review item 5)")
        self.assertEqual(origin_for("DM.RFENDTC"), "Derived")

        # Item 6 fix: EPOCH must be Derived, not HARDCODE
        self.assertEqual(origin_for("AE.EPOCH"), "Derived",
                         "EPOCH must be Derived (review item 6)")

        # Item 7 fix: --DY must be Derived
        self.assertEqual(origin_for("AE.AESTDY"), "Derived",
                         "--DY must be Derived (review item 7)")
        self.assertEqual(origin_for("LB.LBDY"), "Derived")

        # Item 8 fix: --BLFL / --LOBXFL / --CHG must be Derived
        self.assertEqual(origin_for("LB.LBBLFL"), "Derived",
                         "--BLFL must be Derived (review item 8)")
        self.assertEqual(origin_for("LB.LBLOBXFL"), "Derived")
        self.assertEqual(origin_for("LB.LBCHG"), "Derived")

        # Sanity: STUDYID is Protocol; DOMAIN is Assigned; USUBJID is Derived
        self.assertEqual(origin_for("DM.STUDYID"), "Protocol")
        self.assertEqual(origin_for("DM.DOMAIN"), "Assigned")
        self.assertEqual(origin_for("DM.USUBJID"), "Derived")

        # AETERM has a master entry + raw match -> CRF
        self.assertEqual(origin_for("AE.AETERM"), "CRF")

    def test_match_path_records_decision(self):
        """Audit trail must say which path produced each row."""
        from mapper import run
        master = self._make_master()
        raw    = self._make_raw()
        spec   = self._make_spec()
        out    = self.tmp / "results.xlsx"
        results = run(master, raw, spec_path=spec, out_path=out,
                      config_path=CONFIG)

        all_rows = pd.concat([
            results["direct"], results["review"], results["unresolved"]
        ], ignore_index=True)
        all_rows["KEY"] = all_rows["DOMAIN"] + "." + all_rows["SDTM_VARIABLE"]

        def path_for(key):
            row = all_rows[all_rows["KEY"] == key]
            return row.iloc[0]["MATCH_PATH"] if not row.empty else None

        # All RF*DTC, EPOCH, --DY, --BLFL etc. came from the rule table
        self.assertEqual(path_for("DM.RFSTDTC"), "rule_table")
        self.assertEqual(path_for("AE.EPOCH"),   "rule_table")
        self.assertEqual(path_for("LB.LBDY"),    "rule_table")
        self.assertEqual(path_for("LB.LBBLFL"),  "rule_table")
        # AETERM came from master lookup
        self.assertEqual(path_for("AE.AETERM"),  "master_lookup")


if __name__ == "__main__":
    unittest.main(verbosity=2)
