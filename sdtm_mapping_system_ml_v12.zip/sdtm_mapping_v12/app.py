"""
app.py
======
SDTM Master Mapping System - Streamlit Application

Dark-mode interactive UI covering three pipeline phases:
  1. Build Master Mapping   (from completed study specs)
  2. Map New Study          (raw catalog -> SDTM variable mapping)
  3. Write Back to Spec     (populate Input Variables / Origin in spec Excel)

Run:
    streamlit run app.py
"""

import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import datetime as dt
import hashlib
import threading
from pathlib import Path


def _make_tmpdir():
    """Create a temp dir - safe on Windows (no spaces, no TemporaryDirectory cleanup issues)."""
    return tempfile.mkdtemp(prefix='sdtm_')


def _rm_tmpdir(path):
    """Remove temp dir, ignoring errors (openpyxl may still hold handles)."""
    try:
        shutil.rmtree(str(path), ignore_errors=True)
    except Exception:
        pass

import pandas as pd
import streamlit as st

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).parent.resolve()
SRC_DIR = APP_DIR / 'src'
# Add both project root and src/ so all modules are importable
sys.path.insert(0, str(SRC_DIR))
sys.path.insert(0, str(APP_DIR))

# ---------------------------------------------------------------------------
# Page config - must be first Streamlit call
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="SDTM Master Mapping System",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Dark theme CSS
# ---------------------------------------------------------------------------
DARK_CSS = """
<style>
/* ============================================================
   BASE — works on both dark (#0d1117 bg) and Streamlit light theme
   Key: use rgba() with enough opacity so they show on any bg
   ============================================================ */
html, body, [data-testid="stAppViewContainer"] {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif;
}
[data-testid="stSidebar"] {
    background-color: #161b22;
    border-right: 1px solid #30363d;
}
[data-testid="stSidebar"] * { color: #e6edf3 !important; }

/* ---- Header bar ---- */
.main-header {
    background: linear-gradient(135deg, #161b22 0%, #1c2330 100%);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px 28px 16px 28px;
    margin-bottom: 20px;
}
.main-header h1 {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    margin: 0 0 4px 0; letter-spacing: -0.02em;
}
.main-header p { font-size: 13px; color: #8b949e; margin: 0; }

/* ---- Cards ---- */
.card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    padding: 16px 18px;
    margin-bottom: 12px;
}
.card-title {
    font-size: 12px; font-weight: 600; color: #58a6ff;
    letter-spacing: 0.06em; text-transform: uppercase;
    margin-bottom: 10px;
}

/* ---- Metric pills ---- */
.metric-row { display: flex; gap: 10px; flex-wrap: wrap; margin: 12px 0; }
.metric-pill {
    background: #1c2330; border: 1px solid #30363d;
    border-radius: 6px; padding: 10px 16px; text-align: center;
    min-width: 100px; flex: 1;
    transition: transform 0.1s; cursor: default;
}
.metric-pill:hover { transform: translateY(-2px); }
.metric-pill .val {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    font-family: 'IBM Plex Mono', monospace; line-height: 1.2;
}
.metric-pill .val.green  { color: #3fb950; }
.metric-pill .val.amber  { color: #e3b341; }
.metric-pill .val.red    { color: #f85149; }
.metric-pill .val.purple { color: #bc8cff; }
.metric-pill .lbl { font-size: 11px; color: #8b949e; margin-top: 3px; }

/* ---- Status badges ---- */
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 3px;
    font-size: 11px; font-weight: 600; font-family: monospace;
}
.badge-direct  { background: rgba(63,185,80,0.18);  color: #3fb950;  border: 1px solid rgba(63,185,80,0.4);  }
.badge-review  { background: rgba(227,179,65,0.18); color: #e3b341;  border: 1px solid rgba(227,179,65,0.4); }
.badge-unres   { background: rgba(248,81,73,0.18);  color: #f85149;  border: 1px solid rgba(248,81,73,0.4);  }
.badge-cross   { background: rgba(188,140,255,0.18);color: #bc8cff;  border: 1px solid rgba(188,140,255,0.4);}
.badge-info    { background: rgba(88,166,255,0.14); color: #58a6ff;  border: 1px solid rgba(88,166,255,0.4); }

/* ---- Inputs & buttons ---- */
[data-testid="stFileUploader"] {
    background: #161b22; border: 1px dashed #30363d !important;
    border-radius: 6px; padding: 8px;
}
.stButton > button {
    background: #238636 !important; color: #ffffff !important;
    border: none !important; border-radius: 6px !important;
    font-weight: 600 !important; padding: 10px 24px !important;
    font-size: 13px !important; width: 100% !important;
    transition: background 0.2s !important;
}
.stButton > button:hover { background: #2ea043 !important; }
.stButton > button:disabled { background: #21262d !important; color: #8b949e !important; }

/* ---- Sidebar buttons (smaller, muted) ---- */
[data-testid="stSidebar"] .stButton > button {
    background: #21262d !important;
    color: #8b949e !important;
    border: 1px solid #30363d !important;
    font-size: 11px !important;
    padding: 4px 8px !important;
    width: 100% !important;
}
[data-testid="stSidebar"] .stButton > button:hover {
    background: #30363d !important;
    color: #e6edf3 !important;
}

/* ---- Progress bar ---- */
[data-testid="stProgress"] > div > div { background-color: #238636 !important; }

/* ---- Tables — improved alternating rows & hover ---- */
[data-testid="stDataFrame"] { border: 1px solid #30363d; border-radius: 6px; }
[data-testid="stDataFrame"] table { font-size: 12px !important; }
thead th {
    background-color: #161b22 !important; color: #58a6ff !important;
    font-size: 11px !important; text-transform: uppercase !important;
    letter-spacing: 0.04em !important;
}
[data-testid="stDataFrame"] tbody tr:nth-child(even) {
    background-color: rgba(88,166,255,0.04) !important;
}
[data-testid="stDataFrame"] tbody tr:hover {
    background-color: rgba(88,166,255,0.10) !important;
}

/* ---- Tabs — more readable ---- */
[data-testid="stTabs"] [role="tablist"] {
    border-bottom: 2px solid #30363d;
    gap: 2px;
    flex-wrap: wrap;
}
[data-testid="stTabs"] [role="tab"] {
    color: #8b949e !important;
    font-size: 12px !important;
    padding: 7px 14px !important;
    border-radius: 6px 6px 0 0 !important;
    transition: background 0.15s, color 0.15s;
}
[data-testid="stTabs"] [role="tab"]:hover {
    background: rgba(88,166,255,0.08) !important;
    color: #c9d1d9 !important;
}
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: #58a6ff !important;
    background: rgba(88,166,255,0.10) !important;
    border-bottom: 2px solid #58a6ff !important;
    font-weight: 700 !important;
}

/* ---- Alerts ---- */
.stSuccess { background: rgba(63,185,80,0.12) !important;  border-left: 4px solid #3fb950 !important; color: #3fb950 !important; }
.stWarning { background: rgba(227,179,65,0.12) !important; border-left: 4px solid #e3b341 !important; }
.stError   { background: rgba(248,81,73,0.12) !important;  border-left: 4px solid #f85149 !important; }
.stInfo    { background: rgba(88,166,255,0.10) !important; border-left: 4px solid #58a6ff !important; color: #8b949e !important; }

/* ---- Code blocks ---- */
code, pre { background: #161b22 !important; color: #a5d6ff !important; border: 1px solid #30363d !important; }

/* ---- Log area ---- */
.log-box {
    background: #0d1117; border: 1px solid #30363d; border-radius: 5px;
    padding: 14px; font-family: 'IBM Plex Mono', monospace;
    font-size: 13px; line-height: 1.6; color: #c9d1d9;
    max-height: 420px; overflow-y: auto;
    white-space: pre-wrap;
    scroll-behavior: smooth;
}
.log-box .log-ok   { color: #3fb950; font-weight: 600; }
.log-box .log-warn { color: #e3b341; }
.log-box .log-err  { color: #f85149; font-weight: 600; }
.log-info  { color: #8b949e; }
.log-ok    { color: #3fb950; }
.log-warn  { color: #e3b341; }
.log-err   { color: #f85149; }

/* ---- Sidebar labels ---- */
.sidebar-section {
    font-size: 10px; font-weight: 600; letter-spacing: 0.1em;
    text-transform: uppercase; color: #6e7681; padding: 12px 0 4px 0;
    border-bottom: 1px solid #30363d; margin-bottom: 8px;
}

/* ---- Divider ---- */
hr { border-color: #30363d !important; }

/* ---- Compare page: diff row colors ---- */
/* Applied via pandas Styler — these are fallbacks */
.diff-changed { background: rgba(227,179,65,0.18) !important; }
.diff-same    { background: rgba(63,185,80,0.10) !important;  }

/* ---- Tier color indicators ---- */
.tier-direct { color:#3fb950; font-weight:700; font-size:11px; }
.tier-review { color:#e3b341; font-weight:700; font-size:11px; }
.tier-cross  { color:#bc8cff; font-weight:700; font-size:11px; }
.tier-unres  { color:#f85149; font-weight:700; font-size:11px; }

/* ---- Score monospace coloring ---- */
.score-high   { color:#3fb950; font-weight:700; font-family:monospace; }
.score-medium { color:#e3b341; font-weight:700; font-family:monospace; }
.score-low    { color:#f85149; font-weight:700; font-family:monospace; }

/* ---- Raw->SDTM mapping table monospace ---- */
.raw-ds-name { color:#58a6ff; font-family:monospace; font-weight:600; }
.sdtm-domain { color:#3fb950; font-family:monospace; font-weight:600; }
</style>
"""

st.markdown(DARK_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def save_upload(uploaded_file, dest_dir):
    """Save a Streamlit UploadedFile to dest_dir; return Path."""
    dest = Path(dest_dir) / uploaded_file.name
    dest.write_bytes(uploaded_file.getbuffer())
    return dest


def bytes_to_upload_mock(content_bytes, filename, dest_dir):
    """Write raw bytes to a file; return Path."""
    dest = Path(dest_dir) / filename
    dest.write_bytes(content_bytes)
    return dest


def _bytes_to_file(name_bytes_tuple):
    """Wrap cached (name, bytes) tuple as a file-like object for uploaders that expect files."""
    import io as _io
    if name_bytes_tuple is None:
        return None
    name, bdata = name_bytes_tuple
    buf = _io.BytesIO(bdata)
    buf.name = name
    return buf


def metric_html(val, label, color=""):
    cls = "val " + color if color else "val"
    return (
        '<div class="metric-pill">'
        f'<div class="{cls}">{val}</div>'
        f'<div class="lbl">{label}</div>'
        '</div>'
    )


def log_html(lines):
    inner = "\n".join(lines[-120:])
    uid = "logbox_" + str(abs(hash(inner)) % 99999)
    # Auto-scroll to bottom using a tiny inline script
    scroll_js = f"""<script>
(function(){{
  var el=document.getElementById('{uid}');
  if(el){{el.scrollTop=el.scrollHeight;}}
  setTimeout(function(){{var e=document.getElementById('{uid}');if(e)e.scrollTop=e.scrollHeight;}},80);
}})();
</script>"""
    return f'<div class="log-box" id="{uid}">{inner}</div>{scroll_js}'



def _render_xai_bar(xai_str: str) -> str:
    """Convert a SCORE_BREAKDOWN string to a compact HTML score bar."""
    import ast
    try:
        if not xai_str or xai_str.lower() in ("", "nan"):
            return ""
        d = ast.literal_eval(str(xai_str))
        signals = [
            ("Exact",   d.get("w_name_exact",  0), "#58a6ff"),
            ("Fuzzy",   d.get("w_name_fuzzy",  0), "#bc8cff"),
            ("Label",   d.get("w_label_tfidf", 0), "#e3b341"),
            ("History", d.get("w_master_freq", 0), "#3fb950"),
        ]
        bars = ""
        for name, val, color in signals:
            pct = min(max(float(val) * 100, 0), 100)
            bars += (
                f'<div style="display:flex;align-items:center;gap:6px;margin:2px 0">'
                f'<span style="width:46px;font-size:10px;color:#8b949e">{name}</span>'
                f'<div style="flex:1;background:#21262d;border-radius:3px;height:8px">'
                f'<div style="width:{pct:.0f}%;background:{color};height:8px;border-radius:3px"></div>'
                f'</div>'
                f'<span style="width:34px;font-size:10px;color:{color};text-align:right">{val:.2f}</span>'
                f'</div>'
            )
        total = d.get("composite", 0)
        color_t = "#3fb950" if total >= 0.82 else "#e3b341" if total >= 0.55 else "#f85149"
        return (
            f'<div style="font-size:10px;color:{color_t};font-weight:700;margin-bottom:4px">'
            f'Score: {total:.3f}</div>' + bars
        )
    except Exception:
        return ""


def excel_download_button(df_dict, filename, label="Download Excel"):
    """Create an in-memory Excel workbook and return a download button."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in df_dict.items():
            if df is not None and not df.empty:
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    buf.seek(0)
    st.download_button(
        label=label,
        data=buf.read(),
        file_name=filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def file_download_button(path, label="Download File"):
    """Offer a file for download by path."""
    with open(path, "rb") as f:
        data = f.read()
    ext  = Path(path).suffix.lower()
    mime = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if ext in (".xlsx", ".xlsm") else "application/octet-stream"
    )
    st.download_button(label=label, data=data,
                       file_name=Path(path).name, mime=mime)


# ---------------------------------------------------------------------------
# Progress-aware wrapper for build_master_mapping
# ---------------------------------------------------------------------------

def run_build_with_progress(spec_paths, sponsor_paths, existing_master,
                             out_path, config_path, study_dates):
    """
    Wrap build_master_mapping with real-time Streamlit progress feedback.
    Yields (pct, message) via st.progress + st.status updates.
    """
    import master_builder as mb

    log_lines = []
    progress   = st.progress(0, text="Starting master build...")
    status_box = st.empty()

    steps = []
    if existing_master:
        steps.append(("Loading existing master", 5))
    for sp in spec_paths:
        steps.append((f"Reading study spec: {Path(sp).name}", 15))
    for sp in (sponsor_paths or []):
        steps.append((f"Reading sponsor spec: {Path(sp).name}", 15))
    steps.append(("Consolidating groups & confidence scores", 20))
    steps.append(("Writing master_mapping.xlsx", 10))

    total_weight = sum(w for _, w in steps)
    cumulative   = 0

    def tick(msg, weight):
        nonlocal cumulative
        cumulative += weight
        pct = min(int(cumulative / total_weight * 100), 99)
        progress.progress(pct, text=msg)
        log_lines.append(f"  {msg}")
        status_box.markdown(log_html(log_lines), unsafe_allow_html=True)
        time.sleep(0.05)

    # Patch the module's logger to capture output
    import logging, io as _io

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg = self.format(record)
            # strip timestamp prefix
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        tick("Initialising...", 0)

        orig_process = mb.process_spec_file
        proc_count   = [0]

        def patched_process(spec_path, cfg, study_date, is_sponsor, log):
            proc_count[0] += 1
            prefix = "Sponsor std" if is_sponsor else f"Study {proc_count[0]}"
            tick(f"{prefix}: {Path(spec_path).name}", 15)
            return orig_process(spec_path, cfg, study_date, is_sponsor, log)

        mb.process_spec_file = patched_process

        master_df = mb.build_master_mapping(
            spec_paths=spec_paths,
            sponsor_paths=sponsor_paths,
            existing_master=existing_master,
            out_path=out_path,
            config_path=config_path,
            study_dates=study_dates,
        )

        mb.process_spec_file = orig_process
        tick("Complete!", 10)
        progress.progress(100, text="Master mapping built successfully")
        return master_df, log_lines

    except Exception as exc:
        mb.process_spec_file = orig_process
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_map_with_progress(master_path, raw_path, spec_path,
                           out_path, config_path):
    """Wrap mapper.run with real-time progress."""
    import mapper as mp
    import logging

    log_lines = []
    progress   = st.progress(0, text="Starting variable mapping...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    # Patch run_mapping to emit per-domain progress
    orig_run_mapping = mp.run_mapping
    domains_seen = [0]

    def patched_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log):
        total_vars = len(sdtm_vars_df)
        pct_per_var = 60 / max(total_vars, 1)

        orig_find = mp.find_best_group
        var_count = [0]

        def patched_find(sdtm_var, domain, *args, **kwargs):
            var_count[0] += 1
            pct = 20 + int(var_count[0] * pct_per_var)
            progress.progress(
                min(pct, 80),
                text=f"Mapping {domain}.{sdtm_var}  [{var_count[0]}/{total_vars}]",
            )
            return orig_find(sdtm_var, domain, *args, **kwargs)

        mp.find_best_group = patched_find
        result = orig_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log)
        mp.find_best_group = orig_find
        return result

    mp.run_mapping = patched_run_mapping

    try:
        progress.progress(5,  text="Loading master mapping...")
        time.sleep(0.1)
        progress.progress(10, text="Loading raw catalog...")
        time.sleep(0.1)
        progress.progress(15, text="Building TF-IDF label index...")

        results = mp.run(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=str(spec_path) if spec_path else None,
            out_path=out_path,
            config_path=config_path,
        )

        mp.run_mapping = orig_run_mapping
        progress.progress(90, text="Writing results Excel...")
        time.sleep(0.2)
        progress.progress(100, text="Mapping complete!")
        return results, log_lines

    except Exception as exc:
        mp.run_mapping = orig_run_mapping
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_writeback_with_progress(spec_path, results_path, out_path,
                                 highlight_review, populate_origin,
                                 populate_action, dry_run, config_path):
    """Wrap spec_writeback.write_back with progress."""
    import spec_writeback as sw
    import logging

    log_lines = []
    progress   = st.progress(0, text="Preparing write-back...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        progress.progress(10, text="Loading mapping results...")
        time.sleep(0.1)
        progress.progress(25, text="Opening spec workbook...")
        time.sleep(0.1)
        progress.progress(35, text="Writing Input Variables, Origin, Mapping Action...")

        wb_result = sw.write_back(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
            highlight_review=highlight_review,
            populate_origin=populate_origin,
            populate_action=populate_action,
            dry_run=dry_run,
            config_path=str(config_path),
        )
        # write_back now returns (path, validation_report)
        if isinstance(wb_result, tuple):
            result_path, validation_report = wb_result
        else:
            result_path, validation_report = wb_result, None

        progress.progress(90, text="Running post-writeback validation...")
        time.sleep(0.15)
        progress.progress(100, text="Write-back complete!")
        return result_path, validation_report, log_lines

    except Exception as exc:
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


# ---------------------------------------------------------------------------
# Coverage chart (pure matplotlib -> PNG bytes)
# ---------------------------------------------------------------------------

def coverage_chart_bytes(coverage_df):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        domains = coverage_df["DOMAIN"].tolist()
        direct  = coverage_df["DIRECT"].astype(int).tolist()
        review  = coverage_df["REVIEW"].astype(int).tolist()
        unres   = coverage_df["UNRESOLVED"].astype(int).tolist()

        x     = range(len(domains))
        width = 0.25

        fig, ax = plt.subplots(figsize=(max(7, len(domains) * 1.2), 4), facecolor="#0d1117")
        ax.set_facecolor("#161b22")

        bars_d = ax.bar([i - width for i in x], direct,  width, label="Direct",     color="#3fb950", alpha=0.9)
        bars_r = ax.bar([i         for i in x], review,  width, label="Review",     color="#e3b341", alpha=0.9)
        bars_u = ax.bar([i + width for i in x], unres,   width, label="Unresolved", color="#f85149", alpha=0.9)

        ax.set_xticks(list(x))
        ax.set_xticklabels(domains, color="#e6edf3", fontsize=11)
        ax.tick_params(colors="#8b949e")
        ax.spines["bottom"].set_color("#30363d")
        ax.spines["left"].set_color("#30363d")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_ylabel("Variables", color="#8b949e", fontsize=10)
        ax.set_title("Mapping Coverage by Domain", color="#e6edf3", fontsize=12, pad=10)
        ax.yaxis.label.set_color("#8b949e")
        ax.tick_params(axis="y", colors="#8b949e")
        ax.grid(axis="y", color="#30363d", linewidth=0.5, linestyle="--")

        legend = ax.legend(
            facecolor="#161b22", edgecolor="#30363d",
            labelcolor="#e6edf3", fontsize=9,
        )

        # Value labels on bars
        for bars in (bars_d, bars_r, bars_u):
            for bar in bars:
                h = bar.get_height()
                if h > 0:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2, h + 0.1,
                        str(int(h)), ha="center", va="bottom",
                        color="#e6edf3", fontsize=8,
                    )

        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                    facecolor="#0d1117")
        plt.close(fig)
        buf.seek(0)
        return buf.read()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown(
        '<div class="main-header"><h1>SDTM Mapper</h1>'
        '<p>Master Mapping System v4</p></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-section">Navigation</div>', unsafe_allow_html=True)

    page = st.radio(
        "Select phase",
        options=["Build Master", "Map New Study", "Write Back to Spec",
                 "Compare Specs", "CDM Variable Filter", "View Master", "Help"],
        label_visibility="collapsed",
    )

    st.markdown('<div class="sidebar-section">Settings</div>', unsafe_allow_html=True)

    cfg_path_input = st.text_input(
        "config.yaml path",
        value=str(APP_DIR / "src" / "config.yaml"),
        help="Path to config.yaml. Edit thresholds and weights there.",
    )

    # ---- Reset controls (raw + writeback only) ----
    st.markdown('<div class="sidebar-section">Reset</div>', unsafe_allow_html=True)
    st.caption("Phase 1 & 2 master mapping is preserved across resets.")
    _rcol1, _rcol2 = st.columns(2)
    with _rcol1:
        if st.button("🗑 Raw Data", help="Clear raw catalog and mapping results"):
            for _k in ("results_xlsx_bytes", "map_done"):
                st.session_state.pop(_k, None)
            st.success("Cleared.")
    with _rcol2:
        if st.button("🗑 Writeback", help="Clear write-back spec data"):
            for _k in ("wb_spec_bytes",):
                st.session_state.pop(_k, None)
            st.success("Cleared.")

    st.markdown('<div class="sidebar-section">About</div>', unsafe_allow_html=True)
    st.caption(
        "Each completed study fed into Build Master improves "
        "matching accuracy for all future studies."
    )


# ---------------------------------------------------------------------------
# Main header
# ---------------------------------------------------------------------------

st.markdown(
    '<div class="main-header">'
    '<h1>SDTM Master Mapping System v4</h1>'
    '<p>Build a cross-study master mapping knowledge base from completed SDTM specs, '
    'then automatically map new study raw variables to SDTM with confidence-scored '
    'outputs and direct spec write-back.</p>'
    '</div>',
    unsafe_allow_html=True,
)


# ===========================================================================
# PAGE: Build Master
# ===========================================================================

# ---------------------------------------------------------------------------
# Session state init
# ---------------------------------------------------------------------------

if "cdm_filter_dict" not in st.session_state:
    from cdm_filter import DEFAULT_CDM_VARIABLES, DEFAULT_CDM_DATASETS, DEFAULT_CDM_SUFFIXES
    st.session_state["cdm_filter_dict"] = {
        "cdm_variables":   sorted(DEFAULT_CDM_VARIABLES),
        "cdm_datasets":    sorted(DEFAULT_CDM_DATASETS),
        "cdm_suffixes":    list(DEFAULT_CDM_SUFFIXES),
        "custom_patterns": [],
    }

# ---------------------------------------------------------------------------
# Auto-update master mapping when watched spec folder has new/changed files
# ---------------------------------------------------------------------------

def _file_hash(path):
    """Return SHA1 hex of a file for change detection."""
    try:
        return hashlib.sha1(Path(path).read_bytes()).hexdigest()
    except Exception:
        return ""

def _scan_watch_folder(folder):
    """Return {filename: hash} for all xlsx/xlsm files in folder."""
    result = {}
    try:
        for p in Path(folder).glob("*.xls*"):
            result[p.name] = _file_hash(p)
    except Exception:
        pass
    return result

# ---------------------------------------------------------------------------
# Persistent session state init
# All upload bytes are cached here so tab switches / download clicks
# do NOT reset the uploaded files. The UI file_uploader widgets use
# these cached bytes if the widget itself is empty after a re-run.
# ---------------------------------------------------------------------------
_SS_DEFAULTS = {
    "watch_hashes":          {},
    "watch_folder":          "",
    "auto_update_log":       [],
    # Phase 1
    "master_xlsx_bytes":     None,
    "master_built":          False,
    # Phase 2
    "raw_bytes":             None,
    "spec_bytes":            None,
    "results_xlsx_bytes":    None,
    "map_done":              False,
    # Phase 3 / Write Back
    "wb_spec_bytes":         None,
    "wb_results_bytes":      None,
    # Compare
    "cmp_orig_bytes":        None,
    "cmp_mapped_bytes":      None,
    # Validation
    "last_val_report":       None,
    "last_val_report_excel": None,
}
for _k, _v in _SS_DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v


if page == "Build Master":
    st.markdown("## Phase 1 - Build Master Mapping")
    st.info(
        "Upload completed study spec Excel files. Each study added improves "
        "accuracy for future mappings. Sponsor standard specs get a confidence "
        "priority boost and supersede conflicting study mappings.",
    )

    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Completed Study Specs</div>', unsafe_allow_html=True)
        study_files = st.file_uploader(
            "Upload one or more completed study spec Excel files",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="study_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Sponsor Standard Specs (optional)</div>', unsafe_allow_html=True)
        sponsor_files = st.file_uploader(
            "Upload sponsor standard / template spec(s). These take priority over study mappings.",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="sponsor_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Existing Master (Append Mode)</div>', unsafe_allow_html=True)
        existing_master_file = st.file_uploader(
            "Optional: upload an existing master_mapping.xlsx to append new studies",
            type=["xlsx"],
            key="existing_master",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Study Dates (optional)</div>', unsafe_allow_html=True)
        st.caption("Older studies get a recency decay. Format: filename=YYYY-MM-DD (one per line)")
        dates_text = st.text_area(
            "Study dates",
            placeholder="study_a.xlsx=2022-06-01\nstudy_b.xlsx=2023-11-15\nsponsor_std.xlsx=2024-01-01",
            height=120,
            label_visibility="collapsed",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Conflict Strategy</div>', unsafe_allow_html=True)
        conflict_strategy = st.selectbox(
            "How to resolve conflicting mappings across studies",
            options=["sponsor_priority", "most_frequent"],
            index=0,
            help="sponsor_priority: sponsor standard wins. most_frequent: highest N_STUDIES wins.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">SDTMIG Version & Therapeutic Area</div>', unsafe_allow_html=True)
        st.caption(
            "Auto-detected from each spec Study tab. Override here if needed. "
            "Version-matched studies get higher confidence weight in the master."
        )
        target_ig_version = st.selectbox(
            "Target SDTMIG Version (for this master)",
            options=["Auto-detect from specs", "3.4", "3.3", "3.2", "3.1.3", "3.1.2"],
            index=0,
            help="Studies from the same SDTMIG version get full weight. Older versions are down-weighted.",
        )
        target_ta = st.multiselect(
            "Therapeutic Area filter (leave empty = all TAs pooled)",
            options=[
                "ONCOLOGY", "CARDIOLOGY", "NEUROLOGY", "RESPIRATORY",
                "IMMUNOLOGY", "RHEUMATOLOGY", "NEPHROLOGY", "OPHTHALMOLOGY",
                "HEMATOLOGY", "ENDOCRINOLOGY", "INFECTIOUS_DISEASE",
                "DERMATOLOGY", "GASTROENTEROLOGY", "MUSCULOSKELETAL",
            ],
            default=[],
            help="If selected, only studies matching these TAs are used for scoring that domain.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    run_build = st.button(
        "Build Master Mapping",
        disabled=(not study_files and not sponsor_files),
    )

    if run_build:
        try:
            import yaml, re
            with open(cfg_path_input) as f:
                cfg_data = yaml.safe_load(f)
            cfg_data["master_build"]["conflict_strategy"] = conflict_strategy
            # Write temp config
            tmp_cfg = Path(tempfile.mkdtemp()) / "config.yaml"
            import yaml as _yaml
            with open(tmp_cfg, "w") as f:
                _yaml.dump(cfg_data, f, default_flow_style=False, allow_unicode=False)

            tmpdir = _make_tmpdir()
            spec_paths    = [save_upload(f, tmpdir) for f in (study_files or [])]
            sponsor_paths = [save_upload(f, tmpdir) for f in (sponsor_files or [])]
            existing_path = None
            if existing_master_file:
                existing_path = save_upload(existing_master_file, tmpdir)

            study_dates = {}
            for line in dates_text.strip().splitlines():
                line = line.strip()
                if "=" in line:
                    fn, date = line.split("=", 1)
                    study_dates[fn.strip()] = date.strip()

            out_master = Path(tmpdir) / "master_mapping.xlsx"

            st.markdown("### Building...")
            master_df, log_lines = run_build_with_progress(
                spec_paths=spec_paths,
                sponsor_paths=sponsor_paths,
                existing_master=existing_path,
                out_path=out_master,
                config_path=tmp_cfg,
                study_dates=study_dates,
            )

            if master_df is not None and not master_df.empty:
                st.success(
                    f"Master mapping built: {len(master_df):,} rows | "
                    f"{master_df['SDTM_VARIABLE'].nunique()} SDTM variables | "
                    f"{master_df['DOMAIN'].nunique()} domains"
                )

                # Metrics
                top_df = master_df[master_df["IS_TOP_GROUP"]]
                high_n = int((top_df["MASTER_CONFIDENCE"] >= 0.82).sum())
                mid_n  = int(((top_df["MASTER_CONFIDENCE"] >= 0.55) & (top_df["MASTER_CONFIDENCE"] < 0.82)).sum())
                low_n  = int((top_df["MASTER_CONFIDENCE"] < 0.55).sum())

                pills = (
                    '<div class="metric-row">'
                    + metric_html(master_df["SDTM_VARIABLE"].nunique(), "SDTM Variables")
                    + metric_html(master_df["DOMAIN"].nunique(), "Domains", "")
                    + metric_html(int((master_df["IS_SPONSOR_STD"] == True).sum()), "Sponsor-Std Rows", "purple")
                    + metric_html(high_n, "High Conf (>=82%)", "green")
                    + metric_html(mid_n,  "Medium Conf",       "amber")
                    + metric_html(low_n,  "Low Conf (<55%)",   "red")
                    + '</div>'
                )
                st.markdown(pills, unsafe_allow_html=True)

                # Domain summary table
                st.markdown("#### Domain Summary")
                dom_sum = (
                    top_df.groupby("DOMAIN")
                    .agg(
                        SDTM_VARS=("SDTM_VARIABLE", "nunique"),
                        AVG_CONF=("MASTER_CONFIDENCE", "mean"),
                        HIGH_CONF=("MASTER_CONFIDENCE", lambda x: int((x >= 0.82).sum())),
                    )
                    .reset_index()
                    .round({"AVG_CONF": 3})
                )
                st.dataframe(dom_sum, use_container_width=True, hide_index=True)

                # Download
                st.markdown("#### Download")
                file_download_button(out_master, "Download master_mapping.xlsx")

                # Store in session state for next phase
                st.session_state["master_xlsx_bytes"] = out_master.read_bytes()
                st.session_state["master_built"]      = True

        except Exception as exc:
            st.error(f"Build failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)

    # ---- Auto-update watcher UI ----
    st.markdown("---")
    st.markdown("#### Auto-Update: Watch Folder for New/Changed Specs")
    st.caption(
        "Point to a local folder. When a spec Excel file changes or a new one appears, "
        "the master mapping is automatically rebuilt and session state is updated."
    )
    watch_folder = st.text_input(
        "Watch folder path (leave blank to disable)",
        value=st.session_state.get("watch_folder", ""),
        placeholder="/path/to/completed_specs/",
        key="watch_folder_input",
    )
    wcol1, wcol2 = st.columns([1, 3])
    with wcol1:
        check_now = st.button("Check for Changes")
    with wcol2:
        if st.session_state.get("auto_update_log"):
            st.caption("Last auto-update: " + st.session_state["auto_update_log"][-1])

    if watch_folder and (check_now or st.session_state.get("watch_folder") != watch_folder):
        st.session_state["watch_folder"] = watch_folder
        current_hashes = _scan_watch_folder(watch_folder)
        old_hashes     = st.session_state.get("watch_hashes", {})
        changed = [fn for fn, h in current_hashes.items() if old_hashes.get(fn) != h]
        if changed and st.session_state.get("master_built"):
            st.warning(f"Changes detected in: {', '.join(changed)} — rebuilding master...")
            try:
                import yaml as _yw
                with open(cfg_path_input) as _fw:
                    _cfw = _yw.safe_load(_fw)
                _tmpd = _make_tmpdir()
                _spec_paths = [Path(watch_folder) / fn for fn in current_hashes]
                _out = Path(_tmpd) / "master_mapping.xlsx"
                _existing = None
                if st.session_state.get("master_built"):
                    _existing = Path(_tmpd) / "existing_master.xlsx"
                    _existing.write_bytes(st.session_state["master_xlsx_bytes"])
                _cfg_tmp = Path(_tmpd) / "config.yaml"
                with open(_cfg_tmp, "w") as _f:
                    _yw.dump(_cfw, _f)
                _mdf, _ll = run_build_with_progress(
                    spec_paths=_spec_paths, sponsor_paths=[],
                    existing_master=_existing, out_path=_out,
                    config_path=_cfg_tmp, study_dates={},
                )
                if _mdf is not None:
                    st.session_state["master_xlsx_bytes"] = _out.read_bytes()
                    st.session_state["master_built"] = True
                    _msg = f"{dt.datetime.now():%H:%M:%S} — auto-rebuilt from {len(changed)} changed file(s)"
                    st.session_state["auto_update_log"].append(_msg)
                    st.success(f"Master auto-updated: {_msg}")
                _rm_tmpdir(_tmpd)
            except Exception as _e:
                st.error(f"Auto-update failed: {_e}")
        elif changed:
            st.info(f"Changed files detected ({', '.join(changed)}) — run Build Master first to create initial master.")
        else:
            st.success("No changes detected in watch folder.")
        st.session_state["watch_hashes"] = current_hashes


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================

elif page == "Map New Study":
    st.markdown("## Phase 2 - Map Raw Variables to SDTM")
    st.info(
        "Upload your raw SAS datasets (.xpt / .sas7bdat) directly, or a PROC CONTENTS "
        "catalog (Excel/CSV). The system maps each raw variable to the correct SDTM domain "
        "and variable using the master mapping knowledge base. Review results before writing "
        "to spec."
    )

    from cdm_filter import CdmFilter
    _flt = CdmFilter.from_dict(st.session_state.get("cdm_filter_dict", {}))

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Master Mapping</div>', unsafe_allow_html=True)
        master_source = st.radio(
            "Master source",
            ["Upload master_mapping.xlsx", "Use master built in Phase 1 (this session)"],
            label_visibility="collapsed",
        )
        if master_source == "Upload master_mapping.xlsx":
            master_upload = st.file_uploader(
                "master_mapping.xlsx",
                type=["xlsx"],
                key="master_for_map",
            )
        else:
            master_upload = None
            if st.session_state.get("master_built"):
                st.success("Phase 1 master mapping is ready.")
            else:
                st.info(
                    "No master built in this session yet. "
                    "Go to Build Master (Phase 1) first, or upload a "
                    "master_mapping.xlsx from a previous run."
                )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Raw Datasets</div>', unsafe_allow_html=True)
        raw_input_mode = st.radio(
            "Input type",
            ["SAS files (.xpt / .sas7bdat)", "PROC CONTENTS catalog (Excel/CSV)"],
            key="raw_input_mode",
        )
        if raw_input_mode == "SAS files (.xpt / .sas7bdat)":
            sas_uploads = st.file_uploader(
                "Upload one or more SAS datasets (each file = one raw dataset)",
                type=["xpt", "sas7bdat"],
                accept_multiple_files=True,
                key="sas_files",
            )
            raw_upload = None
        else:
            raw_upload = st.file_uploader(
                "PROC CONTENTS output or variable registry (Excel or CSV)",
                type=["xlsx", "csv"],
                key="raw_catalog",
            )
            if raw_upload is not None:
                st.session_state["raw_bytes"] = (raw_upload.name, raw_upload.getbuffer().tobytes())
            sas_uploads = []
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">New Study SDTM Spec (optional)</div>', unsafe_allow_html=True)
        spec_upload = st.file_uploader(
            "New study spec Excel. Maps the spec variable list exactly. "
            "If not provided, all variables in the master are mapped.",
            type=["xlsx", "xlsm"],
            key="new_spec",
        )
        if spec_upload is not None:
            st.session_state["spec_bytes"] = (spec_upload.name, spec_upload.getbuffer().tobytes())
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Matching Thresholds</div>', unsafe_allow_html=True)
        auto_thresh   = st.slider("Auto-accept threshold", 0.50, 0.98, 0.82, 0.01,
                                  help="Score >= this: mapped directly to spec (green cell)")
        review_thresh = st.slider("Review threshold",      0.30, 0.80, 0.55, 0.01,
                                  help="Score >= this: flagged for programmer review (amber cell)")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">SDTMIG Version Lock</div>', unsafe_allow_html=True)
        # Auto-detect version from uploaded spec using study_metadata module
        _detected_version = ""
        _spec_for_ver = spec_upload or (
            _spec_cached[1] if _spec_cached else None
        )
        if _spec_for_ver is not None:
            try:
                import sys as _sys
                _sys.path.insert(0, str(APP_DIR / "src"))
                from study_metadata import read_study_metadata, extract_sdtmig_version
                import io as _io, tempfile as _tf
                if hasattr(_spec_for_ver, "read"):
                    _spec_bytes_tmp = _spec_for_ver.read()
                    _spec_for_ver.seek(0)
                else:
                    _spec_bytes_tmp = _spec_for_ver
                _tmp_spec = _tf.mktemp(suffix=".xlsx")
                with open(_tmp_spec, "wb") as _fh:
                    _fh.write(_spec_bytes_tmp)
                import logging as _lg_sv
                _meta = read_study_metadata(_tmp_spec, _lg_sv.getLogger("sdtm_pipeline"))
                _detected_version = _meta.sdtmig_version or ""
                if _detected_version:
                    st.caption(f"Detected from spec Study tab: **SDTMIG {_detected_version}**")
            except Exception:
                pass

        _ver_options = ["No preference (all versions)", "3.4", "3.3", "3.2", "3.1.3"]
        _ver_default_idx = 0
        if _detected_version:
            for _vi, _vopt in enumerate(_ver_options):
                if _detected_version in _vopt:
                    _ver_default_idx = _vi
                    break

        sdtmig_version_lock = st.selectbox(
            "Prioritise mappings from studies using this SDTMIG version",
            options=_ver_options,
            index=_ver_default_idx,
            help="Auto-detected from the 'Mapping Specification IG' field in the spec Study tab. Historical mappings from studies using the same SDTMIG version are weighted higher.",
        )
        show_xai = st.checkbox(
            "Show score breakdown (XAI) in results",
            value=False,
            help="Shows how each of the 4 signals contributed to the composite score. Useful for reviewing borderline matches.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        flt_dict = st.session_state.get("cdm_filter_dict", {})
        n_excl_vars = len(flt_dict.get("cdm_variables", []))
        n_excl_ds   = len(flt_dict.get("cdm_datasets",  []))
        st.caption(
            f"CDM filter active: {n_excl_vars} variable names, {n_excl_ds} dataset names excluded. "
            "Edit in CDM Variable Filter page."
        )

    st.markdown("---")
    # Use cached bytes if widget cleared (tab switch / download re-run)
    _raw_cached = st.session_state.get("raw_bytes")
    raw_ready    = bool(sas_uploads) or (raw_upload is not None) or bool(_raw_cached)
    master_ready = (
        (master_source == "Upload master_mapping.xlsx" and master_upload is not None)
        or (master_source != "Upload master_mapping.xlsx" and st.session_state.get("master_built"))
    )
    _spec_cached = st.session_state.get("spec_bytes")
    if spec_upload is None and _spec_cached:
        st.caption(f"✓ Spec cached: {_spec_cached[0]} (re-upload to change)")
    if raw_upload is None and not sas_uploads and _raw_cached:
        st.caption(f"✓ Raw catalog cached: {_raw_cached[0]} (re-upload to change)")
    run_map = st.button(
        "Run Mapping  (raw -> SDTM)",
        disabled=(not master_ready or not raw_ready),
    )

    if run_map:
        tmpdir = _make_tmpdir()
        try:
            import yaml as _yaml
            with open(cfg_path_input) as _f:
                cfg_data = _yaml.safe_load(_f)
            cfg_data["matching"]["thresholds"]["auto_accept"] = auto_thresh
            cfg_data["matching"]["thresholds"]["review"]       = review_thresh
            tmp_cfg = Path(tmpdir) / "config.yaml"
            with open(tmp_cfg, "w") as _f:
                _yaml.dump(cfg_data, _f, default_flow_style=False, allow_unicode=False)

            # Save master
            if master_upload is not None:
                master_path = save_upload(master_upload, tmpdir)
            else:
                master_path = Path(tmpdir) / "master_mapping.xlsx"
                master_path.write_bytes(st.session_state["master_xlsx_bytes"])

            # Handle SAS files
            if sas_uploads:
                from mapper import read_sas_files
                import logging as _logging
                _log = _logging.getLogger("sdtm_pipeline")
                sas_paths  = [save_upload(f, tmpdir) for f in sas_uploads]
                catalog_df = read_sas_files(sas_paths, _log)
                # Apply CDM filter
                _, excl = _flt.filter_catalog(catalog_df)
                catalog_df, _ = _flt.filter_catalog(catalog_df)
                raw_path = Path(tmpdir) / "raw_catalog_combined.csv"
                catalog_df.to_csv(raw_path, index=False)
            else:
                if raw_upload is not None:
                    raw_path_raw = save_upload(raw_upload, tmpdir)
                elif st.session_state.get("raw_bytes"):
                    _rname, _rbytes = st.session_state["raw_bytes"]
                    raw_path_raw = Path(tmpdir) / _rname
                    raw_path_raw.write_bytes(_rbytes)
                else:
                    st.error("No raw catalog available. Please upload one.")
                    raise ValueError("No raw catalog")
                # Apply CDM filter to catalog
                import yaml as _y2
                with open(tmp_cfg) as _f2:
                    _cfg2 = _y2.safe_load(_f2)
                import logging as _lg2
                _log2 = _lg2.getLogger("sdtm_pipeline")
                from mapper import read_raw_catalog as _rrc
                _full_cat = _rrc(raw_path_raw, _cfg2, _log2)
                catalog_filtered, catalog_excluded = _flt.filter_catalog(_full_cat)
                raw_path = Path(tmpdir) / "raw_filtered.csv"
                catalog_filtered.to_csv(raw_path, index=False)
                if not catalog_excluded.empty:
                    st.info(
                        f"CDM filter excluded {len(catalog_excluded)} variables "
                        f"from {catalog_excluded['RAW_DATASET'].nunique()} datasets before mapping."
                    )

            if spec_upload is not None:
                spec_path = save_upload(spec_upload, tmpdir)
            elif st.session_state.get("spec_bytes"):
                _sname, _sbytes = st.session_state["spec_bytes"]
                spec_path = Path(tmpdir) / _sname
                spec_path.write_bytes(_sbytes)
            else:
                spec_path = None
            out_path  = Path(tmpdir) / "mapping_results.xlsx"

            st.markdown("### Mapping raw variables to SDTM...")
            results, log_lines = run_map_with_progress(
                master_path, raw_path, spec_path, out_path, tmp_cfg,
            )

            if results:
                direct_df   = results.get("direct",              pd.DataFrame())
                review_df   = results.get("review",              pd.DataFrame())
                unres_df    = results.get("unresolved",          pd.DataFrame())
                unmapped    = results.get("unmapped_raw",        pd.DataFrame())
                coverage    = results.get("coverage",            pd.DataFrame())
                cross_ds_df = results.get("cross_dataset_match", pd.DataFrame())

                d_n   = len(direct_df)
                r_n   = len(review_df)
                u_n   = len(unres_df)
                total = d_n + r_n + u_n

                st.success(
                    f"Mapping complete: {d_n} auto-mapped | "
                    f"{r_n} need review | {u_n} unresolved | {total} total"
                )

                cds_n = len(cross_ds_df)
                pills = (
                    '<div class="metric-row">'
                    + metric_html(d_n,   "Auto-Mapped",          "green")
                    + metric_html(r_n,   "Needs Review",         "amber")
                    + metric_html(cds_n, "Cross-Dataset Match",  "purple")
                    + metric_html(u_n,   "Unresolved",           "red")
                    + metric_html(
                        f"{round(100*d_n/total)}%" if total else "0%",
                        "Auto-Map Rate", "green"
                      )
                    + metric_html(len(unmapped), "Unmapped Raw Vars", "")
                    + '</div>'
                )
                st.markdown(pills, unsafe_allow_html=True)

                # ---- Raw Dataset -> SDTM Domain mapping table ----
                all_mapped = pd.concat(
                    [df for df in [direct_df, review_df, cross_ds_df] if not df.empty],
                    ignore_index=True,
                )

                def _parse_ds_domain_rows(df_in, tier_label):
                    rows = []
                    if df_in is None or df_in.empty:
                        return rows
                    for _, mrow in df_in.iterrows():
                        raw_str = str(mrow.get("RAW_VARIABLES_ASSIGNED", "") or "")
                        if not raw_str or raw_str in ("nan", ""):
                            continue
                        for tok in raw_str.split(","):
                            tok   = tok.strip()
                            parts = tok.split(".")
                            if len(parts) >= 3 and parts[0].upper() == "RAW":
                                rds = parts[1].upper()
                                rv  = parts[2].upper()
                            elif len(parts) == 2:
                                rds, rv = parts[0].upper(), parts[1].upper()
                            else:
                                continue
                            rows.append({
                                "RAW_DATASET":   rds,
                                "RAW_VARIABLE":  rv,
                                "SDTM_DOMAIN":   str(mrow.get("DOMAIN", "")),
                                "SDTM_VARIABLE": str(mrow.get("SDTM_VARIABLE", "")),
                                "TIER":          tier_label,
                                "SCORE":         mrow.get("COMPOSITE_SCORE", ""),
                            })
                    return rows

                ds_domain_rows = (
                    _parse_ds_domain_rows(direct_df,   "AUTO")
                    + _parse_ds_domain_rows(review_df,   "REVIEW")
                    + _parse_ds_domain_rows(cross_ds_df, "CROSS-DATASET")
                )

                if ds_domain_rows:
                    ds_detail = pd.DataFrame(ds_domain_rows)

                    # Summary: RAW_DATASET → which SDTM domains it feeds
                    # Format: raw.ae → AE, DM  (how the spec shows it)
                    ds_summary_rows = []
                    for rds, grp in ds_detail.groupby("RAW_DATASET"):
                        domains_list = sorted(grp["SDTM_DOMAIN"].dropna().unique())
                        ds_summary_rows.append({
                            "RAW_DATASET":      rds,
                            "RAW_DATASET_PATH": f"raw.{rds.lower()}",
                            "MAPS_TO_DOMAINS":  " → " + ", ".join(domains_list),
                            "SDTM_DOMAINS":     ", ".join(domains_list),
                            "N_SDTM_DOMAINS":   len(domains_list),
                            "N_RAW_VARS_USED":  grp["RAW_VARIABLE"].nunique(),
                            "N_SDTM_VARS":      grp["SDTM_VARIABLE"].nunique(),
                            "TIERS":            ", ".join(sorted(grp["TIER"].dropna().unique())),
                        })
                    ds_summary = pd.DataFrame(ds_summary_rows).sort_values("RAW_DATASET")

                    # Issue detection: flag datasets that map to unexpected domains
                    ds_issues = []
                    for _, dr in ds_summary.iterrows():
                        rds = dr["RAW_DATASET"]
                        domains = dr["SDTM_DOMAINS"].split(", ")
                        rds_prefix = rds[:2].upper()
                        unexpected = [d for d in domains
                                      if d[:2].upper() != rds_prefix
                                      and d not in ("DM", "SUPPQUAL")]
                        if unexpected:
                            ds_issues.append({
                                "RAW_DATASET":        rds,
                                "MAPS_TO":            dr["SDTM_DOMAINS"],
                                "UNEXPECTED_DOMAINS": ", ".join(unexpected),
                                "ISSUE":              "Raw dataset name prefix does not match SDTM domain — verify mapping intent",
                            })

                    st.markdown("---")
                    st.markdown("#### Raw Dataset → SDTM Domain Mapping")
                    st.caption(
                        "How raw datasets feed SDTM domains. Format: raw.ae → AE, DM means "
                        "the raw.ae dataset feeds both AE and DM domains. "
                        "⚠ rows = dataset name prefix doesn't match SDTM domain — verify intent."
                    )

                    # Colour-code issues inline
                    ds_summary["Status"] = ds_summary["RAW_DATASET"].apply(
                        lambda r: "⚠ Prefix mismatch"
                        if any(i["RAW_DATASET"] == r for i in ds_issues) else "✓ OK"
                    )
                    # Show clean mapping format: raw.ae → AE, DM
                    display_summary = ds_summary[[
                        "RAW_DATASET_PATH","MAPS_TO_DOMAINS",
                        "N_RAW_VARS_USED","N_SDTM_VARS","N_SDTM_DOMAINS","Status"
                    ]].rename(columns={
                        "RAW_DATASET_PATH": "Raw Dataset",
                        "MAPS_TO_DOMAINS":  "Maps To SDTM Domains",
                        "N_RAW_VARS_USED":  "Raw Vars Used",
                        "N_SDTM_VARS":      "SDTM Vars Covered",
                        "N_SDTM_DOMAINS":   "# SDTM Domains",
                    })
                    st.dataframe(display_summary, use_container_width=True, hide_index=True)

                    if ds_issues:
                        st.warning(
                            f"{len(ds_issues)} raw dataset(s) map to domains that don't match their name prefix. "
                            "These may be intentional (e.g. QSXXX → QS) or miscategorised — review below."
                        )
                        with st.expander("⚠ Dataset-Domain Mismatch Issues"):
                            st.dataframe(pd.DataFrame(ds_issues),
                                         use_container_width=True, hide_index=True)

                    with st.expander("Detailed variable-level dataset→domain mapping"):
                        st.dataframe(ds_detail, use_container_width=True, hide_index=True)

                # ---- Coverage chart ----
                if not coverage.empty:
                    chart_bytes = coverage_chart_bytes(coverage)
                    if chart_bytes:
                        st.markdown("---")
                        st.markdown("#### Coverage by SDTM Domain")
                        st.image(chart_bytes)
                    display_cols = [
                        c for c in
                        ["DOMAIN","TOTAL","DIRECT","REVIEW","UNRESOLVED",
                         "AUTO_PCT","TOTAL_COVERAGE_PCT","N_DERIVED","N_TIMING","N_RESULT"]
                        if c in coverage.columns
                    ]
                    st.dataframe(coverage[display_cols], use_container_width=True, hide_index=True)

                # ---- Mapping results tabs ----
                st.markdown("---")
                st.markdown("#### Mapping Results — Review Before Writing to Spec")
                st.caption(
                    "🟢 GREEN = auto-accepted (bold text + green fill in spec). "
                    "🟡 AMBER = needs review (bold text + amber fill). "
                    "🟣 CROSS-DATASET = variable name matched across differently-named dataset — manual review required. "
                    "These highlights are written into the Input Variables column of your spec."
                )

                def build_view(df, tier_label, extra_cols=None, include_xai=False):
                    if df is None or df.empty:
                        return pd.DataFrame()
                    rows = []
                    for _, r in df.iterrows():
                        raw_str = str(r.get("RAW_VARIABLES_ASSIGNED", "") or "")
                        if not raw_str or raw_str in ("nan", ""):
                            raw_tokens = [("", "")]
                        else:
                            raw_tokens = []
                            for tok in raw_str.split(","):
                                tok = tok.strip()
                                parts = tok.split(".")
                                if len(parts) >= 3:
                                    raw_tokens.append((parts[-2], parts[-1]))
                                elif len(parts) == 2:
                                    raw_tokens.append((parts[0], parts[1]))
                                else:
                                    raw_tokens.append(("", tok))
                        score_val = r.get("COMPOSITE_SCORE", 0.0) or 0.0
                        try:
                            score_val = float(score_val)
                        except Exception:
                            score_val = 0.0
                        for rds, rv in raw_tokens:
                            row_d = {
                                "RAW_DATASET":   rds,
                                "RAW_VARIABLE":  rv,
                                "SDTM_DOMAIN":   str(r.get("DOMAIN", "")),
                                "SDTM_VARIABLE": str(r.get("SDTM_VARIABLE", "")),
                                "SDTM_LABEL":    str(r.get("SDTM_LABEL", "")),
                                "MAPPING_ACTION":str(r.get("MAPPING_ACTION", "")),
                                "ORIGIN":        str(r.get("ORIGIN", "")),
                                "SCORE":         round(score_val, 3),
                            }
                            if include_xai:
                                row_d["SCORE_BREAKDOWN"] = str(r.get("SCORE_BREAKDOWN", "") or "")
                            if extra_cols:
                                for ec in extra_cols:
                                    row_d[ec] = str(r.get(ec, "") or "")
                            rows.append(row_d)
                    return pd.DataFrame(rows)

                view_direct   = build_view(direct_df,   "AUTO",          include_xai=show_xai)
                view_review   = build_view(review_df,   "REVIEW",        include_xai=show_xai)
                view_cross_ds = build_view(cross_ds_df, "CROSS-DATASET", extra_cols=["MATCH_NOTE"], include_xai=show_xai)
                view_unres    = build_view(unres_df,    "UNRESOLVED")

                tab_labels = []
                if not view_direct.empty:   tab_labels.append(f"🟢 Auto-Mapped ({d_n})")
                if not view_review.empty:   tab_labels.append(f"🟡 Review ({r_n})")
                if not view_cross_ds.empty: tab_labels.append(f"🟣 Cross-Dataset ({cds_n})")
                if not view_unres.empty:    tab_labels.append(f"🔴 Unresolved ({u_n})")
                if not unmapped.empty:      tab_labels.append(f"Unmapped Raw ({len(unmapped)})")

                def _score_color(v):
                    try:
                        f = float(v)
                        if f >= 0.82: return "color: #3fb950; font-weight:700"
                        if f >= 0.55: return "color: #e3b341; font-weight:700"
                        return "color: #f85149; font-weight:700"
                    except Exception:
                        return ""

                def _styled_df(df_in):
                    if "SCORE" in df_in.columns:
                        return df_in.style.applymap(_score_color, subset=["SCORE"])
                    return df_in

                if tab_labels:
                    tabs = st.tabs(tab_labels)
                    ti = 0
                    if not view_direct.empty:
                        with tabs[ti]:
                            st.caption(
                                "✅ Auto-mapped with high confidence — "
                                "Input Variables will be **GREEN bold** in the spec."
                            )
                            st.dataframe(_styled_df(view_direct), use_container_width=True, hide_index=True)
                            if show_xai and "SCORE_BREAKDOWN" in view_direct.columns:
                                with st.expander("📊 Score Breakdown (XAI)"):
                                    for _, xr in view_direct.iterrows():
                                        xai_html = _render_xai_bar(xr.get("SCORE_BREAKDOWN",""))
                                        if xai_html:
                                            st.markdown(
                                                f"<div style='background:#161b22;border:1px solid #30363d;"
                                                f"border-radius:6px;padding:10px 14px;margin:4px 0'>"
                                                f"<span style='font-size:12px;color:#e6edf3;font-weight:600'>"
                                                f"{xr.get('SDTM_DOMAIN','')}.{xr.get('SDTM_VARIABLE','')}"
                                                f" ← {xr.get('RAW_DATASET','')}.{xr.get('RAW_VARIABLE','')}"
                                                f"</span>{xai_html}</div>",
                                                unsafe_allow_html=True
                                            )
                        ti += 1
                    if not view_review.empty:
                        with tabs[ti]:
                            st.caption(
                                "⚠️ Lower confidence — programmer review needed. "
                                "Input Variables will be **AMBER bold** in the spec."
                            )
                            st.dataframe(_styled_df(view_review), use_container_width=True, hide_index=True)
                            if show_xai and "SCORE_BREAKDOWN" in view_review.columns:
                                with st.expander("📊 Score Breakdown (XAI) — why these were flagged"):
                                    for _, xr in view_review.iterrows():
                                        xai_html = _render_xai_bar(xr.get("SCORE_BREAKDOWN",""))
                                        if xai_html:
                                            st.markdown(
                                                f"<div style='background:#161b22;border:1px solid #30363d;"
                                                f"border-radius:6px;padding:10px 14px;margin:4px 0'>"
                                                f"<span style='font-size:12px;color:#e3b341;font-weight:600'>"
                                                f"{xr.get('SDTM_DOMAIN','')}.{xr.get('SDTM_VARIABLE','')}"
                                                f" ← {xr.get('RAW_DATASET','')}.{xr.get('RAW_VARIABLE','')}"
                                                f"</span>{xai_html}</div>",
                                                unsafe_allow_html=True
                                            )
                        ti += 1
                    if not view_cross_ds.empty:
                        with tabs[ti]:
                            st.warning(
                                "🟣 Variable name matched across differently-named dataset. "
                                "Dataset name differs from SDTM domain prefix. "
                                "**Each row requires manual programmer review before adding to spec.**"
                            )
                            st.dataframe(view_cross_ds, use_container_width=True, hide_index=True)
                            st.info(
                                "Confirm the raw dataset genuinely feeds this SDTM domain, "
                                "then manually update the spec or use Write Back (written as REVIEW-tier)."
                            )
                        ti += 1
                    if not view_unres.empty:
                        with tabs[ti]:
                            st.caption("No match found. Not written to spec. Manual assignment required.")
                            st.dataframe(view_unres, use_container_width=True, hide_index=True)
                        ti += 1
                    if not unmapped.empty:
                        with tabs[ti]:
                            st.caption("Raw variables not matched to any SDTM variable.")
                            st.dataframe(unmapped, use_container_width=True, hide_index=True)

                st.markdown("---")
                st.markdown("#### Download Results and Proceed to Write Back")
                file_download_button(out_path, "Download mapping_results.xlsx")
                st.session_state["results_xlsx_bytes"] = out_path.read_bytes()
                st.session_state["map_done"] = True
                st.success(
                    "Mapping complete. Go to **Write Back to Spec** to apply "
                    "these results to your sponsor template."
                )

        except Exception as exc:
            st.error(f"Mapping failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)


# ===========================================================================
# PAGE: Write Back to Spec
# ===========================================================================

elif page == "Write Back to Spec":
    st.markdown("## Phase 3 - Write Back to Spec")
    st.info(
        "Populate Input Variables, Mapping Action, and Origin columns in your "
        "SDTM spec Excel. All original formatting is preserved. "
        "Input Variables cells are highlighted with **bold text + fill color**: "
        "🟢 GREEN (bold green) = auto-accepted, 🟡 AMBER (bold amber) = needs review. "
        "Cross-dataset matches are written as AMBER (review tier). "
        "A change-log sheet is appended for full traceability."
    )

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">New Study Spec</div>', unsafe_allow_html=True)
        wb_spec_upload = st.file_uploader(
            "New study SDTM spec Excel (sponsor template with blank Input Variables)",
            type=["xlsx", "xlsm"],
            key="wb_spec",
        )
        if wb_spec_upload is not None:
            st.session_state["wb_spec_bytes"] = wb_spec_upload.getbuffer().tobytes()
        elif st.session_state.get("wb_spec_bytes"):
            st.caption("✓ Using previously uploaded spec (re-upload to change)")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Mapping Results</div>', unsafe_allow_html=True)
        results_source = st.radio(
            "Results source",
            ["Upload mapping_results.xlsx", "Use results from Phase 2"],
            label_visibility="collapsed",
        )
        if results_source == "Upload mapping_results.xlsx":
            wb_results_upload = st.file_uploader(
                "mapping_results.xlsx from Phase 2",
                type=["xlsx"],
                key="wb_results",
            )
        else:
            wb_results_upload = None
            if st.session_state.get("map_done"):
                st.success("Phase 2 mapping results are ready.")
            else:
                st.warning("No mapping results in this session. Run Phase 2 first.")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Write-Back Options</div>', unsafe_allow_html=True)
        populate_origin  = st.checkbox("Populate Origin column",              value=True)
        populate_action  = st.checkbox("Populate Mapping Action (blank only)", value=True)
        highlight_review = st.checkbox(
            "Highlight Input Variables cells (green=direct, amber=review)",
            value=True,
        )
        dry_run_mode = st.checkbox(
            "Dry-run mode (preview changes, do not write file)",
            value=False,
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">What gets highlighted</div>', unsafe_allow_html=True)
        st.markdown(
            '<div style="font-size:12px;color:#8b949e;line-height:2.2">'
            '<span style="background:#C6EFCE;color:#276221;font-weight:bold;padding:2px 8px;border-radius:3px">GREEN + Bold</span>'
            '&nbsp; Input Variables cell = auto-accepted (score &ge; auto threshold)<br>'
            '<span style="background:#FFF2CC;color:#7d6608;font-weight:bold;padding:2px 8px;border-radius:3px">AMBER + Bold</span>'
            '&nbsp; Input Variables cell = needs programmer review<br>'
            '<span style="background:#FFC7CE;color:#9C0006;font-weight:bold;padding:2px 8px;border-radius:3px">RED + Bold</span>'
            '&nbsp; Input Variables cell = cross-dataset match (manual review required)<br>'
            '<small>Bold text + fill color ensures highlights are visible even over existing sponsor cell colors.<br>'
            'Only the Input Variables cell is highlighted &mdash; all other cells keep their original sponsor formatting.</small>'
            '</div>',
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    results_ready = (
        (results_source == "Upload mapping_results.xlsx" and wb_results_upload is not None)
        or (results_source != "Upload mapping_results.xlsx" and st.session_state.get("map_done"))
    )
    spec_ready_wb = (wb_spec_upload is not None) or bool(st.session_state.get("wb_spec_bytes"))
    if not spec_ready_wb:
        st.caption("Upload a spec Excel to enable Write Back")
    run_wb = st.button(
        "Dry-Run Preview" if dry_run_mode else "Write Back to Spec",
        disabled=(not spec_ready_wb or not results_ready),
    )

    if run_wb:
        tmpdir = _make_tmpdir()
        try:
            if wb_spec_upload is not None:
                spec_path = save_upload(wb_spec_upload, tmpdir)
            elif st.session_state.get("wb_spec_bytes"):
                spec_path = Path(tmpdir) / "wb_spec.xlsx"
                spec_path.write_bytes(st.session_state["wb_spec_bytes"])
            else:
                st.error("No spec file available. Please upload one.")
                raise ValueError("No spec file")

            if wb_results_upload is not None:
                results_path = save_upload(wb_results_upload, tmpdir)
            else:
                results_path = Path(tmpdir) / "mapping_results.xlsx"
                results_path.write_bytes(st.session_state["results_xlsx_bytes"])

            out_path = Path(tmpdir) / (
                "spec_preview.xlsx" if dry_run_mode else "spec_mapped.xlsx"
            )

            st.markdown("### Writing...")
            result_path, val_report, log_lines = run_writeback_with_progress(
                spec_path=spec_path,
                results_path=results_path,
                out_path=out_path,
                highlight_review=highlight_review,
                populate_origin=populate_origin,
                populate_action=populate_action,
                dry_run=dry_run_mode,
                config_path=cfg_path_input,
            )

            if dry_run_mode:
                st.warning(
                    "Dry-run complete. Check the log above for preview of changes. "
                    "Uncheck Dry-run mode and re-run to apply."
                )
            else:
                st.success(
                    "✅ Spec updated. Input Variables cells are highlighted with bold text + fill color "
                    "(GREEN bold = auto-accepted, AMBER bold = needs review). "
                    "A change-log sheet has been appended — use it to trace every updated variable."
                )
                file_download_button(out_path, "Download Updated Spec Excel")

                # ---- Validation Report ----
                if val_report:
                    st.markdown("---")
                    st.markdown("#### Post-Writeback Validation Report")
                    st.session_state["last_val_report"] = val_report
                    from excel_validator import render_validation_report, export_validation_report_excel
                    st.markdown(render_validation_report(val_report), unsafe_allow_html=True)

                    # Download buttons — JSON and Excel formats
                    import json as _json, io as _io
                    val_json_bytes = _json.dumps(val_report, indent=2).encode()
                    _dl_col1, _dl_col2 = st.columns(2)
                    with _dl_col1:
                        st.download_button(
                            label="📋 Download Validation Report (JSON)",
                            data=val_json_bytes,
                            file_name=f"validation_report_{out_path.stem}.json",
                            mime="application/json",
                        )
                    with _dl_col2:
                        try:
                            _val_excel_buf = _io.BytesIO()
                            export_validation_report_excel(val_report, _val_excel_buf)
                            _val_excel_buf.seek(0)
                            st.download_button(
                                label="📊 Download Validation Report (Excel)",
                                data=_val_excel_buf.read(),
                                file_name=f"validation_report_{out_path.stem}.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            )
                        except Exception as _ve2:
                            st.caption(f"Excel export unavailable: {_ve2}")

                    # Recommendations
                    recs = val_report.get("recommendations", [])
                    if recs:
                        with st.expander(f"📌 {len(recs)} Recommendations"):
                            for rec in recs:
                                icon = "🔧" if rec.get("auto_fix_possible") else "👤"
                                tgt  = rec.get("target", "")
                                tgt_str = ", ".join(tgt) if isinstance(tgt, list) else str(tgt)
                                st.markdown(
                                    f"{icon} **{rec['action']}** — target: `{tgt_str}`"
                                    + (f"  \n→ _{rec['auto_fix_action']}_"
                                       if rec.get("auto_fix_action") else "")
                                )

        except Exception as exc:
            st.error(f"Write-back failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)


# ===========================================================================
# PAGE: CDM Variable Filter
# ===========================================================================

# ===========================================================================
# PAGE: Compare Specs - side-by-side diff of original vs mapped spec
# ===========================================================================

elif page == "Compare Specs":
    st.markdown("## Compare Specs — Side-by-Side Review")
    st.info(
        "Upload the original (standard) spec and the mapped spec from Write Back. "
        "Differences in Input Variables, Mapping Action, and Origin are shown side by side. "
        "Only changed rows are shown by default."
    )

    cmp_col_l, cmp_col_r = st.columns(2)
    with cmp_col_l:
        st.markdown('<div class="card"><div class="card-title">Original / Standard Spec</div>', unsafe_allow_html=True)
        orig_spec_upload = st.file_uploader("Original spec Excel", type=["xlsx","xlsm"], key="cmp_orig")
        if orig_spec_upload is not None:
            st.session_state["cmp_orig_bytes"] = (orig_spec_upload.name, orig_spec_upload.getbuffer().tobytes())
        elif st.session_state.get("cmp_orig_bytes"):
            st.caption(f"✓ Cached: {st.session_state['cmp_orig_bytes'][0]}")
        st.markdown("</div>", unsafe_allow_html=True)
    with cmp_col_r:
        st.markdown('<div class="card"><div class="card-title">Mapped Spec (Write Back output)</div>', unsafe_allow_html=True)
        mapped_spec_upload = st.file_uploader("Mapped spec Excel", type=["xlsx","xlsm"], key="cmp_mapped")
        if mapped_spec_upload is not None:
            st.session_state["cmp_mapped_bytes"] = (mapped_spec_upload.name, mapped_spec_upload.getbuffer().tobytes())
        elif st.session_state.get("cmp_mapped_bytes"):
            st.caption(f"✓ Cached: {st.session_state['cmp_mapped_bytes'][0]}")
        st.markdown("</div>", unsafe_allow_html=True)

    cmp_opt_l, cmp_opt_r = st.columns(2)
    with cmp_opt_l:
        show_all_rows    = st.checkbox("Show all rows (not just changed)", value=False)
    with cmp_opt_r:
        domain_filter_cmp = st.text_input("Filter domains (comma-separated, blank = all)", placeholder="DM, AE, CM")

    _SKIP_SHEETS = {"study","standards","toc","<ds>","ta","te","ti","tv","ts","td",
                    "ta-data","te-data","maintenance","valuelist","suppqual"}
    _HDR_VAR  = ["variable","sdtm variable","varname","var"]
    _HDR_DS   = ["dataset","domain","sdtm dataset"]
    _HDR_INP  = ["input variables","input variable","input_variables","raw inputs","source variables"]
    _HDR_ACT  = ["mapping action","mapping_action","derivation","algorithm","action"]
    _HDR_ORIG = ["origin","data origin","source type"]

    def _read_spec_for_compare(uploaded_file):
        import io as _io
        raw_bytes = uploaded_file.read()
        uploaded_file.seek(0)
        result = {}
        try:
            xl = pd.ExcelFile(_io.BytesIO(raw_bytes), engine="openpyxl")
            for sn in xl.sheet_names:
                if sn.lower().strip() in _SKIP_SHEETS:
                    continue
                try:
                    df = pd.read_excel(_io.BytesIO(raw_bytes), sheet_name=sn,
                                       header=None, engine="openpyxl", dtype=str).fillna("")
                    hdr_row, col_map = None, {}
                    for ri in range(min(15, len(df))):
                        row_vals = df.iloc[ri].tolist()
                        found = {}
                        for ci, v in enumerate(row_vals):
                            vl = str(v).strip().lower()
                            if vl in _HDR_VAR  and "VAR"  not in found: found["VAR"]    = ci
                            if vl in _HDR_DS   and "DS"   not in found: found["DS"]     = ci
                            if vl in _HDR_INP  and "INP"  not in found: found["INP"]    = ci
                            if vl in _HDR_ACT  and "ACT"  not in found: found["ACT"]    = ci
                            if vl in _HDR_ORIG and "ORIG" not in found: found["ORIG"]   = ci
                        if "VAR" in found and "INP" in found:
                            hdr_row, col_map = ri, found
                            break
                    if hdr_row is None:
                        continue
                    data = df.iloc[hdr_row + 1:].reset_index(drop=True)
                    rows = []
                    for _, drow in data.iterrows():
                        var = str(drow.iloc[col_map["VAR"]]).strip()
                        if not var or var.lower() == "nan":
                            continue
                        rows.append({
                            "VARIABLE":       var.upper(),
                            "DOMAIN":         str(drow.iloc[col_map["DS"]]).strip().upper() if "DS" in col_map else sn.upper(),
                            "INPUT_VARIABLES":str(drow.iloc[col_map["INP"]]).strip()  if "INP"  in col_map else "",
                            "MAPPING_ACTION": str(drow.iloc[col_map["ACT"]]).strip()  if "ACT"  in col_map else "",
                            "ORIGIN":         str(drow.iloc[col_map["ORIG"]]).strip() if "ORIG" in col_map else "",
                        })
                    if rows:
                        result[sn] = pd.DataFrame(rows)
                except Exception:
                    continue
        except Exception as exc:
            st.error(f"Could not read spec: {exc}")
        return result

    def _norm_tokens_cmp(s):
        return sorted(t.strip().lower() for t in str(s).replace(";",",").split(",") if t.strip() and t.strip() != "nan")

    # Use cached bytes if upload widgets are empty
    _cmp_orig_src   = orig_spec_upload   or (st.session_state.get("cmp_orig_bytes")   and _bytes_to_file(st.session_state["cmp_orig_bytes"]))
    _cmp_mapped_src = mapped_spec_upload or (st.session_state.get("cmp_mapped_bytes") and _bytes_to_file(st.session_state["cmp_mapped_bytes"]))

    if _cmp_orig_src and _cmp_mapped_src:
        with st.spinner("Reading and comparing specs..."):
            orig_sheets   = _read_spec_for_compare(_cmp_orig_src)
            mapped_sheets = _read_spec_for_compare(_cmp_mapped_src)

        if not orig_sheets or not mapped_sheets:
            st.error("Could not read one or both specs.")
        else:
            filter_list = [d.strip().upper() for d in domain_filter_cmp.split(",") if d.strip()]
            diff_rows_all, same_rows_all = [], []

            for sn, orig_df in orig_sheets.items():
                if filter_list and sn.upper() not in filter_list:
                    continue
                mapped_df = mapped_sheets.get(sn)
                if mapped_df is None:
                    continue

                merged = orig_df.merge(mapped_df, on="VARIABLE", suffixes=("_O","_M"), how="outer").fillna("")
                merged["SHEET"] = sn

                for col in ("INPUT_VARIABLES","MAPPING_ACTION","ORIGIN"):
                    for sfx in ("_O","_M"):
                        k = col + sfx
                        if k not in merged.columns:
                            merged[k] = ""
                        merged[k] = merged[k].astype(str).str.strip()

                def _iv_changed(row):
                    return _norm_tokens_cmp(row["INPUT_VARIABLES_O"]) != _norm_tokens_cmp(row["INPUT_VARIABLES_M"])
                def _act_changed(row):
                    return str(row.get("MAPPING_ACTION_O","")).upper().strip() != str(row.get("MAPPING_ACTION_M","")).upper().strip()
                def _orig_changed(row):
                    return str(row.get("ORIGIN_O","")).upper().strip() != str(row.get("ORIGIN_M","")).upper().strip()

                merged["IV_DIFF"]   = merged.apply(_iv_changed, axis=1)
                merged["ACT_DIFF"]  = merged.apply(_act_changed, axis=1)
                merged["ORIG_DIFF"] = merged.apply(_orig_changed, axis=1)
                merged["ANY_DIFF"]  = merged["IV_DIFF"] | merged["ACT_DIFF"] | merged["ORIG_DIFF"]

                diff_rows_all.append(merged[merged["ANY_DIFF"]])
                same_rows_all.append(merged[~merged["ANY_DIFF"]])

            diff_df_all = pd.concat(diff_rows_all, ignore_index=True) if diff_rows_all else pd.DataFrame()
            same_df_all = pd.concat(same_rows_all, ignore_index=True) if same_rows_all else pd.DataFrame()
            total_cmp   = len(diff_df_all) + len(same_df_all)

            st.markdown("---")
            cmp_pills = (
                '<div class="metric-row">'
                + metric_html(total_cmp,        "Total Variables", "")
                + metric_html(len(diff_df_all), "Changed",   "amber")
                + metric_html(len(same_df_all), "Unchanged", "green")
                + metric_html(
                    f"{round(100*len(diff_df_all)/total_cmp)}%" if total_cmp else "0%",
                    "Change Rate", "amber"
                )
                + '</div>'
            )
            st.markdown(cmp_pills, unsafe_allow_html=True)

            display_df = pd.concat([diff_df_all, same_df_all], ignore_index=True) if show_all_rows else diff_df_all

            if display_df.empty:
                st.success("No differences found between the two specs.")
            else:
                # Build readable view
                def _flag(b):
                    return "✏️" if b else "✓"

                view_rows = []
                for _, row in display_df.iterrows():
                    iv_o = row.get("INPUT_VARIABLES_O","")
                    iv_m = row.get("INPUT_VARIABLES_M","")
                    act_o = row.get("MAPPING_ACTION_O","")
                    act_m = row.get("MAPPING_ACTION_M","")
                    orig_o = row.get("ORIGIN_O","")
                    orig_m = row.get("ORIGIN_M","")
                    view_rows.append({
                        "Sheet":           row.get("SHEET",""),
                        "Variable":        row.get("VARIABLE",""),
                        "Status":          "✏️ Changed" if row.get("ANY_DIFF") else "✓ Same",
                        "IV — Original":   iv_o,
                        "IV — Mapped":     iv_m,
                        "IV Δ":            _flag(row.get("IV_DIFF",False)),
                        "Action — Orig":   act_o,
                        "Action — Mapped": act_m,
                        "Origin — Orig":   orig_o,
                        "Origin — Mapped": orig_m,
                    })
                view_df = pd.DataFrame(view_rows)

                # Color-grade with st.dataframe column config
                def _highlight_status(val):
                    if val == "✏️ Changed":
                        return "background-color:#FFF2CC;color:#7D6608;font-weight:bold"
                    return "background-color:#C6EFCE;color:#276221"

                st.markdown(f"**Showing {len(view_df)} rows** — {len(diff_df_all)} with differences")

                # Per-domain tabs
                domain_tabs_list = sorted(view_df["Sheet"].dropna().unique().tolist())
                if len(domain_tabs_list) > 1:
                    all_tab_labels = ["🗂 All Domains"] + domain_tabs_list
                    dtabs = st.tabs(all_tab_labels)
                    for dti, dlabel in enumerate(all_tab_labels):
                        with dtabs[dti]:
                            sub = view_df if dlabel == "🗂 All Domains" else view_df[view_df["Sheet"] == dlabel]
                            st.dataframe(
                                sub.drop(columns=["Sheet"], errors="ignore").style.applymap(
                                    _highlight_status, subset=["Status"]
                                ),
                                use_container_width=True, hide_index=True,
                            )
                else:
                    st.dataframe(
                        view_df.drop(columns=["Sheet"], errors="ignore").style.applymap(
                            _highlight_status, subset=["Status"]
                        ),
                        use_container_width=True, hide_index=True,
                    )

                st.markdown("---")
                excel_download_button(
                    {"Changed": diff_df_all[["SHEET","VARIABLE","INPUT_VARIABLES_O","INPUT_VARIABLES_M",
                                             "MAPPING_ACTION_O","MAPPING_ACTION_M","ORIGIN_O","ORIGIN_M"]]
                                if not diff_df_all.empty else pd.DataFrame(),
                     "All":     display_df[["SHEET","VARIABLE","INPUT_VARIABLES_O","INPUT_VARIABLES_M",
                                            "MAPPING_ACTION_O","MAPPING_ACTION_M"]].head(5000)},
                    "spec_comparison.xlsx",
                    "📥 Download Comparison Excel",
                )
    else:
        missing = []
        if not _cmp_orig_src:   missing.append("Original spec")
        if not _cmp_mapped_src: missing.append("Mapped spec")
        st.markdown(
            f'<div class="card" style="text-align:center;padding:40px">'
            f'<div style="font-size:48px">📊</div>'
            f'<div class="card-title" style="font-size:14px;margin-top:12px">Upload both specs to start comparison</div>'
            f'<div style="font-size:12px;color:#8b949e;margin-top:6px">'
            f'Still needed: {", ".join(missing)}</div>'
            '</div>',
            unsafe_allow_html=True,
        )

elif page == "CDM Variable Filter":
    st.markdown("## CDM Variable Filter")
    st.info(
        "CDM-generated variables (audit trail fields, system IDs, query fields) "
        "should not be mapped to SDTM. Define which raw variables and entire datasets "
        "to exclude before running the mapping. All lists are editable and saved for the session."
    )

    from cdm_filter import CdmFilter
    flt      = CdmFilter.from_dict(st.session_state.get("cdm_filter_dict", {}))

    # Live preview
    st.markdown("### Preview Filter on Your Raw Catalog")
    preview_raw = st.file_uploader(
        "Upload raw catalog (Excel or CSV) to see what would be excluded",
        type=["xlsx", "csv"], key="cdm_preview",
    )
    if preview_raw:
        tmpd = _make_tmpdir()
        try:
            import yaml as _y, logging as _lg
            rp = save_upload(preview_raw, tmpd)
            with open(cfg_path_input) as _f:
                _cfg = _y.safe_load(_f)
            _log = _lg.getLogger("sdtm_pipeline")
            from mapper import read_raw_catalog as _rrc
            raw_prev = _rrc(rp, _cfg, _log)
            usable, excluded = flt.filter_catalog(raw_prev)
            cv1, cv2 = st.columns(2)
            with cv1:
                st.markdown(
                    f'<div class="card"><div class="card-title">Usable ({len(usable)})</div>',
                    unsafe_allow_html=True,
                )
                if not usable.empty:
                    st.dataframe(
                        usable[["RAW_DATASET","VARIABLE","LABEL"]],
                        use_container_width=True, hide_index=True,
                    )
                st.markdown("</div>", unsafe_allow_html=True)
            with cv2:
                st.markdown(
                    f'<div class="card"><div class="card-title">Excluded ({len(excluded)})</div>',
                    unsafe_allow_html=True,
                )
                if not excluded.empty:
                    st.dataframe(
                        excluded[["RAW_DATASET","VARIABLE","LABEL"]],
                        use_container_width=True, hide_index=True,
                    )
                else:
                    st.success("No variables excluded by current filter.")
                st.markdown("</div>", unsafe_allow_html=True)
        except Exception as _exc:
            st.error(f"Preview failed: {_exc}")
        finally:
            _rm_tmpdir(tmpd)

    st.markdown("---")
    tab_vars, tab_ds, tab_sfx, tab_custom = st.tabs([
        "Variable Names", "Dataset Names", "Suffix Patterns", "Custom Regex",
    ])

    with tab_vars:
        st.markdown("##### Excluded Variable Names")
        st.caption(
            "These exact variable names are excluded regardless of which dataset they appear in. "
            "Common examples: CREATEDDTM, MODIFIEDDTM, FORMOID, LOCKED."
        )
        var_text = st.text_area(
            "One variable name per line (uppercase)",
            value="\n".join(sorted(flt.cdm_variables)),
            height=320,
            key="cdm_var_edit",
        )
        vc1, vc2, vc3 = st.columns([2, 2, 1])
        with vc1:
            new_var = st.text_input("Add variable", key="add_cdm_var")
        with vc2:
            del_var = st.text_input("Remove variable", key="del_cdm_var")
        with vc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key="save_vars"):
                new_set = {v.strip().upper() for v in var_text.splitlines() if v.strip()}
                if new_var.strip():
                    new_set.add(new_var.strip().upper())
                if del_var.strip():
                    new_set.discard(del_var.strip().upper())
                flt.cdm_variables = new_set
                st.session_state["cdm_filter_dict"] = flt.to_dict()
                st.success(f"Saved: {len(new_set)} variable exclusions")

    with tab_ds:
        st.markdown("##### Excluded Dataset Names")
        st.caption(
            "All variables from these datasets are excluded entirely. "
            "Examples: AUDIT, QUERIES, BATCHLOG."
        )
        ds_text = st.text_area(
            "One dataset name per line (uppercase MEMNAME)",
            value="\n".join(sorted(flt.cdm_datasets)),
            height=220,
            key="cdm_ds_edit",
        )
        dc1, dc2, dc3 = st.columns([2, 2, 1])
        with dc1:
            new_ds = st.text_input("Add dataset", key="add_cdm_ds")
        with dc2:
            del_ds = st.text_input("Remove dataset", key="del_cdm_ds")
        with dc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key="save_ds"):
                new_set = {d.strip().upper() for d in ds_text.splitlines() if d.strip()}
                if new_ds.strip():
                    new_set.add(new_ds.strip().upper())
                if del_ds.strip():
                    new_set.discard(del_ds.strip().upper())
                flt.cdm_datasets = new_set
                st.session_state["cdm_filter_dict"] = flt.to_dict()
                st.success(f"Saved: {len(new_set)} dataset exclusions")

    with tab_sfx:
        st.markdown("##### Excluded Variable Suffixes")
        st.caption("Variables ending with these suffixes are excluded (CDM backup copies).")
        sfx_text = st.text_area(
            "One suffix per line (e.g. _PREV)",
            value="\n".join(flt.cdm_suffixes),
            height=160,
            key="cdm_sfx_edit",
        )
        if st.button("Save Suffixes"):
            new_sfx = [s.strip().upper() for s in sfx_text.splitlines() if s.strip()]
            flt.cdm_suffixes = new_sfx
            st.session_state["cdm_filter_dict"] = flt.to_dict()
            st.success(f"Saved: {len(new_sfx)} suffix patterns")

    with tab_custom:
        st.markdown("##### Custom Regex Patterns")
        st.caption("Python regex patterns matched against variable names. e.g. ^SYS_ excludes SYS_* variables.")
        custom_text = st.text_area(
            "One regex per line",
            value="\n".join(flt.custom_patterns),
            height=140,
            key="cdm_custom_edit",
        )
        if st.button("Save Patterns"):
            import re as _re
            valid, invalid = [], []
            for p in custom_text.splitlines():
                p = p.strip()
                if not p:
                    continue
                try:
                    _re.compile(p)
                    valid.append(p)
                except _re.error:
                    invalid.append(p)
            flt.custom_patterns = valid
            st.session_state["cdm_filter_dict"] = flt.to_dict()
            if invalid:
                st.warning(f"Invalid patterns skipped: {invalid}")
            st.success(f"Saved: {len(valid)} custom patterns")

    st.markdown("---")
    st.info(
        "The CDM filter is applied automatically during Phase 2 (Map New Study). "
        "Excluded variables appear in the Excluded tab of the results and are never "
        "written to the spec."
    )

elif page == "View Master":
    st.markdown("## View Master Mapping")

    col_l, col_r = st.columns([2, 1])
    with col_l:
        master_view_file = st.file_uploader(
            "Upload master_mapping.xlsx to explore",
            type=["xlsx"],
            key="master_view",
        )
    with col_r:
        if st.session_state.get("master_built"):
            if st.button("Load master from Phase 1"):
                st.session_state["master_view_bytes"] = st.session_state["master_xlsx_bytes"]

    view_bytes = None
    if master_view_file:
        view_bytes = master_view_file.read()
    elif st.session_state.get("master_view_bytes"):
        view_bytes = st.session_state["master_view_bytes"]

    if view_bytes:
        try:
            master_all = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_all",
                                       engine="openpyxl", dtype=object)
            master_top = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_top",
                                       engine="openpyxl", dtype=object)

            if "MASTER_CONFIDENCE" in master_all.columns:
                master_all["MASTER_CONFIDENCE"] = pd.to_numeric(
                    master_all["MASTER_CONFIDENCE"], errors="coerce"
                )

            # Metrics
            pills = (
                '<div class="metric-row">'
                + metric_html(master_all["SDTM_VARIABLE"].nunique() if not master_all.empty else 0, "SDTM Variables")
                + metric_html(master_all["DOMAIN"].nunique()        if not master_all.empty else 0, "Domains")
                + metric_html(len(master_all), "Total Rows")
                + metric_html(
                    int((master_all["MASTER_CONFIDENCE"] >= 0.82).sum()) if "MASTER_CONFIDENCE" in master_all.columns else 0,
                    "High Conf (>=82%)", "green"
                  )
                + '</div>'
            )
            st.markdown(pills, unsafe_allow_html=True)

            st.markdown("---")

            # Filter controls
            fc1, fc2, fc3 = st.columns([1, 1, 2])
            with fc1:
                domains = sorted(master_all["DOMAIN"].dropna().unique().tolist()) if not master_all.empty else []
                domain_filter = st.multiselect("Filter by Domain", options=domains, default=domains)
            with fc2:
                tier_filter = st.multiselect(
                    "Confidence tier",
                    options=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                    default=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                )
            with fc3:
                search_var = st.text_input("Search SDTM Variable", placeholder="e.g. AESTDTC")

            filtered = master_top.copy() if not master_top.empty else master_all.copy()
            if "DOMAIN" in filtered.columns and domain_filter:
                filtered = filtered[filtered["DOMAIN"].isin(domain_filter)]
            if search_var and "SDTM_VARIABLE" in filtered.columns:
                filtered = filtered[
                    filtered["SDTM_VARIABLE"].str.contains(search_var.upper(), na=False)
                ]
            if "MASTER_CONFIDENCE" in filtered.columns:
                conf = pd.to_numeric(filtered["MASTER_CONFIDENCE"], errors="coerce")
                masks = []
                if "High (>=82%)"    in tier_filter: masks.append(conf >= 0.82)
                if "Medium (55-82%)" in tier_filter: masks.append((conf >= 0.55) & (conf < 0.82))
                if "Low (<55%)"      in tier_filter: masks.append(conf < 0.55)
                if masks:
                    import functools
                    combined = functools.reduce(lambda a, b: a | b, masks)
                    filtered = filtered[combined]

            st.markdown(f"**{len(filtered)} rows shown**")
            display_cols = [
                c for c in
                ["DOMAIN","SDTM_VARIABLE","SDTM_LABEL","INPUT_VARIABLES",
                 "MAPPING_ACTION","ORIGIN","N_STUDIES","MASTER_CONFIDENCE",
                 "IS_SPONSOR_STD","SOURCE_FILES"]
                if c in filtered.columns
            ]
            st.dataframe(filtered[display_cols], use_container_width=True, hide_index=True)

        except Exception as exc:
            st.error(f"Could not read master mapping: {exc}")

    else:
        st.info("Upload a master_mapping.xlsx or build one in Phase 1.")


# ===========================================================================
# PAGE: Help
# ===========================================================================

elif page == "Help":
    st.markdown("## Help & Quick Reference")

    tab1, tab2, tab3, tab4 = st.tabs(["Workflow", "File Formats", "Thresholds", "CLI Usage"])

    with tab1:
        st.markdown("""
### Three-Phase Workflow

**Phase 1 - Build Master**

Upload every completed and QC-approved SDTM spec Excel file from previous studies.
The system extracts all `DOMAIN | SDTM_VARIABLE | Input Variables` mappings and
builds a frequency-weighted, recency-decayed confidence score for each.
Sponsor standard specs receive a 3x study-count boost so they always take priority.

Add studies incrementally using Append Mode - no need to rebuild from scratch each time.

---

**Phase 2 - Map New Study**

Upload the new study's raw variable catalog (typically a SAS PROC CONTENTS output
exported to Excel or CSV). The system:

1. Builds a group-aware index of the master mapping
2. Builds a TF-IDF label similarity index over raw variable labels
3. Scores every SDTM variable using a 4-signal composite scorer:
   - Name exact match (35%)
   - Name fuzzy similarity (20%)
   - Label TF-IDF cosine (25%)
   - Master confidence / frequency (20%)
4. Classifies each result as Direct, Review, or Unresolved

---

**Phase 3 - Write Back**

Upload the new study SDTM spec (blank Input Variables). The results from Phase 2
are written into the correct cells while preserving all original formatting.
Origin is written using priority: CRF > Derived > Protocol > eDT > Assigned.
Review rows are highlighted with bold text + fill color (GREEN bold = auto-accepted, AMBER bold = needs review).
A change-log sheet is appended listing every updated cell with tier, score, and notes.
        """)

    with tab2:
        st.markdown("""
### Expected File Formats

**Completed Study Spec (Phase 1 input)**
- Excel workbook with one sheet per SDTM domain
- Must have a TOC sheet with Dataset and Active columns
- Only domains where Active = Y/YES are processed
- Trial domains (TA TE TI TV TS TD) always excluded even if Active=Y
- Required columns per domain sheet: Variable, Input Variables, Mapping Action
- Optional columns: Label, Origin, Codelist, Core, SAS Type, SAS Length

**Raw Variable Catalog (Phase 2 input)**
- PROC CONTENTS output exported to Excel or CSV
- Required columns: MEMNAME (dataset), NAME (variable)
- Optional: LABEL, FORMAT, TYPE

**New Study Spec (Phase 3 input)**
- Same format as completed study spec
- Input Variables, Mapping Action, Origin columns should be blank
- The write-back populates them based on Phase 2 results
        """)

    with tab3:
        st.markdown("""
### Confidence Score & Thresholds

The composite score (0 to 1.0) combines four signals:

| Signal | Default Weight | Description |
|---|---|---|
| Name exact | 35% | Exact slug match between SDTM var name and raw var name |
| Name fuzzy | 20% | Best of seq_ratio / token_sort / token_set similarity |
| Label TF-IDF | 25% | Cosine similarity of variable labels |
| Master freq | 20% | Historical confidence from master_mapping |

**Thresholds (configurable in config.yaml and UI sliders):**

| Tier | Default | Action |
|---|---|---|
| Direct | >= 0.82 | Written to spec immediately | GREEN bold |
| Review | >= 0.55 | Flagged for human review | AMBER bold |
| Cross-Dataset | name >= 0.75 | Variable name match across differently-named dataset | AMBER bold (manual review) |
| Unresolved | < 0.55 | Not written; manual assignment required | — |

**Partial-group penalty:** If a multi-token group (e.g. date+time) has only
some tokens found in the raw catalog, the group score is penalised proportionally.
Default penalty factor: 0.70 (configurable).
        """)

    with tab4:
        st.markdown("""
### CLI Usage (without the UI)

All phases are also available as standalone Python scripts:

```bash
# Phase 1: Build master from completed studies
python pipeline.py build \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --out     master_mapping.xlsx

# Append a new study to existing master
python pipeline.py build \\
    --specs    studies/study_c.xlsx \\
    --existing master_mapping.xlsx \\
    --out      master_mapping.xlsx

# Phase 2: Map new study
python pipeline.py map \\
    --master master_mapping.xlsx \\
    --raw    new_study/proc_contents.xlsx \\
    --spec   new_study/sdtm_spec.xlsx \\
    --out    new_study/mapping_results.xlsx

# Phase 3: Write-back
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx

# Dry-run preview
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx \\
    --dry-run

# Full pipeline (all three phases)
python pipeline.py full \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --raw     new_study/proc_contents.xlsx \\
    --spec    new_study/sdtm_spec.xlsx
```
        """)