"""
Map New Study page — Phase 2
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)


# ---------------------------------------------------------------------------
# Results display — extracted so it can be called from both the run path
# and the session-restore path (tab switch / download re-render).
# ---------------------------------------------------------------------------

def _render_results(
    direct_df, review_df, unres_df, unmapped, coverage, cross_ds_df,
    show_xai, results_xlsx_bytes,
):
    """Render the full mapping results section from dataframes."""
    d_n   = len(direct_df)
    r_n   = len(review_df)
    u_n   = len(unres_df)
    total = d_n + r_n + u_n
    cds_n = len(cross_ds_df)

    st.success(
        f"Mapping complete: {d_n} auto-mapped | "
        f"{r_n} need review | {u_n} unresolved | {total} total"
    )

    pills = (
        '<div class="metric-row">'
        + metric_html(d_n,   "Auto-Mapped",         "green")
        + metric_html(r_n,   "Needs Review",        "amber")
        + metric_html(cds_n, "Cross-Dataset Match", "purple")
        + metric_html(u_n,   "Unresolved",          "red")
        + metric_html(
            f"{round(100*d_n/total)}%" if total else "0%",
            "Auto-Map Rate", "green"
          )
        + metric_html(len(unmapped), "Unmapped Raw Vars", "")
        + '</div>'
    )
    st.markdown(pills, unsafe_allow_html=True)

    # ---- Raw Dataset -> SDTM Domain mapping table -----------------------
    def _parse_ds_domain_rows(df_in, tier_label):
        rows = []
        if df_in is None or df_in.empty:
            return rows
        for _, mrow in df_in.iterrows():
            raw_str = str(mrow.get("RAW_VARIABLES_ASSIGNED", "") or "")
            if not raw_str or raw_str in ("nan", ""):
                continue
            for tok in raw_str.split(","):
                tok   = tok.strip()
                parts = tok.split(".")
                if len(parts) >= 3 and parts[0].upper() == "RAW":
                    rds = parts[1].upper()
                    rv  = parts[2].upper()
                elif len(parts) == 2:
                    rds, rv = parts[0].upper(), parts[1].upper()
                else:
                    continue
                rows.append({
                    "RAW_DATASET":   rds,
                    "RAW_VARIABLE":  rv,
                    "SDTM_DOMAIN":   str(mrow.get("DOMAIN", "")),
                    "SDTM_VARIABLE": str(mrow.get("SDTM_VARIABLE", "")),
                    "TIER":          tier_label,
                    "SCORE":         mrow.get("COMPOSITE_SCORE", ""),
                })
        return rows

    ds_domain_rows = (
        _parse_ds_domain_rows(direct_df,   "AUTO")
        + _parse_ds_domain_rows(review_df,   "REVIEW")
        + _parse_ds_domain_rows(cross_ds_df, "CROSS-DATASET")
    )

    if ds_domain_rows:
        ds_detail = pd.DataFrame(ds_domain_rows)
        ds_summary_rows = []
        for rds, grp in ds_detail.groupby("RAW_DATASET"):
            domains_list = sorted(grp["SDTM_DOMAIN"].dropna().unique())
            ds_summary_rows.append({
                "RAW_DATASET":      rds,
                "RAW_DATASET_PATH": f"raw.{rds.lower()}",
                "MAPS_TO_DOMAINS":  " -> " + ", ".join(domains_list),
                "SDTM_DOMAINS":     ", ".join(domains_list),
                "N_SDTM_DOMAINS":   len(domains_list),
                "N_RAW_VARS_USED":  grp["RAW_VARIABLE"].nunique(),
                "N_SDTM_VARS":      grp["SDTM_VARIABLE"].nunique(),
                "TIERS":            ", ".join(sorted(grp["TIER"].dropna().unique())),
            })
        ds_summary = pd.DataFrame(ds_summary_rows).sort_values("RAW_DATASET")

        LEGIT_CROSS = {
            ("AE","DS"),("AE","MH"),("CM","EC"),("CM","SU"),("CM","EX"),
            ("EX","EC"),("EX","CM"),("LB","PC"),("VS","EG"),("EG","VS"),
            ("QS","RS"),("RS","QS"),("DS","AE"),("MH","AE"),
        }
        ALWAYS_OK_DOMAINS = {"DM","SUPPQUAL","SE","SV","CO","SM"}
        ds_issues = []
        for _, dr in ds_summary.iterrows():
            rds = dr["RAW_DATASET"]
            domains = dr["SDTM_DOMAINS"].split(", ")
            rds_prefix = rds[:2].upper()
            unexpected = [
                d for d in domains
                if d[:2].upper() != rds_prefix
                and d.upper() not in ALWAYS_OK_DOMAINS
                and (rds_prefix, d[:2].upper()) not in LEGIT_CROSS
            ]
            if unexpected:
                ds_issues.append({
                    "RAW_DATASET":        rds,
                    "MAPS_TO":            dr["SDTM_DOMAINS"],
                    "UNEXPECTED_DOMAINS": ", ".join(unexpected),
                    "ISSUE":              "Unexpected cross-domain - verify mapping intent",
                })

        st.markdown("---")
        st.markdown("#### Raw Dataset -> SDTM Domain Mapping")
        st.caption(
            "How raw datasets feed SDTM domains. "
            "Format: raw.ae -> AE, DM means the raw.ae dataset feeds both AE and DM. "
            "Warning rows = dataset prefix does not match SDTM domain - verify intent."
        )
        ds_summary["Status"] = ds_summary["RAW_DATASET"].apply(
            lambda r: "Warning: Prefix mismatch"
            if any(i["RAW_DATASET"] == r for i in ds_issues) else "OK"
        )
        display_summary = ds_summary[[
            "RAW_DATASET_PATH","MAPS_TO_DOMAINS",
            "N_RAW_VARS_USED","N_SDTM_VARS","N_SDTM_DOMAINS","Status"
        ]].rename(columns={
            "RAW_DATASET_PATH": "Raw Dataset",
            "MAPS_TO_DOMAINS":  "Maps To SDTM Domains",
            "N_RAW_VARS_USED":  "Raw Vars Used",
            "N_SDTM_VARS":      "SDTM Vars Covered",
            "N_SDTM_DOMAINS":   "# SDTM Domains",
        })
        st.dataframe(display_summary, use_container_width=True, hide_index=True)
        if ds_issues:
            st.warning(
                f"{len(ds_issues)} raw dataset(s) map to domains that do not match "
                "their name prefix. These may be intentional or miscategorised - review below."
            )
            with st.expander("Dataset-Domain Mismatch Issues"):
                st.dataframe(pd.DataFrame(ds_issues), use_container_width=True, hide_index=True)
        with st.expander("Detailed variable-level dataset->domain mapping"):
            st.dataframe(ds_detail, use_container_width=True, hide_index=True)

    # ---- Coverage chart -------------------------------------------------
    if not coverage.empty:
        chart_bytes = coverage_chart_bytes(coverage)
        if chart_bytes:
            st.markdown("---")
            st.markdown("#### Coverage by SDTM Domain")
            st.image(chart_bytes)
        display_cols = [
            c for c in
            ["DOMAIN","TOTAL","DIRECT","REVIEW","UNRESOLVED",
             "AUTO_PCT","TOTAL_COVERAGE_PCT","N_DERIVED","N_TIMING","N_RESULT"]
            if c in coverage.columns
        ]
        st.dataframe(coverage[display_cols], use_container_width=True, hide_index=True)

    # ---- Mapping results tabs -------------------------------------------
    st.markdown("---")
    st.markdown("#### Mapping Results - Review Before Writing to Spec")
    st.caption(
        "GREEN = auto-accepted (bold text + green fill in spec). "
        "AMBER = needs review (bold text + amber fill). "
        "CROSS-DATASET = variable name matched across differently-named dataset - manual review required. "
        "These highlights are written into the Input Variables column of your spec."
    )

    def build_view(df, tier_label, extra_cols=None, include_xai=False):
        if df is None or df.empty:
            return pd.DataFrame()
        rows = []
        for _, r in df.iterrows():
            raw_str = str(r.get("RAW_VARIABLES_ASSIGNED", "") or "")
            if not raw_str or raw_str in ("nan", ""):
                raw_tokens = [("", "")]
            else:
                raw_tokens = []
                for tok in raw_str.split(","):
                    tok = tok.strip()
                    parts = tok.split(".")
                    if len(parts) >= 3:
                        raw_tokens.append((parts[-2], parts[-1]))
                    elif len(parts) == 2:
                        raw_tokens.append((parts[0], parts[1]))
                    else:
                        raw_tokens.append(("", tok))
            score_val = r.get("COMPOSITE_SCORE", 0.0) or 0.0
            try:
                score_val = float(score_val)
            except Exception:
                score_val = 0.0
            for rds, rv in raw_tokens:
                row_d = {
                    "RAW_DATASET":    rds,
                    "RAW_VARIABLE":   rv,
                    "SDTM_DOMAIN":    str(r.get("DOMAIN", "")),
                    "SDTM_VARIABLE":  str(r.get("SDTM_VARIABLE", "")),
                    "SDTM_LABEL":     str(r.get("SDTM_LABEL", "")),
                    "MAPPING_ACTION": str(r.get("MAPPING_ACTION", "")),
                    "ORIGIN":         str(r.get("ORIGIN", "")),
                    "SCORE":          round(score_val, 3),
                }
                if include_xai:
                    row_d["SCORE_BREAKDOWN"] = str(r.get("SCORE_BREAKDOWN", "") or "")
                if extra_cols:
                    for ec in extra_cols:
                        row_d[ec] = str(r.get(ec, "") or "")
                rows.append(row_d)
        return pd.DataFrame(rows)

    view_direct   = build_view(direct_df,   "AUTO",          include_xai=show_xai)
    view_review   = build_view(review_df,   "REVIEW",        include_xai=show_xai)
    view_cross_ds = build_view(cross_ds_df, "CROSS-DATASET", extra_cols=["MATCH_NOTE"], include_xai=show_xai)
    view_unres    = build_view(unres_df,    "UNRESOLVED")

    tab_labels = []
    if not view_direct.empty:   tab_labels.append(f"Auto-Mapped ({d_n})")
    if not view_review.empty:   tab_labels.append(f"Review ({r_n})")
    if not view_cross_ds.empty: tab_labels.append(f"Cross-Dataset ({cds_n})")
    if not view_unres.empty:    tab_labels.append(f"Unresolved ({u_n})")
    if not unmapped.empty:      tab_labels.append(f"Unmapped Raw ({len(unmapped)})")

    def _score_color(v):
        try:
            f = float(v)
            if f >= 0.82: return "color: #3fb950; font-weight:700"
            if f >= 0.55: return "color: #e3b341; font-weight:700"
            return "color: #f85149; font-weight:700"
        except Exception:
            return ""

    def _styled_df(df_in):
        if "SCORE" in df_in.columns:
            return df_in.style.applymap(_score_color, subset=["SCORE"])
        return df_in

    if tab_labels:
        tabs = st.tabs(tab_labels)
        ti = 0
        if not view_direct.empty:
            with tabs[ti]:
                st.caption("Auto-mapped with high confidence - Input Variables will be GREEN bold in the spec.")
                st.dataframe(_styled_df(view_direct), use_container_width=True, hide_index=True)
                if show_xai and "SCORE_BREAKDOWN" in view_direct.columns:
                    with st.expander("Score Breakdown (XAI)"):
                        for _, xr in view_direct.iterrows():
                            xai_html = _render_xai_bar(xr.get("SCORE_BREAKDOWN",""))
                            if xai_html:
                                st.markdown(
                                    f"<div style='background:#161b22;border:1px solid #30363d;"
                                    f"border-radius:6px;padding:10px 14px;margin:4px 0'>"
                                    f"<span style='font-size:12px;color:#e6edf3;font-weight:600'>"
                                    f"{xr.get('SDTM_DOMAIN','')}.{xr.get('SDTM_VARIABLE','')}"
                                    f" <- {xr.get('RAW_DATASET','')}.{xr.get('RAW_VARIABLE','')}"
                                    f"</span>{xai_html}</div>",
                                    unsafe_allow_html=True
                                )
            ti += 1
        if not view_review.empty:
            with tabs[ti]:
                st.caption("Lower confidence - programmer review needed. Input Variables will be AMBER bold in the spec.")
                st.dataframe(_styled_df(view_review), use_container_width=True, hide_index=True)
                if show_xai and "SCORE_BREAKDOWN" in view_review.columns:
                    with st.expander("Score Breakdown (XAI) - why these were flagged"):
                        for _, xr in view_review.iterrows():
                            xai_html = _render_xai_bar(xr.get("SCORE_BREAKDOWN",""))
                            if xai_html:
                                st.markdown(
                                    f"<div style='background:#161b22;border:1px solid #30363d;"
                                    f"border-radius:6px;padding:10px 14px;margin:4px 0'>"
                                    f"<span style='font-size:12px;color:#e3b341;font-weight:600'>"
                                    f"{xr.get('SDTM_DOMAIN','')}.{xr.get('SDTM_VARIABLE','')}"
                                    f" <- {xr.get('RAW_DATASET','')}.{xr.get('RAW_VARIABLE','')}"
                                    f"</span>{xai_html}</div>",
                                    unsafe_allow_html=True
                                )
            ti += 1
        if not view_cross_ds.empty:
            with tabs[ti]:
                st.warning(
                    "Variable name matched across differently-named dataset. "
                    "Dataset name differs from SDTM domain prefix. "
                    "Each row requires manual programmer review before adding to spec."
                )
                st.dataframe(view_cross_ds, use_container_width=True, hide_index=True)
                st.info(
                    "Confirm the raw dataset genuinely feeds this SDTM domain, "
                    "then manually update the spec or use Write Back (written as REVIEW-tier)."
                )
            ti += 1
        if not view_unres.empty:
            with tabs[ti]:
                st.caption("No match found. Not written to spec. Manual assignment required.")
                st.dataframe(view_unres, use_container_width=True, hide_index=True)
            ti += 1
        if not unmapped.empty:
            with tabs[ti]:
                st.caption("Raw variables not matched to any SDTM variable.")
                st.dataframe(unmapped, use_container_width=True, hide_index=True)

    # ---- Download -------------------------------------------------------
    st.markdown("---")
    st.markdown("#### Download Results and Proceed to Write Back")
    if results_xlsx_bytes:
        st.download_button(
            label="Download mapping_results.xlsx",
            data=results_xlsx_bytes,
            file_name="mapping_results.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    st.success(
        "Mapping complete. Go to Write Back to Spec to apply "
        "these results to your sponsor template."
    )


# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------

def render():
    """Render this page."""
    cfg_path_input = st.session_state.get(
        "cfg_path_input",
        str(APP_DIR / "src" / "config.yaml")
    )
    st.markdown("## Phase 2 - Map Raw Variables to SDTM")
    st.info(
        "Upload your raw SAS datasets (.xpt / .sas7bdat) directly, or a PROC CONTENTS "
        "catalog (Excel/CSV). The system maps each raw variable to the correct SDTM domain "
        "and variable using the master mapping knowledge base. Review results before writing "
        "to spec."
    )

    from cdm_filter import CdmFilter
    _flt = CdmFilter.from_dict(st.session_state.get("cdm_filter_dict", {}))

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Master Mapping</div>', unsafe_allow_html=True)
        master_source = st.radio(
            "Master source",
            ["Upload master_mapping.xlsx", "Use master built in Phase 1 (this session)"],
            label_visibility="collapsed",
        )
        if master_source == "Upload master_mapping.xlsx":
            master_upload = st.file_uploader(
                "master_mapping.xlsx",
                type=["xlsx"],
                key="master_for_map",
            )
            if master_upload is not None:
                st.session_state["map_master_bytes"] = (
                    master_upload.name, master_upload.getbuffer().tobytes()
                )
            elif st.session_state.get("map_master_bytes"):
                st.caption(
                    f"Cached: {st.session_state['map_master_bytes'][0]} "
                    "(re-upload to change)"
                )
        else:
            master_upload = None
            if st.session_state.get("master_built"):
                st.success("Phase 1 master mapping is ready.")
            else:
                st.info(
                    "No master built in this session yet. "
                    "Go to Build Master (Phase 1) first, or upload a "
                    "master_mapping.xlsx from a previous run."
                )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Raw Datasets</div>', unsafe_allow_html=True)
        raw_input_mode = st.radio(
            "Input type",
            ["SAS files (.xpt / .sas7bdat)", "PROC CONTENTS catalog (Excel/CSV)"],
            key="raw_input_mode",
        )
        if raw_input_mode == "SAS files (.xpt / .sas7bdat)":
            sas_uploads = st.file_uploader(
                "Upload one or more SAS datasets (each file = one raw dataset)",
                type=["xpt", "sas7bdat"],
                accept_multiple_files=True,
                key="sas_files",
            )
            raw_upload = None
        else:
            raw_upload = st.file_uploader(
                "PROC CONTENTS output or variable registry (Excel or CSV)",
                type=["xlsx", "csv"],
                key="raw_catalog",
            )
            if raw_upload is not None:
                st.session_state["raw_bytes"] = (raw_upload.name, raw_upload.getbuffer().tobytes())
            elif st.session_state.get("raw_bytes"):
                st.caption(
                    f"Cached: {st.session_state['raw_bytes'][0]} "
                    "(re-upload to change)"
                )
            sas_uploads = []
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">New Study SDTM Spec (optional)</div>', unsafe_allow_html=True)
        spec_upload = st.file_uploader(
            "New study spec Excel. Maps the spec variable list exactly. "
            "If not provided, all variables in the master are mapped.",
            type=["xlsx", "xlsm"],
            key="new_spec",
        )
        if spec_upload is not None:
            st.session_state["spec_bytes"] = (spec_upload.name, spec_upload.getbuffer().tobytes())
        elif st.session_state.get("spec_bytes"):
            st.caption(
                f"Cached: {st.session_state['spec_bytes'][0]} "
                "(re-upload to change)"
            )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Matching Thresholds</div>', unsafe_allow_html=True)
        auto_thresh   = st.slider("Auto-accept threshold", 0.50, 0.98, 0.82, 0.01,
                                  help="Score >= this: mapped directly to spec (green cell)")
        review_thresh = st.slider("Review threshold",      0.30, 0.80, 0.55, 0.01,
                                  help="Score >= this: flagged for programmer review (amber cell)")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">SDTMIG Version Lock</div>', unsafe_allow_html=True)
        _detected_version = ""
        _ss_spec = st.session_state.get("spec_bytes")
        _spec_for_ver = spec_upload if spec_upload is not None else (
            _ss_spec[1] if _ss_spec else None
        )
        if _spec_for_ver is not None:
            try:
                import sys as _sys, tempfile as _tf, logging as _lg_sv
                _sys.path.insert(0, str(APP_DIR / "src"))
                from study_metadata import read_study_metadata
                if hasattr(_spec_for_ver, "read"):
                    _spec_bytes_tmp = _spec_for_ver.read()
                    _spec_for_ver.seek(0)
                else:
                    _spec_bytes_tmp = (
                        bytes(_spec_for_ver)
                        if not isinstance(_spec_for_ver, (bytes, bytearray))
                        else _spec_for_ver
                    )
                _tmp_spec = _tf.mktemp(suffix=".xlsx")
                with open(_tmp_spec, "wb") as _fh:
                    _fh.write(_spec_bytes_tmp)
                _meta = read_study_metadata(_tmp_spec, _lg_sv.getLogger("sdtm_pipeline"))
                _detected_version = _meta.sdtmig_version or ""
                _detected_ig_raw  = _meta.sdtmig_version_raw or ""
                if _detected_version:
                    # Display the FULL Mapping Specification IG value prominently
                    st.caption(
                        f"📄 **Mapping Specification IG**: {_detected_ig_raw}"
                    )
                    st.caption(
                        f"   → Extracted SDTMIG version: **{_detected_version}**"
                    )
                elif _detected_ig_raw:
                    st.caption(f"📄 **Mapping Specification IG**: {_detected_ig_raw} — version not extracted")
            except Exception as _ver_err:
                st.caption(f"Could not read version from spec: {_ver_err}")

        _ver_options = ["No preference (all versions)", "3.4", "3.3", "3.2", "3.1.3", "3.1.2", "3.1.1", "3.0"]
        _ver_default_idx = 0
        if _detected_version:
            for _vi, _vopt in enumerate(_ver_options):
                if _vopt == _detected_version:
                    _ver_default_idx = _vi; break
                if _detected_version and _vopt.startswith(_detected_version):
                    _ver_default_idx = _vi; break
                if _detected_version in _vopt:
                    _ver_default_idx = _vi; break

        sdtmig_version_lock = st.selectbox(
            "Prioritise mappings from studies using this SDTMIG version",
            options=_ver_options,
            index=_ver_default_idx,
            help="Auto-detected from the Mapping Specification IG field in the spec Study tab.",
        )
        show_xai = st.checkbox(
            "Show score breakdown (XAI) in results",
            value=st.session_state.get("map_show_xai", False),
            help="Shows how each signal contributed to the composite score.",
        )
        st.session_state["map_show_xai"] = show_xai
        st.markdown("</div>", unsafe_allow_html=True)

        flt_dict    = st.session_state.get("cdm_filter_dict", {})
        n_excl_vars = len(flt_dict.get("cdm_variables", []))
        n_excl_ds   = len(flt_dict.get("cdm_datasets",  []))
        st.caption(
            f"CDM filter active: {n_excl_vars} variable names, {n_excl_ds} dataset names excluded. "
            "Edit in CDM Variable Filter page."
        )

    st.markdown("---")
    _raw_cached    = st.session_state.get("raw_bytes")
    _master_cached = st.session_state.get("map_master_bytes")
    raw_ready    = bool(sas_uploads) or (raw_upload is not None) or bool(_raw_cached)
    master_ready = (
        (master_source == "Upload master_mapping.xlsx"
         and (master_upload is not None or bool(_master_cached)))
        or (master_source != "Upload master_mapping.xlsx"
            and st.session_state.get("master_built"))
    )
    run_map = st.button(
        "Run Mapping  (raw -> SDTM)",
        disabled=(not master_ready or not raw_ready),
    )

    # ------------------------------------------------------------------
    # RUN PATH — execute mapping and persist results to session state
    # ------------------------------------------------------------------
    if run_map:
        # Clear stale cache before a fresh run
        for _k in ["map_results_cache", "results_xlsx_bytes", "map_done",
                   "direct_df_cache", "review_df_cache"]:
            st.session_state.pop(_k, None)

        tmpdir = _make_tmpdir()
        try:
            import yaml as _yaml
            with open(cfg_path_input) as _f:
                cfg_data = _yaml.safe_load(_f)
            cfg_data["matching"]["thresholds"]["auto_accept"] = auto_thresh
            cfg_data["matching"]["thresholds"]["review"]       = review_thresh
            tmp_cfg = Path(tmpdir) / "config.yaml"
            with open(tmp_cfg, "w") as _f:
                _yaml.dump(cfg_data, _f, default_flow_style=False, allow_unicode=False)

            # Resolve master
            if master_upload is not None:
                master_path = save_upload(master_upload, tmpdir)
            elif st.session_state.get("map_master_bytes"):
                _mname, _mbytes = st.session_state["map_master_bytes"]
                master_path = Path(tmpdir) / _mname
                master_path.write_bytes(_mbytes)
            else:
                master_data = st.session_state["master_xlsx_bytes"]
                master_path = Path(tmpdir) / "master_mapping.xlsx"
                if isinstance(master_data, (bytes, bytearray)):
                    master_path.write_bytes(master_data)
                else:
                    _, _mb = master_data
                    master_path.write_bytes(_mb)

            # Resolve raw catalog
            if sas_uploads:
                from mapper import read_sas_files
                import logging as _logging
                _log = _logging.getLogger("sdtm_pipeline")
                sas_paths  = [save_upload(f, tmpdir) for f in sas_uploads]
                catalog_df = read_sas_files(sas_paths, _log)
                catalog_df, _ = _flt.filter_catalog(catalog_df)
                raw_path = Path(tmpdir) / "raw_catalog_combined.csv"
                catalog_df.to_csv(raw_path, index=False)
            else:
                if raw_upload is not None:
                    raw_path_raw = save_upload(raw_upload, tmpdir)
                elif st.session_state.get("raw_bytes"):
                    _rname, _rbytes = st.session_state["raw_bytes"]
                    raw_path_raw = Path(tmpdir) / _rname
                    raw_path_raw.write_bytes(_rbytes)
                else:
                    st.error("No raw catalog available. Please upload one.")
                    raise ValueError("No raw catalog")
                import yaml as _y2
                with open(tmp_cfg) as _f2:
                    _cfg2 = _y2.safe_load(_f2)
                import logging as _lg2
                _log2 = _lg2.getLogger("sdtm_pipeline")
                from mapper import read_raw_catalog as _rrc
                _full_cat = _rrc(raw_path_raw, _cfg2, _log2)
                catalog_filtered, catalog_excluded = _flt.filter_catalog(_full_cat)
                raw_path = Path(tmpdir) / "raw_filtered.csv"
                catalog_filtered.to_csv(raw_path, index=False)
                if not catalog_excluded.empty:
                    st.info(
                        f"CDM filter excluded {len(catalog_excluded)} variables "
                        f"from {catalog_excluded['RAW_DATASET'].nunique()} datasets before mapping."
                    )

            # Resolve spec
            if spec_upload is not None:
                spec_path = save_upload(spec_upload, tmpdir)
            elif st.session_state.get("spec_bytes"):
                _sname, _sbytes = st.session_state["spec_bytes"]
                spec_path = Path(tmpdir) / _sname
                spec_path.write_bytes(_sbytes)
            else:
                spec_path = None
            out_path = Path(tmpdir) / "mapping_results.xlsx"

            st.markdown("### Mapping raw variables to SDTM...")
            results, log_lines = run_map_with_progress(
                master_path, raw_path, spec_path, out_path, tmp_cfg,
            )

            if results:
                direct_df   = results.get("direct",              pd.DataFrame())
                review_df   = results.get("review",              pd.DataFrame())
                unres_df    = results.get("unresolved",          pd.DataFrame())
                unmapped    = results.get("unmapped_raw",        pd.DataFrame())
                coverage    = results.get("coverage",            pd.DataFrame())
                cross_ds_df = results.get("cross_dataset_match", pd.DataFrame())

                results_xlsx_bytes = out_path.read_bytes()

                # Persist full results for session-restore on tab switch
                st.session_state["map_results_cache"] = {
                    "direct":              direct_df.to_dict("records")   if not direct_df.empty   else [],
                    "review":              review_df.to_dict("records")   if not review_df.empty   else [],
                    "unresolved":          unres_df.to_dict("records")    if not unres_df.empty    else [],
                    "unmapped_raw":        unmapped.to_dict("records")    if not unmapped.empty    else [],
                    "coverage":            coverage.to_dict("records")    if not coverage.empty    else [],
                    "cross_dataset_match": cross_ds_df.to_dict("records") if not cross_ds_df.empty else [],
                }
                st.session_state["results_xlsx_bytes"]   = results_xlsx_bytes
                st.session_state["direct_df_cache"]      = direct_df.to_dict("records") if not direct_df.empty else []
                st.session_state["review_df_cache"]      = review_df.to_dict("records") if not review_df.empty else []
                st.session_state["map_done"]             = True
                st.session_state["mapping_results_dict"] = {
                    k: v for k, v in results.items()
                    if isinstance(v, pd.DataFrame)
                }

                _render_results(
                    direct_df, review_df, unres_df, unmapped, coverage, cross_ds_df,
                    show_xai, results_xlsx_bytes,
                )

        except Exception as exc:
            st.error(f"Mapping failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)

    # ------------------------------------------------------------------
    # RESTORE PATH — results already computed this session; re-display
    # them on every re-render caused by tab switch or download click.
    # ------------------------------------------------------------------
    elif st.session_state.get("map_done") and st.session_state.get("map_results_cache"):
        cache = st.session_state["map_results_cache"]

        def _from_records(records):
            return pd.DataFrame(records) if records else pd.DataFrame()

        _render_results(
            direct_df          = _from_records(cache.get("direct",              [])),
            review_df          = _from_records(cache.get("review",              [])),
            unres_df           = _from_records(cache.get("unresolved",          [])),
            unmapped           = _from_records(cache.get("unmapped_raw",        [])),
            coverage           = _from_records(cache.get("coverage",            [])),
            cross_ds_df        = _from_records(cache.get("cross_dataset_match", [])),
            show_xai           = st.session_state.get("map_show_xai", False),
            results_xlsx_bytes = st.session_state.get("results_xlsx_bytes", b""),
        )

# ===========================================================================
# PAGE: Write Back to Spec
# ===========================================================================

