"""
app.py
======
SDTM Master Mapping System - Streamlit Application

Dark-mode interactive UI covering three pipeline phases:
  1. Build Master Mapping   (from completed study specs)
  2. Map New Study          (raw catalog -> SDTM variable mapping)
  3. Write Back to Spec     (populate Input Variables / Origin in spec Excel)

Run:
    streamlit run app.py
"""

import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
from pathlib import Path


def _make_tmpdir():
    """Create a temp dir - safe on Windows (no spaces, no TemporaryDirectory cleanup issues)."""
    return tempfile.mkdtemp(prefix='sdtm_')


def _rm_tmpdir(path):
    """Remove temp dir, ignoring errors (openpyxl may still hold handles)."""
    try:
        shutil.rmtree(str(path), ignore_errors=True)
    except Exception:
        pass

import pandas as pd
import streamlit as st

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).parent.resolve()
SRC_DIR = APP_DIR / 'src'
# Add both project root and src/ so all modules are importable
sys.path.insert(0, str(SRC_DIR))
sys.path.insert(0, str(APP_DIR))

# ---------------------------------------------------------------------------
# Page config - must be first Streamlit call
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="SDTM Master Mapping System",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Dark theme CSS
# ---------------------------------------------------------------------------
DARK_CSS = """
<style>
/* ---- Base ---- */
html, body, [data-testid="stAppViewContainer"] {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif;
}
[data-testid="stSidebar"] {
    background-color: #161b22;
    border-right: 1px solid #30363d;
}
[data-testid="stSidebar"] * { color: #e6edf3 !important; }

/* ---- Header bar ---- */
.main-header {
    background: linear-gradient(135deg, #161b22 0%, #1c2330 100%);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px 28px 16px 28px;
    margin-bottom: 20px;
}
.main-header h1 {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    margin: 0 0 4px 0; letter-spacing: -0.02em;
}
.main-header p { font-size: 13px; color: #8b949e; margin: 0; }

/* ---- Cards ---- */
.card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    padding: 16px 18px;
    margin-bottom: 12px;
}
.card-title {
    font-size: 12px; font-weight: 600; color: #58a6ff;
    letter-spacing: 0.06em; text-transform: uppercase;
    margin-bottom: 10px;
}

/* ---- Metric pills ---- */
.metric-row { display: flex; gap: 10px; flex-wrap: wrap; margin: 12px 0; }
.metric-pill {
    background: #1c2330; border: 1px solid #30363d;
    border-radius: 6px; padding: 10px 16px; text-align: center;
    min-width: 100px; flex: 1;
}
.metric-pill .val {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    font-family: 'IBM Plex Mono', monospace; line-height: 1.2;
}
.metric-pill .val.green  { color: #3fb950; }
.metric-pill .val.amber  { color: #e3b341; }
.metric-pill .val.red    { color: #f85149; }
.metric-pill .val.purple { color: #bc8cff; }
.metric-pill .lbl { font-size: 11px; color: #8b949e; margin-top: 3px; }

/* ---- Status badges ---- */
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 3px;
    font-size: 11px; font-weight: 600; font-family: monospace;
}
.badge-direct  { background: rgba(63,185,80,0.15);  color: #3fb950;  border: 1px solid rgba(63,185,80,0.3);  }
.badge-review  { background: rgba(227,179,65,0.15); color: #e3b341;  border: 1px solid rgba(227,179,65,0.3); }
.badge-unres   { background: rgba(248,81,73,0.15);  color: #f85149;  border: 1px solid rgba(248,81,73,0.3);  }
.badge-info    { background: rgba(88,166,255,0.12); color: #58a6ff;  border: 1px solid rgba(88,166,255,0.3); }

/* ---- Inputs & buttons ---- */
[data-testid="stFileUploader"] {
    background: #161b22; border: 1px dashed #30363d !important;
    border-radius: 6px; padding: 8px;
}
.stButton > button {
    background: #238636 !important; color: #ffffff !important;
    border: none !important; border-radius: 6px !important;
    font-weight: 600 !important; padding: 10px 24px !important;
    font-size: 13px !important; width: 100% !important;
    transition: background 0.2s !important;
}
.stButton > button:hover { background: #2ea043 !important; }
.stButton > button:disabled { background: #21262d !important; color: #8b949e !important; }

/* ---- Progress bar ---- */
[data-testid="stProgress"] > div > div { background-color: #238636 !important; }

/* ---- Tables ---- */
[data-testid="stDataFrame"] { border: 1px solid #30363d; border-radius: 6px; }
thead th {
    background-color: #161b22 !important; color: #58a6ff !important;
    font-size: 11px !important; text-transform: uppercase !important;
}

/* ---- Tabs ---- */
[data-testid="stTabs"] [role="tab"] { color: #8b949e !important; }
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: #58a6ff !important; border-bottom-color: #58a6ff !important;
}

/* ---- Alerts ---- */
.stSuccess { background: rgba(63,185,80,0.1) !important; border: 1px solid rgba(63,185,80,0.3) !important; color: #3fb950 !important; }
.stWarning { background: rgba(227,179,65,0.1) !important; border: 1px solid rgba(227,179,65,0.3) !important; }
.stError   { background: rgba(248,81,73,0.1)  !important; border: 1px solid rgba(248,81,73,0.3)  !important; }
.stInfo    { background: rgba(88,166,255,0.1)  !important; border: 1px solid rgba(88,166,255,0.3) !important; color: #58a6ff !important; }

/* ---- Code blocks ---- */
code, pre { background: #161b22 !important; color: #a5d6ff !important; border: 1px solid #30363d !important; }

/* ---- Log area ---- */
.log-box {
    background: #0d1117; border: 1px solid #30363d; border-radius: 5px;
    padding: 12px; font-family: 'IBM Plex Mono', monospace;
    font-size: 11px; color: #8b949e; max-height: 300px; overflow-y: auto;
    white-space: pre-wrap;
}
.log-info  { color: #8b949e; }
.log-ok    { color: #3fb950; }
.log-warn  { color: #e3b341; }
.log-err   { color: #f85149; }

/* ---- Sidebar labels ---- */
.sidebar-section {
    font-size: 10px; font-weight: 600; letter-spacing: 0.1em;
    text-transform: uppercase; color: #6e7681; padding: 12px 0 4px 0;
    border-bottom: 1px solid #30363d; margin-bottom: 8px;
}

/* ---- Divider ---- */
hr { border-color: #30363d !important; }
</style>
"""

st.markdown(DARK_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def save_upload(uploaded_file, dest_dir):
    """Save a Streamlit UploadedFile to dest_dir; return Path."""
    dest = Path(dest_dir) / uploaded_file.name
    dest.write_bytes(uploaded_file.getbuffer())
    return dest


def bytes_to_upload_mock(content_bytes, filename, dest_dir):
    """Write raw bytes to a file; return Path."""
    dest = Path(dest_dir) / filename
    dest.write_bytes(content_bytes)
    return dest


def metric_html(val, label, color=""):
    cls = "val " + color if color else "val"
    return (
        '<div class="metric-pill">'
        f'<div class="{cls}">{val}</div>'
        f'<div class="lbl">{label}</div>'
        '</div>'
    )


def log_html(lines):
    inner = "\n".join(lines[-80:])
    return f'<div class="log-box">{inner}</div>'


def excel_download_button(df_dict, filename, label="Download Excel"):
    """Create an in-memory Excel workbook and return a download button."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in df_dict.items():
            if df is not None and not df.empty:
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    buf.seek(0)
    st.download_button(
        label=label,
        data=buf.read(),
        file_name=filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def file_download_button(path, label="Download File"):
    """Offer a file for download by path."""
    with open(path, "rb") as f:
        data = f.read()
    ext  = Path(path).suffix.lower()
    mime = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if ext in (".xlsx", ".xlsm") else "application/octet-stream"
    )
    st.download_button(label=label, data=data,
                       file_name=Path(path).name, mime=mime)


# ---------------------------------------------------------------------------
# Progress-aware wrapper for build_master_mapping
# ---------------------------------------------------------------------------

def run_build_with_progress(spec_paths, sponsor_paths, existing_master,
                             out_path, config_path, study_dates):
    """
    Wrap build_master_mapping with real-time Streamlit progress feedback.
    Yields (pct, message) via st.progress + st.status updates.
    """
    import master_builder as mb

    log_lines = []
    progress   = st.progress(0, text="Starting master build...")
    status_box = st.empty()

    steps = []
    if existing_master:
        steps.append(("Loading existing master", 5))
    for sp in spec_paths:
        steps.append((f"Reading study spec: {Path(sp).name}", 15))
    for sp in (sponsor_paths or []):
        steps.append((f"Reading sponsor spec: {Path(sp).name}", 15))
    steps.append(("Consolidating groups & confidence scores", 20))
    steps.append(("Writing master_mapping.xlsx", 10))

    total_weight = sum(w for _, w in steps)
    cumulative   = 0

    def tick(msg, weight):
        nonlocal cumulative
        cumulative += weight
        pct = min(int(cumulative / total_weight * 100), 99)
        progress.progress(pct, text=msg)
        log_lines.append(f"  {msg}")
        status_box.markdown(log_html(log_lines), unsafe_allow_html=True)
        time.sleep(0.05)

    # Patch the module's logger to capture output
    import logging, io as _io

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg = self.format(record)
            # strip timestamp prefix
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        tick("Initialising...", 0)

        orig_process = mb.process_spec_file
        proc_count   = [0]

        def patched_process(spec_path, cfg, study_date, is_sponsor, log):
            proc_count[0] += 1
            prefix = "Sponsor std" if is_sponsor else f"Study {proc_count[0]}"
            tick(f"{prefix}: {Path(spec_path).name}", 15)
            return orig_process(spec_path, cfg, study_date, is_sponsor, log)

        mb.process_spec_file = patched_process

        master_df = mb.build_master_mapping(
            spec_paths=spec_paths,
            sponsor_paths=sponsor_paths,
            existing_master=existing_master,
            out_path=out_path,
            config_path=config_path,
            study_dates=study_dates,
        )

        mb.process_spec_file = orig_process
        tick("Complete!", 10)
        progress.progress(100, text="Master mapping built successfully")
        return master_df, log_lines

    except Exception as exc:
        mb.process_spec_file = orig_process
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_map_with_progress(master_path, raw_path, spec_path,
                           out_path, config_path):
    """Wrap mapper.run with real-time progress."""
    import mapper as mp
    import logging

    log_lines = []
    progress   = st.progress(0, text="Starting variable mapping...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    # Patch run_mapping to emit per-domain progress
    orig_run_mapping = mp.run_mapping
    domains_seen = [0]

    def patched_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log):
        total_vars = len(sdtm_vars_df)
        pct_per_var = 60 / max(total_vars, 1)

        orig_find = mp.find_best_group
        var_count = [0]

        def patched_find(sdtm_var, domain, *args, **kwargs):
            var_count[0] += 1
            pct = 20 + int(var_count[0] * pct_per_var)
            progress.progress(
                min(pct, 80),
                text=f"Mapping {domain}.{sdtm_var}  [{var_count[0]}/{total_vars}]",
            )
            return orig_find(sdtm_var, domain, *args, **kwargs)

        mp.find_best_group = patched_find
        result = orig_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log)
        mp.find_best_group = orig_find
        return result

    mp.run_mapping = patched_run_mapping

    try:
        progress.progress(5,  text="Loading master mapping...")
        time.sleep(0.1)
        progress.progress(10, text="Loading raw catalog...")
        time.sleep(0.1)
        progress.progress(15, text="Building TF-IDF label index...")

        results = mp.run(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=str(spec_path) if spec_path else None,
            out_path=out_path,
            config_path=config_path,
        )

        mp.run_mapping = orig_run_mapping
        progress.progress(90, text="Writing results Excel...")
        time.sleep(0.2)
        progress.progress(100, text="Mapping complete!")
        return results, log_lines

    except Exception as exc:
        mp.run_mapping = orig_run_mapping
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_writeback_with_progress(spec_path, results_path, out_path,
                                 highlight_review, populate_origin,
                                 populate_action, dry_run, config_path):
    """Wrap spec_writeback.write_back with progress."""
    import spec_writeback as sw
    import logging

    log_lines = []
    progress   = st.progress(0, text="Preparing write-back...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        progress.progress(10, text="Loading mapping results...")
        time.sleep(0.1)
        progress.progress(25, text="Opening spec workbook...")
        time.sleep(0.1)
        progress.progress(35, text="Writing Input Variables, Origin, Mapping Action...")

        result = sw.write_back(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
            highlight_review=highlight_review,
            populate_origin=populate_origin,
            populate_action=populate_action,
            dry_run=dry_run,
            config_path=str(config_path),
        )

        progress.progress(90, text="Appending change-log sheet...")
        time.sleep(0.15)
        progress.progress(100, text="Write-back complete!")
        return result, log_lines

    except Exception as exc:
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


# ---------------------------------------------------------------------------
# Coverage chart (pure matplotlib -> PNG bytes)
# ---------------------------------------------------------------------------

def coverage_chart_bytes(coverage_df):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        domains = coverage_df["DOMAIN"].tolist()
        direct  = coverage_df["DIRECT"].astype(int).tolist()
        review  = coverage_df["REVIEW"].astype(int).tolist()
        unres   = coverage_df["UNRESOLVED"].astype(int).tolist()

        x     = range(len(domains))
        width = 0.25

        fig, ax = plt.subplots(figsize=(max(7, len(domains) * 1.2), 4), facecolor="#0d1117")
        ax.set_facecolor("#161b22")

        bars_d = ax.bar([i - width for i in x], direct,  width, label="Direct",     color="#3fb950", alpha=0.9)
        bars_r = ax.bar([i         for i in x], review,  width, label="Review",     color="#e3b341", alpha=0.9)
        bars_u = ax.bar([i + width for i in x], unres,   width, label="Unresolved", color="#f85149", alpha=0.9)

        ax.set_xticks(list(x))
        ax.set_xticklabels(domains, color="#e6edf3", fontsize=11)
        ax.tick_params(colors="#8b949e")
        ax.spines["bottom"].set_color("#30363d")
        ax.spines["left"].set_color("#30363d")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_ylabel("Variables", color="#8b949e", fontsize=10)
        ax.set_title("Mapping Coverage by Domain", color="#e6edf3", fontsize=12, pad=10)
        ax.yaxis.label.set_color("#8b949e")
        ax.tick_params(axis="y", colors="#8b949e")
        ax.grid(axis="y", color="#30363d", linewidth=0.5, linestyle="--")

        legend = ax.legend(
            facecolor="#161b22", edgecolor="#30363d",
            labelcolor="#e6edf3", fontsize=9,
        )

        # Value labels on bars
        for bars in (bars_d, bars_r, bars_u):
            for bar in bars:
                h = bar.get_height()
                if h > 0:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2, h + 0.1,
                        str(int(h)), ha="center", va="bottom",
                        color="#e6edf3", fontsize=8,
                    )

        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                    facecolor="#0d1117")
        plt.close(fig)
        buf.seek(0)
        return buf.read()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown(
        '<div class="main-header"><h1>SDTM Mapper</h1>'
        '<p>Master Mapping System v3</p></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-section">Navigation</div>', unsafe_allow_html=True)

    page = st.radio(
        "Select phase",
        options=["Build Master", "Map New Study", "Write Back to Spec", "CDM Variable Filter", "View Master", "Help"],
        label_visibility="collapsed",
    )

    st.markdown('<div class="sidebar-section">Settings</div>', unsafe_allow_html=True)

    cfg_path_input = st.text_input(
        "config.yaml path",
        value=str(APP_DIR / "src" / "config.yaml"),
        help="Path to config.yaml. Edit thresholds and weights there.",
    )

    st.markdown('<div class="sidebar-section">About</div>', unsafe_allow_html=True)
    st.caption(
        "Each completed study fed into Build Master improves "
        "matching accuracy for all future studies."
    )


# ---------------------------------------------------------------------------
# Main header
# ---------------------------------------------------------------------------

st.markdown(
    '<div class="main-header">'
    '<h1>SDTM Master Mapping System</h1>'
    '<p>Build a cross-study master mapping knowledge base from completed SDTM specs, '
    'then automatically map new study raw variables to SDTM with confidence-scored '
    'outputs and direct spec write-back.</p>'
    '</div>',
    unsafe_allow_html=True,
)


# ===========================================================================
# PAGE: Build Master
# ===========================================================================

# ---------------------------------------------------------------------------
# Session state init
# ---------------------------------------------------------------------------

if "cdm_filter_dict" not in st.session_state:
    from cdm_filter import DEFAULT_CDM_VARIABLES, DEFAULT_CDM_DATASETS, DEFAULT_CDM_SUFFIXES
    st.session_state["cdm_filter_dict"] = {
        "cdm_variables":   sorted(DEFAULT_CDM_VARIABLES),
        "cdm_datasets":    sorted(DEFAULT_CDM_DATASETS),
        "cdm_suffixes":    list(DEFAULT_CDM_SUFFIXES),
        "custom_patterns": [],
    }

if page == "Build Master":
    st.markdown("## Phase 1 - Build Master Mapping")
    st.info(
        "Upload completed study spec Excel files. Each study added improves "
        "accuracy for future mappings. Sponsor standard specs get a confidence "
        "priority boost and supersede conflicting study mappings.",
    )

    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Completed Study Specs</div>', unsafe_allow_html=True)
        study_files = st.file_uploader(
            "Upload one or more completed study spec Excel files",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="study_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Sponsor Standard Specs (optional)</div>', unsafe_allow_html=True)
        sponsor_files = st.file_uploader(
            "Upload sponsor standard / template spec(s). These take priority over study mappings.",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="sponsor_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Existing Master (Append Mode)</div>', unsafe_allow_html=True)
        existing_master_file = st.file_uploader(
            "Optional: upload an existing master_mapping.xlsx to append new studies",
            type=["xlsx"],
            key="existing_master",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Study Dates (optional)</div>', unsafe_allow_html=True)
        st.caption("Older studies get a recency decay. Format: filename=YYYY-MM-DD (one per line)")
        dates_text = st.text_area(
            "Study dates",
            placeholder="study_a.xlsx=2022-06-01\nstudy_b.xlsx=2023-11-15\nsponsor_std.xlsx=2024-01-01",
            height=120,
            label_visibility="collapsed",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Conflict Strategy</div>', unsafe_allow_html=True)
        conflict_strategy = st.selectbox(
            "How to resolve conflicting mappings across studies",
            options=["sponsor_priority", "most_frequent"],
            index=0,
            help="sponsor_priority: sponsor standard wins. most_frequent: highest N_STUDIES wins.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">SDTMIG Version & Therapeutic Area</div>', unsafe_allow_html=True)
        st.caption(
            "Auto-detected from each spec Study tab. Override here if needed. "
            "Version-matched studies get higher confidence weight in the master."
        )
        target_ig_version = st.selectbox(
            "Target SDTMIG Version (for this master)",
            options=["Auto-detect from specs", "3.4", "3.3", "3.2", "3.1.3", "3.1.2"],
            index=0,
            help="Studies from the same SDTMIG version get full weight. Older versions are down-weighted.",
        )
        target_ta = st.multiselect(
            "Therapeutic Area filter (leave empty = all TAs pooled)",
            options=[
                "ONCOLOGY", "CARDIOLOGY", "NEUROLOGY", "RESPIRATORY",
                "IMMUNOLOGY", "RHEUMATOLOGY", "NEPHROLOGY", "OPHTHALMOLOGY",
                "HEMATOLOGY", "ENDOCRINOLOGY", "INFECTIOUS_DISEASE",
                "DERMATOLOGY", "GASTROENTEROLOGY", "MUSCULOSKELETAL",
            ],
            default=[],
            help="If selected, only studies matching these TAs are used for scoring that domain.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    run_build = st.button(
        "Build Master Mapping",
        disabled=(not study_files and not sponsor_files),
    )

    if run_build:
        try:
            import yaml, re
            with open(cfg_path_input) as f:
                cfg_data = yaml.safe_load(f)
            cfg_data["master_build"]["conflict_strategy"] = conflict_strategy
            # Write temp config
            tmp_cfg = Path(tempfile.mkdtemp()) / "config.yaml"
            import yaml as _yaml
            with open(tmp_cfg, "w") as f:
                _yaml.dump(cfg_data, f, default_flow_style=False, allow_unicode=False)

            tmpdir = _make_tmpdir()
            spec_paths    = [save_upload(f, tmpdir) for f in (study_files or [])]
            sponsor_paths = [save_upload(f, tmpdir) for f in (sponsor_files or [])]
            existing_path = None
            if existing_master_file:
                existing_path = save_upload(existing_master_file, tmpdir)

            study_dates = {}
            for line in dates_text.strip().splitlines():
                line = line.strip()
                if "=" in line:
                    fn, date = line.split("=", 1)
                    study_dates[fn.strip()] = date.strip()

            out_master = Path(tmpdir) / "master_mapping.xlsx"

            st.markdown("### Building...")
            master_df, log_lines = run_build_with_progress(
                spec_paths=spec_paths,
                sponsor_paths=sponsor_paths,
                existing_master=existing_path,
                out_path=out_master,
                config_path=tmp_cfg,
                study_dates=study_dates,
            )

            if master_df is not None and not master_df.empty:
                st.success(
                    f"Master mapping built: {len(master_df):,} rows | "
                    f"{master_df['SDTM_VARIABLE'].nunique()} SDTM variables | "
                    f"{master_df['DOMAIN'].nunique()} domains"
                )

                # Metrics
                top_df = master_df[master_df["IS_TOP_GROUP"]]
                high_n = int((top_df["MASTER_CONFIDENCE"] >= 0.82).sum())
                mid_n  = int(((top_df["MASTER_CONFIDENCE"] >= 0.55) & (top_df["MASTER_CONFIDENCE"] < 0.82)).sum())
                low_n  = int((top_df["MASTER_CONFIDENCE"] < 0.55).sum())

                pills = (
                    '<div class="metric-row">'
                    + metric_html(master_df["SDTM_VARIABLE"].nunique(), "SDTM Variables")
                    + metric_html(master_df["DOMAIN"].nunique(), "Domains", "")
                    + metric_html(int((master_df["IS_SPONSOR_STD"] == True).sum()), "Sponsor-Std Rows", "purple")
                    + metric_html(high_n, "High Conf (>=82%)", "green")
                    + metric_html(mid_n,  "Medium Conf",       "amber")
                    + metric_html(low_n,  "Low Conf (<55%)",   "red")
                    + '</div>'
                )
                st.markdown(pills, unsafe_allow_html=True)

                # Domain summary table
                st.markdown("#### Domain Summary")
                dom_sum = (
                    top_df.groupby("DOMAIN")
                    .agg(
                        SDTM_VARS=("SDTM_VARIABLE", "nunique"),
                        AVG_CONF=("MASTER_CONFIDENCE", "mean"),
                        HIGH_CONF=("MASTER_CONFIDENCE", lambda x: int((x >= 0.82).sum())),
                    )
                    .reset_index()
                    .round({"AVG_CONF": 3})
                )
                st.dataframe(dom_sum, use_container_width=True, hide_index=True)

                # Download
                st.markdown("#### Download")
                file_download_button(out_master, "Download master_mapping.xlsx")

                # Store in session state for next phase
                st.session_state["master_xlsx_bytes"] = out_master.read_bytes()
                st.session_state["master_built"]      = True

        except Exception as exc:
            st.error(f"Build failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================

elif page == "Map New Study":
    st.markdown("## Phase 2 - Map Raw Variables to SDTM")
    st.info(
        "Upload your raw SAS datasets (.xpt / .sas7bdat) directly, or a PROC CONTENTS "
        "catalog (Excel/CSV). The system maps each raw variable to the correct SDTM domain "
        "and variable using the master mapping knowledge base. Review results before writing "
        "to spec."
    )

    from cdm_filter import CdmFilter
    _flt = CdmFilter.from_dict(st.session_state.get("cdm_filter_dict", {}))

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Master Mapping</div>', unsafe_allow_html=True)
        master_source = st.radio(
            "Master source",
            ["Upload master_mapping.xlsx", "Use master built in Phase 1 (this session)"],
            label_visibility="collapsed",
        )
        if master_source == "Upload master_mapping.xlsx":
            master_upload = st.file_uploader(
                "master_mapping.xlsx",
                type=["xlsx"],
                key="master_for_map",
            )
        else:
            master_upload = None
            if st.session_state.get("master_built"):
                st.success("Phase 1 master mapping is ready.")
            else:
                st.info(
                    "No master built in this session yet. "
                    "Go to Build Master (Phase 1) first, or upload a "
                    "master_mapping.xlsx from a previous run."
                )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Raw Datasets</div>', unsafe_allow_html=True)
        raw_input_mode = st.radio(
            "Input type",
            ["SAS files (.xpt / .sas7bdat)", "PROC CONTENTS catalog (Excel/CSV)"],
            key="raw_input_mode",
        )
        if raw_input_mode == "SAS files (.xpt / .sas7bdat)":
            sas_uploads = st.file_uploader(
                "Upload one or more SAS datasets (each file = one raw dataset)",
                type=["xpt", "sas7bdat"],
                accept_multiple_files=True,
                key="sas_files",
            )
            raw_upload = None
        else:
            raw_upload = st.file_uploader(
                "PROC CONTENTS output or variable registry (Excel or CSV)",
                type=["xlsx", "csv"],
                key="raw_catalog",
            )
            sas_uploads = []
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">New Study SDTM Spec (optional)</div>', unsafe_allow_html=True)
        spec_upload = st.file_uploader(
            "New study spec Excel. Maps the spec variable list exactly. "
            "If not provided, all variables in the master are mapped.",
            type=["xlsx", "xlsm"],
            key="new_spec",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Matching Thresholds</div>', unsafe_allow_html=True)
        auto_thresh   = st.slider("Auto-accept threshold", 0.50, 0.98, 0.82, 0.01,
                                  help="Score >= this: mapped directly to spec (green cell)")
        review_thresh = st.slider("Review threshold",      0.30, 0.80, 0.55, 0.01,
                                  help="Score >= this: flagged for programmer review (amber cell)")
        st.markdown("</div>", unsafe_allow_html=True)

        flt_dict = st.session_state.get("cdm_filter_dict", {})
        n_excl_vars = len(flt_dict.get("cdm_variables", []))
        n_excl_ds   = len(flt_dict.get("cdm_datasets",  []))
        st.caption(
            f"CDM filter active: {n_excl_vars} variable names, {n_excl_ds} dataset names excluded. "
            "Edit in CDM Variable Filter page."
        )

    st.markdown("---")
    raw_ready    = bool(sas_uploads) or (raw_upload is not None)
    master_ready = (
        (master_source == "Upload master_mapping.xlsx" and master_upload is not None)
        or (master_source != "Upload master_mapping.xlsx" and st.session_state.get("master_built"))
    )
    run_map = st.button(
        "Run Mapping  (raw -> SDTM)",
        disabled=(not master_ready or not raw_ready),
    )

    if run_map:
        tmpdir = _make_tmpdir()
        try:
            import yaml as _yaml
            with open(cfg_path_input) as _f:
                cfg_data = _yaml.safe_load(_f)
            cfg_data["matching"]["thresholds"]["auto_accept"] = auto_thresh
            cfg_data["matching"]["thresholds"]["review"]       = review_thresh
            tmp_cfg = Path(tmpdir) / "config.yaml"
            with open(tmp_cfg, "w") as _f:
                _yaml.dump(cfg_data, _f, default_flow_style=False, allow_unicode=False)

            # Save master
            if master_upload is not None:
                master_path = save_upload(master_upload, tmpdir)
            else:
                master_path = Path(tmpdir) / "master_mapping.xlsx"
                master_path.write_bytes(st.session_state["master_xlsx_bytes"])

            # Handle SAS files
            if sas_uploads:
                from mapper import read_sas_files
                import logging as _logging
                _log = _logging.getLogger("sdtm_pipeline")
                sas_paths  = [save_upload(f, tmpdir) for f in sas_uploads]
                catalog_df = read_sas_files(sas_paths, _log)
                # Apply CDM filter
                _, excl = _flt.filter_catalog(catalog_df)
                catalog_df, _ = _flt.filter_catalog(catalog_df)
                raw_path = Path(tmpdir) / "raw_catalog_combined.csv"
                catalog_df.to_csv(raw_path, index=False)
            else:
                raw_path_raw = save_upload(raw_upload, tmpdir)
                # Apply CDM filter to catalog
                import yaml as _y2
                with open(tmp_cfg) as _f2:
                    _cfg2 = _y2.safe_load(_f2)
                import logging as _lg2
                _log2 = _lg2.getLogger("sdtm_pipeline")
                from mapper import read_raw_catalog as _rrc
                _full_cat = _rrc(raw_path_raw, _cfg2, _log2)
                catalog_filtered, catalog_excluded = _flt.filter_catalog(_full_cat)
                raw_path = Path(tmpdir) / "raw_filtered.csv"
                catalog_filtered.to_csv(raw_path, index=False)
                if not catalog_excluded.empty:
                    st.info(
                        f"CDM filter excluded {len(catalog_excluded)} variables "
                        f"from {catalog_excluded['RAW_DATASET'].nunique()} datasets before mapping."
                    )

            spec_path = save_upload(spec_upload, tmpdir) if spec_upload else None
            out_path  = Path(tmpdir) / "mapping_results.xlsx"

            st.markdown("### Mapping raw variables to SDTM...")
            results, log_lines = run_map_with_progress(
                master_path, raw_path, spec_path, out_path, tmp_cfg,
            )

            if results:
                direct_df   = results.get("direct",              pd.DataFrame())
                review_df   = results.get("review",              pd.DataFrame())
                unres_df    = results.get("unresolved",          pd.DataFrame())
                unmapped    = results.get("unmapped_raw",        pd.DataFrame())
                coverage    = results.get("coverage",            pd.DataFrame())
                cross_ds_df = results.get("cross_dataset_match", pd.DataFrame())

                d_n   = len(direct_df)
                r_n   = len(review_df)
                u_n   = len(unres_df)
                total = d_n + r_n + u_n

                st.success(
                    f"Mapping complete: {d_n} auto-mapped | "
                    f"{r_n} need review | {u_n} unresolved | {total} total"
                )

                cds_n = len(cross_ds_df)
                pills = (
                    '<div class="metric-row">'
                    + metric_html(d_n,   "Auto-Mapped",          "green")
                    + metric_html(r_n,   "Needs Review",         "amber")
                    + metric_html(cds_n, "Cross-Dataset Match",  "purple")
                    + metric_html(u_n,   "Unresolved",           "red")
                    + metric_html(
                        f"{round(100*d_n/total)}%" if total else "0%",
                        "Auto-Map Rate", "green"
                      )
                    + metric_html(len(unmapped), "Unmapped Raw Vars", "")
                    + '</div>'
                )
                st.markdown(pills, unsafe_allow_html=True)

                # ---- Raw Dataset -> SDTM Domain mapping table ----
                all_mapped = pd.concat(
                    [df for df in [direct_df, review_df, cross_ds_df] if not df.empty],
                    ignore_index=True,
                )

                def _parse_ds_domain_rows(df_in, tier_label):
                    rows = []
                    if df_in is None or df_in.empty:
                        return rows
                    for _, mrow in df_in.iterrows():
                        raw_str = str(mrow.get("RAW_VARIABLES_ASSIGNED", "") or "")
                        if not raw_str or raw_str in ("nan", ""):
                            continue
                        for tok in raw_str.split(","):
                            tok   = tok.strip()
                            parts = tok.split(".")
                            if len(parts) >= 3 and parts[0].upper() == "RAW":
                                rds = parts[1].upper()
                                rv  = parts[2].upper()
                            elif len(parts) == 2:
                                rds, rv = parts[0].upper(), parts[1].upper()
                            else:
                                continue
                            rows.append({
                                "RAW_DATASET":   rds,
                                "RAW_VARIABLE":  rv,
                                "SDTM_DOMAIN":   str(mrow.get("DOMAIN", "")),
                                "SDTM_VARIABLE": str(mrow.get("SDTM_VARIABLE", "")),
                                "TIER":          tier_label,
                                "SCORE":         mrow.get("COMPOSITE_SCORE", ""),
                            })
                    return rows

                ds_domain_rows = (
                    _parse_ds_domain_rows(direct_df,   "AUTO")
                    + _parse_ds_domain_rows(review_df,   "REVIEW")
                    + _parse_ds_domain_rows(cross_ds_df, "CROSS-DATASET")
                )

                if ds_domain_rows:
                    ds_detail = pd.DataFrame(ds_domain_rows)

                    # Summary: RAW_DATASET → which SDTM domains it feeds
                    ds_summary = (
                        ds_detail.groupby("RAW_DATASET")
                        .agg(
                            SDTM_DOMAINS=("SDTM_DOMAIN",
                                          lambda x: ", ".join(sorted(x.dropna().unique()))),
                            N_SDTM_VARS=("SDTM_VARIABLE", "nunique"),
                            N_VARS_MAPPED=("RAW_VARIABLE", "nunique"),
                            TIERS=("TIER",
                                   lambda x: ", ".join(sorted(x.dropna().unique()))),
                        )
                        .reset_index()
                        .sort_values("RAW_DATASET")
                    )

                    # Issue detection: flag datasets that map to unexpected domains
                    ds_issues = []
                    for _, dr in ds_summary.iterrows():
                        rds = dr["RAW_DATASET"]
                        domains = dr["SDTM_DOMAINS"].split(", ")
                        rds_prefix = rds[:2].upper()
                        unexpected = [d for d in domains
                                      if d[:2].upper() != rds_prefix
                                      and d not in ("DM", "SUPPQUAL")]
                        if unexpected:
                            ds_issues.append({
                                "RAW_DATASET":        rds,
                                "MAPS_TO":            dr["SDTM_DOMAINS"],
                                "UNEXPECTED_DOMAINS": ", ".join(unexpected),
                                "ISSUE":              "Raw dataset name prefix does not match SDTM domain — verify mapping intent",
                            })

                    st.markdown("---")
                    st.markdown("#### Raw Dataset → SDTM Domain Coverage")
                    st.caption(
                        "Shows which raw datasets feed which SDTM domains. "
                        "One raw dataset can legitimately map to multiple SDTM domains "
                        "(e.g. QS raw data → QS + MH + CM). "
                        "Flagged rows have dataset-name/domain-name prefix mismatches — review these."
                    )

                    # Colour-code issues inline
                    ds_summary["⚠ Issues"] = ds_summary["RAW_DATASET"].apply(
                        lambda r: "⚠ Check domain mismatch"
                        if any(i["RAW_DATASET"] == r for i in ds_issues) else "✓ OK"
                    )
                    st.dataframe(ds_summary, use_container_width=True, hide_index=True)

                    if ds_issues:
                        st.warning(
                            f"{len(ds_issues)} raw dataset(s) map to domains that don't match their name prefix. "
                            "These may be intentional (e.g. QSXXX → QS) or miscategorised — review below."
                        )
                        with st.expander("⚠ Dataset-Domain Mismatch Issues"):
                            st.dataframe(pd.DataFrame(ds_issues),
                                         use_container_width=True, hide_index=True)

                    with st.expander("Detailed variable-level dataset→domain mapping"):
                        st.dataframe(ds_detail, use_container_width=True, hide_index=True)

                # ---- Coverage chart ----
                if not coverage.empty:
                    chart_bytes = coverage_chart_bytes(coverage)
                    if chart_bytes:
                        st.markdown("---")
                        st.markdown("#### Coverage by SDTM Domain")
                        st.image(chart_bytes)
                    display_cols = [
                        c for c in
                        ["DOMAIN","TOTAL","DIRECT","REVIEW","UNRESOLVED",
                         "AUTO_PCT","TOTAL_COVERAGE_PCT","N_DERIVED","N_TIMING","N_RESULT"]
                        if c in coverage.columns
                    ]
                    st.dataframe(coverage[display_cols], use_container_width=True, hide_index=True)

                # ---- Mapping results tabs ----
                st.markdown("---")
                st.markdown("#### Mapping Results — Review Before Writing to Spec")
                st.caption(
                    "🟢 GREEN = auto-accepted (bold text + green fill in spec). "
                    "🟡 AMBER = needs review (bold text + amber fill). "
                    "🟣 CROSS-DATASET = variable name matched across differently-named dataset — manual review required. "
                    "These highlights are written into the Input Variables column of your spec."
                )

                def build_view(df, tier_label, extra_cols=None):
                    if df is None or df.empty:
                        return pd.DataFrame()
                    rows = []
                    for _, r in df.iterrows():
                        raw_str = str(r.get("RAW_VARIABLES_ASSIGNED", "") or "")
                        if not raw_str or raw_str in ("nan", ""):
                            raw_tokens = [("", "")]
                        else:
                            raw_tokens = []
                            for tok in raw_str.split(","):
                                tok = tok.strip()
                                parts = tok.split(".")
                                if len(parts) >= 3:
                                    raw_tokens.append((parts[-2], parts[-1]))
                                elif len(parts) == 2:
                                    raw_tokens.append((parts[0], parts[1]))
                                else:
                                    raw_tokens.append(("", tok))
                        for rds, rv in raw_tokens:
                            row_d = {
                                "RAW_DATASET":   rds,
                                "RAW_VARIABLE":  rv,
                                "SDTM_DOMAIN":   str(r.get("DOMAIN", "")),
                                "SDTM_VARIABLE": str(r.get("SDTM_VARIABLE", "")),
                                "SDTM_LABEL":    str(r.get("SDTM_LABEL", "")),
                                "MAPPING_ACTION":str(r.get("MAPPING_ACTION", "")),
                                "ORIGIN":        str(r.get("ORIGIN", "")),
                                "SCORE":         r.get("COMPOSITE_SCORE", ""),
                                "TIER":          tier_label,
                            }
                            if extra_cols:
                                for ec in extra_cols:
                                    row_d[ec] = str(r.get(ec, "") or "")
                            rows.append(row_d)
                    return pd.DataFrame(rows)

                view_direct   = build_view(direct_df,   "AUTO")
                view_review   = build_view(review_df,   "REVIEW")
                view_cross_ds = build_view(cross_ds_df, "CROSS-DATASET", extra_cols=["MATCH_NOTE"])
                view_unres    = build_view(unres_df,    "UNRESOLVED")

                tab_labels = []
                if not view_direct.empty:   tab_labels.append(f"🟢 Auto-Mapped ({d_n})")
                if not view_review.empty:   tab_labels.append(f"🟡 Review ({r_n})")
                if not view_cross_ds.empty: tab_labels.append(f"🟣 Cross-Dataset Match ({cds_n})")
                if not view_unres.empty:    tab_labels.append(f"🔴 Unresolved ({u_n})")
                if not unmapped.empty:      tab_labels.append(f"Unmapped Raw ({len(unmapped)})")

                if tab_labels:
                    tabs = st.tabs(tab_labels)
                    ti = 0
                    if not view_direct.empty:
                        with tabs[ti]:
                            st.caption(
                                "✅ These raw variables were auto-mapped with high confidence. "
                                "Input Variables cells will be highlighted **GREEN** (bold green text) in the spec."
                            )
                            st.dataframe(view_direct, use_container_width=True, hide_index=True)
                        ti += 1
                    if not view_review.empty:
                        with tabs[ti]:
                            st.caption(
                                "⚠️ Lower confidence score — programmer review recommended. "
                                "Input Variables cells will be highlighted **AMBER** (bold amber text) in the spec."
                            )
                            st.dataframe(view_review, use_container_width=True, hide_index=True)
                        ti += 1
                    if not view_cross_ds.empty:
                        with tabs[ti]:
                            st.warning(
                                "🟣 These SDTM variables were matched by **variable name** to a raw variable "
                                "in a differently-named dataset (e.g. QSXXX raw dataset matched QS domain variables). "
                                "The dataset name mismatch means these could not be auto-accepted. "
                                "**Each row requires manual programmer review** before adding to spec."
                            )
                            st.dataframe(view_cross_ds, use_container_width=True, hide_index=True)
                            st.info(
                                "To accept a cross-dataset match: confirm the raw dataset genuinely feeds this "
                                "SDTM domain, then manually add the Input Variable token to your spec, or "
                                "use Write Back to Spec (these will be written as REVIEW-tier with amber highlight)."
                            )
                        ti += 1
                    if not view_unres.empty:
                        with tabs[ti]:
                            st.caption("No match found in master or by variable name. Not written to spec. Manual assignment required.")
                            st.dataframe(view_unres, use_container_width=True, hide_index=True)
                        ti += 1
                    if not unmapped.empty:
                        with tabs[ti]:
                            st.caption("Raw variables that were not matched to any SDTM variable.")
                            st.dataframe(unmapped, use_container_width=True, hide_index=True)

                st.markdown("---")
                st.markdown("#### Download Results and Proceed to Write Back")
                file_download_button(out_path, "Download mapping_results.xlsx")
                st.session_state["results_xlsx_bytes"] = out_path.read_bytes()
                st.session_state["map_done"] = True
                st.success(
                    "Mapping complete. Go to **Write Back to Spec** to apply "
                    "these results to your sponsor template."
                )

        except Exception as exc:
            st.error(f"Mapping failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)


# ===========================================================================
# PAGE: Write Back to Spec
# ===========================================================================

elif page == "Write Back to Spec":
    st.markdown("## Phase 3 - Write Back to Spec")
    st.info(
        "Populate Input Variables, Mapping Action, and Origin columns in your "
        "SDTM spec Excel. All original formatting is preserved. "
        "Input Variables cells are highlighted with **bold text + fill color**: "
        "🟢 GREEN (bold green) = auto-accepted, 🟡 AMBER (bold amber) = needs review. "
        "Cross-dataset matches are written as AMBER (review tier). "
        "A change-log sheet is appended for full traceability."
    )

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">New Study Spec</div>', unsafe_allow_html=True)
        wb_spec_upload = st.file_uploader(
            "New study SDTM spec Excel (sponsor template with blank Input Variables)",
            type=["xlsx", "xlsm"],
            key="wb_spec",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Mapping Results</div>', unsafe_allow_html=True)
        results_source = st.radio(
            "Results source",
            ["Upload mapping_results.xlsx", "Use results from Phase 2"],
            label_visibility="collapsed",
        )
        if results_source == "Upload mapping_results.xlsx":
            wb_results_upload = st.file_uploader(
                "mapping_results.xlsx from Phase 2",
                type=["xlsx"],
                key="wb_results",
            )
        else:
            wb_results_upload = None
            if st.session_state.get("map_done"):
                st.success("Phase 2 mapping results are ready.")
            else:
                st.warning("No mapping results in this session. Run Phase 2 first.")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Write-Back Options</div>', unsafe_allow_html=True)
        populate_origin  = st.checkbox("Populate Origin column",              value=True)
        populate_action  = st.checkbox("Populate Mapping Action (blank only)", value=True)
        highlight_review = st.checkbox(
            "Highlight Input Variables cells (green=direct, amber=review)",
            value=True,
        )
        dry_run_mode = st.checkbox(
            "Dry-run mode (preview changes, do not write file)",
            value=False,
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">What gets highlighted</div>', unsafe_allow_html=True)
        st.markdown(
            '<div style="font-size:12px;color:#8b949e;line-height:2.2">'
            '<span style="background:#C6EFCE;color:#276221;font-weight:bold;padding:2px 8px;border-radius:3px">GREEN + Bold</span>'
            '&nbsp; Input Variables cell = auto-accepted (score &ge; auto threshold)<br>'
            '<span style="background:#FFF2CC;color:#7d6608;font-weight:bold;padding:2px 8px;border-radius:3px">AMBER + Bold</span>'
            '&nbsp; Input Variables cell = needs programmer review<br>'
            '<span style="background:#FFC7CE;color:#9C0006;font-weight:bold;padding:2px 8px;border-radius:3px">RED + Bold</span>'
            '&nbsp; Input Variables cell = cross-dataset match (manual review required)<br>'
            '<small>Bold text + fill color ensures highlights are visible even over existing sponsor cell colors.<br>'
            'Only the Input Variables cell is highlighted &mdash; all other cells keep their original sponsor formatting.</small>'
            '</div>',
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    results_ready = (
        (results_source == "Upload mapping_results.xlsx" and wb_results_upload is not None)
        or (results_source != "Upload mapping_results.xlsx" and st.session_state.get("map_done"))
    )
    run_wb = st.button(
        "Dry-Run Preview" if dry_run_mode else "Write Back to Spec",
        disabled=(wb_spec_upload is None or not results_ready),
    )

    if run_wb:
        tmpdir = _make_tmpdir()
        try:
            spec_path = save_upload(wb_spec_upload, tmpdir)

            if wb_results_upload is not None:
                results_path = save_upload(wb_results_upload, tmpdir)
            else:
                results_path = Path(tmpdir) / "mapping_results.xlsx"
                results_path.write_bytes(st.session_state["results_xlsx_bytes"])

            out_path = Path(tmpdir) / (
                "spec_preview.xlsx" if dry_run_mode else "spec_mapped.xlsx"
            )

            st.markdown("### Writing...")
            result_path, log_lines = run_writeback_with_progress(
                spec_path=spec_path,
                results_path=results_path,
                out_path=out_path,
                highlight_review=highlight_review,
                populate_origin=populate_origin,
                populate_action=populate_action,
                dry_run=dry_run_mode,
                config_path=cfg_path_input,
            )

            if dry_run_mode:
                st.warning(
                    "Dry-run complete. Check the log above for preview of changes. "
                    "Uncheck Dry-run mode and re-run to apply."
                )
            else:
                st.success(
                    "✅ Spec updated. Input Variables cells are highlighted with bold text + fill color "
                    "(GREEN bold = auto-accepted, AMBER bold = needs review, RED bold = cross-dataset). "
                    "A change-log sheet has been appended — use it to trace every updated variable."
                )
                file_download_button(out_path, "Download Updated Spec Excel")

        except Exception as exc:
            st.error(f"Write-back failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)


# ===========================================================================
# PAGE: CDM Variable Filter
# ===========================================================================

elif page == "CDM Variable Filter":
    st.markdown("## CDM Variable Filter")
    st.info(
        "CDM-generated variables (audit trail fields, system IDs, query fields) "
        "should not be mapped to SDTM. Define which raw variables and entire datasets "
        "to exclude before running the mapping. All lists are editable and saved for the session."
    )

    from cdm_filter import CdmFilter
    flt      = CdmFilter.from_dict(st.session_state.get("cdm_filter_dict", {}))

    # Live preview
    st.markdown("### Preview Filter on Your Raw Catalog")
    preview_raw = st.file_uploader(
        "Upload raw catalog (Excel or CSV) to see what would be excluded",
        type=["xlsx", "csv"], key="cdm_preview",
    )
    if preview_raw:
        tmpd = _make_tmpdir()
        try:
            import yaml as _y, logging as _lg
            rp = save_upload(preview_raw, tmpd)
            with open(cfg_path_input) as _f:
                _cfg = _y.safe_load(_f)
            _log = _lg.getLogger("sdtm_pipeline")
            from mapper import read_raw_catalog as _rrc
            raw_prev = _rrc(rp, _cfg, _log)
            usable, excluded = flt.filter_catalog(raw_prev)
            cv1, cv2 = st.columns(2)
            with cv1:
                st.markdown(
                    f'<div class="card"><div class="card-title">Usable ({len(usable)})</div>',
                    unsafe_allow_html=True,
                )
                if not usable.empty:
                    st.dataframe(
                        usable[["RAW_DATASET","VARIABLE","LABEL"]],
                        use_container_width=True, hide_index=True,
                    )
                st.markdown("</div>", unsafe_allow_html=True)
            with cv2:
                st.markdown(
                    f'<div class="card"><div class="card-title">Excluded ({len(excluded)})</div>',
                    unsafe_allow_html=True,
                )
                if not excluded.empty:
                    st.dataframe(
                        excluded[["RAW_DATASET","VARIABLE","LABEL"]],
                        use_container_width=True, hide_index=True,
                    )
                else:
                    st.success("No variables excluded by current filter.")
                st.markdown("</div>", unsafe_allow_html=True)
        except Exception as _exc:
            st.error(f"Preview failed: {_exc}")
        finally:
            _rm_tmpdir(tmpd)

    st.markdown("---")
    tab_vars, tab_ds, tab_sfx, tab_custom = st.tabs([
        "Variable Names", "Dataset Names", "Suffix Patterns", "Custom Regex",
    ])

    with tab_vars:
        st.markdown("##### Excluded Variable Names")
        st.caption(
            "These exact variable names are excluded regardless of which dataset they appear in. "
            "Common examples: CREATEDDTM, MODIFIEDDTM, FORMOID, LOCKED."
        )
        var_text = st.text_area(
            "One variable name per line (uppercase)",
            value="\n".join(sorted(flt.cdm_variables)),
            height=320,
            key="cdm_var_edit",
        )
        vc1, vc2, vc3 = st.columns([2, 2, 1])
        with vc1:
            new_var = st.text_input("Add variable", key="add_cdm_var")
        with vc2:
            del_var = st.text_input("Remove variable", key="del_cdm_var")
        with vc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key="save_vars"):
                new_set = {v.strip().upper() for v in var_text.splitlines() if v.strip()}
                if new_var.strip():
                    new_set.add(new_var.strip().upper())
                if del_var.strip():
                    new_set.discard(del_var.strip().upper())
                flt.cdm_variables = new_set
                st.session_state["cdm_filter_dict"] = flt.to_dict()
                st.success(f"Saved: {len(new_set)} variable exclusions")

    with tab_ds:
        st.markdown("##### Excluded Dataset Names")
        st.caption(
            "All variables from these datasets are excluded entirely. "
            "Examples: AUDIT, QUERIES, BATCHLOG."
        )
        ds_text = st.text_area(
            "One dataset name per line (uppercase MEMNAME)",
            value="\n".join(sorted(flt.cdm_datasets)),
            height=220,
            key="cdm_ds_edit",
        )
        dc1, dc2, dc3 = st.columns([2, 2, 1])
        with dc1:
            new_ds = st.text_input("Add dataset", key="add_cdm_ds")
        with dc2:
            del_ds = st.text_input("Remove dataset", key="del_cdm_ds")
        with dc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key="save_ds"):
                new_set = {d.strip().upper() for d in ds_text.splitlines() if d.strip()}
                if new_ds.strip():
                    new_set.add(new_ds.strip().upper())
                if del_ds.strip():
                    new_set.discard(del_ds.strip().upper())
                flt.cdm_datasets = new_set
                st.session_state["cdm_filter_dict"] = flt.to_dict()
                st.success(f"Saved: {len(new_set)} dataset exclusions")

    with tab_sfx:
        st.markdown("##### Excluded Variable Suffixes")
        st.caption("Variables ending with these suffixes are excluded (CDM backup copies).")
        sfx_text = st.text_area(
            "One suffix per line (e.g. _PREV)",
            value="\n".join(flt.cdm_suffixes),
            height=160,
            key="cdm_sfx_edit",
        )
        if st.button("Save Suffixes"):
            new_sfx = [s.strip().upper() for s in sfx_text.splitlines() if s.strip()]
            flt.cdm_suffixes = new_sfx
            st.session_state["cdm_filter_dict"] = flt.to_dict()
            st.success(f"Saved: {len(new_sfx)} suffix patterns")

    with tab_custom:
        st.markdown("##### Custom Regex Patterns")
        st.caption("Python regex patterns matched against variable names. e.g. ^SYS_ excludes SYS_* variables.")
        custom_text = st.text_area(
            "One regex per line",
            value="\n".join(flt.custom_patterns),
            height=140,
            key="cdm_custom_edit",
        )
        if st.button("Save Patterns"):
            import re as _re
            valid, invalid = [], []
            for p in custom_text.splitlines():
                p = p.strip()
                if not p:
                    continue
                try:
                    _re.compile(p)
                    valid.append(p)
                except _re.error:
                    invalid.append(p)
            flt.custom_patterns = valid
            st.session_state["cdm_filter_dict"] = flt.to_dict()
            if invalid:
                st.warning(f"Invalid patterns skipped: {invalid}")
            st.success(f"Saved: {len(valid)} custom patterns")

    st.markdown("---")
    st.info(
        "The CDM filter is applied automatically during Phase 2 (Map New Study). "
        "Excluded variables appear in the Excluded tab of the results and are never "
        "written to the spec."
    )

elif page == "View Master":
    st.markdown("## View Master Mapping")

    col_l, col_r = st.columns([2, 1])
    with col_l:
        master_view_file = st.file_uploader(
            "Upload master_mapping.xlsx to explore",
            type=["xlsx"],
            key="master_view",
        )
    with col_r:
        if st.session_state.get("master_built"):
            if st.button("Load master from Phase 1"):
                st.session_state["master_view_bytes"] = st.session_state["master_xlsx_bytes"]

    view_bytes = None
    if master_view_file:
        view_bytes = master_view_file.read()
    elif st.session_state.get("master_view_bytes"):
        view_bytes = st.session_state["master_view_bytes"]

    if view_bytes:
        try:
            master_all = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_all",
                                       engine="openpyxl", dtype=object)
            master_top = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_top",
                                       engine="openpyxl", dtype=object)

            if "MASTER_CONFIDENCE" in master_all.columns:
                master_all["MASTER_CONFIDENCE"] = pd.to_numeric(
                    master_all["MASTER_CONFIDENCE"], errors="coerce"
                )

            # Metrics
            pills = (
                '<div class="metric-row">'
                + metric_html(master_all["SDTM_VARIABLE"].nunique() if not master_all.empty else 0, "SDTM Variables")
                + metric_html(master_all["DOMAIN"].nunique()        if not master_all.empty else 0, "Domains")
                + metric_html(len(master_all), "Total Rows")
                + metric_html(
                    int((master_all["MASTER_CONFIDENCE"] >= 0.82).sum()) if "MASTER_CONFIDENCE" in master_all.columns else 0,
                    "High Conf (>=82%)", "green"
                  )
                + '</div>'
            )
            st.markdown(pills, unsafe_allow_html=True)

            st.markdown("---")

            # Filter controls
            fc1, fc2, fc3 = st.columns([1, 1, 2])
            with fc1:
                domains = sorted(master_all["DOMAIN"].dropna().unique().tolist()) if not master_all.empty else []
                domain_filter = st.multiselect("Filter by Domain", options=domains, default=domains)
            with fc2:
                tier_filter = st.multiselect(
                    "Confidence tier",
                    options=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                    default=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                )
            with fc3:
                search_var = st.text_input("Search SDTM Variable", placeholder="e.g. AESTDTC")

            filtered = master_top.copy() if not master_top.empty else master_all.copy()
            if "DOMAIN" in filtered.columns and domain_filter:
                filtered = filtered[filtered["DOMAIN"].isin(domain_filter)]
            if search_var and "SDTM_VARIABLE" in filtered.columns:
                filtered = filtered[
                    filtered["SDTM_VARIABLE"].str.contains(search_var.upper(), na=False)
                ]
            if "MASTER_CONFIDENCE" in filtered.columns:
                conf = pd.to_numeric(filtered["MASTER_CONFIDENCE"], errors="coerce")
                masks = []
                if "High (>=82%)"    in tier_filter: masks.append(conf >= 0.82)
                if "Medium (55-82%)" in tier_filter: masks.append((conf >= 0.55) & (conf < 0.82))
                if "Low (<55%)"      in tier_filter: masks.append(conf < 0.55)
                if masks:
                    import functools
                    combined = functools.reduce(lambda a, b: a | b, masks)
                    filtered = filtered[combined]

            st.markdown(f"**{len(filtered)} rows shown**")
            display_cols = [
                c for c in
                ["DOMAIN","SDTM_VARIABLE","SDTM_LABEL","INPUT_VARIABLES",
                 "MAPPING_ACTION","ORIGIN","N_STUDIES","MASTER_CONFIDENCE",
                 "IS_SPONSOR_STD","SOURCE_FILES"]
                if c in filtered.columns
            ]
            st.dataframe(filtered[display_cols], use_container_width=True, hide_index=True)

        except Exception as exc:
            st.error(f"Could not read master mapping: {exc}")

    else:
        st.info("Upload a master_mapping.xlsx or build one in Phase 1.")


# ===========================================================================
# PAGE: Help
# ===========================================================================

elif page == "Help":
    st.markdown("## Help & Quick Reference")

    tab1, tab2, tab3, tab4 = st.tabs(["Workflow", "File Formats", "Thresholds", "CLI Usage"])

    with tab1:
        st.markdown("""
### Three-Phase Workflow

**Phase 1 - Build Master**

Upload every completed and QC-approved SDTM spec Excel file from previous studies.
The system extracts all `DOMAIN | SDTM_VARIABLE | Input Variables` mappings and
builds a frequency-weighted, recency-decayed confidence score for each.
Sponsor standard specs receive a 3x study-count boost so they always take priority.

Add studies incrementally using Append Mode - no need to rebuild from scratch each time.

---

**Phase 2 - Map New Study**

Upload the new study's raw variable catalog (typically a SAS PROC CONTENTS output
exported to Excel or CSV). The system:

1. Builds a group-aware index of the master mapping
2. Builds a TF-IDF label similarity index over raw variable labels
3. Scores every SDTM variable using a 4-signal composite scorer:
   - Name exact match (35%)
   - Name fuzzy similarity (20%)
   - Label TF-IDF cosine (25%)
   - Master confidence / frequency (20%)
4. Classifies each result as Direct, Review, or Unresolved

---

**Phase 3 - Write Back**

Upload the new study SDTM spec (blank Input Variables). The results from Phase 2
are written into the correct cells while preserving all original formatting.
Origin is written using priority: CRF > Derived > Protocol > eDT > Assigned.
Review rows are highlighted with bold text + fill color (GREEN bold = auto-accepted, AMBER bold = needs review).
A change-log sheet is appended listing every updated cell with tier, score, and notes.
        """)

    with tab2:
        st.markdown("""
### Expected File Formats

**Completed Study Spec (Phase 1 input)**
- Excel workbook with one sheet per SDTM domain
- Must have a TOC sheet with Dataset and Active columns
- Only domains where Active = Y/YES are processed
- Trial domains (TA TE TI TV TS TD) always excluded even if Active=Y
- Required columns per domain sheet: Variable, Input Variables, Mapping Action
- Optional columns: Label, Origin, Codelist, Core, SAS Type, SAS Length

**Raw Variable Catalog (Phase 2 input)**
- PROC CONTENTS output exported to Excel or CSV
- Required columns: MEMNAME (dataset), NAME (variable)
- Optional: LABEL, FORMAT, TYPE

**New Study Spec (Phase 3 input)**
- Same format as completed study spec
- Input Variables, Mapping Action, Origin columns should be blank
- The write-back populates them based on Phase 2 results
        """)

    with tab3:
        st.markdown("""
### Confidence Score & Thresholds

The composite score (0 to 1.0) combines four signals:

| Signal | Default Weight | Description |
|---|---|---|
| Name exact | 35% | Exact slug match between SDTM var name and raw var name |
| Name fuzzy | 20% | Best of seq_ratio / token_sort / token_set similarity |
| Label TF-IDF | 25% | Cosine similarity of variable labels |
| Master freq | 20% | Historical confidence from master_mapping |

**Thresholds (configurable in config.yaml and UI sliders):**

| Tier | Default | Action |
|---|---|---|
| Direct | >= 0.82 | Written to spec immediately | GREEN bold |
| Review | >= 0.55 | Flagged for human review | AMBER bold |
| Cross-Dataset | name >= 0.75 | Variable name match across differently-named dataset | AMBER bold (manual review) |
| Unresolved | < 0.55 | Not written; manual assignment required | — |

**Partial-group penalty:** If a multi-token group (e.g. date+time) has only
some tokens found in the raw catalog, the group score is penalised proportionally.
Default penalty factor: 0.70 (configurable).
        """)

    with tab4:
        st.markdown("""
### CLI Usage (without the UI)

All phases are also available as standalone Python scripts:

```bash
# Phase 1: Build master from completed studies
python pipeline.py build \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --out     master_mapping.xlsx

# Append a new study to existing master
python pipeline.py build \\
    --specs    studies/study_c.xlsx \\
    --existing master_mapping.xlsx \\
    --out      master_mapping.xlsx

# Phase 2: Map new study
python pipeline.py map \\
    --master master_mapping.xlsx \\
    --raw    new_study/proc_contents.xlsx \\
    --spec   new_study/sdtm_spec.xlsx \\
    --out    new_study/mapping_results.xlsx

# Phase 3: Write-back
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx

# Dry-run preview
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx \\
    --dry-run

# Full pipeline (all three phases)
python pipeline.py full \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --raw     new_study/proc_contents.xlsx \\
    --spec    new_study/sdtm_spec.xlsx
```
        """)