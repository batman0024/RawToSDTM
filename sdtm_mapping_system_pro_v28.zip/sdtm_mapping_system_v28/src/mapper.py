"""
mapper.py  (v27 simplified)
===========================
Three-step variable mapping pipeline:

  STEP 1  MASTER LOOKUP
          For each raw variable, look it up in the master mapping by_raw
          index.  If a high-confidence target exists in the spec, assign it.
          This is the strongest signal: hand-curated knowledge from past studies.

  STEP 2  RULE TABLE
          For each unmapped spec variable, consult sdtm_rules.lookup_rule().
          STUDYID, USUBJID, EPOCH, RFSTDTC, --SEQ, --DY, --BLFL, etc. are
          all resolved here with the correct origin / action per CDISC SDTMIG.
          See src/sdtm_rules.py for the canonical rule table.

  STEP 3  FUZZY FALLBACK
          For variables that survive both steps, do a single fuzzy pass
          against same-domain raw variables using Jaro-Winkler + label TF-IDF.
          One score, one threshold, no penalty multipliers.

  STEP 3.5  CROSS-DATASET MATCH (manual review)
          For still-unresolved variables with an exact name match in a
          differently-named raw dataset, flag for manual review.

This replaces the v25/v26 four-scorer pipeline (Phase 1 ML + Phase 2 hard
rules + Phase 3 cross-dataset + dead `find_best_group` legacy scorer) with
one linear flow.  Every mapping decision lives in exactly one place.

The ML scorer is parked at src/_legacy/legacy_ml_scorer.py.  It can be
re-enabled by setting `matching.use_ml_scorer: true` in config.yaml; that
path uses the legacy mapper at src/_legacy/legacy_mapper.py.

Bug fixes carried in from the v26 review:
  #1  group_count NameError                                   (parked legacy fixed too)
  #5  RFSTDTC etc. Origin = Derived, not Assigned/Sponsor    (rule table)
  #6  EPOCH = Derived, not HARDCODE                          (rule table)
  #7  --DY = Derived                                         (rule table pattern)
  #8  --BLFL / --LOBXFL = Derived                            (rule table pattern)
  #10 PROTOCOL inference -> "Protocol", not "Assigned/Sponsor" (origin_normalization)
  #12 Derived check moved before CRF in infer_origin
  #16 Recency reproducible via reference_date param          (master_builder)
  Plus: cross-domain accumulation, ALWAYS_DERIVED handling, SUPP_QUAL.

Result dictionary keys (unchanged for UI compatibility):
  direct, review, unresolved, unmapped_raw, cross_dataset_match, coverage
"""

from __future__ import annotations

import re
import sys
import math
import warnings
import datetime as dt
import argparse
from pathlib import Path
from difflib import SequenceMatcher
from typing import Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from utils import _norm, _slug, load_cfg
from sdtm_knowledge import (
    classify_variable, expand_sdtm_label, infer_origin,
    DOMAIN_CLASS, CRF_DATASET_PREFIXES, EDT_PREFIXES,
)
from sdtm_rules import lookup_rule, needs_raw_source
from logger import get_logger

# Optional: bring in jaro_winkler from the parked ml_scorer's primitives.
# This works whether or not the full MLScorer is enabled.
from ml_scorer import jaro_winkler   # noqa: F401   (still used as primary similarity)


# ---------------------------------------------------------------------------
# Text similarity helpers
# ---------------------------------------------------------------------------

_TOKEN_SPLIT_RE = re.compile(r"[^A-Z0-9]+")


def _token_set(s: str) -> set:
    return set(_TOKEN_SPLIT_RE.split(_slug(s))) - {""}


def seq_ratio(a: str, b: str) -> float:
    a, b = _slug(a), _slug(b)
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def name_sim(a: str, b: str) -> float:
    """Best-of-three name similarity: Jaro-Winkler, sequence ratio, token overlap."""
    a, b = _slug(a), _slug(b)
    if not a or not b:
        return 0.0
    jw = jaro_winkler(a, b)
    sr = SequenceMatcher(None, a, b).ratio()
    sa, sb = _token_set(a), _token_set(b)
    tk = len(sa & sb) / len(sa | sb) if (sa or sb) else 0.0
    return max(jw, sr, tk)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def get_thresholds(cfg: dict, domain: str) -> tuple[float, float]:
    m  = cfg.get("matching", {})
    th = m.get("thresholds", {})
    auto = float(th.get("auto_accept", 0.82))
    rev  = float(th.get("review",      0.55))
    ov   = m.get("domain_overrides", {}).get(str(domain).upper(), {})
    return float(ov.get("auto_accept", auto)), float(ov.get("review", rev))


# ---------------------------------------------------------------------------
# Raw catalog readers (kept verbatim from legacy mapper for UI compatibility)
# ---------------------------------------------------------------------------

def read_sas_files(sas_paths, log):
    """Read one or more SAS datasets (.xpt or .sas7bdat) into a raw catalog DF."""
    rows = []
    for p in sas_paths:
        p = Path(p)
        dataset_name = p.stem.upper()
        ext = p.suffix.lower()
        try:
            if ext == ".xpt":
                df_sas = pd.read_sas(str(p), format="xport", encoding="latin-1")
            elif ext in (".sas7bdat", ".sas"):
                df_sas = pd.read_sas(str(p), format="sas7bdat", encoding="latin-1")
            else:
                log.warning("Unsupported SAS file type: %s", p.name)
                continue

            for col in df_sas.columns:
                label = getattr(df_sas[col], "label",  "") or ""
                fmt   = getattr(df_sas[col], "format", "") or ""
                dtype = str(df_sas[col].dtype)
                var_type = "Num" if ("float" in dtype or "int" in dtype) else "Char"
                rows.append({
                    "RAW_DATASET": dataset_name,
                    "VARIABLE":    str(col).upper(),
                    "LABEL":       str(label).strip(),
                    "FORMAT":      str(fmt).strip(),
                    "TYPE":        var_type,
                })
            log.info("  SAS file %s: %d variables", p.name, len(df_sas.columns))
        except Exception as exc:
            log.error("  Cannot read SAS file %s: %s", p.name, exc)

    if not rows:
        return pd.DataFrame(
            columns=["RAW_DATASET","VARIABLE","LABEL","FORMAT","TYPE","RAW_KEY","VAR_SLUG"]
        )

    out = pd.DataFrame(rows)
    out["VARIABLE"] = out["VARIABLE"].apply(_norm)
    out["RAW_KEY"]  = out["RAW_DATASET"] + "." + out["VARIABLE"]
    out["VAR_SLUG"] = out["VARIABLE"].apply(_slug)
    return (
        out[out["VARIABLE"] != ""]
        .drop_duplicates("RAW_KEY")
        .reset_index(drop=True)
    )


def read_raw_catalog(raw_path, cfg, log):
    """Read raw variable catalog (CSV / Excel / SAS XPT / SAS7BDAT)."""
    aliases = cfg.get("raw_catalog", {}).get("column_aliases", {})
    ext = raw_path.suffix.lower()

    if ext in (".xpt", ".sas7bdat", ".sas"):
        out = read_sas_files([raw_path], log)
        if not out.empty:
            log.info("  Raw catalog (SAS): %d variables in %d datasets",
                     len(out), out["RAW_DATASET"].nunique())
        return out

    def rc(df, key):
        lc = {c.lower(): c for c in df.columns}
        for a in aliases.get(key, [key]):
            if a.lower() in lc:
                return lc[a.lower()]
        for a in aliases.get(key, [key]):
            for col_l, col_o in lc.items():
                if a.lower() in col_l:
                    return col_o
        return None

    if ext == ".csv":
        df = pd.read_csv(raw_path, dtype=object)
    else:
        xl    = pd.ExcelFile(raw_path, engine="openpyxl")
        sheet = xl.sheet_names[0]
        for sn in xl.sheet_names:
            if any(k in sn.lower() for k in ["var", "col", "catalog", "field", "contents", "proc"]):
                sheet = sn
                break
        df = xl.parse(sheet, dtype=object)

    var_col = rc(df, "variable")
    if var_col is None:
        raise ValueError(
            "Cannot find variable column in %s. Expected: %s"
            % (raw_path.name, aliases.get("variable", ["NAME"]))
        )

    ds_col  = rc(df, "dataset")
    lbl_col = rc(df, "label")
    fmt_col = rc(df, "format")
    typ_col = rc(df, "type")

    out = pd.DataFrame()
    out["VARIABLE"]    = df[var_col].apply(_norm)
    out["RAW_DATASET"] = df[ds_col].apply(_norm)  if ds_col  else "UNKNOWN"
    out["LABEL"]       = df[lbl_col].apply(_norm) if lbl_col else ""
    out["FORMAT"]      = df[fmt_col].apply(_norm) if fmt_col else ""
    out["TYPE"]        = df[typ_col].apply(_norm) if typ_col else ""
    out["RAW_KEY"]     = out["RAW_DATASET"] + "." + out["VARIABLE"]
    out["VAR_SLUG"]    = out["VARIABLE"].apply(_slug)
    out = (
        out[out["VARIABLE"] != ""]
        .drop_duplicates("RAW_KEY")
        .reset_index(drop=True)
    )

    log.info("  Raw catalog: %d variables in %d datasets",
             len(out), out["RAW_DATASET"].nunique())
    return out


# ---------------------------------------------------------------------------
# Spec variable reader (carried over from legacy mapper, unchanged)
# ---------------------------------------------------------------------------

_NON_DOMAIN_LOWER = {
    "study", "standards", "toc", "<ds>", "ta", "te", "ti", "tv", "ts", "td",
    "ta-data", "te-data", "ti-data", "tv-data", "ts-data", "td-data",
    "maintenance", "valuelist", "value list", "history of revisions",
    "cover", "index", "readme",
}
_WB_LOG_PATTERN = re.compile(r"_Writeback_[0-9]{8}_[0-9]{4}$")


def read_spec_variables(spec_path, cfg, log):
    """Read SDTM spec to get variables to map. Returns DOMAIN/SDTM_VARIABLE/SDTM_LABEL/MAPPING_ACTION/CORE."""
    bc         = cfg.get("master_build", {})
    aliases    = bc.get("column_aliases", {})
    skip_lower = {s.lower() for s in bc.get("skip_sheets", [])}
    excl       = {d.upper() for d in bc.get("exclude_domains", [])}

    def rc(df, key):
        lc = {c.lower(): c for c in df.columns}
        for a in aliases.get(key, [key]):
            if a.lower() in lc:
                return lc[a.lower()]
        return None

    xl     = pd.ExcelFile(spec_path, engine="openpyxl")
    frames = []

    for sn in xl.sheet_names:
        if sn.lower() in skip_lower or sn.upper() in excl:
            continue
        if sn.strip().lower() in _NON_DOMAIN_LOWER:
            continue
        if _WB_LOG_PATTERN.match(sn.strip()):
            continue
        try:
            df = xl.parse(sn, dtype=object)
            if df.empty:
                continue
            var_al_lower = [a.lower() for a in aliases.get("variable", ["variable"])]
            col_l        = [str(c).strip().lower() for c in df.columns]
            if any(a in col_l for a in var_al_lower):
                hdr = 0
            else:
                hdr = None
                for i in range(min(15, len(df))):
                    rv = [str(v).strip().lower() for v in df.iloc[i].values if pd.notna(v)]
                    if any(a in rv for a in var_al_lower):
                        hdr = i
                        break
            if hdr is None:
                continue
            if hdr > 0:
                df = xl.parse(sn, header=hdr, dtype=object)

            var_c  = rc(df, "variable")
            ds_c   = rc(df, "dataset")
            lbl_c  = rc(df, "label")
            act_c  = rc(df, "mapping_action")
            core_c = rc(df, "core")
            if var_c is None:
                continue

            for _, r in df.iterrows():
                var = _norm(r.get(var_c))
                if not var:
                    continue
                dom = _norm(r.get(ds_c)) if ds_c else sn.upper()
                if not dom:
                    dom = sn.upper()
                if dom in excl:
                    continue
                frames.append({
                    "DOMAIN":         dom,
                    "SDTM_VARIABLE":  var,
                    "SDTM_LABEL":     _norm(r.get(lbl_c)) if lbl_c else "",
                    "MAPPING_ACTION": _norm(r.get(act_c)) if act_c else "",
                    "CORE":           _norm(r.get(core_c)) if core_c else "",
                })
        except Exception as exc:
            log.warning("  Sheet '%s': %s", sn, exc)

    if not frames:
        return pd.DataFrame()
    return (
        pd.DataFrame(frames)
        .drop_duplicates(["DOMAIN", "SDTM_VARIABLE"])
        .reset_index(drop=True)
    )


# ---------------------------------------------------------------------------
# Master index — same shape as v26 so master files remain compatible
# ---------------------------------------------------------------------------

def build_index(master_df: pd.DataFrame) -> dict:
    """
    Build lookup structures from master_mapping.

    Returns:
      by_sdtm          {(DOMAIN, SDTM_VARIABLE): [group_dict, ...]}
      by_raw           {bare_var_slug: [(domain, sdtm_var, conf, group_dict)]}
      by_raw_suffix4   {last4chars: [...same entries...]}  (near-miss bucket)
    """
    by_sdtm:  dict = {}
    by_raw:   dict = {}
    seen_groups: set = set()  # (domain, sdtm_var, group_sig) dedup

    for _, r in master_df.iterrows():
        domain    = str(r.get("DOMAIN",         "") or "").strip()
        var       = str(r.get("SDTM_VARIABLE",  "") or "").strip()
        group_sig = str(r.get("GROUP_SIG",      "") or "").strip()
        try:
            conf = float(r.get("MASTER_CONFIDENCE", 0.0))
        except (TypeError, ValueError):
            conf = 0.0

        if not domain or not var:
            continue

        key = (domain, var, group_sig)
        if key in seen_groups:
            continue
        seen_groups.add(key)

        entry = {
            "DOMAIN":            domain,
            "SDTM_VARIABLE":     var,
            "SDTM_LABEL":        str(r.get("SDTM_LABEL", "") or ""),
            "GROUP_SIG":         group_sig,
            "GROUP_TOKENS":      str(r.get("GROUP_TOKENS", "") or ""),
            "GROUP_COUNT":       int(r.get("GROUP_COUNT", 0) or 0),
            "MAPPING_ACTION":    str(r.get("MAPPING_ACTION", "") or ""),
            "MASTER_CONFIDENCE": conf,
            "IS_SPONSOR_STD":    bool(r.get("IS_SPONSOR_STD", False)),
            "SOURCE_FILES":      str(r.get("SOURCE_FILES", "") or ""),
        }
        by_sdtm.setdefault((domain, var), []).append(entry)

        for tok in (entry["GROUP_TOKENS"] or "").split("|"):
            if not tok:
                continue
            bare_slug = _slug(tok.split(".")[-1])
            if not bare_slug or bare_slug == "NAN":
                continue
            by_raw.setdefault(bare_slug, []).append(
                (domain, var, conf, entry)
            )

    by_raw_suffix4: dict = {}
    seen_ids: dict = {}
    for sl, entries in by_raw.items():
        if len(sl) >= 4:
            bucket = by_raw_suffix4.setdefault(sl[-4:], [])
            seen = seen_ids.setdefault(sl[-4:], set())
            for e in entries:
                if id(e) not in seen:
                    seen.add(id(e))
                    bucket.append(e)

    return {"by_sdtm": by_sdtm, "by_raw": by_raw, "by_raw_suffix4": by_raw_suffix4}


# ---------------------------------------------------------------------------
# TF-IDF label index
# ---------------------------------------------------------------------------

class LabelIndex:
    """TF-IDF cosine over raw variable labels.  Disabled if <3 labeled vars."""

    def __init__(self, raw_df: pd.DataFrame):
        self._ok = False
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity
        except ImportError:
            self._cosine = None
            return
        self._cosine = cosine_similarity

        labeled = raw_df[raw_df["LABEL"].astype(str).str.strip() != ""].copy()
        if len(labeled) < 3:
            return
        self._keys = labeled["RAW_KEY"].tolist()
        corpus    = labeled["LABEL"].astype(str).str.lower().tolist()
        try:
            self._vec    = TfidfVectorizer(
                analyzer="word", ngram_range=(1, 2),
                min_df=1, sublinear_tf=True,
            )
            self._matrix = self._vec.fit_transform(corpus)
            self._ok     = True
        except Exception:
            pass

    @property
    def is_enabled(self) -> bool:
        return self._ok

    def scores(self, query: str, keys: list) -> dict:
        if not self._ok or not (query or "").strip():
            return {k: 0.0 for k in keys}
        try:
            q_vec = self._vec.transform([str(query).lower()])
            ki    = {k: i for i, k in enumerate(self._keys)}
            out: dict = {}
            for k in keys:
                if k in ki:
                    out[k] = float(self._cosine(q_vec, self._matrix[ki[k]])[0][0])
                else:
                    out[k] = 0.0
            return out
        except Exception:
            return {k: 0.0 for k in keys}


# ---------------------------------------------------------------------------
# Pair scoring — single, simple composite
# ---------------------------------------------------------------------------

def pair_score(
    raw_var: str,
    raw_dataset: str,
    raw_label: str,
    sdtm_var: str,
    sdtm_domain: str,
    sdtm_label: str,
    master_conf: float,
    label_sim: float,
    in_master: bool,
    historical_match: bool = False,
) -> tuple[float, dict]:
    """
    One-stop composite score for (raw -> sdtm) pair.  Range [0, 1].

    Components (sum to 1.0):
      0.35  exact slug match              0/1
      0.20  fuzzy name similarity         (Jaro-Winkler / sequence / token-set max)
      0.20  master mapping prior          MASTER_CONFIDENCE if in_master else 0
      0.15  label TF-IDF cosine
      0.10  domain prefix-2 match         0/1

    v28 fix: historical_match is True when the raw token (RAW.<ds>.<var>)
    appears verbatim in the master's GROUP_TOKENS for this SDTM target.
    That is the strongest possible signal — a hand-curated past mapping —
    so we boost the score by `historical_boost` (default 0.45).  This
    fixes the case where raw 'DM.SEX_STD' has slug 'SEXSTD' but the SDTM
    target is 'DM.SEX' (slug 'SEX') and the master legitimately knows
    that 'RAW.DM.SEX_STD' maps to DM.SEX from prior studies.  Without the
    boost the score collapsed to ~0.47 (below review threshold) even
    though the historical mapping is exact.

    Returns (score, breakdown).
    """
    rv_slug = _slug(raw_var)
    sv_slug = _slug(sdtm_var)
    rds     = _slug(raw_dataset)[:2].upper()
    dom2    = _slug(sdtm_domain)[:2].upper()

    exact = 1.0 if rv_slug == sv_slug else 0.0
    fuzzy = name_sim(raw_var, sdtm_var)
    mc    = float(master_conf) if (in_master and master_conf) else 0.0
    ls    = float(label_sim or 0.0)
    dom_m = 1.0 if (rds and dom2 and rds == dom2) else 0.0

    base_score = (
        0.35 * exact
        + 0.20 * fuzzy
        + 0.20 * mc
        + 0.15 * ls
        + 0.10 * dom_m
    )

    # v28: historical-match boost — additive but capped at 1.0
    hist_boost = 0.0
    if historical_match:
        # Boost is proportional to master_conf: a high-confidence historical
        # mapping (mc 0.95) gets ~0.43 boost; weak ones (mc 0.5) get ~0.22.
        # Floor at 0.30 so even a single-study historical match is recognised.
        hist_boost = max(0.30, 0.45 * mc)

    score = float(min(max(base_score + hist_boost, 0.0), 1.0))

    breakdown = {
        "name_exact":       round(exact, 3),
        "name_fuzzy":       round(fuzzy, 3),
        "master_conf":      round(mc, 3),
        "label_tfidf":      round(ls, 3),
        "domain_match":     round(dom_m, 3),
        "historical":       round(hist_boost, 3),
        "composite":        round(score, 4),
    }
    return score, breakdown


# ---------------------------------------------------------------------------
# v28: Historical-match detection — does the exact raw token appear in the
# master's GROUP_TOKENS string for this SDTM target?  GROUP_TOKENS are stored
# as e.g. "RAW.DM.SEX_STD|RAW.PKMERGE.SEX|RAW.DM.SEX".  We compare on slug
# basis so case / underscore variants don't break the match.
# ---------------------------------------------------------------------------

def _is_historical_match(raw_ds: str, raw_var: str,
                         raw_full_tok_slug: str,
                         group_tokens_str: str) -> bool:
    """
    Return True iff `raw_ds.raw_var` (slug-normalised) appears in any of the
    pipe-separated tokens in `group_tokens_str`.

    Tokens look like:  RAW.DM.SEX_STD   sdtm.dm.sex   raw.dm.sex
    We normalise to:   DM.SEXSTD                      raw.dm.sex stripped to bare
                                                      DM.SEX
    """
    if not group_tokens_str or not raw_full_tok_slug:
        return False
    target = raw_full_tok_slug.upper()
    for tok in group_tokens_str.split("|"):
        tok = tok.strip()
        if not tok:
            continue
        # Drop the optional RAW./SDTM./WORK. prefix
        parts = tok.split(".")
        if not parts:
            continue
        if parts[0].upper() in ("RAW", "SDTM", "WORK") and len(parts) >= 2:
            parts = parts[1:]
        if len(parts) >= 2:
            tok_slug = _slug(parts[-2]) + "." + _slug(parts[-1])
        else:
            tok_slug = _slug(parts[-1])
        if tok_slug.upper() == target:
            return True
    return False


def _harvest_master_raw_for_target(
    domain: str, var: str, idx: dict, raw_df: pd.DataFrame,
    cap: int = 12,
) -> list:
    """
    v28: For a (domain, var) target where the rule says the variable is
    derived (e.g. DM.RFPENDTC), look up the master's by_sdtm index to find
    every historical RAW.* token recorded for this target across all
    studies.  For each, check whether the slug-equivalent variable exists
    in the CURRENT study's raw_df (any dataset).  Return the list of tokens
    in the form "RAW.<dataset>.<variable>" using the CURRENT study's
    dataset and variable spelling.

    This preserves the traceability that the v27 rule-table flow lost: when
    a rule fires, the historical raw inputs were silently dropped, so the
    spec's Input Variables column was overwritten with empty.

    Capped at `cap` tokens (default 12, matching the timing/identifier cap)
    to prevent runaway accumulation if a single SDTM target has many
    historical sources.

    Returns a list of "RAW.<DS>.<VAR>" strings; empty list if nothing
    matched in current raw_df.
    """
    by_sdtm_groups = idx.get("by_sdtm", {}).get((domain, var), [])
    if not by_sdtm_groups:
        return []

    # Build slug -> [(RAW_DATASET, VARIABLE)] lookup over current raw_df.
    raw_var_slug_to_pairs: dict = {}
    for _, rr in raw_df.iterrows():
        ds = str(rr["RAW_DATASET"]).strip()
        rv = str(rr["VARIABLE"]).strip()
        if not rv:
            continue
        sl = _slug(rv)
        raw_var_slug_to_pairs.setdefault(sl, []).append((ds, rv))

    # Walk each historical group and try to resolve every token.
    harvested: list = []
    seen: set = set()
    for grp in by_sdtm_groups:
        toks_str = grp.get("GROUP_TOKENS", "") or ""
        for tok in toks_str.split("|"):
            tok = tok.strip()
            if not tok:
                continue
            parts = tok.split(".")
            if not parts:
                continue
            if parts[0].upper() in ("RAW", "SDTM", "WORK") and len(parts) >= 2:
                parts = parts[1:]
            if not parts:
                continue
            hist_var = parts[-1]
            hist_ds  = parts[-2] if len(parts) >= 2 else ""
            hist_var_slug = _slug(hist_var)
            if not hist_var_slug:
                continue

            # Find the variable in current raw catalog.  Prefer same-dataset
            # match if the historical token had a dataset hint.
            pairs = raw_var_slug_to_pairs.get(hist_var_slug, [])
            if not pairs:
                continue
            chosen = None
            if hist_ds:
                hist_ds_pref = _slug(hist_ds)[:2].upper()
                for (ds, rv) in pairs:
                    if _slug(ds)[:2].upper() == hist_ds_pref:
                        chosen = (ds, rv)
                        break
            if chosen is None:
                chosen = pairs[0]

            ds, rv = chosen
            full = "RAW." + ds + "." + rv
            if full.upper() in seen:
                continue
            seen.add(full.upper())
            harvested.append(full)
            if len(harvested) >= cap:
                return harvested

    return harvested


# ---------------------------------------------------------------------------

def cross_domain_compatible(
    raw_dataset: str,
    sdtm_domain: str,
    sdtm_var: str,
) -> tuple[bool, str]:
    """
    Decide whether a raw token from `raw_dataset` is allowed to map to
    `sdtm_var` in `sdtm_domain`, when the two domains differ.

    Same-domain prefix is always allowed.
    Cross-domain is allowed only for:
      * Timing variables ending DT/DTC/DTM (legitimately multi-source)
      * USUBJID / SUBJID / STUDYID coming from DM- or EN- prefixed datasets
      * Same DOMAIN_CLASS (Events vs Events, Findings vs Findings)

    Returns (allowed, reason).
    """
    rds = _slug(raw_dataset)[:2].upper()
    dom = _slug(sdtm_domain)[:2].upper()
    if not rds or not dom or rds == dom:
        return True, "same-domain"

    var_up = sdtm_var.upper().strip()
    is_timing = bool(re.search(r"(DT|DTC|DTM)$", var_up))
    if is_timing:
        return True, "timing-cross-domain"

    if var_up in ("USUBJID", "SUBJID", "STUDYID") and rds in ("DM", "EN"):
        return True, "identifier-from-dm-or-enroll"

    raw_class  = DOMAIN_CLASS.get(rds, "Unknown")
    sdtm_class = DOMAIN_CLASS.get(dom, "Unknown")
    if raw_class != "Unknown" and raw_class == sdtm_class:
        return True, "same-class-cross-domain"

    return False, "different-class"


# ---------------------------------------------------------------------------
# Origin-set construction (kept from legacy)
# ---------------------------------------------------------------------------

CRF_EXCLUDE_FORMATS = ("DATE", "DATETIME", "TIME", "YYMMDD", "DDMMYY", "TOD")


def build_origin_sets(raw_df: pd.DataFrame, master_df: pd.DataFrame) -> tuple[set, set]:
    """Build (crf_var_set, als_var_set) for use by infer_origin."""
    crf_vars: set = set()
    als_vars: set = set()
    for _, rr in raw_df.iterrows():
        raw_ds  = str(rr.get("RAW_DATASET", "")).strip().upper()
        raw_var = str(rr.get("VARIABLE", "")).strip().upper()
        fmt     = str(rr.get("FORMAT", "") or "").upper()
        typ     = str(rr.get("TYPE", "") or "").upper()
        ds_pref = raw_ds[:2] if len(raw_ds) >= 2 else raw_ds
        is_edt  = ds_pref in EDT_PREFIXES
        is_date = any(x in fmt for x in CRF_EXCLUDE_FORMATS)
        is_char = typ in ("C", "CHAR", "CHARACTER", "TEXT", "STRING")
        if not is_edt and is_char and not is_date:
            crf_vars.add(raw_var)
    if "ORIGIN" in master_df.columns:
        for _, mr in master_df.iterrows():
            raw_tok = str(mr.get("RAW_VARIABLE", "") or "").strip().upper()
            origin  = str(mr.get("ORIGIN", "") or "").strip().upper()
            bare    = raw_tok.split(".")[-1] if "." in raw_tok else raw_tok
            if not bare or bare == "NAN":
                continue
            if origin == "CRF":
                crf_vars.add(bare)
            elif origin in ("ASSIGNED", "PROTOCOL", "ASSIGNED/SPONSOR"):
                als_vars.add(bare)
    return crf_vars, als_vars


# ---------------------------------------------------------------------------
# Result-row builder
# ---------------------------------------------------------------------------

RESULT_COLUMNS = [
    "DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL", "VAR_CLASS",
    "RAW_VARIABLES_ASSIGNED", "MAPPING_ACTION", "ORIGIN", "ORIGIN_CONFIDENCE",
    "COMPOSITE_SCORE", "MATCH_TIER", "MATCH_PATH", "GROUP_COUNT",
    "MASTER_CONF", "LABEL_SIM", "PARTIAL_FRAC", "TOP_CANDIDATES",
    "SCORE_BREAKDOWN", "MATCH_NOTE",
]


def _make_row(domain, var, label, vc, raw_assigned,
              action, origin, oconf,
              score, tier, match_path, group_count,
              master_conf, label_sim, partial_frac,
              top_candidates="", xai="", note=""):
    """Build a result row with all standard columns."""
    return {
        "DOMAIN":        domain,
        "SDTM_VARIABLE": var,
        "SDTM_LABEL":    label,
        "VAR_CLASS":     vc,
        "RAW_VARIABLES_ASSIGNED": raw_assigned or "",
        "MAPPING_ACTION":         action or "",
        "ORIGIN":                 origin or "",
        "ORIGIN_CONFIDENCE":      round(float(oconf or 0), 3),
        "COMPOSITE_SCORE":        round(float(score or 0), 4),
        "MATCH_TIER":             tier or "",
        "MATCH_PATH":             match_path or "",
        "GROUP_COUNT":            int(group_count or 0),
        "MASTER_CONF":            round(float(master_conf or 0), 4) if master_conf != "" else "",
        "LABEL_SIM":              round(float(label_sim or 0), 4) if label_sim != "" else "",
        "PARTIAL_FRAC":           round(float(partial_frac or 0), 3) if partial_frac != "" else "",
        "TOP_CANDIDATES":         top_candidates or "",
        "SCORE_BREAKDOWN":        str(xai) if xai else "",
        "MATCH_NOTE":             note or "",
    }


# ---------------------------------------------------------------------------
# Main mapping pipeline
# ---------------------------------------------------------------------------

# Identifier classes that legitimately accept multiple raw sources
_IDENTIFIER_VARS = frozenset({"USUBJID", "SUBJID", "STUDYID"})

# Token caps to prevent noise accumulation
_TOK_CAP_TIMING_OR_ID = 12
_TOK_CAP_DEFAULT      = 6
_EXTRA_TOK_THRESHOLD  = 0.45    # extra tokens must score at least this much


def run_mapping(
    master_df: pd.DataFrame,
    raw_df: pd.DataFrame,
    sdtm_vars_df: pd.DataFrame,
    cfg: dict,
    log,
    master_path=None,
) -> dict:
    """
    Three-step mapping pipeline.  Returns a dict with the same keys the
    UI/services already consume:
      direct, review, unresolved, unmapped_raw, cross_dataset_match, coverage
    """
    auto_t_default = float(cfg.get("matching", {}).get("thresholds", {}).get("auto_accept", 0.82))
    rev_t_default  = float(cfg.get("matching", {}).get("thresholds", {}).get("review",      0.55))
    MIN_SC         = float(cfg.get("matching", {}).get("candidate_min_score", 0.35))

    log.info("[MAP] STEP 0  -- Building master index and label TF-IDF")
    idx     = build_index(master_df)
    lbl_idx = LabelIndex(raw_df)
    log.info("  Label TF-IDF: %s",
             "enabled" if lbl_idx.is_enabled else "disabled (no labels)")

    crf_var_set, als_var_set = build_origin_sets(raw_df, master_df)
    raw_ds_set               = set(raw_df["RAW_DATASET"].tolist())
    log.info("  Origin sets: %d CRF, %d ALS", len(crf_var_set), len(als_var_set))

    spec_var_lookup: dict = {}
    for _, sv in sdtm_vars_df.iterrows():
        d = str(sv.get("DOMAIN", "")).strip()
        v = str(sv.get("SDTM_VARIABLE", "")).strip()
        if d and v:
            spec_var_lookup[(d, v)] = sv

    # --------------------------------------------------------------
    # STEP 1: MASTER LOOKUP (raw-first)
    # --------------------------------------------------------------
    log.info("[MAP] STEP 1  -- Master lookup for %d raw variables", len(raw_df))

    sdtm_assignments: dict = {}   # (domain, var) -> assignment dict
    pe = log.info  # progress emitter

    total_raw = len(raw_df)
    for ri, (_, rr) in enumerate(raw_df.iterrows()):
        if (ri + 1) % 200 == 0 or (ri + 1) == total_raw:
            pe("  Step 1: [%d/%d] raw vars processed", ri + 1, total_raw)

        raw_ds   = str(rr["RAW_DATASET"]).strip()
        raw_var  = str(rr["VARIABLE"]).strip()
        raw_key  = str(rr["RAW_KEY"]).strip()
        raw_lbl  = str(rr.get("LABEL", "") or "").strip()
        raw_slug = _slug(raw_var)
        if not raw_var or not raw_slug:
            continue

        # v28: full-token signature for historical-match detection
        # e.g. raw.dm.sex_std -> RAW.DM.SEX_STD (uppercased, slug-equivalent)
        raw_full_tok_slug = _slug(raw_ds) + "." + raw_slug

        # Look up this bare-name slug in master.by_raw
        candidate_groups = idx["by_raw"].get(raw_slug, [])

        # Suffix-4 fallback for near-miss naming variation
        if not candidate_groups and len(raw_slug) >= 4:
            candidate_groups = idx["by_raw_suffix4"].get(raw_slug[-4:], [])

        best_score = 0.0
        best_key   = None
        best_info: dict = {}

        for (sdtm_dom, sdtm_var, master_conf, group_entry) in candidate_groups:
            # If we have a spec, only consider variables in it
            if spec_var_lookup and (sdtm_dom, sdtm_var) not in spec_var_lookup:
                continue

            # Cross-domain compatibility gate (replaces v26's penalty multipliers)
            ok, _reason = cross_domain_compatible(raw_ds, sdtm_dom, sdtm_var)
            if not ok:
                continue

            sdtm_lbl_exp = expand_sdtm_label(sdtm_var, sdtm_dom)
            label_sim    = lbl_idx.scores(sdtm_lbl_exp, [raw_key]).get(raw_key, 0.0)

            # v28: detect historical match — does this exact raw token appear
            # in the master's GROUP_TOKENS for this SDTM target?
            historical = _is_historical_match(
                raw_ds, raw_var, raw_full_tok_slug,
                group_entry.get("GROUP_TOKENS", "") or "",
            )

            sc, xai = pair_score(
                raw_var=raw_var, raw_dataset=raw_ds, raw_label=raw_lbl,
                sdtm_var=sdtm_var, sdtm_domain=sdtm_dom,
                sdtm_label=group_entry.get("SDTM_LABEL", "") or "",
                master_conf=master_conf,
                label_sim=label_sim,
                in_master=True,
                historical_match=historical,
            )

            if sc > best_score and sc >= MIN_SC:
                best_score = sc
                best_key   = (sdtm_dom, sdtm_var)
                best_info  = {
                    "master_conf": master_conf,
                    "label_sim":   label_sim,
                    "group":       group_entry,
                    "raw_tok":     "RAW." + raw_ds + "." + raw_var,
                    "vc":          classify_variable(sdtm_var, sdtm_dom),
                    "xai":         xai,
                }

        if not best_key:
            continue

        # Record / accumulate the assignment
        existing = sdtm_assignments.get(best_key)
        if existing is None or best_score > existing["score"]:
            prev_extras = []
            if existing is not None:
                for et in existing["raw_tokens"]:
                    if et != best_info["raw_tok"] and et not in prev_extras:
                        prev_extras.append(et)
            sdtm_assignments[best_key] = {
                "score":             best_score,
                "master_conf":       best_info["master_conf"],
                "label_sim":         best_info["label_sim"],
                "group":             best_info["group"],
                "raw_tokens":        [best_info["raw_tok"]] + prev_extras,
                "raw_token_scores":  {best_info["raw_tok"]: best_score},
                "vc":                best_info["vc"],
                "xai":               best_info["xai"],
            }
        else:
            # An additional raw variable maps to the same SDTM target.
            # Accept the extra token only when:
            #   a) it's a timing/datetime variable (legitimately multi-source), OR
            #   b) it's an identifier from DM/ENROLL, OR
            #   c) it comes from the same domain prefix as the target.
            raw_tok      = "RAW." + raw_ds + "." + raw_var
            sdtm_var_key = best_key[1]
            sdtm_dom_key = best_key[0]
            is_timing    = bool(re.search(r"(DT|DTC|DTM)$", sdtm_var_key))
            is_id        = sdtm_var_key in _IDENTIFIER_VARS
            same_dom     = _slug(raw_ds)[:2] == _slug(sdtm_dom_key)[:2]
            from_dm_like = _slug(raw_ds)[:2].upper() in ("DM", "EN")

            accept_extra = (
                is_timing
                or (is_id and (same_dom or from_dm_like))
                or (not is_timing and not is_id and same_dom)
            )

            if (raw_tok not in existing["raw_tokens"]
                    and best_score >= max(MIN_SC, _EXTRA_TOK_THRESHOLD)
                    and accept_extra):
                existing["raw_tokens"].append(raw_tok)
                existing.setdefault("raw_token_scores", {})[raw_tok] = best_score

                cap = _TOK_CAP_TIMING_OR_ID if (is_timing or is_id) else _TOK_CAP_DEFAULT
                if len(existing["raw_tokens"]) > cap:
                    ts = existing.get("raw_token_scores", {})
                    ranked = sorted(
                        existing["raw_tokens"],
                        key=lambda t: ts.get(t, 0.0),
                        reverse=True,
                    )
                    existing["raw_tokens"] = ranked[:cap]

    log.info("  Step 1 complete: %d SDTM variables matched in master", len(sdtm_assignments))

    # --------------------------------------------------------------
    # STEP 2 + 3: walk every spec variable and resolve
    # --------------------------------------------------------------
    log.info("[MAP] STEP 2  -- Resolving %d spec variables (rules + fuzzy)",
             len(sdtm_vars_df))

    direct_rows: list = []
    review_rows: list = []
    unres_rows:  list = []
    mapped_raw_keys: set = set()

    total = len(sdtm_vars_df)
    for i, (_, sv) in enumerate(sdtm_vars_df.iterrows()):
        if (i + 1) % 100 == 0 or (i + 1) == total:
            log.info("  Step 2: [%4d/%d]  direct=%d  review=%d  unres=%d",
                     i + 1, total, len(direct_rows), len(review_rows), len(unres_rows))

        domain = str(sv.get("DOMAIN",         "")).strip()
        var    = str(sv.get("SDTM_VARIABLE",  "")).strip()
        label  = str(sv.get("SDTM_LABEL",     "")).strip()
        action = str(sv.get("MAPPING_ACTION", "")).strip()
        if not domain or not var:
            continue

        auto_t, rev_t = get_thresholds(cfg, domain)
        vc = classify_variable(var, domain)

        # ----- 2a. STEP 1 hit takes priority --------------------
        assignment = sdtm_assignments.get((domain, var))
        if assignment:
            score        = assignment["score"]
            raw_tokens   = list(assignment["raw_tokens"])

            # v28: For Derived variables (e.g. RFPENDTC, RFSTDTC, --DY,
            # --BLFL), augment Step 1's accumulated tokens with the FULL
            # master GROUP_TOKENS harvest.  Step 1 only attaches a raw_var
            # to its single best SDTM target, so multi-input derived
            # targets (like RFPENDTC <- AESTDAT_RAW + AEENDAT_RAW + ...)
            # only get the inputs that didn't have a stronger competing
            # target.  The harvest fills in the rest from the master's
            # historical record.
            _rule_for_var = lookup_rule(domain, var)
            _is_derived_target = (
                (_rule_for_var is not None
                 and not _rule_for_var.get("needs_raw", True)
                 and (_rule_for_var.get("origin", "") or "").lower() == "derived")
                or vc in ("derived", "flag", "sequence")
                or bool(re.search(r"DY$|BLFL$|LOBXFL$|CHG$|PCHG$|SHIFT$|NRIND$",
                                  var.upper()))
            )
            if _is_derived_target:
                _harvested = _harvest_master_raw_for_target(
                    domain, var, idx, raw_df,
                )
                _existing_upper = {t.upper() for t in raw_tokens}
                for _h in _harvested:
                    if _h.upper() not in _existing_upper:
                        raw_tokens.append(_h)
                        _existing_upper.add(_h.upper())

            raw_assigned = ", ".join(raw_tokens)

            # tier from score
            if score >= auto_t:
                tier = "direct"
            elif score >= rev_t:
                tier = "review"
            else:
                tier         = "unresolved"
                raw_tokens   = []
                raw_assigned = ""

            for tok in raw_tokens:
                parts = tok.split(".")
                if len(parts) >= 3:
                    mapped_raw_keys.add(parts[-2] + "." + parts[-1])

            # Origin via central infer_origin
            origin, oconf = infer_origin(
                var, domain, action, raw_tokens,
                crf_var_set, als_var_set, raw_ds_set,
            )
            # v28: if a rule sets origin (Derived/Assigned), prefer rule
            if _rule_for_var is not None and _rule_for_var.get("origin"):
                origin = _rule_for_var["origin"]
                oconf  = max(oconf, _rule_for_var.get("confidence", 0.85))

            mapped_action = (
                action
                or assignment["group"].get("MAPPING_ACTION")
                or ("ASSIGN" if raw_tokens else "DERIVE")
            )
            if _rule_for_var is not None and _rule_for_var.get("action"):
                mapped_action = _rule_for_var["action"]

            row = _make_row(
                domain, var, label, vc, raw_assigned,
                mapped_action, origin, oconf,
                score, tier, "master_lookup",
                assignment["group"].get("GROUP_COUNT", 1),
                assignment["master_conf"], assignment["label_sim"], 1.0,
                xai=assignment.get("xai", {}),
                note=(_rule_for_var.get("algorithm", "")
                      if _rule_for_var is not None else ""),
            )
            (direct_rows if tier == "direct"
             else review_rows if tier == "review"
             else unres_rows).append(row)
            continue

        # ----- 2b. RULE TABLE -----------------------------------
        rule = lookup_rule(domain, var)
        if rule is not None:
            # v28: harvest historical raw sources from the master for this
            # (domain, var).  Even when the rule says the variable is
            # Derived, the master records WHICH raw variables historically
            # fed the derivation (e.g. DM.RFPENDTC <- AE.AESTDAT_RAW,
            # AE.AEENDAT_RAW, CONSENTS.CONSDAT_RAW).  If those raw
            # variables exist in the NEW study's raw catalog, attach them
            # as input variables so the spec preserves traceability.
            harvested_tokens = _harvest_master_raw_for_target(
                domain, var, idx, raw_df,
            )

            # If the rule needs a raw source but Step 1 didn't find one,
            # this becomes a review-tier item — the user must supply one.
            if rule.get("needs_raw"):
                if harvested_tokens:
                    # We DID find raw sources via the master harvest — promote
                    # to review tier with the harvested tokens.
                    row = _make_row(
                        domain, var, label, vc,
                        raw_assigned=", ".join(harvested_tokens),
                        action=rule["action"],
                        origin=rule["origin"],
                        oconf=rule.get("confidence", 0.85),
                        score=0.65, tier="review",
                        match_path="rule_with_master_harvest",
                        group_count=len(harvested_tokens),
                        master_conf="", label_sim="", partial_frac="",
                        note=("Raw sources harvested from master historical "
                              "mappings.  Algorithm: "
                              + (rule.get("algorithm") or "")),
                    )
                    review_rows.append(row)
                    for tok in harvested_tokens:
                        parts = tok.split(".")
                        if len(parts) >= 3:
                            mapped_raw_keys.add(parts[-2] + "." + parts[-1])
                    continue
                row = _make_row(
                    domain, var, label, vc,
                    raw_assigned="", action=rule["action"],
                    origin=rule["origin"], oconf=rule.get("confidence", 0.85),
                    score=0.0, tier="unresolved",
                    match_path="rule_needs_raw",
                    group_count=0,
                    master_conf="", label_sim="", partial_frac="",
                    note=("Rule says variable needs a raw source but none was "
                          "found in master.  Algorithm: "
                          + (rule.get("algorithm") or "")),
                )
                unres_rows.append(row)
                continue

            # Rule with needs_raw=False (e.g. RFSTDTC, RFPENDTC, EPOCH).
            # Even though the rule alone is enough to populate Origin/Action,
            # we still want to surface historical raw sources for
            # traceability.  v28: if harvested tokens exist, include them.
            row = _make_row(
                domain, var, label, vc,
                raw_assigned=(", ".join(harvested_tokens) if harvested_tokens else ""),
                action=rule["action"],
                origin=rule["origin"], oconf=rule.get("confidence", 0.90),
                score=1.0, tier="direct",
                match_path=("rule_with_master_harvest" if harvested_tokens else "rule_table"),
                group_count=len(harvested_tokens),
                master_conf="", label_sim="", partial_frac="",
                note=rule.get("algorithm", ""),
            )
            direct_rows.append(row)
            for tok in harvested_tokens:
                parts = tok.split(".")
                if len(parts) >= 3:
                    mapped_raw_keys.add(parts[-2] + "." + parts[-1])
            continue

        # ----- 2c. FUZZY FALLBACK (same-domain only) -----------
        same_dom_raw = raw_df[
            raw_df["RAW_DATASET"].apply(
                lambda d: _slug(str(d))[:2] == _slug(domain)[:2]
            )
        ]

        best_sc  = 0.0
        best_tok = ""
        best_xai: dict = {}
        best_lbl = 0.0
        if not same_dom_raw.empty:
            sdtm_lbl_exp = (label + " " + expand_sdtm_label(var, domain)).strip()
            lbl_sims = lbl_idx.scores(sdtm_lbl_exp, same_dom_raw["RAW_KEY"].tolist())
            for _, rr in same_dom_raw.iterrows():
                sc, xai = pair_score(
                    raw_var=rr["VARIABLE"], raw_dataset=rr["RAW_DATASET"],
                    raw_label=rr.get("LABEL", "") or "",
                    sdtm_var=var, sdtm_domain=domain, sdtm_label=label,
                    master_conf=0.0,
                    label_sim=lbl_sims.get(rr["RAW_KEY"], 0.0),
                    in_master=False,
                )
                if sc > best_sc:
                    best_sc  = sc
                    best_tok = "RAW." + rr["RAW_DATASET"] + "." + rr["VARIABLE"]
                    best_xai = xai
                    best_lbl = lbl_sims.get(rr["RAW_KEY"], 0.0)

        if best_sc >= rev_t and best_tok:
            origin, oconf = infer_origin(
                var, domain, action, [best_tok],
                crf_var_set, als_var_set, raw_ds_set,
            )
            tier = "direct" if best_sc >= auto_t else "review"
            mapped_action = action or "ASSIGN"
            row = _make_row(
                domain, var, label, vc, best_tok,
                mapped_action, origin, oconf,
                best_sc, tier, "fuzzy_same_domain",
                1, "", best_lbl, 1.0,
                xai=best_xai,
            )
            (direct_rows if tier == "direct" else review_rows).append(row)
            parts = best_tok.split(".")
            if len(parts) >= 3:
                mapped_raw_keys.add(parts[-2] + "." + parts[-1])
            continue

        # ----- 2d. UNRESOLVED — explain why --------------------
        master_groups = idx["by_sdtm"].get((domain, var), [])
        if master_groups:
            note = (
                "Master has historical sources: "
                + ", ".join(sorted({
                    tok for g in master_groups
                    for tok in (g.get("GROUP_TOKENS", "") or "").split("|")
                    if tok and tok.strip()
                }))[:300]
                + ".  None of them are present in the new study raw catalog."
            )
            mp = "master_name_bridge_failed"
        else:
            note = ""
            mp = "no_master_group"

        unres_rows.append(_make_row(
            domain, var, label, vc, "", action, "", 0.0,
            0.0, "unresolved", mp, 0,
            "", "", "",
            note=note,
        ))

    log.info("  Step 2 complete: direct=%d  review=%d  unresolved=%d",
             len(direct_rows), len(review_rows), len(unres_rows))

    # --------------------------------------------------------------
    # STEP 3: cross-dataset variable-name match (manual review)
    # --------------------------------------------------------------
    log.info("[MAP] STEP 3  -- Cross-dataset var-name match for unresolved (%d)",
             len(unres_rows))

    raw_slug_index: dict = {}
    for _, rr in raw_df.iterrows():
        rv  = str(rr["VARIABLE"]).strip()
        rds = str(rr["RAW_DATASET"]).strip()
        rk  = str(rr.get("RAW_KEY", rds + "." + rv))
        sl  = _slug(rv)
        if sl:
            raw_slug_index.setdefault(sl, []).append((rds, rv, rk))

    cross_rows:     list = []
    unres_remaining: list = []
    CROSS_MIN_SIM = 0.72

    for row in unres_rows:
        domain = str(row.get("DOMAIN", "")).strip()
        var    = str(row.get("SDTM_VARIABLE", "")).strip()
        var_slug = _slug(var)
        if not var_slug:
            unres_remaining.append(row)
            continue

        # v28: Skip PROTECTED variables — names that legitimately occur in
        # many datasets but are not interchangeable across SDTM domains.
        # SEX/AGE/RACE/ETHNIC: can appear in PK/MB/QS/etc raw datasets but
        # only DM.SEX gets DM raw sources.  This prevents the v27 bug where
        # `RAW.PKMERGE.SEX` was suggested for `DM.SEX` simply because of
        # name collision.
        var_up = var.upper()
        is_protected_name = (
            var_up in {"SEX", "AGE", "RACE", "ETHNIC", "COUNTRY", "BRTHDTC",
                       "DTHDTC", "DTHFL", "ARMCD", "ARM", "ACTARMCD", "ACTARM",
                       "SITEID", "SUBJID", "USUBJID", "STUDYID", "DOMAIN",
                       "VISITNUM", "VISIT", "VISITDY",
                       "EPOCH", "ELEMENT", "ETCD"}
            or re.match(r"^(SEQ|SPID)$", var_up)
        )

        candidates = raw_slug_index.get(var_slug, [])
        # Cross-dataset is allowed only if cross_domain_compatible passes
        # for at least one candidate (timing variables, or class-compatible).
        manual_pick = None
        for (rds, rv, rk) in candidates:
            if _slug(rds)[:2] == _slug(domain)[:2]:
                continue   # same-domain — would have been caught in Step 1/2
            if is_protected_name:
                continue   # never accept name-collision for protected vars
            ok, _why = cross_domain_compatible(rds, domain, var)
            if not ok:
                continue
            manual_pick = (rds, rv, rk)
            break

        if manual_pick is not None:
            rds, rv, rk = manual_pick
            tok = "RAW." + rds + "." + rv
            cross_row = dict(row)
            cross_row["RAW_VARIABLES_ASSIGNED"] = tok
            cross_row["COMPOSITE_SCORE"]        = round(CROSS_MIN_SIM, 4)
            cross_row["MATCH_TIER"]             = "cross_dataset_var_match"
            cross_row["MAPPING_ACTION"]         = "ASSIGN"
            cross_row["MATCH_NOTE"] = (
                "Variable name appears in raw dataset '%s' but the dataset "
                "name does not match the SDTM domain prefix.  MANUAL REVIEW "
                "REQUIRED: confirm this is a legitimate cross-domain mapping."
            ) % rds
            cross_rows.append(cross_row)
        else:
            unres_remaining.append(row)

    # --------------------------------------------------------------
    # Build output frames
    # --------------------------------------------------------------
    direct_df = pd.DataFrame(direct_rows, columns=RESULT_COLUMNS) if direct_rows else pd.DataFrame(columns=RESULT_COLUMNS)
    review_df = pd.DataFrame(review_rows, columns=RESULT_COLUMNS) if review_rows else pd.DataFrame(columns=RESULT_COLUMNS)
    unres_df  = pd.DataFrame(unres_remaining, columns=RESULT_COLUMNS) if unres_remaining else pd.DataFrame(columns=RESULT_COLUMNS)
    cross_df  = pd.DataFrame(cross_rows,  columns=RESULT_COLUMNS) if cross_rows  else pd.DataFrame(columns=RESULT_COLUMNS)

    # Unmapped raw variables
    unmapped = raw_df[~raw_df["RAW_KEY"].isin(mapped_raw_keys)].copy()
    unmapped = unmapped[["RAW_DATASET", "VARIABLE", "LABEL", "FORMAT"]].copy()
    unmapped.columns = ["RAW_DATASET", "RAW_VARIABLE", "LABEL", "FORMAT"]

    # Coverage per domain
    cov_rows = []
    for dom in sdtm_vars_df["DOMAIN"].unique():
        dom_vars = sdtm_vars_df[sdtm_vars_df["DOMAIN"] == dom]
        tot = len(dom_vars)
        d_n = int((direct_df["DOMAIN"] == dom).sum()) if not direct_df.empty else 0
        r_n = int((review_df["DOMAIN"] == dom).sum()) if not review_df.empty else 0
        u_n = int((unres_df["DOMAIN"]  == dom).sum()) if not unres_df.empty  else 0
        all_dom = pd.concat([df for df in [direct_df, review_df, unres_df] if not df.empty])
        all_dom = all_dom[all_dom["DOMAIN"] == dom] if not all_dom.empty else pd.DataFrame()
        cc = (all_dom["VAR_CLASS"].value_counts().to_dict()
              if not all_dom.empty and "VAR_CLASS" in all_dom.columns else {})
        cov_rows.append({
            "DOMAIN":             dom,
            "TOTAL":              tot,
            "DIRECT":             d_n,
            "REVIEW":             r_n,
            "UNRESOLVED":         u_n,
            "AUTO_PCT":           round(d_n / tot * 100, 1) if tot else 0.0,
            "TOTAL_COVERAGE_PCT": round((d_n + r_n) / tot * 100, 1) if tot else 0.0,
            "N_DERIVED":          cc.get("derived", 0) + cc.get("sequence", 0),
            "N_IDENTIFIER":       cc.get("identifier", 0),
            "N_TIMING":           cc.get("timing", 0),
            "N_RESULT":           cc.get("result", 0),
            "N_CODELIST":         cc.get("codelist", 0),
            "N_GENERAL":          cc.get("general", 0) + cc.get("free_text", 0),
        })
    coverage = pd.DataFrame(cov_rows).sort_values("DOMAIN").reset_index(drop=True)

    log.info("[MAP] FINAL: direct=%d review=%d unresolved=%d cross-ds=%d unmapped-raw=%d",
             len(direct_df), len(review_df), len(unres_df),
             len(cross_df), len(unmapped))

    return {
        "direct":              direct_df,
        "review":              review_df,
        "unresolved":          unres_df,
        "unmapped_raw":        unmapped,
        "coverage":            coverage,
        "cross_dataset_match": cross_df,
    }


# ---------------------------------------------------------------------------
# Audit sheet
# ---------------------------------------------------------------------------

AUDIT_COLUMNS = [
    "AUDIT_TIMESTAMP", "DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL",
    "RAW_VARIABLES_ASSIGNED", "COMPOSITE_SCORE", "MATCH_TIER", "MATCH_PATH",
    "MASTER_FILE", "MASTER_SHA256", "MAPPER_VERSION", "RUN_HOST", "RUN_USER",
    "SYSTEM_VERSION", "CONFIG_AUTO_ACCEPT", "CONFIG_REVIEW", "AUTO_ACCEPTED",
]

SYSTEM_VERSION = "sdtm_mapping_system_v28"


def build_audit_sheet(direct_df, review_df, unres_df, master_path, master_df,
                      cfg, run_timestamp):
    """Build _Mapping_Audit sheet for 21 CFR Part 11 / GxP traceability."""
    import platform
    import getpass
    import hashlib

    cols = [c for c in ("DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE", "MASTER_CONFIDENCE")
            if c in master_df.columns]
    master_hash = (
        hashlib.sha256(master_df[cols].to_csv(index=False).encode()).hexdigest()[:16]
        if cols else "no_columns"
    )
    host = platform.node()
    try:
        user = getpass.getuser()
    except Exception:
        user = "unknown"

    auto_t = cfg.get("matching", {}).get("thresholds", {}).get("auto_accept", 0.82)
    rev_t  = cfg.get("matching", {}).get("thresholds", {}).get("review",      0.55)

    rows = []
    for df, is_auto in [(direct_df, True), (review_df, False), (unres_df, False)]:
        if df is None or df.empty:
            continue
        for _, row in df.iterrows():
            rows.append({
                "AUDIT_TIMESTAMP":        run_timestamp,
                "DOMAIN":                 row.get("DOMAIN", ""),
                "SDTM_VARIABLE":          row.get("SDTM_VARIABLE", ""),
                "SDTM_LABEL":             row.get("SDTM_LABEL", ""),
                "RAW_VARIABLES_ASSIGNED": row.get("RAW_VARIABLES_ASSIGNED", ""),
                "COMPOSITE_SCORE":        row.get("COMPOSITE_SCORE", 0.0),
                "MATCH_TIER":             row.get("MATCH_TIER", ""),
                "MATCH_PATH":             row.get("MATCH_PATH", ""),
                "MASTER_FILE":            getattr(master_path, "name", str(master_path) if master_path else ""),
                "MASTER_SHA256":          master_hash,
                "MAPPER_VERSION":         "rule_based_v28_" + master_hash[:8],
                "RUN_HOST":               host,
                "RUN_USER":               user,
                "SYSTEM_VERSION":         SYSTEM_VERSION,
                "CONFIG_AUTO_ACCEPT":     auto_t,
                "CONFIG_REVIEW":          rev_t,
                "AUTO_ACCEPTED":          is_auto,
            })

    return pd.DataFrame(rows, columns=AUDIT_COLUMNS)


# ---------------------------------------------------------------------------
# Output writer (preserves the v26 sheet structure)
# ---------------------------------------------------------------------------

def write_results(results: dict, out_path: Path, log,
                  master_path=None, master_df=None, cfg=None) -> None:
    """Write the multi-sheet results workbook."""
    from openpyxl.styles import PatternFill, Font, Alignment
    from openpyxl.utils import get_column_letter

    fill_h     = PatternFill("solid", fgColor="1F3864")
    font_h     = Font(bold=True, color="FFFFFF", size=10)
    fill_green = PatternFill("solid", fgColor="E2EFDA")
    fill_amber = PatternFill("solid", fgColor="FFF2CC")
    fill_red   = PatternFill("solid", fgColor="FFE0E0")
    fill_blue  = PatternFill("solid", fgColor="DDEEFF")

    run_ts = dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

    audit_df = pd.DataFrame()
    if master_df is not None and cfg is not None:
        try:
            audit_df = build_audit_sheet(
                results.get("direct"), results.get("review"), results.get("unresolved"),
                master_path, master_df, cfg, run_ts,
            )
        except Exception as exc:
            log.warning("  Could not build audit sheet: %s", exc)

    sheets = [
        ("direct",               results["direct"],                                fill_green),
        ("review",               results["review"],                                fill_amber),
        ("cross_dataset_match",  results.get("cross_dataset_match", pd.DataFrame()), fill_amber),
        ("unresolved",           results["unresolved"],                            fill_red),
        ("unmapped_raw",         results["unmapped_raw"],                          fill_blue),
        ("coverage",             results["coverage"],                              None),
        ("_Mapping_Audit",       audit_df,                                         None),
    ]

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        for sn, df, _ in sheets:
            data = df if (df is not None and not df.empty) else pd.DataFrame({"(empty)": []})
            data.to_excel(writer, sheet_name=sn, index=False)

        wb = writer.book
        for sn, df, row_fill in sheets:
            if sn not in wb.sheetnames:
                continue
            ws = wb[sn]
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = fill_h
                cell.font = font_h
                cell.alignment = Alignment(horizontal="center")

            if row_fill and sn in ("direct", "review") and df is not None and not df.empty:
                sci = next(
                    (i for i, c in enumerate(ws[1], 1) if str(c.value) == "COMPOSITE_SCORE"),
                    None,
                )
                if sci:
                    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
                        try:
                            v = float(row[sci - 1].value or 0)
                            f = fill_green if v >= 0.82 else fill_amber if v >= 0.55 else fill_red
                            for cell in row:
                                cell.fill = f
                        except (TypeError, ValueError):
                            pass

            for ci in range(1, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(ci)].width = min(
                    max(10, max(
                        (len(str(ws.cell(r, ci).value or ""))
                         for r in range(1, min(ws.max_row + 1, 200))),
                        default=8,
                    ) + 2),
                    60,
                )

    log.info("  Results -> %s", out_path)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run(master_path, raw_path, spec_path=None, out_path=None, config_path=None) -> dict:
    """Main callable API for the mapper."""
    cfg     = load_cfg(config_path or Path("config.yaml"))
    log_cfg = cfg.get("logging", {})
    log     = get_logger(log_cfg.get("log_file", ""), log_cfg.get("level", "INFO"))
    out_path = out_path or Path("mapping_results.xlsx")
    master_path = Path(master_path)

    log.info("[MAP] Loading master: %s", master_path.name)
    master_df = pd.read_excel(master_path, sheet_name="master_all", engine="openpyxl",
                              dtype=object)
    master_df["MASTER_CONFIDENCE"] = pd.to_numeric(
        master_df.get("MASTER_CONFIDENCE", 0), errors="coerce",
    ).fillna(0.0)

    log.info("[MAP] Loading raw catalog: %s", raw_path.name)
    raw_df = read_raw_catalog(raw_path, cfg, log)

    sdtm_vars_df = None
    if spec_path and Path(spec_path).exists():
        log.info("[MAP] Loading SDTM spec: %s", Path(spec_path).name)
        sdtm_vars_df = read_spec_variables(Path(spec_path), cfg, log)
        if sdtm_vars_df is not None and not sdtm_vars_df.empty:
            log.info("  Spec variables to map: %d", len(sdtm_vars_df))

    if sdtm_vars_df is None or sdtm_vars_df.empty:
        log.info("[MAP] No spec provided -- deriving variable list from master_top")
        sdtm_vars_df = pd.read_excel(master_path, sheet_name="master_top",
                                     engine="openpyxl", dtype=object)
        sdtm_vars_df = (
            sdtm_vars_df[["DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL", "MAPPING_ACTION"]]
            .drop_duplicates(["DOMAIN", "SDTM_VARIABLE"])
            .reset_index(drop=True)
        )
        sdtm_vars_df["CORE"] = ""

    results = run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log,
                          master_path=master_path)
    write_results(results, out_path, log, master_path=master_path,
                  master_df=master_df, cfg=cfg)
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Map new study raw vars to SDTM (v28 rule-based).")
    ap.add_argument("--master", required=True)
    ap.add_argument("--raw",    required=True)
    ap.add_argument("--spec",   default=None)
    ap.add_argument("--out",    default="mapping_results.xlsx")
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()
    run(
        master_path=Path(args.master),
        raw_path=Path(args.raw),
        spec_path=args.spec,
        out_path=Path(args.out),
        config_path=Path(args.config),
    )
