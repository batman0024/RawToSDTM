"""
Write Back to Spec page — Phase 3
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)

def _render_writeback_results(out_bytes, out_filename, val_report,
                              changelog_bytes, dry_run_mode):
    """Render the writeback output panel from cached bytes — used both
    after a fresh run and on session-restore (download click / tab change).

    v28 fix: previously `out_path` lived in a tmpdir cleaned up at end of
    the try-finally, so any rerender (download click, tab switch) lost
    the file and the panel disappeared.  Now we cache the bytes in
    session state so the panel persists across reruns.
    """
    if dry_run_mode:
        st.warning(
            "Dry-run complete. Check the log above for preview of changes. "
            "Uncheck Dry-run mode and re-run to apply."
        )
        return

    st.success(
        "✅ Spec updated. Input Variables cells are highlighted with bold text + fill color "
        "(GREEN bold = auto-accepted, AMBER bold = needs review). "
        "The spec structure is preserved exactly — no extra sheets added."
    )
    # Primary download — bytes in session, not the tmpdir path
    st.download_button(
        label="⬇ Download Updated Spec Excel",
        data=out_bytes,
        file_name=out_filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        key="wb_dl_spec",
    )

    # Secondary download: changelog as separate file
    if changelog_bytes:
        import datetime as _dt
        _cl_name = "writeback_changelog_" + _dt.datetime.now().strftime("%Y%m%d_%H%M") + ".xlsx"
        st.download_button(
            label="📋 Download Writeback Changelog (separate Excel)",
            data=changelog_bytes,
            file_name=_cl_name,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            help="Full audit trail of every cell updated: old value, new value, tier, score. "
                 "Not embedded in the spec — download separately for traceability.",
            key="wb_dl_changelog",
        )

    # ---- Validation Report ----
    if val_report:
        st.markdown("---")
        st.markdown("#### Post-Writeback Validation Report")
        from excel_validator import render_validation_report, export_validation_report_excel
        st.markdown(render_validation_report(val_report), unsafe_allow_html=True)

        # Download buttons — JSON and Excel formats
        import json as _json, io as _io
        val_json_bytes = _json.dumps(val_report, indent=2).encode()
        _stem = Path(out_filename).stem
        _dl_col1, _dl_col2 = st.columns(2)
        with _dl_col1:
            st.download_button(
                label="📋 Download Validation Report (JSON)",
                data=val_json_bytes,
                file_name=f"validation_report_{_stem}.json",
                mime="application/json",
                key="wb_dl_val_json",
            )
        with _dl_col2:
            try:
                _val_excel_buf = _io.BytesIO()
                export_validation_report_excel(val_report, _val_excel_buf)
                _val_excel_buf.seek(0)
                st.download_button(
                    label="📊 Download Validation Report (Excel)",
                    data=_val_excel_buf.read(),
                    file_name=f"validation_report_{_stem}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="wb_dl_val_xlsx",
                )
            except Exception as _ve2:
                st.caption(f"Excel export unavailable: {_ve2}")

        # Recommendations
        recs = val_report.get("recommendations", [])
        if recs:
            with st.expander(f"📌 {len(recs)} Recommendations"):
                for rec in recs:
                    icon = "🔧" if rec.get("auto_fix_possible") else "👤"
                    tgt  = rec.get("target", "")
                    tgt_str = ", ".join(tgt) if isinstance(tgt, list) else str(tgt)
                    st.markdown(
                        f"{icon} **{rec['action']}** — target: `{tgt_str}`"
                        + (f"  \n→ _{rec['auto_fix_action']}_"
                           if rec.get("auto_fix_action") else "")
                    )


def render():
    """Render this page."""
    cfg_path_input = st.session_state.get(
        "cfg_path_input",
        str(APP_DIR / "src" / "config.yaml")
    )
    st.markdown("## Phase 3 - Write Back to Spec")
    st.info(
        "Populate Input Variables, Mapping Action, and Origin columns in your "
        "SDTM spec Excel. All original formatting is preserved. "
        "Input Variables cells are highlighted with **bold text + fill color**: "
        "🟢 GREEN (bold green) = auto-accepted, 🟡 AMBER (bold amber) = needs review. "
        "Cross-dataset matches are written as AMBER (review tier). "
        "A change-log sheet is appended for full traceability."
    )

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">New Study Spec</div>', unsafe_allow_html=True)
        wb_spec_upload = st.file_uploader(
            "New study SDTM spec Excel (sponsor template with blank Input Variables)",
            type=["xlsx", "xlsm"],
            key="wb_spec_uploader",
        )
        if wb_spec_upload is not None:
            st.session_state["wb_spec_bytes"] = wb_spec_upload.getbuffer().tobytes()
            st.session_state["wb_spec_name"]  = wb_spec_upload.name
        elif st.session_state.get("wb_spec_bytes"):
            _cached_name = st.session_state.get("wb_spec_name", "spec.xlsx")
            st.success(f"✓ Spec cached: **{_cached_name}** — re-upload above to change")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Mapping Results</div>', unsafe_allow_html=True)
        results_source = st.radio(
            "Results source",
            ["Upload mapping_results.xlsx", "Use results from Phase 2"],
            label_visibility="collapsed",
            key="wb_results_source",   # v28: explicit key to persist choice
        )
        if results_source == "Upload mapping_results.xlsx":
            wb_results_upload = st.file_uploader(
                "mapping_results.xlsx from Phase 2",
                type=["xlsx"],
                key="wb_results_uploader",
            )
            if wb_results_upload is not None:
                st.session_state["wb_results_bytes"] = (
                    wb_results_upload.name,
                    wb_results_upload.getbuffer().tobytes(),
                )
            elif st.session_state.get("wb_results_bytes"):
                _rn = st.session_state["wb_results_bytes"][0]
                st.success(f"✓ Results cached: **{_rn}** — re-upload above to change")
        else:
            wb_results_upload = None
            if st.session_state.get("map_done"):
                st.success("Phase 2 mapping results are ready.")
            else:
                st.warning("No mapping results in this session. Run Phase 2 first.")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Write-Back Options</div>', unsafe_allow_html=True)
        populate_origin  = st.checkbox("Populate Origin column",              value=True,
                                       key="wb_pop_origin")
        populate_action  = st.checkbox("Populate Mapping Action (blank only)", value=True,
                                       key="wb_pop_action")
        highlight_review = st.checkbox(
            "Highlight Input Variables cells (green=direct, amber=review)",
            value=True,
            key="wb_highlight",
        )
        dry_run_mode = st.checkbox(
            "Dry-run mode (preview changes, do not write file)",
            value=False,
            key="wb_dry_run",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">What gets highlighted</div>', unsafe_allow_html=True)
        st.markdown(
            '<div style="font-size:12px;color:#8b949e;line-height:2.2">'
            '<span style="background:#C6EFCE;color:#276221;font-weight:bold;padding:2px 8px;border-radius:3px">GREEN + Bold</span>'
            '&nbsp; Input Variables cell = auto-accepted (score &ge; auto threshold)<br>'
            '<span style="background:#FFF2CC;color:#7d6608;font-weight:bold;padding:2px 8px;border-radius:3px">AMBER + Bold</span>'
            '&nbsp; Input Variables cell = needs programmer review<br>'
            '<span style="background:#FFC7CE;color:#9C0006;font-weight:bold;padding:2px 8px;border-radius:3px">RED + Bold</span>'
            '&nbsp; Input Variables cell = cross-dataset match (manual review required)<br>'
            '<small>Bold text + fill color ensures highlights are visible even over existing sponsor cell colors.<br>'
            'Only the Input Variables cell is highlighted &mdash; all other cells keep their original sponsor formatting.</small>'
            '</div>',
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    results_ready = (
        (results_source == "Upload mapping_results.xlsx"
         and (wb_results_upload is not None or bool(st.session_state.get("wb_results_bytes"))))
        or (results_source != "Upload mapping_results.xlsx" and st.session_state.get("map_done"))
    )
    spec_ready_wb = (wb_spec_upload is not None) or bool(st.session_state.get("wb_spec_bytes"))
    if not spec_ready_wb:
        st.caption("Upload a spec Excel to enable Write Back")
    run_wb = st.button(
        "Dry-Run Preview" if dry_run_mode else "Write Back to Spec",
        disabled=(not spec_ready_wb or not results_ready),
        key="wb_run_btn",
    )

    if run_wb:
        # Clear stale cache before a fresh run
        for _k in ["wb_out_bytes", "wb_out_filename", "wb_val_report",
                   "wb_changelog_bytes", "wb_done", "wb_dry_run_done"]:
            st.session_state.pop(_k, None)

        tmpdir = _make_tmpdir()
        try:
            if wb_spec_upload is not None:
                spec_path = save_upload(wb_spec_upload, tmpdir)
            elif st.session_state.get("wb_spec_bytes"):
                spec_path = Path(tmpdir) / "wb_spec.xlsx"
                spec_path.write_bytes(st.session_state["wb_spec_bytes"])
            else:
                st.error("No spec file available. Please upload one.")
                raise ValueError("No spec file")

            if wb_results_upload is not None:
                results_path = save_upload(wb_results_upload, tmpdir)
            elif st.session_state.get("wb_results_bytes"):
                _rname, _rbytes = st.session_state["wb_results_bytes"]
                results_path = Path(tmpdir) / _rname
                results_path.write_bytes(_rbytes)
            else:
                results_path = Path(tmpdir) / "mapping_results.xlsx"
                results_path.write_bytes(st.session_state["results_xlsx_bytes"])

            # Apply manual approval decisions from Review & Approve panel
            _approvals = st.session_state.get("mapping_approvals", {})
            _dropped   = {k for k, v in _approvals.items() if v == "drop"}
            if _dropped:
                try:
                    import openpyxl as _opx
                    _wb_res = _opx.load_workbook(str(results_path))
                    for _sn in ("direct", "review", "cross_dataset_match"):
                        if _sn not in _wb_res.sheetnames:
                            continue
                        _ws_res = _wb_res[_sn]
                        _hdr_res = {str(_c.value).upper(): _c.column for _c in _ws_res[1] if _c.value}
                        _dom_col = _hdr_res.get("DOMAIN")
                        _var_col = _hdr_res.get("SDTM_VARIABLE")
                        if not _dom_col or not _var_col:
                            continue
                        _rows_to_del = []
                        for _ri in range(2, _ws_res.max_row + 1):
                            _dom = str(_ws_res.cell(_ri, _dom_col).value or "").strip()
                            _var = str(_ws_res.cell(_ri, _var_col).value or "").strip()
                            if f"{_dom}.{_var}" in _dropped:
                                _rows_to_del.append(_ri)
                        for _ri in reversed(_rows_to_del):
                            _ws_res.delete_rows(_ri)
                    _wb_res.save(str(results_path))
                    if _dropped:
                        st.info(f"Applied review decisions: {len(_dropped)} mapping(s) dropped before write-back.")
                except Exception as _ae:
                    st.warning(f"Could not apply approval filter: {_ae}")

            out_filename = "spec_preview.xlsx" if dry_run_mode else "spec_mapped.xlsx"
            out_path = Path(tmpdir) / out_filename

            st.markdown("### Writing...")
            result_path, val_report, changelog_bytes, log_lines = run_writeback_with_progress(
                spec_path=spec_path,
                results_path=results_path,
                out_path=out_path,
                highlight_review=highlight_review,
                populate_origin=populate_origin,
                populate_action=populate_action,
                dry_run=dry_run_mode,
                config_path=cfg_path_input,
            )

            # v28: cache output bytes so download/tab-change rerenders work
            if not dry_run_mode and out_path.exists():
                _out_bytes = out_path.read_bytes()
                st.session_state["wb_out_bytes"]       = _out_bytes
                st.session_state["wb_out_filename"]    = out_filename
                st.session_state["wb_val_report"]      = val_report
                st.session_state["wb_changelog_bytes"] = changelog_bytes or b""
                st.session_state["wb_done"]            = True
                st.session_state["last_val_report"]    = val_report

                _render_writeback_results(
                    out_bytes        = _out_bytes,
                    out_filename     = out_filename,
                    val_report       = val_report,
                    changelog_bytes  = changelog_bytes or b"",
                    dry_run_mode     = False,
                )
            else:
                st.session_state["wb_dry_run_done"] = True
                _render_writeback_results(
                    out_bytes=b"", out_filename="",
                    val_report=val_report,
                    changelog_bytes=b"",
                    dry_run_mode=True,
                )

        except Exception as exc:
            st.error(f"Write-back failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)

    # ------------------------------------------------------------------
    # RESTORE PATH — write-back already ran this session; re-render output
    # panel on every rerun (download click, tab change).
    # ------------------------------------------------------------------
    elif st.session_state.get("wb_done") and st.session_state.get("wb_out_bytes"):
        _render_writeback_results(
            out_bytes        = st.session_state["wb_out_bytes"],
            out_filename     = st.session_state.get("wb_out_filename", "spec_mapped.xlsx"),
            val_report       = st.session_state.get("wb_val_report"),
            changelog_bytes  = st.session_state.get("wb_changelog_bytes", b""),
            dry_run_mode     = False,
        )


# ===========================================================================
# PAGE: CDM Variable Filter
# ===========================================================================

# ===========================================================================
# PAGE: Compare Specs - side-by-side diff of original vs mapped spec
# ===========================================================================

