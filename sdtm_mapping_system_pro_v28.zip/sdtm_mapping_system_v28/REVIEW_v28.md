# REVIEW v28 — five-bug production fix from v27

This release fixes five bugs reported from v27 production use.  Each item
below maps a user-reported symptom to its root cause and the surgical
fix applied.  No architectural changes — the v27 three-step mapping
pipeline is unchanged.

---

## Item 1 — Cache resets on download / tab change (Write Back)

### Symptom
After running Write Back to Spec, the user clicked the download button
or switched to another tab, and the Write Back panel went blank.  They
had to re-upload the spec and re-run.

### Root cause
The output spec lived in a `tmpdir` cleaned up at the end of the
try-finally block.  Streamlit re-renders the entire page on every event,
so as soon as the rerun arrived, the `out_path` reference was dead and
the panel rendered nothing.

### Fix — `ui/pages/writeback.py`

After a successful run, cache the output bytes, validation report, and
changelog into `st.session_state`:

```python
st.session_state["wb_out_bytes"]       = out_path.read_bytes()
st.session_state["wb_out_filename"]    = out_filename
st.session_state["wb_val_report"]      = val_report
st.session_state["wb_changelog_bytes"] = changelog_bytes or b""
st.session_state["wb_done"]            = True
```

Added a RESTORE PATH that re-renders the panel from cached bytes when
the user returns:

```python
elif st.session_state.get("wb_done") and st.session_state.get("wb_out_bytes"):
    _render_writeback_results(...)
```

Refactored the panel rendering into `_render_writeback_results()` —
single source of truth for both fresh-run and restore paths.

Added explicit `key=` to every widget (`wb_results_source`,
`wb_pop_origin`, `wb_pop_action`, `wb_highlight`, `wb_dry_run`,
`wb_run_btn`, `wb_dl_spec`, `wb_dl_changelog`, `wb_dl_val_json`,
`wb_dl_val_xlsx`) so their state survives reruns even if the parent
container changes.

The Reset → Writeback button in the sidebar now clears all `wb_*`
session keys, not just `wb_spec_bytes`.

---

## Item 2 — Direct mapping cross-domain bleed

### Symptom (from screenshots, v27 production)

| SDTM target | Original (correct) | v27 actual (wrong) |
|---|---|---|
| `DM.SEX` | `RAW.DM.SEX_STD` | `RAW.PKMERGE.SEX` |
| `DM.SCRNID` | `RAW.DM.SCRNID` | `RAW.AE.SCRNID` |
| `DM.SITEID` | `RAW.DM.SITEID` | weird mappings |

### Root cause

Two compounding issues:

**(a) `pair_score()` undervalued historical signal**

For `DM.SEX_STD → DM.SEX`, the slug match is False (`SEXSTD ≠ SEX`),
fuzzy is moderate, master_conf is 0.95, label_sim is high, dom_match=1
(both DM).  Composite ≈ 0.467, which is **below the review threshold of
0.55**.  So the pair was not even tier-eligible, despite being the
master's exact historical mapping.

**(b) Step 3 cross-dataset name match was too permissive**

For unresolved `DM.SEX`, Step 3 looked up the slug `SEX` across all raw
datasets, found `PKMERGE.SEX`, observed that `PK` ≠ `DM`, and flagged
the cross-dataset match for "manual review".  Write-back treated
cross-dataset rows as review tier and wrote them straight into the
spec.

### Fix — `src/mapper.py`

**(a) Historical-match boost in `pair_score()`**

New helper:
```python
def _is_historical_match(raw_ds, raw_var, raw_full_tok_slug,
                         group_tokens_str) -> bool:
    """True iff RAW.<ds>.<var> appears verbatim in master.GROUP_TOKENS"""
```

`pair_score()` accepts `historical_match: bool = False`.  When True:
```python
hist_boost = max(0.30, 0.45 * mc)   # mc = master_conf
score = base_score + hist_boost     # capped at 1.0
```

This lifts `DM.SEX_STD → DM.SEX` from 0.47 to 0.89 (auto-accept tier).
A new `historical` field appears in the XAI score breakdown so the
boost is auditable.

Step 1 computes a `raw_full_tok_slug` (`<DS>.<VAR>` slug) per raw
variable and passes the result of `_is_historical_match()` into every
`pair_score()` call.

**(b) Step 3 cross-dataset is now restricted**

```python
is_protected_name = var_up in {"SEX", "AGE", "RACE", "ETHNIC",
                               "COUNTRY", "BRTHDTC", "DTHDTC", "DTHFL",
                               "ARMCD", "ARM", "ACTARMCD", "ACTARM",
                               "SITEID", "SUBJID", "USUBJID", "STUDYID",
                               "DOMAIN", "VISITNUM", "VISIT", "VISITDY",
                               "EPOCH", "ELEMENT", "ETCD"} or ...

for (rds, rv, rk) in candidates:
    if _slug(rds)[:2] == _slug(domain)[:2]:    continue   # same-domain
    if is_protected_name:                       continue   # never cross-map
    ok, _why = cross_domain_compatible(rds, domain, var)
    if not ok:                                  continue
    manual_pick = (rds, rv, rk); break
```

`PKMERGE.SEX → DM.SEX` is now blocked because `SEX` is protected.
`AE.SCRNID → DM.SCRNID` is similarly blocked because `SCRNID` is among
the identifier names handled exclusively in same-domain context.

### Verification

`/home/claude/test_v28.py`:
```
PASS: DM.SEX -> DM.SEX_STD (no PKMERGE bleed)
PASS: DM.SCRNID -> DM.SCRNID (no AE bleed)
```

---

## Item 3 — `RFPENDTC` (and other Derived rules) lost their raw inputs

### Symptom

For `DM.RFPENDTC`, the original spec had four input variables
(`AESTDAT_RAW`, `AEENDAT_RAW`, `CONSDAT_RAW`, `AEHSTDAT_RAW`).  After
v27 ran, the Input Variables column was empty.  The same happened for
`DM.RFSTDTC` (master had `PK_EX.EXSTDAT_RAW` historically) and for any
other variable whose rule has `needs_raw=False`.

### Root cause

`sdtm_rules.py` defines:
```python
("DM", "RFPENDTC"): {
    "origin": "Derived", "action": "DERIVE", "needs_raw": False,
    "algorithm": "Date of end of subject participation",
    "confidence": 0.90,
},
```

When the rule fires in Step 2b, the row is emitted with
`raw_assigned=""`, discarding any historical raw sources the master
recorded for this target across past studies.

Even when Step 1 succeeded for some inputs (e.g. AEENDAT_RAW found
RFPENDTC in `idx[by_raw]`), Step 1's primary loop routes each raw_var
to its single **best** target.  `AESTDAT_RAW` had `AESTDTC` (same
domain) as a stronger competitor than RFPENDTC (cross-domain), so it
landed on AESTDTC and never accumulated to RFPENDTC.

### Fix — `src/mapper.py`

New helper:
```python
def _harvest_master_raw_for_target(domain, var, idx, raw_df, cap=12):
    """Walks idx[by_sdtm][(domain,var)] groups, collects every historical
    RAW.* token, resolves each against the current study's raw catalog
    (preferring same-dataset match), returns up to `cap` tokens in the
    spelling of the current raw catalog."""
```

**Step 2a (master lookup branch)** — when Step 1 succeeded for an SDTM
target that is Derived (rule `needs_raw=False` + origin "Derived", or
var_class derived/flag/sequence, or matches `--DY/BLFL/LOBXFL/CHG/PCHG/
SHIFT/NRIND`), augment Step 1's accumulated tokens with the full master
harvest:

```python
if _is_derived_target:
    _harvested = _harvest_master_raw_for_target(domain, var, idx, raw_df)
    for _h in _harvested:
        if _h.upper() not in {t.upper() for t in raw_tokens}:
            raw_tokens.append(_h)
```

**Step 2b (rule table branch)** — when the rule has `needs_raw=True`
and Step 1 found nothing, try the master harvest before falling back
to "unresolved":
```python
if rule.get("needs_raw"):
    if harvested_tokens:
        # Promote to review tier with harvested tokens
        row = _make_row(..., raw_assigned=", ".join(harvested_tokens),
                        tier="review", match_path="rule_with_master_harvest", ...)
        review_rows.append(row); continue
    # else fall through to unresolved (existing behaviour)
```

When the rule has `needs_raw=False`, attach harvested tokens to the
direct row instead of leaving the cell blank:
```python
row = _make_row(..., raw_assigned=", ".join(harvested_tokens),
                tier="direct",
                match_path="rule_with_master_harvest" if harvested_tokens
                           else "rule_table", ...)
```

**Rule overrides**: when a rule is present in Step 2a, its `origin` and
`action` now take precedence over `infer_origin()` defaults, fixing
edge cases where the heuristic was writing "Collected" for a Derived
RF*DTC.

### Verification

```
PASS: DM.RFPENDTC harvested -> RAW.AE.AEENDAT_RAW, RAW.AE.AEHSTDAT_RAW,
                               RAW.CONSENTS.CONSDAT_RAW, RAW.AE.AESTDAT_RAW
PASS: DM.RFSTDTC harvested -> RAW.PK_EX.EXSTDAT_RAW
PASS: AE.AESTDTC -> RAW.AE.AESTDAT_RAW, RAW.AE.AESTTIM
```

All four historical sources reappear on RFPENDTC, even though
`AESTDAT_RAW`'s primary target is correctly `AE.AESTDTC`.

---

## Item 4 — SDTMIG version not fully shown

### Symptom

The user wanted to see the entire `Mapping Specification IG` cell text
from the spec's Study tab (e.g. `SDTMIGV3.3 Mapping Specifications
IG-CORE-define21-V1.2.pdf`), not just the parsed version number `3.3`.
v27 displayed the version inside a small `st.info` box that was easy to
miss.

### Fix — `ui/pages/map_study.py`

Replaced the `st.info` block with a prominent dark-blue card:

```html
<div style="background:#0d1f3a;border:1px solid #1f6feb;
            border-left:4px solid #58a6ff;...">
  <div style="font-size:11px;color:#8b949e;font-weight:600;...">
    📄 Mapping Specification IG (from Study tab)
    <span style="background:#1f6feb;color:#fff;...">v3.3</span>
  </div>
  <div style="font-size:13px;color:#e6edf3;font-family:monospace;
              word-break:break-all">
    SDTMIGV3.3 Mapping Specifications IG-CORE-define21-V1.2.pdf
  </div>
</div>
```

The full IG string is now the headline, the version is a small badge.
HTML-escaped via custom escaping so arbitrary punctuation in the IG
string is safe.  If the version cannot be parsed, the badge turns red
and reads "version not parseable" (replaces the previous optimistic
"version extracted" message).

---

## Item 5 — Review tab values not visible

### Symptom

For rule-table matches (e.g. AE study days `--DY`, SUPPQUAL structural
variables, RFENDTC, EPOCH), the `RAW DATASET` and `INPUT VARS` columns
appeared empty.  Combined with poor column-width balance, the panel
looked broken.

### Root cause

`raw_assigned=""` for rule-table matches is correct (those variables
truly have no raw source).  But the v27 layout had nothing else to
show in those cells, leaving them blank.  The user couldn't tell the
difference between "blank because Derived per rule" and "blank because
something went wrong".

### Fix — `ui/helpers.py`, `_render_review_panel()`

**Rebalanced columns** (total normalised to 12 units):

| | TIER | SDTM Target | Path | Source / Algorithm | Action | Score | Decide |
|---|---|---|---|---|---|---|---|
| v27 | 0.6 | 1.2 | 1.8 | 2.8 | 1.8 | 0.7 | 0.6 |
| v28 | 0.4 | 1.6 | 1.0 | **4.5** | 1.0 | 0.7 | 0.8 |

**Tier indicator**: replaced `🟢 / 🟡` emoji with a solid coloured dot
(green = AUTO, amber = REVIEW).  More compact, visually consistent,
HTML-tooltip-able.

**New Path column**: a coloured pill badge for `MATCH_PATH`:

| Path | Badge | Color |
|---|---|---|
| `rule_with_master_harvest` | `master+rule` | purple |
| `rule_table`, `rule_needs_raw` | `rule` | purple |
| `master_lookup` | `master` | green |
| `fuzzy_*` | `fuzzy` | amber |
| `cross_dataset_*` | `cross-ds` | red |
| `no_master_group` | `none` | grey |

The user now sees WHY each row resolved.

**Source / Algorithm column** — biggest change.  When raw tokens exist:

```
RAW.AE.AESTDAT_RAW, RAW.AE.AEENDAT_RAW, RAW.CONSENTS.CONSDAT_RAW +N more
```

Comma-separated, first 6 tokens visible, `+N more` link if there are
extras.  Word-wraps so long token lists are readable.

When `raw_assigned=""` (rule-table match):

```
⚙ Derived
Date of end of subject participation
```

Origin appears in purple bold, algorithm note appears underneath in
italic grey.  Empty cells are gone — every row tells the user what's
happening.

**SDTM target**: domain.var bold on top, label underneath truncated to
80 chars.  Replaces the previous label-in-its-own-column layout, which
left domain/var cramped.

---

## Files changed

```
src/mapper.py                  +320 lines  (helpers, harvest, score boost,
                                            cross-ds tightening, rule overrides)
ui/helpers.py                  ~190 lines  rewritten review panel
ui/pages/writeback.py          ~180 lines  cache + RESTORE PATH refactor
ui/pages/map_study.py          +60 lines   prominent IG card + widget keys
app.py                         ~10 lines   v28 version bumps + reset list
CHANGELOG.md                    +130 lines v28 entry
REVIEW_v28.md                   new file   this document
```

## Tests

```
$ python -m unittest tests.test_pipeline tests.test_regressions
Ran 77 tests in 8.0s

OK
```

```
$ python /home/claude/test_v28.py
PASS: DM.SEX -> DM.SEX_STD (no PKMERGE bleed)
PASS: DM.SCRNID -> DM.SCRNID (no AE bleed)
PASS: DM.RFPENDTC harvested -> RAW.AE.AEENDAT_RAW, RAW.AE.AEHSTDAT_RAW,
                               RAW.CONSENTS.CONSDAT_RAW, RAW.AE.AESTDAT_RAW
PASS: DM.RFSTDTC harvested -> RAW.PK_EX.EXSTDAT_RAW
PASS: AE.AESTDTC -> RAW.AE.AESTDAT_RAW, RAW.AE.AESTTIM
PASS: DM.AGE protected from cross-domain mapping
All v28 assertions passed.
```
