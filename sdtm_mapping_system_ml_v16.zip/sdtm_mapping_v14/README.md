# SDTM Master Mapping System

A modular Python pipeline that learns from completed SDTM specification files
and automatically maps new study raw variables to SDTM, with confidence-scored
outputs, group-aware multi-token matching, cross-dataset variable detection,
and direct spec write-back.

**Version 4.0** — see `CHANGELOG.md` for full history.

---

## What It Does

| Phase | Module | Input | Output |
|---|---|---|---|
| 1 Build Master | `master_builder.py` | Completed study specs + sponsor standard | `master_mapping.xlsx` |
| 2 Map New Study | `mapper.py` | Master + new raw catalog | `mapping_results.xlsx` |
| 2b Cross-Dataset Match | `mapper.py` (Phase 3) | Unresolved vars + raw catalog | `cross_dataset_match` sheet |
| 3 Write Back | `spec_writeback.py` | Spec + mapping results | Updated spec Excel |

The more completed studies you feed into Phase 1, the higher the auto-accept
rate in Phase 2. This is the core learning loop.

### New in v4.0

**Variable-Level Cross-Dataset Matching** — After the standard two-phase match,
a third pass scans unresolved SDTM variables against the full raw catalog by
variable *name* similarity only (≥ 0.75), ignoring dataset names. This catches
non-standard dataset naming (e.g. raw dataset `QSXXX` containing variables
`QSTEST`, `QSORRES` that match `QS` domain targets). These matches land in a
dedicated `🟣 Cross-Dataset Match` tab and require manual programmer sign-off.

**Raw Dataset → SDTM Domain Table** — A summary table shows every raw dataset,
the SDTM domains it feeds, variable counts, and auto-detected prefix mismatches
(e.g. `AEXX` feeding `CM` domain gets flagged ⚠ for review).

**Fixed Highlight Visibility** — Input Variables cells now use bold colored
text *plus* fill color (`C6EFCE` green / `FFF2CC` amber / `FFC7CE` red),
ensuring highlights remain visible over any existing sponsor cell formatting.

**Change-Log Note Column** — The `_Writeback_` change-log sheet now includes
a `Note` column explaining cross-dataset match rationale for each updated cell.

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Launch the Streamlit UI

```bash
streamlit run app.py
```

Open `http://localhost:8501` in your browser.

### 3. Or use the CLI

```bash
# Build master from completed studies
python src/pipeline.py build \
    --specs   sample_data/study_a_with_trial.xlsx \
               sample_data/study_b_spec.xlsx \
               sample_data/study_c_spec.xlsx \
    --sponsor sample_data/sponsor_std_v3.xlsx \
    --out     master_mapping.xlsx

# Map new study
python src/pipeline.py map \
    --master master_mapping.xlsx \
    --raw    sample_data/new_study_raw.xlsx \
    --spec   sample_data/new_study_spec.xlsx \
    --out    mapping_results.xlsx

# Write back into spec
python src/pipeline.py writeback \
    --spec    sample_data/new_study_spec.xlsx \
    --results mapping_results.xlsx \
    --out     spec_mapped.xlsx

# Full pipeline in one command
python src/pipeline.py full \
    --specs   sample_data/study_a_with_trial.xlsx \
               sample_data/study_b_spec.xlsx \
    --sponsor sample_data/sponsor_std_v3.xlsx \
    --raw     sample_data/new_study_raw.xlsx \
    --spec    sample_data/new_study_spec.xlsx
```

---

## Project Structure

```
sdtm_mapping/
|-- app.py                   Streamlit dark-mode UI (5 pages)
|-- requirements.txt         Python dependencies
|-- README.md                This file
|
|-- src/
|   |-- config.yaml          All thresholds, weights, column aliases
|   |-- sdtm_knowledge.py    SDTM structural knowledge base
|   |-- logger.py            Centralised logging (console + file)
|   |-- master_builder.py    Phase 1: build master from completed specs
|   |-- mapper.py            Phase 2: map new study raw catalog
|   |-- spec_writeback.py    Phase 3: write results into spec Excel
|   \-- pipeline.py          CLI orchestrator (build/map/writeback/full)
|
|-- sample_data/
|   |-- study_a_with_trial.xlsx   Completed study spec (with TA trial domain)
|   |-- study_b_spec.xlsx         Completed study spec
|   |-- study_c_spec.xlsx         Completed study spec (VS, EX domains)
|   |-- sponsor_std_v3.xlsx       Sponsor standard spec (priority boost)
|   |-- new_study_raw.xlsx        New study PROC CONTENTS output
|   \-- new_study_spec.xlsx       New study SDTM spec (blank Input Variables)
|
|-- tests/
|   \-- test_pipeline.py     Integration tests covering all 6 scenarios
|
\-- docs/
    \-- docs.html            Full system documentation (open in browser)
```

---

## Key Design Decisions

### TOC-First Filtering

Every spec workbook is processed via a strict two-layer filter:

1. **TOC layer**: Only domains where `Active = Y/YES/TRUE/1/X` are processed.
   Trial design domains (`TA TE TI TV TS TD`) are removed even if `Active = Y`.
2. **Sheet-name layer**: Trial domains are checked again at sheet level.

If no TOC sheet is found, all non-excluded sheets are processed with a warning.

### Group-Aware Multi-Token Storage

The cell `"RAW.AE.AESTDAT, RAW.AE.AESTTIM"` is stored as a group, not split
into unrelated rows. Four columns link the tokens:

- `GROUP_SIG` -- sorted-set hash, same group from different studies shares this
- `GROUP_POSITION` -- original order (date = 1, time = 2)
- `GROUP_COUNT` -- number of tokens in this group
- `GROUP_TOKENS` -- ordered pipe-separated list for mapper retrieval

### Partial-Group Penalty

If a group has 2 tokens and only 1 is found in the new raw catalog, the score
is penalised: `score *= penalty + (1 - penalty) * fraction_found`
Default penalty = 0.70, configurable in `config.yaml`.

### 4-Signal Composite Scorer

```
score = (0.35 * name_exact
       + 0.20 * name_fuzzy
       + 0.25 * label_tfidf
       + 0.20 * master_freq) * class_modifier
```

All weights configurable in `config.yaml`.

### Sponsor Priority

Sponsor standard specs receive a 3x study-count equivalent boost. With
`conflict_strategy: sponsor_priority`, sponsor mappings always appear first.

### Origin Priority Chain

`CRF (1) > Derived (2) > Protocol (3) > eDT (4) > Assigned (5)`

An existing Origin value is only overwritten by a higher-priority one.

---

## Configuration

All behaviour is controlled via `src/config.yaml`. Key settings:

```yaml
matching:
  thresholds:
    auto_accept: 0.82    # score >= this -> direct (written to spec)
    review:      0.55    # score >= this -> flagged for human review

  weights:
    name_exact:   0.35
    name_fuzzy:   0.20
    label_tfidf:  0.25
    master_freq:  0.20

master_build:
  conflict_strategy: "sponsor_priority"   # or most_frequent
  sponsor_boost_factor: 3.0
  recency_decay_years: 3
```

No code changes needed to tune thresholds. Edit `config.yaml` or use the
UI sliders in the Streamlit app.

---

## Input File Requirements

### Completed Study Spec (Phase 1)

- Excel workbook (`.xlsx` or `.xlsm`)
- TOC sheet with `Dataset` and `Active` columns
- One sheet per SDTM domain (e.g. DM, AE, LB)
- Required columns: `Variable`, `Input Variables`, `Mapping Action`
- `Input Variables` format: `RAW.DATASET.VARIABLE` comma-separated

### Raw Variable Catalog (Phase 2)

- Excel or CSV
- SAS PROC CONTENTS output: `MEMNAME`, `NAME`, `LABEL`, `FORMAT`, `TYPE`
- Any column layout works via aliases in `config.yaml`

---

## Output Files

### `master_mapping.xlsx`

| Sheet | Contents |
|---|---|
| `master_top` | Best group per SDTM variable; `INPUT_VARIABLES` column reassembled |
| `master_all` | All groups; one row per token; confidence color-coded |
| `domain_summary` | Per-domain stats |
| `extraction_log` | Raw extraction rows (used by append/incremental mode) |

### `mapping_results.xlsx`

| Sheet | Contents | Highlight in Spec |
|---|---|---|
| `direct` | Auto-accepted (score ≥ auto threshold) | 🟢 GREEN bold text + green fill |
| `review` | Needs human review (score ≥ review threshold) | 🟡 AMBER bold text + amber fill |
| `cross_dataset_match` | Variable name matched across differently-named dataset (manual review) | 🔴 RED bold text + red fill |
| `unresolved` | No match found; not written to spec | — |
| `unmapped_raw` | Raw variables not matched to any SDTM variable | — |
| `coverage` | Per-domain stats with var-class breakdown | — |

The `cross_dataset_match` sheet contains a `MATCH_NOTE` column explaining the
dataset mismatch for each row. These rows require explicit programmer sign-off
before the mapping is considered valid. When loaded by Write Back (Phase 3),
they are treated as review-tier and written with amber+bold highlight.

---

## Incremental Updates

Add a new completed study without rebuilding from scratch:

```bash
python src/pipeline.py build \
    --specs    new_completed_study.xlsx \
    --existing master_mapping.xlsx \
    --out      master_mapping.xlsx
```

---

## Dependencies

```
pandas >= 2.0
openpyxl >= 3.1
scikit-learn >= 1.3
pyyaml >= 6.0
streamlit >= 1.32
matplotlib >= 3.8
```

---

## Documentation

Open `docs/docs.html` in any browser for full system documentation including
architecture diagrams, scoring formula, CLI reference, and file format specs.
