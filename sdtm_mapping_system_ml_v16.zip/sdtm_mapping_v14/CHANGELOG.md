# Changelog

All notable changes to the SDTM Master Mapping System.

---

## v4.0 (current)

### New Features

- **Phase 3: Variable-Level Cross-Dataset Match** (`mapper.py`)
  After the standard two-phase raw→SDTM matching, a new Phase 3 scans all
  remaining unresolved SDTM variables against the entire raw catalog using
  variable *name* similarity (≥ 0.75), irrespective of dataset name. This
  catches cases like `QSXXX` raw dataset containing variables that match
  `QS` domain targets where the dataset naming convention is non-standard.
  Results appear in a new `cross_dataset_match` sheet in `mapping_results.xlsx`.

- **Cross-Dataset Manual Review Tab** (`app.py`)
  A dedicated `🟣 Cross-Dataset Match` tab in Phase 2 results shows all
  variable-level matches that crossed dataset-name boundaries, with a
  `MATCH_NOTE` column explaining the dataset mismatch. Each entry requires
  explicit programmer sign-off before it is promoted to spec.

- **Raw Dataset → SDTM Domain Coverage Table** (`app.py`)
  A new summary table in Phase 2 shows every raw dataset and the SDTM
  domains it maps to, including variable counts and tier breakdown.
  Dataset-name/domain-name prefix mismatches are auto-detected and flagged
  with ⚠ warnings so the programmer can verify mapping intent (e.g. QSXXX → QS).

- **MATCH_NOTE column in cross-dataset results**
  Each cross-dataset row carries a human-readable note explaining which
  raw dataset was matched, the similarity score, and that manual review is
  required. This note is also propagated to the spec write-back change-log.

### Fixes & Improvements

- **Highlight visibility fixed** (`spec_writeback.py`)
  Input Variables cells now use `PatternFill(patternType="solid", ...)` with
  brighter fill colors (`#C6EFCE` green, `#FFF2CC` amber, `#FFC7CE` red)
  *plus* bold colored font (`Font(bold=True, color=...)`). The double
  signal (fill + bold text) ensures highlights are visible even when the
  original spec has competing cell theme colors or conditional formats.

- **Three-color highlight system**
  GREEN + bold = auto-accepted (direct tier).
  AMBER + bold = needs programmer review (review tier + cross-dataset).
  RED + bold   = unresolved cross-dataset match (written only when explicitly
  promoted from the Cross-Dataset Match tab).

- **Change-log Note column** (`spec_writeback.py`)
  The `_Writeback_YYYYMMDD_HHMM` change-log sheet now includes a `Note`
  column that carries the `MATCH_NOTE` for cross-dataset rows, making it
  easy to filter the change-log by match type during QC.

- **Cross-dataset results loaded in write-back** (`spec_writeback.py`)
  `load_results()` now reads the `cross_dataset_match` sheet from
  `mapping_results.xlsx` and treats those rows as review-tier, so they are
  automatically included in write-back with amber highlighting.

- **Dataset coverage issue detection** (`app.py`)
  The Raw Dataset → SDTM Domain table auto-flags datasets whose name prefix
  does not match any of the SDTM domains they feed, helping catch
  miscategorised datasets early before spec write-back.

---

## v3.0

### New Features

- **Streamlit dark-mode UI** (`app.py`) with five pages:
  Build Master, Map New Study, Write Back to Spec, View Master, Help
- **Real-time progress bars** -- per-variable granularity on the mapper phase
- **Group-aware master index** -- `build_index()` stores `GROUP_TOKENS` so the
  mapper retrieves all tokens of the best group atomically
- **Partial-group scoring** -- `score_group_against_raw()` penalises groups
  where only a fraction of tokens are found in the new raw catalog
- **Dry-run mode** in `spec_writeback.py` -- preview all changes without
  writing any file; shows old/new values per cell in the log
- **Coverage var-class breakdown** -- coverage report now includes N_DERIVED,
  N_IDENTIFIER, N_TIMING, N_RESULT, N_CODELIST, N_GENERAL per domain
- **Centralised logging** via `logger.py` -- all modules write to a single
  Python logger; optional log file configured in `config.yaml`
- **Integration test suite** -- 20 tests covering all modules and end-to-end

### Improvements

- `read_toc_active_domains()` recognises 10 TOC sheet name variants and
  14 Active column name variants; handles status values like "In Scope",
  "Planned", "Produce" etc.
- Two-layer trial domain exclusion: TOC layer + sheet-name layer
- NaN guard in `agg_group()` for extraction_log reload in append mode
- Origin priority: CRF(1) > Derived(2) > Protocol(3) > eDT(4) > Assigned(5)
  -- an existing Origin only overwritten by higher-priority value
- All source files confirmed 100% clean ASCII (zero non-ASCII bytes)

---

## v2.0

### New Features

- **Group-aware storage** in master mapping -- multi-token Input Variable
  cells stored with GROUP_SIG, GROUP_POSITION, GROUP_COUNT, GROUP_TOKENS
- **TOC-first filtering** -- `_read_toc_active_domains()` function with
  two-layer trial domain exclusion
- **Sponsor versioning** -- sponsor standard specs take priority over study
  mappings via `IS_TOP_GROUP` flag and `IS_SPONSOR_STD` sorting
- **Append/incremental mode** -- add new studies without full rebuild

### Improvements

- Composite scorer upgraded to 4 signals (name exact + fuzzy + TF-IDF + freq)
- TF-IDF label index with `expand_sdtm_label()` abbreviation expansion
- `normalize_action()` maps 35 free-text action variants to 9 canonical tokens
- Per-domain threshold overrides in `config.yaml`
- Variable class modifiers applied to composite score
- `spec_writeback.py`: change-log sheet, SDTM.* token preservation

---

## v1.0

- Initial implementation: `rawtosdtm_18.py`, `spec_stream_02.py`, `eval_06.py`
- Single SequenceMatcher threshold (0.92)
- Flat master_mapping structure (one row per raw token, no group concept)
- No TOC filtering; no logging; no progress feedback


### New Features

- **Streamlit dark-mode UI** (`app.py`) with five pages:
  Build Master, Map New Study, Write Back to Spec, View Master, Help
- **Real-time progress bars** -- per-variable granularity on the mapper phase
- **Group-aware master index** -- `build_index()` stores `GROUP_TOKENS` so the
  mapper retrieves all tokens of the best group atomically
- **Partial-group scoring** -- `score_group_against_raw()` penalises groups
  where only a fraction of tokens are found in the new raw catalog
- **Dry-run mode** in `spec_writeback.py` -- preview all changes without
  writing any file; shows old/new values per cell in the log
- **Coverage var-class breakdown** -- coverage report now includes N_DERIVED,
  N_IDENTIFIER, N_TIMING, N_RESULT, N_CODELIST, N_GENERAL per domain
- **Centralised logging** via `logger.py` -- all modules write to a single
  Python logger; optional log file configured in `config.yaml`
- **Integration test suite** -- 20 tests covering all modules and end-to-end

### Improvements

- `read_toc_active_domains()` recognises 10 TOC sheet name variants and
  14 Active column name variants; handles status values like "In Scope",
  "Planned", "Produce" etc.
- Two-layer trial domain exclusion: TOC layer + sheet-name layer
- NaN guard in `agg_group()` for extraction_log reload in append mode
- Origin priority: CRF(1) > Derived(2) > Protocol(3) > eDT(4) > Assigned(5)
  -- an existing Origin only overwritten by higher-priority value
- All source files confirmed 100% clean ASCII (zero non-ASCII bytes)

---

## v2.0

### New Features

- **Group-aware storage** in master mapping -- multi-token Input Variable
  cells stored with GROUP_SIG, GROUP_POSITION, GROUP_COUNT, GROUP_TOKENS
- **TOC-first filtering** -- `_read_toc_active_domains()` function with
  two-layer trial domain exclusion
- **Sponsor versioning** -- sponsor standard specs take priority over study
  mappings via `IS_TOP_GROUP` flag and `IS_SPONSOR_STD` sorting
- **Append/incremental mode** -- add new studies without full rebuild

### Improvements

- Composite scorer upgraded to 4 signals (name exact + fuzzy + TF-IDF + freq)
- TF-IDF label index with `expand_sdtm_label()` abbreviation expansion
- `normalize_action()` maps 35 free-text action variants to 9 canonical tokens
- Per-domain threshold overrides in `config.yaml`
- Variable class modifiers applied to composite score
- `spec_writeback.py`: change-log sheet, SDTM.* token preservation

---

## v1.0

- Initial implementation: `rawtosdtm_18.py`, `spec_stream_02.py`, `eval_06.py`
- Single SequenceMatcher threshold (0.92)
- Flat master_mapping structure (one row per raw token, no group concept)
- No TOC filtering; no logging; no progress feedback
