"""
ml_scorer.py
============
ML-enhanced scoring engine for raw -> SDTM variable matching.

Architecture:
  1. Feature extraction:  18 signals per (raw_var, sdtm_var) candidate pair
  2. GradientBoosting classifier trained on master_mapping positive pairs
     (generates synthetic negatives from cross-domain and random pairs)
  3. At inference time:
     - Phase A (master-guided): score only pairs the master has seen
     - Phase B (label-fallback): for unknowns, score same-domain candidates
       using feature vector, classifier predicts probability of correct match

Signals used:
  Name signals (4):
    - jaro_winkler:   better than SequenceMatcher for short clinical names
    - char_3gram:     shared 3-character n-grams / total n-grams (overlap)
    - prefix_match:   how many leading chars are identical (AESTART vs AESTDTC)
    - token_set:      set intersection of uppercase tokens
  Label signals (2):
    - label_tfidf:    TF-IDF cosine (from LabelIndex, already built)
    - label_token_overlap: shared words between raw label and sdtm label
  Format/type signals (3):
    - format_is_date: raw FORMAT contains DATE/TIME -> implies timing variable
    - type_num:       raw TYPE is Num -> matches derived/result vars
    - sdtm_is_timing: SDTM variable ends in DT/DTC/TM/DTM
  Domain signals (2):
    - domain_match:   raw dataset prefix matches SDTM domain prefix exactly
    - domain_fuzzy:   similarity between raw dataset name and SDTM domain
  Master signals (4):
    - master_conf:    MASTER_CONFIDENCE from master_mapping
    - is_sponsor_std: was this pair seen in sponsor standard?
    - master_freq:    N_STUDIES this pair appeared in
    - in_master:      1 if this exact (raw_slug, sdtm_var) pair is in master
  SDTM structure signals (3):
    - var_class_id:   1 if SDTM var is identifier class (USUBJID etc.)
    - var_class_deriv:1 if SDTM var is always derived (SEQ, CHG etc.)
    - var_class_time: 1 if SDTM var is timing class

Trained on:
  Positive pairs: every (RAW_VARIABLE, SDTM_VARIABLE) row in master_mapping
  Negative pairs: synthetic cross-domain pairs + random same-domain wrong pairs
  Ratio:          1:4 positive:negative

Outputs a probability [0..1] that the raw variable belongs to the SDTM variable.
This replaces the hand-tuned weighted sum with a model that learns weights from data.
"""

from __future__ import annotations

import re
import math
import hashlib
import warnings
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yaml

warnings.filterwarnings("ignore")

from sdtm_knowledge import classify_variable, ALWAYS_DERIVED, PROTOCOL_VARS


# ---------------------------------------------------------------------------
# Jaro-Winkler (pure stdlib, no external deps)
# ---------------------------------------------------------------------------

def _jaro(s1: str, s2: str) -> float:
    if s1 == s2:
        return 1.0
    l1, l2 = len(s1), len(s2)
    if l1 == 0 or l2 == 0:
        return 0.0
    match_dist = max(l1, l2) // 2 - 1
    if match_dist < 0:
        match_dist = 0
    s1m = [False] * l1
    s2m = [False] * l2
    matches = 0
    for i in range(l1):
        lo = max(0, i - match_dist)
        hi = min(i + match_dist + 1, l2)
        for j in range(lo, hi):
            if s2m[j] or s1[i] != s2[j]:
                continue
            s1m[i] = s2m[j] = True
            matches += 1
            break
    if not matches:
        return 0.0
    k = t = 0
    for i in range(l1):
        if not s1m[i]:
            continue
        while not s2m[k]:
            k += 1
        if s1[i] != s2[k]:
            t += 1
        k += 1
    return (matches / l1 + matches / l2 + (matches - t / 2) / matches) / 3.0


def jaro_winkler(s1: str, s2: str, p: float = 0.1) -> float:
    """Jaro-Winkler similarity. Better than SequenceMatcher for short names."""
    j = _jaro(s1, s2)
    prefix = 0
    for c1, c2 in zip(s1[:4], s2[:4]):
        if c1 == c2:
            prefix += 1
        else:
            break
    return min(j + prefix * p * (1.0 - j), 1.0)


def char_ngram_sim(s1: str, s2: str, n: int = 3) -> float:
    """Fraction of n-grams shared between two strings."""
    g1 = {s1[i:i + n] for i in range(len(s1) - n + 1)}
    g2 = {s2[i:i + n] for i in range(len(s2) - n + 1)}
    if not g1 or not g2:
        return float(s1 == s2)
    return len(g1 & g2) / len(g1 | g2)


def prefix_match(s1: str, s2: str) -> float:
    """Fraction of leading characters that are identical."""
    n = sum(1 for a, b in zip(s1, s2) if a == b)
    if n == 0:
        return 0.0
    # divide by length of shorter
    return n / min(len(s1), len(s2)) if (s1 and s2) else 0.0


def token_set_overlap(s1: str, s2: str) -> float:
    """Set overlap of uppercase alpha tokens."""
    def tokens(s):
        return set(re.findall(r"[A-Z]{2,}", s.upper()))
    t1, t2 = tokens(s1), tokens(s2)
    if not t1 or not t2:
        return 0.0
    return len(t1 & t2) / len(t1 | t2)


# ---------------------------------------------------------------------------
# Feature vector builder
# ---------------------------------------------------------------------------

FEATURE_NAMES = [
    "jaro_winkler",
    "char_3gram",
    "prefix_match",
    "token_set",
    "label_tfidf",
    "label_token_overlap",
    "format_is_date",
    "format_is_time",
    "type_num",
    "sdtm_is_timing",
    "sdtm_is_datetime",
    "domain_match_exact",
    "domain_match_prefix2",
    "master_conf",
    "is_sponsor_std",
    "in_master",
    "var_class_derived",
    "var_class_timing",
    # Version and TA context (Gap 1 + Gap 2 from architectural review)
    "sdtmig_version_match",
    "ta_match",
    "study_phase_match",
]


def _norm(s):
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip()).upper()


def _slug(s):
    return re.sub(r"[^A-Z0-9]", "", _norm(s))


def build_feature_vector(
    raw_var: str,
    raw_dataset: str,
    raw_label: str,
    raw_format: str,
    raw_type: str,
    sdtm_var: str,
    sdtm_domain: str,
    sdtm_label: str,
    master_conf: float,
    is_sponsor_std: bool,
    in_master: bool,
    label_tfidf_score: float,
    study_sdtmig_version: str = "",
    study_ta: str = "",
    study_phase: str = "",
    master_sdtmig_version: str = "",
    master_ta: str = "",
    master_phase: str = "",
) -> np.ndarray:
    """
    Build an 18-element feature vector for one (raw, sdtm) candidate pair.
    All values normalised to [0, 1].
    """
    rv  = _slug(raw_var)
    sv  = _slug(sdtm_var)
    rl  = _norm(raw_label)
    sl  = _norm(sdtm_label)
    rds = _slug(raw_dataset)
    dom = _slug(sdtm_domain)
    fmt = _norm(raw_format).upper()
    typ = _norm(raw_type).upper()

    # Name signals
    jw      = jaro_winkler(rv, sv)
    ng3     = char_ngram_sim(rv, sv, 3) if (len(rv) >= 3 and len(sv) >= 3) else float(rv == sv)
    pref    = prefix_match(rv, sv)
    tok_set = token_set_overlap(rv, sv)

    # Label signals
    lbl_tov = token_set_overlap(rl, sl) if (rl and sl) else 0.0

    # Format/type signals
    fmt_date = 1.0 if any(x in fmt for x in ("DATE", "YYMMDD", "DDMMYY")) else 0.0
    fmt_time = 1.0 if any(x in fmt for x in ("TIME", "TOD", "HH")) else 0.0
    typ_num  = 1.0 if typ in ("N", "NUM", "NUMERIC", "FLOAT", "INTEGER") else 0.0

    # SDTM structure signals
    sdtm_timing = 1.0 if re.search(r"(DT|TM|DTC|DTM)$", sv) else 0.0
    sdtm_dtm    = 1.0 if sv.endswith("DTC") or sv.endswith("DTM") else 0.0

    # Domain signals
    dom_exact  = 1.0 if rds == dom else 0.0
    dom_pref2  = 1.0 if (len(rds) >= 2 and len(dom) >= 2 and rds[:2] == dom[:2]) else 0.0

    # Master signals
    mc         = float(master_conf) if master_conf else 0.0
    spon       = 1.0 if is_sponsor_std else 0.0
    inm        = 1.0 if in_master else 0.0

    # SDTM variable class signals
    vc            = classify_variable(sdtm_var, sdtm_domain)
    vc_derived    = 1.0 if (vc in ("derived", "sequence", "flag")
                            or sdtm_var in ALWAYS_DERIVED) else 0.0
    vc_timing     = 1.0 if vc == "timing" else 0.0

    # Version and TA context signals
    from study_metadata import version_weight
    ver_match = version_weight(study_sdtmig_version, master_sdtmig_version) if (
        study_sdtmig_version and master_sdtmig_version) else 0.90
    ta_m  = 1.0 if (study_ta and master_ta and study_ta == master_ta) else (
            0.5 if (study_ta and master_ta) else 0.85)
    ph_m  = 1.0 if (study_phase and master_phase and study_phase == master_phase) else (
            0.7 if (study_phase and master_phase) else 0.85)

    return np.array([
        jw, ng3, pref, tok_set,
        label_tfidf_score, lbl_tov,
        fmt_date, fmt_time, typ_num,
        sdtm_timing, sdtm_dtm,
        dom_exact, dom_pref2,
        mc, spon, inm,
        vc_derived, vc_timing,
        ver_match, ta_m, ph_m,
    ], dtype=np.float32)


# ---------------------------------------------------------------------------
# Training data generator
# ---------------------------------------------------------------------------

def build_training_data(master_df: pd.DataFrame, label_idx=None) -> tuple:
    """
    Build feature matrix X and label vector y from master_mapping data.

    Positive pairs: all (RAW_VARIABLE -> SDTM_VARIABLE) rows in master
    Negative pairs: synthetic wrong mappings (cross-domain + random same-domain)
    """
    # Collect all positive pairs
    pos_rows = master_df[
        master_df["RAW_VARIABLE"].notna()
        & (master_df["RAW_VARIABLE"].astype(str).str.strip() != "")
        & (master_df["RAW_VARIABLE"].astype(str).str.upper() != "NAN")
    ].copy()

    if pos_rows.empty:
        return np.zeros((0, len(FEATURE_NAMES))), np.array([])

    X_rows = []
    y_rows = []

    # All SDTM (domain, var, label) entries for negative sampling
    sdtm_entries = (
        master_df[["DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL"]]
        .drop_duplicates()
        .to_dict("records")
    )

    rng = np.random.default_rng(42)

    for _, row in pos_rows.iterrows():
        raw_tok   = str(row.get("RAW_VARIABLE", "") or "")
        raw_parts = raw_tok.split(".")
        raw_var   = raw_parts[-1] if raw_parts else raw_tok
        raw_ds    = raw_parts[-2] if len(raw_parts) >= 2 else raw_parts[0]
        sdtm_var  = str(row.get("SDTM_VARIABLE", "") or "")
        sdtm_dom  = str(row.get("DOMAIN", "") or "")
        sdtm_lbl  = str(row.get("SDTM_LABEL", "") or "")
        mc        = float(row.get("MASTER_CONFIDENCE", 0) or 0)
        spon      = bool(row.get("IS_SPONSOR_STD", False))

        if not raw_var or not sdtm_var:
            continue

        lbl_sim = 0.0
        if label_idx is not None:
            rk = raw_ds + "." + raw_var
            lbl_sim = label_idx.scores(sdtm_lbl, [rk]).get(rk, 0.0)

        # POSITIVE example
        fv = build_feature_vector(
            raw_var, raw_ds, "",
            "", "",
            sdtm_var, sdtm_dom, sdtm_lbl,
            mc, spon, True, lbl_sim,
        )
        X_rows.append(fv)
        y_rows.append(1)

        # Generate 4 NEGATIVE examples per positive
        # Mix of cross-domain and same-domain wrong pairs
        neg_pool = sdtm_entries.copy()
        rng.shuffle(neg_pool)
        neg_added = 0
        for neg in neg_pool:
            neg_var = neg["SDTM_VARIABLE"]
            neg_dom = neg["DOMAIN"]
            neg_lbl = neg["SDTM_LABEL"]
            # Skip the correct pair
            if neg_var == sdtm_var and neg_dom == sdtm_dom:
                continue
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "",
                "", "",
                neg_var, neg_dom, str(neg_lbl or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            neg_added += 1
            if neg_added >= 4:
                break

    if not X_rows:
        return np.zeros((0, len(FEATURE_NAMES))), np.array([])

    X = np.vstack(X_rows)
    y = np.array(y_rows, dtype=np.int32)
    return X, y


# ---------------------------------------------------------------------------
# ML Scorer class
# ---------------------------------------------------------------------------

class MLScorer:
    """
    Gradient Boosted Trees classifier trained on master_mapping pairs.
    Predicts P(raw_var -> sdtm_var is correct match).

    Falls back gracefully to feature-weighted scoring if insufficient
    training data (< 10 positive pairs).
    """

    def __init__(self):
        self._model    = None
        self._trained  = False
        self._n_pos    = 0
        self._fallback_weights = {
            "jaro_winkler":  0.35,
            "char_3gram":    0.10,
            "label_tfidf":   0.25,
            "master_conf":   0.20,
            "domain_match":  0.10,
        }

    def train(self, master_df: pd.DataFrame, label_idx=None, log=None):
        """
        Train the classifier on master_mapping data.
        Automatically called by mapper.run() before the mapping loop.
        """
        from sklearn.ensemble import GradientBoostingClassifier

        X, y = build_training_data(master_df, label_idx)
        self._n_pos = int((y == 1).sum()) if len(y) > 0 else 0

        if log:
            log.info("  MLScorer: %d positive pairs, %d total training examples",
                     self._n_pos, len(y))

        if self._n_pos < 5:
            if log:
                log.warning("  MLScorer: insufficient training data (%d pos). "
                            "Using fallback weighted scoring.", self._n_pos)
            self._trained = False
            return

        # GradientBoosting: works well with small datasets, handles class imbalance
        self._model = GradientBoostingClassifier(
            n_estimators=120,
            max_depth=4,
            learning_rate=0.08,
            subsample=0.85,
            min_samples_leaf=2,
            random_state=42,
        )
        self._model.fit(X, y)
        self._trained = True

        if log:
            # Quick self-assessment on training data
            train_acc = float(self._model.score(X, y))
            log.info("  MLScorer: trained. Train accuracy=%.3f  features=%d",
                     train_acc, len(FEATURE_NAMES))
            # Feature importances
            importances = sorted(
                zip(FEATURE_NAMES, self._model.feature_importances_),
                key=lambda x: -x[1],
            )
            top5 = ", ".join(f"{n}={v:.3f}" for n, v in importances[:5])
            log.info("  MLScorer: top features: %s", top5)

    def score(
        self,
        raw_var: str,
        raw_dataset: str,
        raw_label: str,
        raw_format: str,
        raw_type: str,
        sdtm_var: str,
        sdtm_domain: str,
        sdtm_label: str,
        master_conf: float,
        is_sponsor_std: bool,
        in_master: bool,
        label_tfidf_score: float,
    ) -> float:
        """
        Return a match probability [0..1] for this (raw, sdtm) pair.
        """
        fv = build_feature_vector(
            raw_var, raw_dataset, raw_label, raw_format, raw_type,
            sdtm_var, sdtm_domain, sdtm_label,
            master_conf, is_sponsor_std, in_master, label_tfidf_score,
        )

        if self._trained and self._model is not None:
            # P(class=1) from gradient boosting
            prob = float(self._model.predict_proba(fv.reshape(1, -1))[0, 1])
            return prob
        else:
            # Fallback: hand-weighted combination of key signals
            rv  = _slug(raw_var)
            sv  = _slug(sdtm_var)
            rds = _slug(raw_dataset)
            dom = _slug(sdtm_domain)
            jw  = jaro_winkler(rv, sv)
            ng3 = char_ngram_sim(rv, sv, 3) if len(rv) >= 3 and len(sv) >= 3 else float(rv == sv)
            dom_m = 1.0 if (len(rds) >= 2 and len(dom) >= 2 and rds[:2] == dom[:2]) else 0.0
            mc    = float(master_conf or 0)
            lbl   = float(label_tfidf_score or 0)
            return min(
                0.35 * jw
                + 0.10 * ng3
                + 0.20 * mc
                + 0.25 * lbl
                + 0.10 * dom_m,
                1.0,
            )

    @property
    def is_trained(self) -> bool:
        return self._trained

    def feature_names(self) -> list:
        return list(FEATURE_NAMES)
