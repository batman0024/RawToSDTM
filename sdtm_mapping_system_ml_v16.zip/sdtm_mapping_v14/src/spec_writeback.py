"""
spec_writeback.py
=================
Write mapping results back into the new study SDTM spec Excel.
Preserves ALL original formatting (fonts, colors, borders, dropdowns).
Only cell values are written.

Columns updated where found in each domain sheet:
  Input Variables   RAW.DATASET.VARIABLE tokens (comma-separated, ordered)
  Mapping Action    controlled action keyword (only if currently blank)
  Origin            CRF / Derived / Assigned / Protocol / eDT
                    (priority-aware: CRF outranks all, will overwrite lower)

Review-tier rows are amber-highlighted.
A change-log sheet is appended to the updated workbook.

Usage:
    python spec_writeback.py \\
        --spec     new_study_spec.xlsx \\
        --results  mapping_results.xlsx \\
        --out      new_study_spec_mapped.xlsx

    # Dry-run: preview changes without writing
    python spec_writeback.py \\
        --spec    new_study_spec.xlsx \\
        --results mapping_results.xlsx \\
        --out     new_study_spec_mapped.xlsx \\
        --dry-run
"""

from __future__ import annotations

import re
import sys
import math
import warnings
import datetime as dt
import argparse
from pathlib import Path

import pandas as pd
import yaml

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

from logger import get_logger
from excel_validator import ExcelValidator, render_validation_report
from master_builder import (read_origin_values_from_spec,
                             normalize_origin_to_cdisc)


# ---------------------------------------------------------------------------
# Column header target lists (all lowercase for comparison)
# ---------------------------------------------------------------------------

DATASET_HDR   = ["dataset", "domain", "sdtm dataset", "sdtm domain", "dataset*"]
VARIABLE_HDR  = ["variable", "sdtm variable", "sdtm_variable", "var", "varname"]
INPUT_HDR     = [
    "input variables", "input variable", "input_variables",
    "raw inputs", "source variables", "raw variables",
    "input_variable", "raw", "source", "raw input",
]
ACTION_HDR    = [
    "mapping action", "mapping_action", "derivation",
    "algorithm", "rule", "method", "action", "mapping rule",
]
ORIGIN_HDR    = ["origin", "data origin", "source type", "data source"]
CORE_HDR      = ["gilead core", "core", "cdisc core", "required", "sponsor core"]

# Origin priority (lower number = higher priority)
ORIGIN_PRIORITY = {
    "CRF":      1,
    "DERIVED":  2,
    "PROTOCOL": 3,
    "EDT":      4,
    "ASSIGNED": 5,
}

FILL_REVIEW  = PatternFill(patternType="solid", fgColor="FFF2CC")   # amber - review tier
FILL_DIRECT  = PatternFill(patternType="solid", fgColor="C6EFCE")   # bright green - auto-accepted
FILL_UNRES   = PatternFill(patternType="solid", fgColor="FFC7CE")   # bright red   - unresolved
FILL_HEADER  = PatternFill(patternType="solid", fgColor="1F3864")
FONT_HEADER  = Font(bold=True, color="FFFFFF", size=10)
FONT_UPDATED = Font(bold=True, color="000000")   # Bold text for updated cells


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _norm(s):
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip()).upper()


def _hdr(val, targets):
    """Return True if cell value matches any header target (case-insensitive)."""
    if val is None:
        return False
    return str(val).strip().lower() in targets


def _origin_priority(val):
    """Return numeric priority for an origin value (lower = higher priority)."""
    return ORIGIN_PRIORITY.get(str(val).upper().strip(), 9)


# ---------------------------------------------------------------------------
# Results loader
# ---------------------------------------------------------------------------

def load_results(results_path, log):
    """
    Load direct + review sheets from mapping_results.xlsx.
    Returns {(DOMAIN, SDTM_VARIABLE): row_dict}.
    Direct rows overwrite review rows for the same key.
    """
    combined = {}
    for sheet in ("review", "direct", "cross_dataset_match"):
        try:
            df = pd.read_excel(results_path, sheet_name=sheet,
                               engine="openpyxl", dtype=object)
            if df.empty:
                continue
            for _, r in df.iterrows():
                dom = _norm(r.get("DOMAIN",        ""))
                var = _norm(r.get("SDTM_VARIABLE", ""))
                if not dom or not var:
                    continue
                raw_val = r.get("RAW_VARIABLES_ASSIGNED", "")
                import math as _math
                if raw_val is None or (isinstance(raw_val, float) and _math.isnan(raw_val)):
                    raw_val = ""
                # cross_dataset_match rows are treated as review tier so they
                # get amber + bold highlight and appear in the change-log
                effective_tier = "review" if sheet == "cross_dataset_match" else sheet
                combined[(dom, var)] = {
                    "raw":    str(raw_val).strip(),
                    "action": str(r.get("MAPPING_ACTION",         "") or ""),
                    "origin": str(r.get("ORIGIN",                 "") or ""),
                    "score":  float(r.get("COMPOSITE_SCORE",   0.0) or 0.0),
                    "tier":   effective_tier,
                    "note":   str(r.get("MATCH_NOTE", "") or ""),
                }
        except Exception as exc:
            log.warning("  Could not load sheet '%s': %s", sheet, exc)

    direct_n = sum(1 for v in combined.values() if v["tier"] == "direct")
    review_n = sum(1 for v in combined.values() if v["tier"] == "review")
    log.info(
        "  Loaded %d mapped variables (%d direct, %d review/cross-dataset)",
        len(combined), direct_n, review_n,
    )
    return combined


# ---------------------------------------------------------------------------
# Main write-back
# ---------------------------------------------------------------------------

def write_back(
    spec_path,
    results_path,
    out_path,
    highlight_review=True,
    populate_origin=True,
    populate_action=True,
    dry_run=False,
    config_path="config.yaml",
):
    """
    Update Input Variables (and optionally Origin, Mapping Action) in the
    spec workbook without touching any formatting.

    Args:
        spec_path:        original spec Excel
        results_path:     mapping_results.xlsx from mapper.py
        out_path:         output path for updated spec
        highlight_review: amber-highlight review-tier rows
        populate_origin:  write Origin column
        populate_action:  write Mapping Action (only if currently blank)
        dry_run:          preview changes to log without writing any file
        config_path:      config.yaml path

    Returns:
        path to updated spec (or None if dry_run)
    """
    try:
        cfg_p = Path(config_path)
        if not cfg_p.exists():
            module_dir = Path(__file__).parent
            candidate  = module_dir / cfg_p.name
            if candidate.exists():
                cfg_p = candidate
        with open(cfg_p) as f:
            cfg = yaml.safe_load(f)
    except Exception:
        cfg = {}

    log_cfg = cfg.get("logging", {})
    log     = get_logger(log_cfg.get("log_file", ""), log_cfg.get("level", "INFO"))

    if dry_run:
        log.info("[WRITEBACK] DRY-RUN mode - no file will be written")

    log.info("[WRITEBACK] Loading results: %s", results_path.name)
    mapping = load_results(results_path, log)
    if not mapping:
        log.warning("[WRITEBACK] No mapped variables - nothing to write")
        return None

    log.info("[WRITEBACK] Loading spec: %s", spec_path.name)
    ext      = spec_path.suffix.lower()
    is_macro = (ext == ".xlsm")
    wb       = load_workbook(spec_path, data_only=False, keep_vba=is_macro)

    # Capture before-state snapshot for post-writeback validation
    _validator = ExcelValidator(spec_path)

    # Read valid Origin values from Maintenance/Valuelist tab of this spec
    # so we normalize origins to the exact values the spec expects
    valid_origins = read_origin_values_from_spec(spec_path, {})
    if valid_origins:
        log.info("  Valid origin values from spec Maintenance tab: %s",
                 sorted(valid_origins))
    else:
        log.info("  No Maintenance tab found; using CDISC standard Origin values")

    change_log     = []
    skipped_sheets = []
    total_updates  = 0

    import re as _re_wb
    for ws in wb.worksheets:
        sn = ws.title
        # Skip non-domain sheets — never write into these
        _SKIP_WB = {
            "study", "standards", "toc", "<ds>", "ta", "te", "ti", "tv", "ts", "td",
            "ta-data", "te-data", "ti-data", "tv-data", "ts-data", "td-data",
            "maintenance", "valuelist", "value list", "history of revisions",
            "cover", "index", "readme",
        }
        if sn.strip().lower() in _SKIP_WB:
            continue
        # Skip any previously appended writeback change-log sheets
        if _re_wb.match(r"_Writeback_[0-9]{8}_[0-9]{4}$", sn.strip()):
            continue

        # Find header row
        hdr_row = None
        col_idx = {}
        for r in range(1, min(ws.max_row + 1, 15)):
            row_vals = {c: ws.cell(r, c).value for c in range(1, ws.max_column + 1)}
            ds = va = inp = act = orig = core = None
            for c, val in row_vals.items():
                if ds   is None and _hdr(val, DATASET_HDR):  ds   = c
                if va   is None and _hdr(val, VARIABLE_HDR): va   = c
                if inp  is None and _hdr(val, INPUT_HDR):    inp  = c
                if act  is None and _hdr(val, ACTION_HDR):   act  = c
                if orig is None and _hdr(val, ORIGIN_HDR):   orig = c
                if core is None and _hdr(val, CORE_HDR):     core = c
            if ds and va and inp:
                hdr_row = r
                col_idx = {"ds": ds, "var": va, "inp": inp,
                           "act": act, "orig": orig, "core": core}
                break

        if hdr_row is None:
            skipped_sheets.append(sn)
            continue

        # ---- Strip conditional formatting that covers Input Variables column ----
        # Excel CF rules override cell-level PatternFill, making highlights invisible.
        # Removing CF rules on the inp column lets our bold+fill take effect.
        try:
            from openpyxl.utils import range_boundaries
            inp_ci = col_idx["inp"]
            keys_to_del = []
            for cf_sqref in list(ws.conditional_formatting._cf_rules.keys()):
                try:
                    # sqref may be multiple ranges e.g. "K1:K200 M1:M200"
                    for rng in str(cf_sqref).split():
                        mn_c, _, mx_c, _ = range_boundaries(rng)
                        if mn_c <= inp_ci <= mx_c:
                            keys_to_del.append(cf_sqref)
                            break
                except Exception:
                    pass
            for k in keys_to_del:
                try:
                    del ws.conditional_formatting._cf_rules[k]
                except Exception:
                    pass
        except Exception:
            pass

        sheet_updates = 0

        for r in range(hdr_row + 1, ws.max_row + 1):
            ds_val  = ws.cell(r, col_idx["ds"]).value
            var_val = ws.cell(r, col_idx["var"]).value
            if ds_val is None and var_val is None:
                continue

            dom = _norm(ds_val)
            var = _norm(var_val)
            if not var:
                continue

            # Lookup by (domain, var) then by var alone as fallback
            key = (dom, var) if (dom, var) in mapping else \
                  next((k for k in mapping if k[1] == var), None)
            if key is None:
                continue

            m    = mapping[key]
            tier = m["tier"]
            sc   = m["score"]

            # ---- Input Variables ----------------------------------------
            inp_cell = ws.cell(r, col_idx["inp"])
            old_inp  = str(inp_cell.value or "").strip()

            # Parse existing tokens in the spec cell
            existing_tokens = [
                t.strip() for t in old_inp.replace(";", ",").split(",")
                if t.strip()
            ] if old_inp else []

            def bare(tok):
                """Return bare variable slug for comparison (strips known prefixes/suffixes)."""
                import re as _re
                t = tok.strip().upper()
                # Strip well-known namespace prefixes: raw. sdtm. work. sdtm.xx.
                t = _re.sub(r"^(RAW|SDTM|WORK)\.", "", t)
                # Strip remaining dataset.variable prefix (keep only variable name)
                parts = t.split(".")
                varname = parts[-1] if parts else t
                # Strip common data-cleaning suffixes
                varname = _re.sub(
                    r"_(RAW|STD|ORIG|CLEAN|MOD|ADJ|IMPUTE|UNMOD|RECODED|DECODE|IMP)$",
                    "", varname, flags=_re.IGNORECASE,
                )
                return varname.upper()

            # ----------------------------------------------------------------
            # Classify each existing token so we know how to handle it
            # ----------------------------------------------------------------
            # PRESERVE (always keep, never drop):
            #   - sdtm.*   same-domain SDTM cross-references  (e.g. sdtm.dm.age)
            #   - work.*   SAS work-dataset references        (e.g. work.ds._dsstdtc)
            #   - SDTM.*   uppercase variant
            #   - tokens with no dot at all (plain derived expressions)
            #   - any token whose prefix matches the current SDTM domain
            #     (e.g. sdtm.se.sestdtc for a DS domain variable)
            # CONDITIONAL (keep if still in new mapping, drop otherwise):
            #   - raw.*    actual raw dataset references
            # SKIP (filter out garbage that landed in the cell):
            #   - free-text notes like "Vendor datasets", "See derivation", etc.
            #   - tokens longer than 80 chars or containing spaces

            import re as _re

            def _is_preserve_token(tok):
                """Return True for tokens that must ALWAYS be kept.
                IMPORTANT: garbage check must be done first in the caller.
                This function does NOT call _is_garbage to avoid forward-ref issues."""
                t = tok.strip().upper()
                if not t:
                    return False
                # Explicitly exclude known-garbage patterns even without spaces
                if t.lower() in ("nan", "none", "null", ""):
                    return False
                if len(t) > 1000:
                    return False
                if t.startswith("SDTM."):                 # sdtm.domain.var cross-ref
                    return True
                if t.startswith("WORK."):                 # work.dataset SAS temp table
                    return True
                # Plain token (no dot) — only preserve if it looks like a valid identifier
                # NOT free-text (must have no spaces, reasonable length)
                if "." not in t and " " not in tok.strip() and len(tok.strip()) <= 80:
                    return True
                return False

            def _is_raw_token(tok):
                t = tok.strip().upper()
                return t.startswith("RAW.")

            def _is_garbage(tok):
                """Detect free-text notes that ended up in Input Variables cells."""
                t = tok.strip()
                if not t or t.lower() == "nan":
                    return True
                # Free-text notes contain spaces (multiple words like "Vendor datasets")
                # Real variable tokens never contain spaces
                if " " in t:
                    return True
                # Extremely long values (>1000 chars) are almost certainly garbage
                if len(t) > 1000:
                    return True
                return False

            # New tokens from mapper result (skip empty / nan)
            mapped_raw = m["raw"] or ""
            new_mapped_tokens = [
                t.strip() for t in mapped_raw.split(",")
                if t.strip() and not _is_garbage(t.strip())
            ]
            new_mapped_bares = {bare(t) for t in new_mapped_tokens}

            # Build final token list with clear rules:
            final_tokens = []
            for et in existing_tokens:
                if _is_garbage(et):
                    continue                        # drop free-text notes / garbage
                if _is_preserve_token(et):
                    final_tokens.append(et)         # always keep sdtm.*, work.*, plain
                elif _is_raw_token(et):
                    if bare(et) in new_mapped_bares:
                        final_tokens.append(et)     # raw token still valid in new mapping
                    # else: drop — raw dataset absent from current catalog
                else:
                    # Unknown prefix (e.g. some other namespace) — keep to be safe
                    final_tokens.append(et)

            # Add new mapped RAW tokens not yet covered
            covered_bares = {bare(t) for t in final_tokens}
            for mt in new_mapped_tokens:
                if bare(mt) not in covered_bares:
                    final_tokens.append(mt)
                    covered_bares.add(bare(mt))

            # Deduplicate preserving order
            seen_f, deduped_f = set(), []
            for t in final_tokens:
                tk = t.strip()
                if tk and tk not in seen_f:
                    seen_f.add(tk)
                    deduped_f.append(tk)

            new_inp = ", ".join(deduped_f)
            if new_inp.lower() == "nan":
                new_inp = ""

            # Normalise for comparison:
            # - collapse ALL whitespace (spaces, newlines, tabs) around tokens
            # - split on both comma AND newline so multi-line cells compare equal
            #   to single-line comma-separated cells (Excel wraps long values with \n)
            # - sort tokens so order differences don't trigger false positives
            def _norm_inp(s):
                import re as _re
                # treat newlines and semicolons as comma separators
                flat = _re.sub(r"[\n\r;]+", ",", str(s))
                tokens = sorted(
                    t.strip().upper()
                    for t in flat.split(",")
                    if t.strip() and t.strip().upper() not in ("", "NAN")
                )
                return "|".join(tokens)   # pipe-join for unambiguous comparison

            inp_changed = (_norm_inp(new_inp) != _norm_inp(old_inp))
            inp_is_new  = bool(new_inp and not old_inp)

            # Always write the canonical token value when we have a mapping.
            # The value write ensures the cell content is normalised (no line-breaks,
            # canonical comma-space separation). Highlight ONLY when tokens genuinely differ.
            if new_inp and not dry_run:
                inp_cell.value = new_inp

            # Apply highlight only when content genuinely changed
            if (inp_changed or inp_is_new) and highlight_review and not dry_run:
                if tier in ("review", "review_needs_direct"):
                    inp_cell.fill = FILL_REVIEW
                    inp_cell.font = Font(bold=True, color="7D6608", size=10)
                elif tier == "direct":
                    inp_cell.fill = FILL_DIRECT
                    inp_cell.font = Font(bold=True, color="276221", size=10)
                else:
                    inp_cell.fill = FILL_UNRES
                    inp_cell.font = Font(bold=True, color="9C0006", size=10)

            if inp_changed or inp_is_new:
                change_log.append({
                    "Sheet":     sn,
                    "Domain":    dom,
                    "Variable":  var,
                    "Column":    "Input Variables",
                    "Old_Value": old_inp,
                    "New_Value": new_inp,
                    "Tier":      tier,
                    "Score":     round(sc, 4),
                    "Note":      m.get("note", ""),
                })
                sheet_updates += 1

            # ---- Mapping Action ------------------------------------------
            # ISSUE 4: If action is DROP but we now have raw variables -> change to ASSIGN
            if populate_action and col_idx.get("act"):
                act_cell   = ws.cell(r, col_idx["act"])
                old_act    = str(act_cell.value or "").strip().upper()
                new_action = (m["action"] or "").strip().upper()

                should_update_action = False
                resolved_action      = new_action or old_act

                if old_act == "DROP" and new_inp:
                    # Had DROP but now has raw variable -> change to ASSIGN
                    resolved_action      = "ASSIGN"
                    should_update_action = True
                elif not old_act and new_action:
                    # Blank -> fill with mapped action
                    resolved_action      = new_action
                    should_update_action = True

                if should_update_action:
                    if not dry_run:
                        act_cell.value = resolved_action
                    change_log.append({
                        "Sheet":     sn,
                        "Domain":    dom,
                        "Variable":  var,
                        "Column":    "Mapping Action",
                        "Old_Value": old_act,
                        "New_Value": resolved_action,
                        "Tier":      tier,
                        "Score":     round(sc, 4),
                    })

            # ---- Origin (priority-aware: CRF > Derived > Protocol > ...) -
            if populate_origin and col_idx.get("orig") and m["origin"]:
                orig_cell = ws.cell(r, col_idx["orig"])
                old_orig  = str(orig_cell.value or "").strip().upper()
                new_orig  = m["origin"]
                new_p     = _origin_priority(new_orig)
                old_p     = _origin_priority(old_orig)

                should_write = (
                    not old_orig
                    or old_orig in ("", "N/A", "NA", "UNKNOWN")
                    or new_p < old_p  # new value has higher priority
                )
                # Normalize to CDISC/spec valid value before writing
                new_orig = normalize_origin_to_cdisc(new_orig, valid_origins)
                if should_write:
                    if not dry_run:
                        orig_cell.value = new_orig
                    change_log.append({
                        "Sheet":     sn,
                        "Domain":    dom,
                        "Variable":  var,
                        "Column":    "Origin",
                        "Old_Value": old_orig,
                        "New_Value": new_orig,
                        "Tier":      tier,
                        "Score":     round(sc, 4),
                    })

            # (row-level highlight removed - only inp_cell is highlighted above)

        log.info("  [%-10s] %d cells updated", sn, sheet_updates)
        total_updates += sheet_updates

    if skipped_sheets:
        log.info("  Skipped (no variable header found): %s", skipped_sheets)

    # Preview in dry-run mode
    if dry_run:
        log.info("\n  DRY-RUN PREVIEW - %d changes would be made:", len(change_log))
        for entry in change_log[:30]:
            log.info(
                "    [%s] %s.%s -> %s: '%s' -> '%s'",
                entry["Tier"], entry["Domain"], entry["Variable"],
                entry["Column"], entry["Old_Value"], entry["New_Value"],
            )
        if len(change_log) > 30:
            log.info("    ... and %d more changes", len(change_log) - 30)
        return None

    # Append change-log sheet
    if change_log:
        ts_str  = dt.datetime.now().strftime("%Y%m%d_%H%M")
        log_sn  = ("_Writeback_" + ts_str)[:31]
        log_ws  = wb.create_sheet(log_sn)
        headers = ["Sheet", "Domain", "Variable", "Column",
                   "Old_Value", "New_Value", "Tier", "Score", "Note"]
        for ci, h in enumerate(headers, 1):
            c = log_ws.cell(1, ci, h)
            c.fill = FILL_HEADER
            c.font = FONT_HEADER
            c.alignment = Alignment(horizontal="center")
        for ri, entry in enumerate(change_log, 2):
            for ci, h in enumerate(headers, 1):
                log_ws.cell(ri, ci, entry.get(h, ""))
        log_ws.freeze_panes = "A2"
        log_ws.auto_filter.ref = (
            "A1:" + get_column_letter(len(headers)) + str(len(change_log) + 1)
        )
        for ci in range(1, len(headers) + 1):
            log_ws.column_dimensions[get_column_letter(ci)].width = 22

    wb.save(out_path)

    log.info(
        "[WRITEBACK]  %d total cell updates  |  %d change-log entries  ->  %s",
        total_updates, len(change_log), out_path,
    )

    # Run post-writeback validation
    validation_report = None
    try:
        validation_report = _validator.validate_after(out_path)
        overall = validation_report["summary"]["overall_status"]
        risk    = validation_report["summary"]["risk_score"]
        log.info("[VALIDATE]  status=%s  risk=%.0f%%  checks=%d  failed=%d",
                 overall, risk*100,
                 validation_report["summary"]["total_checks"],
                 validation_report["summary"]["failed"])
        for issue in validation_report.get("issues", []):
            log.warning("  [%s] %s — %s",
                        issue["severity"], issue["issue"], issue.get("root_cause",""))
    except Exception as _ve:
        log.warning("[VALIDATE]  Validation step failed: %s", _ve)

    return out_path, validation_report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Write mapping results into SDTM spec Excel.")
    ap.add_argument("--spec",         required=True)
    ap.add_argument("--results",      required=True)
    ap.add_argument("--out",          required=True)
    ap.add_argument("--no-origin",    action="store_true")
    ap.add_argument("--no-action",    action="store_true")
    ap.add_argument("--no-highlight", action="store_true")
    ap.add_argument("--dry-run",      action="store_true",
                    help="Preview changes without writing any file")
    ap.add_argument("--config",       default="config.yaml")
    args = ap.parse_args()
    write_back(
        spec_path=Path(args.spec),
        results_path=Path(args.results),
        out_path=Path(args.out),
        highlight_review=not args.no_highlight,
        populate_origin=not args.no_origin,
        populate_action=not args.no_action,
        dry_run=args.dry_run,
        config_path=args.config,
    )
