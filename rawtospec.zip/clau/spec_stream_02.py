
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SDTM Mapping Suggestion Engine (fast, fuzzy)

Usage:
    python sdtm_mapper.py --master master_mapping.xlsx --raw new_study_raw_catalog.csv --out mapping_suggestions.xlsx \
                          [--topk 5] [--auto-thresh 0.80] [--review-thresh 0.60]

Inputs:
  - master_mapping.xlsx : Historic/curated raw→SDTM master mapping (xlsx/csv). Recommended columns:
        RAW_VARIABLE, RAW_LABEL(optional), SDTM_VARIABLE, SDTM_DOMAIN, MAPPING_ACTION, RULE_EXPRESSION(optional), ORIGIN(optional)
  - new_study_raw_catalog.csv : New study raw metadata exported from SAS PROC CONTENTS (CSV) with columns:
        MEMNAME, NAME, LABEL

Outputs:
  - mapping_suggestions.xlsx : Top-k mapping suggestions per raw variable with confidence scores and statuses.

Notes:
  - Uses composite fuzzy matching (token sort + token set + partial ratio) over raw names/labels and SDTM targets.
  - Adds a small domain hint based on dataset prefix (e.g., AE*, CM*, LB*).
  - You can tune thresholds (--auto-thresh, --review-thresh).
  - Extend sdtm_labels_dict or load SDTM labels if available to improve label matching.
"""

import io
import os
import re
import datetime as dt
import warnings
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from difflib import SequenceMatcher

# Suppress openpyxl data-validation warnings only
warnings.filterwarnings(
    "ignore",
    message="Data Validation extension is not supported and will be removed",
    category=UserWarning,
    module="openpyxl"
)

EXCEL_ENGINE = "openpyxl"
DEFAULT_TOC = "TOC"
DEFAULT_EXCLUSIONS = {"ta","te","ti","tv","ts","td"}  # normalized lowercase

# -------------------- Core helpers --------------------
def normalize_text(x: str) -> str:
    if pd.isna(x):
        return ""
    s = re.sub(r"\s+", " ", str(x).strip())
    return s.lower()

def normalize_action(x: str) -> str:
    """Normalize mapping action for robust equality checks."""
    if pd.isna(x) or str(x).strip() == "":
        return ""
    s = str(x).strip()
    s = re.sub(r"\s+", " ", s).lower()
    s = re.sub(r"[ ]+", " ", s)  # non-breaking spaces
    return s.strip()

def split_to_list(x: str) -> list:
    if x is None or (isinstance(x, float) and np.isnan(x)) or pd.isna(x) or str(x).strip() == "":
        return []
    s = str(x)
    s = s.replace("\r", " ").replace("\n", ",")
    s = s.replace("\n", ",").replace(";", ",").replace("+", ",")
    parts = [p.strip() for p in s.split(",") if p.strip() != ""]
    parts = sorted(set(p.lower() for p in parts))
    return parts

def ensure_raw_list(x):
    if isinstance(x, list):
        return x
    if x is None or (isinstance(x, float) and np.isnan(x)) or pd.isna(x):
        return []
    return split_to_list(str(x))

def list_to_str(lst: list) -> str:
    return ",".join(lst)

def dedupe_columns(df: pd.DataFrame) -> pd.DataFrame:
    return df.loc[:, ~df.columns.duplicated()]

def auto_rename_columns(df: pd.DataFrame, alias_map) -> pd.DataFrame:
    df = dedupe_columns(df)
    colmap = {}
    lower_cols = {c.lower(): c for c in df.columns}
    existing = set(df.columns)
    for canonical, aliases in alias_map.items():
        if canonical in existing:
            continue
        chosen = None
        for a in aliases:
            if a.lower() in lower_cols:
                chosen = lower_cols[a.lower()]
                break
        if not chosen:
            for lc, orig in lower_cols.items():
                if any(a.lower() in lc for a in aliases):
                    chosen = orig
                    break
        if chosen:
            colmap[chosen] = canonical
    df = df.rename(columns=colmap)
    return dedupe_columns(df)

def canonical_token(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower().strip())

def resolve_sheet_name(xls: pd.ExcelFile, dataset: str) -> str:
    if not dataset:
        return None
    ds = str(dataset).strip()
    ds_lower = ds.lower()
    ds_tok = canonical_token(ds)
    for s in xls.sheet_names:
        if s.strip().lower() == ds_lower:
            return s
    tokens = {s: canonical_token(s) for s in xls.sheet_names}
    for s, tok in tokens.items():
        if tok == ds_tok:
            return s
    for s, tok in tokens.items():
        if ds_tok and ds_tok in tok:
            return s
    return None

def coalesce_cols(df: pd.DataFrame, cols: list, default=None) -> pd.Series:
    s = pd.Series([np.nan] * len(df), index=df.index)
    for c in cols:
        if c in df.columns:
            s = s.combine_first(df[c])
    if default is not None:
        s = s.fillna(default)
    return s

def most_common_non_empty(values: list) -> str:
    vals = [v for v in values if v and str(v).strip() != ""]
    if not vals:
        return ""
    vc = pd.Series(vals).value_counts()
    top = vc.index[0]
    uniq = list(dict.fromkeys(vals))
    if len(uniq) == 1:
        return top
    return " | ".join(uniq)

def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a or "", b or "").ratio()

# -------------------- Aliases --------------------
TOC_ALIAS = {
    "ACTIVE": ["active", "is active", "include", "enabled", "flag"],
    "DATASET": ["dataset", "sdtm dataset", "domain", "table", "target dataset"]
}

SPEC_ALIAS_DOMAIN = {
    "VARIABLE": ["variable", "sdtm variable", "target variable", "variable name", "sdtm_var"],
    "INPUT_VARIABLE": ["input_variable", "input variable", "raw inputs", "raw variables",
                       "source variables", "source variable", "raw var", "raw fields",
                       "source columns", "source fields", "raw", "src variables"],
    "DATASET": ["dataset", "dataset*", "domain", "sdtm dataset", "target dataset"],
    "MAPPING_ACTION": ["mapping_action", "mapping action", "derivation", "rule",
                       "algorithm", "transform", "method"]
}

# -------------------- Readers --------------------
def read_active_datasets(spec_buf_or_path, toc_sheet, exclusions: set):
    toc = pd.read_excel(spec_buf_or_path, sheet_name=toc_sheet, engine=EXCEL_ENGINE, dtype=object)
    toc = auto_rename_columns(toc, TOC_ALIAS)
    if "ACTIVE" not in toc.columns or "DATASET" not in toc.columns:
        raise ValueError("TOC sheet must contain ACTIVE and DATASET columns.")
    toc["ACTIVE"] = toc["ACTIVE"].apply(normalize_text)
    toc["DATASET"] = toc["DATASET"].apply(lambda s: str(s).strip())
    active = toc[toc["ACTIVE"].isin(["y", "yes", "true", "1"])]["DATASET"].tolist()
    active_filtered = [ds for ds in active if normalize_text(ds) not in exclusions]
    if not active_filtered:
        raise ValueError("No active datasets after exclusions.")
    return active_filtered

def read_spec_for_datasets(spec_buf_or_path, datasets: list):
    """Read and consolidate spec for given datasets; returns rows per key (JOIN_DOMAIN.VARIABLE)."""
    xls = pd.ExcelFile(spec_buf_or_path, engine=EXCEL_ENGINE)
    frames = []
    for dataset in datasets:
        sheet = resolve_sheet_name(xls, dataset)
        if not sheet:
            continue
        df = pd.read_excel(spec_buf_or_path, sheet_name=sheet, engine=EXCEL_ENGINE, dtype=object)
        if df.empty:
            continue
        df = auto_rename_columns(df, SPEC_ALIAS_DOMAIN)

        for col in ["VARIABLE", "INPUT_VARIABLE", "MAPPING_ACTION"]:
            if col not in df.columns:
                df[col] = np.nan

        df["VARIABLE"] = df["VARIABLE"].apply(normalize_text)
        df["RAW_LIST_SPEC"] = df["INPUT_VARIABLE"].apply(split_to_list).apply(ensure_raw_list)
        df["RAW_INPUTS_SPEC"] = df["RAW_LIST_SPEC"].apply(list_to_str)

        df["ACTION_ORIG_SPEC"] = df["MAPPING_ACTION"].apply(lambda x: "" if pd.isna(x) else str(x).strip())
        df["ACTION_NORM_SPEC"] = df["ACTION_ORIG_SPEC"].apply(normalize_action)

        dom_norm = normalize_text(dataset)
        df["DOMAIN"] = dom_norm

        if "DATASET" in df.columns:
            df["DATASET_NORM"] = df["DATASET"].apply(normalize_text)
            df["SPEC_DOMAIN"] = np.where(df["DATASET_NORM"].eq("qnam"), "qnam", dom_norm)
        else:
            df["SPEC_DOMAIN"] = dom_norm

        df["JOIN_DOMAIN"] = np.where(df["SPEC_DOMAIN"].eq("qnam"), "qnam", df["DOMAIN"])

        df = df[(df["JOIN_DOMAIN"] != "") & (df["VARIABLE"] != "")]
        frames.append(df[["DOMAIN","SPEC_DOMAIN","JOIN_DOMAIN","VARIABLE",
                          "RAW_LIST_SPEC","RAW_INPUTS_SPEC",
                          "ACTION_ORIG_SPEC","ACTION_NORM_SPEC"]].copy())

    if not frames:
        return pd.DataFrame(columns=["DOMAIN","SPEC_DOMAIN","JOIN_DOMAIN","VARIABLE",
                                     "RAW_LIST_SPEC","RAW_INPUTS_SPEC",
                                     "ACTION_ORIG_SPEC","ACTION_NORM_SPEC","KEY"])

    spec_all = pd.concat(frames, ignore_index=True)

    # Aggregate to unique key rows
    def union_lists(series_of_lists):
        union = set()
        for lst in series_of_lists:
            if isinstance(lst, list):
                union.update(lst)
        return sorted(union)

    agg = (
        spec_all
        .groupby(["DOMAIN","SPEC_DOMAIN","JOIN_DOMAIN","VARIABLE"], dropna=False)
        .agg({
            "RAW_LIST_SPEC": union_lists,
            "RAW_INPUTS_SPEC": lambda s: list_to_str(sorted(set(",".join([x for x in s if x]).split(",")))) if len(s) else "",
            "ACTION_ORIG_SPEC": most_common_non_empty,
            "ACTION_NORM_SPEC": most_common_non_empty
        })
        .reset_index()
    )
    agg["RAW_INPUTS_SPEC"] = agg["RAW_LIST_SPEC"].apply(list_to_str)
    agg["KEY"] = (agg["JOIN_DOMAIN"].astype(str).str.strip() + "." +
                  agg["VARIABLE"].astype(str).str.strip()).str.lower()
    return dedupe_columns(agg)

def read_spec_all_sheets(spec_buf_or_path):
    """Read every sheet in the spec workbook as potential domains (flexible base spec)."""
    xls = pd.ExcelFile(spec_buf_or_path, engine=EXCEL_ENGINE)
    datasets = xls.sheet_names
    return read_spec_for_datasets(spec_buf_or_path, datasets)

# -------------------- Compare (Spec vs Spec) --------------------
def compare_spec_vs_spec(base_df: pd.DataFrame, cmp_df: pd.DataFrame, active_domains_cmp: list):
    # Merge universe of keys; orientation: compare spec as reference
    merged = base_df.merge(
        cmp_df, on="KEY", how="outer",
        suffixes=("_BASE","_CMP"), indicator=True
    )

    merged["JOIN_DOMAIN"] = coalesce_cols(merged, ["JOIN_DOMAIN_CMP","JOIN_DOMAIN_BASE"], default="")
    merged["SPEC_DOMAIN_CMP"] = coalesce_cols(merged, ["SPEC_DOMAIN_CMP","JOIN_DOMAIN"], default=merged["JOIN_DOMAIN"])
    merged["SPEC_DOMAIN_BASE"] = coalesce_cols(merged, ["SPEC_DOMAIN_BASE","JOIN_DOMAIN"], default=merged["JOIN_DOMAIN"])
    merged["DOMAIN"] = merged["JOIN_DOMAIN"]
    merged["VARIABLE"] = coalesce_cols(merged, ["VARIABLE_CMP","VARIABLE_BASE"], default="")

    statuses, raw_statuses, act_statuses = [], [], []
    miss_lists, extra_lists, sim_actions = [], [], []
    for _, row in merged.iterrows():
        in_base = row["_merge"] in ("both","left_only")
        in_cmp = row["_merge"] in ("both","right_only")

        base_raw = ensure_raw_list(row.get("RAW_LIST_SPEC_BASE", []))
        cmp_raw  = ensure_raw_list(row.get("RAW_LIST_SPEC_CMP", []))
        base_set, cmp_set = set(base_raw), set(cmp_raw)

        base_act = normalize_action(row.get("ACTION_NORM_SPEC_BASE", ""))
        cmp_act  = normalize_action(row.get("ACTION_NORM_SPEC_CMP", ""))

        sim_actions.append(similarity(base_act, cmp_act))

        if in_base and in_cmp:
            raw_equal = (base_set == cmp_set)
            act_equal = (base_act == cmp_act)

            missing = sorted(cmp_set - base_set)      # what base lacks vs compare
            extra   = sorted(base_set - cmp_set)      # what base has extra vs compare

            if raw_equal and act_equal:
                status = "Exact"; raw_status = "Exact"; act_status = "Exact"
            elif raw_equal and not act_equal:
                status = "RawOnlyMatch"; raw_status = "Exact"; act_status = "Mismatch"
            elif act_equal and not raw_equal:
                status = "ActionOnlyMatch"; raw_status = "Mismatch"; act_status = "Exact"
            else:
                status = "BothMismatch"; raw_status = "Mismatch"; act_status = "Mismatch"
        elif in_cmp and not in_base:
            status = "NotInBase"; raw_status = "NotInBase"; act_status = "NotInBase"
            missing = sorted(list(cmp_set)); extra = []
        elif in_base and not in_cmp:
            status = "NotInCompare"; raw_status = "NotInCompare"; act_status = "NotInCompare"
            missing = []; extra = sorted(list(base_set))
        else:
            status = "Unknown"; raw_status = "Unknown"; act_status = "Unknown"
            missing = []; extra = []

        statuses.append(status)
        raw_statuses.append(raw_status)
        act_statuses.append(act_status)
        miss_lists.append(missing)
        extra_lists.append(extra)

    merged["status"] = statuses
    merged["raw_status"] = raw_statuses
    merged["action_status"] = act_statuses
    merged["similarity_action"] = sim_actions

    # Details view
    details_cols = [
        "SPEC_DOMAIN_CMP","SPEC_DOMAIN_BASE","JOIN_DOMAIN","DOMAIN","VARIABLE",
        "RAW_INPUTS_SPEC_CMP","RAW_INPUTS_SPEC_BASE",
        "ACTION_ORIG_SPEC_CMP","ACTION_ORIG_SPEC_BASE",
        "status","raw_status","action_status","similarity_action"
    ]
    details_df = dedupe_columns(merged[details_cols].copy()).rename(
        columns={"SPEC_DOMAIN_CMP":"DOMAIN_COMPARE","SPEC_DOMAIN_BASE":"DOMAIN_BASE"}
    )

    # Raw diffs
    raw_diff = pd.DataFrame({
        "DOMAIN": merged["JOIN_DOMAIN"],
        "VARIABLE": merged["VARIABLE"],
        "missing_in_base_vs_compare": [list_to_str(x) for x in miss_lists],
        "extra_in_base_vs_compare":   [list_to_str(x) for x in extra_lists],
        "raw_status": merged["raw_status"],
        "action_status": merged["action_status"],
        "similarity_action": merged["similarity_action"]
    })

    # Action diffs
    act_diff = pd.DataFrame({
        "DOMAIN": merged["JOIN_DOMAIN"],
        "VARIABLE": merged["VARIABLE"],
        "action_compare": merged.get("ACTION_ORIG_SPEC_CMP", ""),
        "action_base": merged.get("ACTION_ORIG_SPEC_BASE", ""),
        "action_status": merged["action_status"],
        "similarity_action": merged["similarity_action"]
    })

    # Domain summary (relative to Compare Spec active domains)
    group_domain = "DOMAIN_COMPARE"
    details_df[group_domain] = details_df["DOMAIN_COMPARE"].fillna(details_df["JOIN_DOMAIN"])

    # Filter universe to active compare domains (+ always keep QNAM)
    active_norm = [normalize_text(d) for d in active_domains_cmp]
    active_mask = details_df["JOIN_DOMAIN"].isin(active_norm + ["qnam"])
    details_active = details_df[active_mask].copy()

    cmp_universe = (
        details_active[details_active["RAW_INPUTS_SPEC_CMP"].notna()]
        .groupby(group_domain)["VARIABLE"].nunique().rename("compare_var_count").reset_index()
    )
    exact_counts = (
        details_active[details_active["status"]=="Exact"]
        .groupby(group_domain)["VARIABLE"].nunique().rename("exact_var_count").reset_index()
    )
    rawonly_counts = (
        details_active[details_active["status"]=="RawOnlyMatch"]
        .groupby(group_domain)["VARIABLE"].nunique().rename("rawonly_var_count").reset_index()
    )
    actiononly_counts = (
        details_active[details_active["status"]=="ActionOnlyMatch"]
        .groupby(group_domain)["VARIABLE"].nunique().rename("actiononly_var_count").reset_index()
    )
    bothmm_counts = (
        details_active[details_active["status"]=="BothMismatch"]
        .groupby(group_domain)["VARIABLE"].nunique().rename("bothmismatch_var_count").reset_index()
    )
    notinbase_counts = (
        details_active[details_active["status"]=="NotInBase"]
        .groupby(group_domain)["VARIABLE"].nunique().rename("notinbase_var_count").reset_index()
    )
    notincompare_counts = (
        details_active[details_active["status"]=="NotInCompare"]
        .groupby(group_domain)["VARIABLE"].nunique().rename("notincompare_var_count").reset_index()
    )

    domain_summary = (
        pd.DataFrame({group_domain: sorted(details_active[group_domain].unique())})
        .merge(cmp_universe, on=group_domain, how="left")
        .merge(exact_counts, on=group_domain, how="left")
        .merge(rawonly_counts, on=group_domain, how="left")
        .merge(actiononly_counts, on=group_domain, how="left")
        .merge(bothmm_counts, on=group_domain, how="left")
        .merge(notinbase_counts, on=group_domain, how="left")
        .merge(notincompare_counts, on=group_domain, how="left")
        .fillna(0)
    ).rename(columns={group_domain: "DOMAIN"})

    # Accuracy: exact / compare
    domain_summary["accuracy_exact_pct"] = np.where(
        domain_summary["compare_var_count"] > 0,
        domain_summary["exact_var_count"] / domain_summary["compare_var_count"],
        0.0
    )

    # Coverage: (present in base) / compare = (compare - NotInBase) / compare
    matched_in_base = domain_summary["compare_var_count"] - domain_summary["notinbase_var_count"]
    domain_summary["coverage_base_vs_compare_pct"] = np.where(
        domain_summary["compare_var_count"] > 0,
        matched_in_base / domain_summary["compare_var_count"],
        0.0
    )

    # Overall KPIs
    total_cmp = int(domain_summary["compare_var_count"].sum())
    total_exact = int(domain_summary["exact_var_count"].sum())
    total_rawonly = int(domain_summary["rawonly_var_count"].sum())
    total_actiononly = int(domain_summary["actiononly_var_count"].sum())
    total_bothmm = int(domain_summary["bothmismatch_var_count"].sum())
    total_notinbase = int(domain_summary["notinbase_var_count"].sum())
    total_notincompare = int(domain_summary["notincompare_var_count"].sum())

    overall_df = pd.DataFrame({
        "metric": [
            "total_compare_vars","total_exact_matches","total_rawonly_matches","total_actiononly_matches",
            "total_both_mismatches","total_not_in_base","total_not_in_compare",
            "overall_accuracy_exact_pct","overall_coverage_base_vs_compare_pct"
        ],
        "value": [
            total_cmp, total_exact, total_rawonly, total_actiononly,
            total_bothmm, total_notinbase, total_notincompare,
            (total_exact / total_cmp) if total_cmp else 0.0,
            ((total_cmp - total_notinbase) / total_cmp) if total_cmp else 0.0
        ]
    })

    unmatched_in_base = details_active[details_active["status"]=="NotInBase"].copy()
    unmatched_in_compare = details_active[details_active["status"]=="NotInCompare"].copy()

    return details_df, details_active, domain_summary, overall_df, unmatched_in_base, unmatched_in_compare, raw_diff, act_diff

# -------------------- Excel writer with AutoFilter + Freeze --------------------
def write_excel_with_filters(base_spec_single, cmp_spec_single,
                             details_df, details_active, domain_summary, overall_df,
                             unmatched_in_base, unmatched_in_compare, raw_diff, act_diff):
    from openpyxl.utils import get_column_letter
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_name = f"spec_vs_spec_comparison_{ts}.xlsx"
    sheets = [
        ("variable_details_all", details_df),
        ("variable_details_active", details_active),
        ("domain_summary_active", domain_summary),
        ("unmatched_in_base", unmatched_in_base),
        ("unmatched_in_compare", unmatched_in_compare),
        ("raw_diff_details", raw_diff),
        ("action_diff_details", act_diff),
        ("base_spec_single", base_spec_single),
        ("compare_spec_single", cmp_spec_single),
        ("summary_overall", overall_df),
    ]
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine=EXCEL_ENGINE) as writer:
        for name, df in sheets:
            df.to_excel(writer, sheet_name=name, index=False)
        # Freeze & filters + modest autofit (same style as your app)
        for name, df in sheets:
            ws = writer.sheets[name]
            ws.freeze_panes = "A2"
            nrows = (len(df) + 1) or 1
            ncols = max(len(df.columns), 1)
            from openpyxl.utils import get_column_letter
            last_col_letter = get_column_letter(ncols)
            ws.auto_filter.ref = f"A1:{last_col_letter}{nrows}"
            for idx, col in enumerate(df.columns, start=1):
                max_len = max([len(str(col))] + [len(str(v)) for v in df[col].astype(str).head(200)])
                ws.column_dimensions[get_column_letter(idx)].width = min(max(10, max_len + 2), 60)
    buf.seek(0)
    return out_name, buf

# -------------------- UI --------------------
st.set_page_config(page_title="SDTM Spec vs Spec - Interactive", layout="wide")
st.title("SDTM Spec vs Spec - Interactive")
st.caption("Upload Base & Compare specs, TOC from Compare drives ACTIVE domains. Detailed domain & variable comparison on raw inputs and mapping action. Exports Excel with AutoFilter & frozen headers.")

with st.sidebar:
    st.header("Inputs")
    base_src = st.radio("Base Spec source", ["Upload", "Folder path"])
    cmp_src  = st.radio("Compare Spec source", ["Upload", "Folder path"])
    toc_sheet = st.text_input("TOC sheet name (Compare Spec)", value=DEFAULT_TOC)

    exclusions_input = st.text_input("Exclude datasets (comma)", value="TA,TE,TI,TV,TS,TD")
    exclusions = {normalize_text(x) for x in exclusions_input.split(",") if x.strip()}

    # Base file
    if base_src == "Upload":
        base_file = st.file_uploader("Upload Base Spec Excel (.xlsx)", type=["xlsx"], key="base")
    else:
        base_folder = st.text_input("Base Spec folder path", value="", key="base_folder")
        base_choice = None
        if base_folder and os.path.isdir(base_folder):
            xls_list = [f for f in os.listdir(base_folder) if f.lower().endswith(".xlsx")]
            base_choice = st.selectbox("Select base file", options=xls_list) if xls_list else None
        base_file = (os.path.join(base_folder, base_choice) if base_choice else None)

    # Compare file
    if cmp_src == "Upload":
        cmp_file = st.file_uploader("Upload Compare Spec Excel (.xlsx)", type=["xlsx"], key="cmp")
    else:
        cmp_folder = st.text_input("Compare Spec folder path", value="", key="cmp_folder")
        cmp_choice = None
        if cmp_folder and os.path.isdir(cmp_folder):
            xls_list = [f for f in os.listdir(cmp_folder) if f.lower().endswith(".xlsx")]
            cmp_choice = st.selectbox("Select compare file", options=xls_list) if xls_list else None
        cmp_file = (os.path.join(cmp_folder, cmp_choice) if cmp_choice else None)

    st.divider()
    include_inactive = st.checkbox("Include inactive domains in views", value=False)
    run_btn = st.button("Run Spec Comparison", use_container_width=True)

    st.divider()
    st.header("App Controls")
    st.caption("Stop or exit the app when you’re done.")
    if st.button("Stop run (soft)", use_container_width=True):
        st.warning("Run stopped. Server still running. Close CMD or press Ctrl+C to exit fully.")
        st.stop()
    confirm_exit = st.checkbox("Confirm exit")
    if st.button("Exit app (hard)", type="primary", disabled=not confirm_exit, use_container_width=True):
        st.success("Exiting the app...")
        os._exit(0)

tabs = st.tabs(["Summary", "Domain Accuracy", "Variable Details", "Unmatched", "Raw Diffs", "Action Diffs", "Spec Snapshots", "Export"])

if run_btn:
    try:
        # Prepare IO handles
        base_io = base_file if isinstance(base_file, io.BytesIO) else (open(base_file, "rb") if isinstance(base_file, str) and os.path.isfile(base_file) else None)
        cmp_io  = cmp_file  if isinstance(cmp_file, io.BytesIO)  else (open(cmp_file,  "rb") if isinstance(cmp_file,  str) and os.path.isfile(cmp_file)  else None)
        if not base_io or not cmp_io:
            st.error("Please provide valid Base Spec and Compare Spec Excel files.")
        else:
            with st.spinner("Reading ACTIVE domains from Compare Spec TOC..."):
                active_cmp = read_active_datasets(cmp_io, toc_sheet, exclusions)

            # reset buffers to start (important for BytesIO handles)
            if hasattr(base_io, "seek"): base_io.seek(0)
            if hasattr(cmp_io, "seek"):  cmp_io.seek(0)

            with st.spinner("Building consolidated specs (Base & Compare)..."):
                cmp_spec_single = read_spec_for_datasets(cmp_io, active_cmp)   # active compare domains only
                base_spec_single_all = read_spec_all_sheets(base_io)           # read all sheets in base
                # Filter base to compare's active JOIN_DOMAINs + QNAM
                active_norm = [normalize_text(d) for d in active_cmp]
                base_spec_single = base_spec_single_all[
                    base_spec_single_all["JOIN_DOMAIN"].isin(active_norm + ["qnam"])
                ].copy()

            with st.spinner("Comparing Spec vs Spec..."):
                details_df, details_active, domain_summary, overall_df, unmatched_in_base, unmatched_in_compare, raw_diff, act_diff = compare_spec_vs_spec(
                    base_spec_single, cmp_spec_single, active_cmp
                )

            # Toggle inactive views in UI
            view_df = details_df if include_inactive else details_active

            # ---- Summary tab ----
            with tabs[0]:
                st.subheader("Overall KPIs (relative to Compare Spec active domains)")
                overall = dict(zip(overall_df["metric"], overall_df["value"]))
                col1, col2, col3, col4, col5, col6 = st.columns(6)
                col1.metric("Compare Vars", int(overall.get("total_compare_vars", 0)))
                col2.metric("Exact Matches", int(overall.get("total_exact_matches", 0)))
                col3.metric("Raw-only Matches", int(overall.get("total_rawonly_matches", 0)))
                col4.metric("Action-only Matches", int(overall.get("total_actiononly_matches", 0)))
                col5.metric("Accuracy (Exact)", f"{float(overall.get('overall_accuracy_exact_pct', 0.0)):.2%}")
                col6.metric("Coverage (Base vs Compare)", f"{float(overall.get('overall_coverage_base_vs_compare_pct', 0.0)):.2%}")
                st.subheader("Overall Table")
                st.dataframe(overall_df, use_container_width=True)

            # ---- Domain Accuracy tab ----
            with tabs[1]:
                st.subheader("Domain-wise Summary (Active Compare Domains)")
                st.dataframe(domain_summary, use_container_width=True)
                st.divider()
                st.subheader("Accuracy (Exact / Compare) by Domain")
                fig, ax = plt.subplots(figsize=(10,4))
                ds = domain_summary.sort_values("accuracy_exact_pct", ascending=False)
                ax.bar(ds["DOMAIN"], ds["accuracy_exact_pct"])
                ax.set_title("Exact Accuracy by Domain")
                ax.set_ylabel("Accuracy")
                ax.set_xticklabels(ds["DOMAIN"], rotation=45, ha="right")
                ax.grid(axis="y", alpha=0.3)
                st.pyplot(fig)

            # ---- Variable Details tab ----
            with tabs[2]:
                st.subheader("Variable-level Details")
                st.dataframe(view_df, use_container_width=True)

            # ---- Unmatched tab ----
            with tabs[3]:
                c1, c2 = st.columns(2)
                with c1:
                    st.subheader("Present in Compare, missing in Base (NotInBase)")
                    st.dataframe(unmatched_in_base, use_container_width=True)
                with c2:
                    st.subheader("Present in Base, missing in Compare (NotInCompare)")
                    st.dataframe(unmatched_in_compare, use_container_width=True)

            # ---- Raw Diffs tab ----
            with tabs[4]:
                st.subheader("Raw Input Differences (Base vs Compare)")
                st.dataframe(raw_diff, use_container_width=True)

            # ---- Action Diffs tab ----
            with tabs[5]:
                st.subheader("Mapping Action Differences")
                st.dataframe(act_diff, use_container_width=True)

            # ---- Spec Snapshots tab ----
            with tabs[6]:
                st.subheader("Consolidated Base Spec (filtered to active compare domains)")
                st.dataframe(base_spec_single, use_container_width=True)
                st.subheader("Consolidated Compare Spec (active only)")
                st.dataframe(cmp_spec_single, use_container_width=True)

            # ---- Export tab ----
            with tabs[7]:
                st.subheader("Export to Excel with AutoFilter")
                out_name, out_buf = write_excel_with_filters(
                    base_spec_single, cmp_spec_single,
                    details_df, details_active, domain_summary, overall_df,
                    unmatched_in_base, unmatched_in_compare, raw_diff, act_diff
                )
                st.download_button(
                    label=f"Download: {out_name}",
                    data=out_buf,
                    file_name=out_name,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
                st.info("The Excel file includes AutoFilter and frozen headers on all sheets.")

    except Exception as e:
        st.error(f"ERROR: {e}")
