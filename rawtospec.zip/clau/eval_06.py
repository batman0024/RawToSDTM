
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SDTM Mapping Accuracy Checker (Assigned-as-Standard)

- Treat the assigned workbook as the gold standard.
- Accuracy = Exact matches / assigned unique variables (domain-wise & overall).
- Flags variables mapped in assigned but not in spec (NotInSpec).
- TOC-driven active dataset filtering on the spec side; excludes TA/TE/TI/TV/TS/TD.
- Preserves QNAM (row-level SPEC_DOMAIN from spec sheet Dataset/Dataset*; assigned can provide SPEC_DOMAIN).
- Key = JOIN_DOMAIN + '.' + VARIABLE, where JOIN_DOMAIN = 'qnam' if SPEC_DOMAIN == 'qnam', else DOMAIN.
- Set-based raw comparison (order-insensitive) with per-variable diffs.
- Progress bars; suppress openpyxl data-validation warnings; no rule logic.

Run:
    python sdtm_accuracy_assigned_standard.py "spec.xlsx" "assigned.xlsx"
"""

import sys
import warnings
import datetime as dt
import re
import numpy as np
import pandas as pd

# Progress bar
try:
    from tqdm.auto import tqdm
    TQDM_AVAILABLE = True
except Exception:
    TQDM_AVAILABLE = False

# Suppress only openpyxl data-validation warnings
warnings.filterwarnings(
    "ignore",
    message="Data Validation extension is not supported and will be removed",
    category=UserWarning,
    module="openpyxl"
)

EXCEL_ENGINE   = "openpyxl"
ASSIGNED_SHEET = "assigned_final_concat"
TOC_SHEET      = "TOC"
EXCLUDE_DATASETS = {d.lower() for d in ["TA", "TE", "TI", "TV", "TS", "TD"]}

# ---------- Helpers ----------
def normalize_text(x: str) -> str:
    if pd.isna(x):
        return ""
    s = re.sub(r"\s+", " ", str(x).strip())
    return s.lower()

def split_to_list(x: str) -> list:
    if x is None or (isinstance(x, float) and np.isnan(x)) or pd.isna(x) or str(x).strip() == "":
        return []
    s = str(x)
    s = s.replace("\r", " ").replace("\n", ",")
    s = s.replace("|", ",").replace(";", ",").replace("+", ",")
    parts = [p.strip() for p in s.split(",") if p.strip() != ""]
    parts = sorted(set(p.lower() for p in parts))
    return parts

def ensure_raw_list(x):
    if isinstance(x, list):
        return x
    if x is None or (isinstance(x, float) and np.isnan(x)) or pd.isna(x):
        return []
    return split_to_list(str(x))

def list_to_str(lst: list) -> str:
    return ",".join(lst)

def dedupe_columns(df: pd.DataFrame) -> pd.DataFrame:
    return df.loc[:, ~df.columns.duplicated()]

def auto_rename_columns(df: pd.DataFrame, alias_map) -> pd.DataFrame:
    df = dedupe_columns(df)
    colmap = {}
    lower_cols = {c.lower(): c for c in df.columns}
    existing = set(df.columns)
    for canonical, aliases in alias_map.items():
        if canonical in existing:
            continue
        chosen = None
        for a in aliases:
            if a.lower() in lower_cols:
                chosen = lower_cols[a.lower()]
                break
        if not chosen:
            for lc, orig in lower_cols.items():
                if any(a.lower() in lc for a in aliases):
                    chosen = orig
                    break
        if chosen:
            colmap[chosen] = canonical
    df = df.rename(columns=colmap)
    return dedupe_columns(df)

def canonical_token(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower().strip())

def resolve_sheet_name(xls: pd.ExcelFile, dataset: str) -> str:
    if not dataset:
        return None
    ds = str(dataset).strip()
    ds_lower = ds.lower()
    ds_tok = canonical_token(ds)
    for s in xls.sheet_names:
        if s.strip().lower() == ds_lower:
            return s
    tokens = {s: canonical_token(s) for s in xls.sheet_names}
    for s, tok in tokens.items():
        if tok == ds_tok:
            return s
    for s, tok in tokens.items():
        if ds_tok and ds_tok in tok:
            return s
    return None

def make_key(join_domain: str, variable: str) -> str:
    return f"{(join_domain or '').strip()}.{(variable or '').strip()}".lower()

def coalesce_cols(df: pd.DataFrame, cols: list, default=None) -> pd.Series:
    s = pd.Series([np.nan] * len(df), index=df.index)
    for c in cols:
        if c in df.columns:
            s = s.combine_first(df[c])
    if default is not None:
        s = s.fillna(default)
    return s

# ---------- Aliases ----------
TOC_ALIAS = {
    "ACTIVE":  ["active", "is active", "include", "enabled", "flag"],
    "DATASET": ["dataset", "sdtm dataset", "domain", "table", "target dataset"]
}

SPEC_ALIAS_DOMAIN = {
    "VARIABLE":       ["variable", "sdtm variable", "target variable", "variable name", "sdtm_var"],
    "INPUT_VARIABLE": ["input_variable", "input variable", "raw inputs", "raw variables",
                       "source variables", "source variable", "raw var", "raw fields",
                       "source columns", "source fields", "raw", "src variables"],
    "DATASET":        ["dataset", "dataset*", "domain", "sdtm dataset", "target dataset"]
}

ASSIGNED_ALIAS = {
    "SPEC_DOMAIN": ["spec_domain"],
    "VARIABLE":    ["sdtm_variable", "variable", "sdtm var", "sdtm variable name"],
    "RAW_INPUTS":  ["raw_variables_assigned", "raw inputs", "raw_inputs", "source variables",
                    "raw_inputs_concat", "source_vars_concat", "raw", "input_variable"],
    "DOMAIN":      ["domain", "dataset", "sdtm domain", "sdtm dataset", "target domain"]
}

# ---------- Read ACTIVE datasets from TOC ----------
def read_active_datasets(spec_path: str) -> list:
    toc = pd.read_excel(spec_path, sheet_name=TOC_SHEET, engine=EXCEL_ENGINE, dtype=object)
    toc = auto_rename_columns(toc, TOC_ALIAS)
    if "ACTIVE" not in toc.columns or "DATASET" not in toc.columns:
        raise ValueError("TOC sheet must contain ACTIVE and DATASET columns.")
    toc["ACTIVE"]  = toc["ACTIVE"].apply(normalize_text)
    toc["DATASET"] = toc["DATASET"].apply(lambda s: str(s).strip())
    active = toc[toc["ACTIVE"].isin(["y", "yes", "true", "1"])] ["DATASET"].tolist()
    active_filtered = [ds for ds in active if normalize_text(ds) not in EXCLUDE_DATASETS]
    if not active_filtered:
        raise ValueError("No active datasets after exclusions (TA/TE/TI/TV/TS/TD).")
    return active_filtered

# ---------- Read & build spec for ACTIVE datasets ----------
def read_spec_active(spec_path: str, active_datasets: list) -> pd.DataFrame:
    xls = pd.ExcelFile(spec_path, engine=EXCEL_ENGINE)
    frames = []

    ds_iter = active_datasets
    if TQDM_AVAILABLE:
        ds_iter = tqdm(active_datasets, desc="Reading active domain sheets", unit="sheet")

    for dataset in ds_iter:
        sheet = resolve_sheet_name(xls, dataset)
        if not sheet:
            continue

        df = pd.read_excel(spec_path, sheet_name=sheet, engine=EXCEL_ENGINE, dtype=object)
        if df.empty:
            continue

        df = auto_rename_columns(df, SPEC_ALIAS_DOMAIN)

        for col in ["VARIABLE", "INPUT_VARIABLE"]:
            if col not in df.columns:
                df[col] = np.nan

        df["VARIABLE"] = df["VARIABLE"].apply(normalize_text)

        df["RAW_LIST_SPEC"]   = df["INPUT_VARIABLE"].apply(split_to_list)
        df["RAW_LIST_SPEC"]   = df["RAW_LIST_SPEC"].apply(ensure_raw_list)
        df["RAW_INPUTS_SPEC"] = df["RAW_LIST_SPEC"].apply(list_to_str)

        dom_norm = normalize_text(dataset)
        df["DOMAIN"] = dom_norm

        # Row-level SPEC_DOMAIN from the sheet's dataset column
        if "DATASET" in df.columns:
            df["DATASET_NORM"] = df["DATASET"].apply(normalize_text)
            df["SPEC_DOMAIN"]  = np.where(df["DATASET_NORM"].eq("qnam"), "qnam", dom_norm)
        else:
            df["SPEC_DOMAIN"]  = dom_norm

        # JOIN_DOMAIN key on spec side (respect QNAM)
        df["JOIN_DOMAIN"] = np.where(df["SPEC_DOMAIN"].eq("qnam"), "qnam", df["DOMAIN"])

        df = df["DOMAIN SPEC_DOMAIN JOIN_DOMAIN VARIABLE RAW_INPUTS_SPEC RAW_LIST_SPEC".split()].copy()
        df = df[(df["JOIN_DOMAIN"] != "") & (df["VARIABLE"] != "")]
        frames.append(df)

    if not frames:
        raise ValueError("No usable rows found in active datasets' sheets.")

    spec_all = pd.concat(frames, ignore_index=True)

    def union_lists(series_of_lists):
        union = set()
        for lst in series_of_lists:
            if isinstance(lst, list):
                union.update(lst)
        return sorted(union)

    agg = (
        spec_all
        .groupby(["DOMAIN", "SPEC_DOMAIN", "JOIN_DOMAIN", "VARIABLE"], dropna=False)
        .agg({"RAW_LIST_SPEC": union_lists})
        .reset_index()
    )
    agg["RAW_INPUTS_SPEC"] = agg["RAW_LIST_SPEC"].apply(list_to_str)
    agg["KEY"] = (agg["JOIN_DOMAIN"].astype(str).str.strip() + "." + agg["VARIABLE"].astype(str).str.strip()).str.lower()
    return dedupe_columns(agg)

# ---------- Read assigned (supports SPEC_DOMAIN / SDTM_VARIABLE / RAW_VARIABLES_ASSIGNED) ----------
def read_assigned(assigned_path: str, assigned_sheet: str = ASSIGNED_SHEET) -> pd.DataFrame:
    df = pd.read_excel(assigned_path, sheet_name=assigned_sheet, engine=EXCEL_ENGINE, dtype=object)
    if df.empty:
        raise ValueError(f"Assigned sheet '{assigned_sheet}' is empty or not found.")
    df = auto_rename_columns(df, ASSIGNED_ALIAS)

    for col in ["SPEC_DOMAIN", "DOMAIN", "VARIABLE", "RAW_INPUTS"]:
        if col not in df.columns:
            df[col] = np.nan

    # normalize
    df["SPEC_DOMAIN"] = df["SPEC_DOMAIN"].apply(normalize_text)
    df["DOMAIN"]      = df["DOMAIN"].apply(normalize_text)
    df["VARIABLE"]    = df["VARIABLE"].apply(normalize_text)

    # raw list
    df["RAW_LIST_ASSIGNED"]   = df["RAW_INPUTS"].apply(split_to_list)
    df["RAW_LIST_ASSIGNED"]   = df["RAW_LIST_ASSIGNED"].apply(ensure_raw_list)
    df["RAW_INPUTS_ASSIGNED"] = df["RAW_LIST_ASSIGNED"].apply(list_to_str)

    # JOIN_DOMAIN key on assigned side (respect QNAM; else domain)
    df["JOIN_DOMAIN"] = np.where(df["SPEC_DOMAIN"].eq("qnam"), "qnam", df["DOMAIN"])

    df = df[(df["JOIN_DOMAIN"] != "") & (df["VARIABLE"] != "")]
    df["KEY"] = (df["JOIN_DOMAIN"].astype(str).str.strip() + "." + df["VARIABLE"].astype(str).str.strip()).str.lower()
    return dedupe_columns(df)

# ---------- Compare (Assigned-as-Standard) ----------
def compare_spec_vs_assigned(spec_df: pd.DataFrame, assigned_df: pd.DataFrame):
    merged = spec_df.merge(
        assigned_df, on="KEY", how="outer",
        suffixes=("_SPEC", "_ASSIGNED"), indicator=True
    )

    # Coalesce JOIN_DOMAIN and SPEC_DOMAIN from both sides
    merged["JOIN_DOMAIN"] = coalesce_cols(merged, ["JOIN_DOMAIN_SPEC", "JOIN_DOMAIN_ASSIGNED"], default="")
    merged["SPEC_DOMAIN"] = coalesce_cols(merged, ["SPEC_DOMAIN_SPEC", "SPEC_DOMAIN_ASSIGNED"], default=merged["JOIN_DOMAIN"])
    merged["DOMAIN"]      = coalesce_cols(merged, ["DOMAIN_SPEC", "DOMAIN_ASSIGNED"], default="")
    merged["VARIABLE"]    = coalesce_cols(merged, ["VARIABLE_SPEC", "VARIABLE_ASSIGNED"], default="")

    # Iterate with progress bar
    idx_iter = merged.index
    if TQDM_AVAILABLE:
        idx_iter = tqdm(merged.index, desc="Comparing variables (assigned standard)", unit="var")

    statuses, raw_set_statuses = [], []
    missing_lists, extra_lists = [], []

    for i in idx_iter:
        row = merged.loc[i]
        in_spec     = row["_merge"] in ("both", "left_only")
        in_assigned = row["_merge"] in ("both", "right_only")

        spec_raw_list     = ensure_raw_list(row.get("RAW_LIST_SPEC", []))
        assigned_raw_list = ensure_raw_list(row.get("RAW_LIST_ASSIGNED", []))

        spec_set     = set(spec_raw_list)
        assigned_set = set(assigned_raw_list)

        if in_assigned and in_spec:
            if spec_set == assigned_set:
                raw_set_status = "Exact"; missing = []; extra = []
            else:
                # Assigned-as-standard: missing items are assigned - spec
                missing = sorted(assigned_set - spec_set)
                # Extra items present in spec beyond assigned
                extra   = sorted(spec_set - assigned_set)
                raw_set_status = "Mismatch"
            status = "Exact" if raw_set_status == "Exact" else "Mismatch"
        elif in_assigned and not in_spec:
            raw_set_status = "NotInSpec"; missing = sorted(list(assigned_set)); extra = []
            status = "NotInSpec"  # GOLD standard has a mapping not present in spec
        elif in_spec and not in_assigned:
            raw_set_status = "NotMappedAssigned"; missing = []; extra = sorted(list(spec_set))
            status = "NotMappedAssigned"  # Spec has mapping not present in GOLD standard
        else:
            raw_set_status = "Unknown"; missing = []; extra = []
            status = "Unknown"

        raw_set_statuses.append(raw_set_status)
        statuses.append(status)
        missing_lists.append(missing)
        extra_lists.append(extra)

    merged["raw_set_status"] = raw_set_statuses
    merged["match_status"]   = statuses
    merged["accuracy_flag"]  = (merged["match_status"] == "Exact").astype(int)

    # Details (assigned standard)
    details_cols = [
        "SPEC_DOMAIN",
        "JOIN_DOMAIN", "DOMAIN", "VARIABLE",
        "RAW_INPUTS_SPEC",
        "RAW_INPUTS_ASSIGNED",
        "raw_set_status", "match_status", "accuracy_flag"
    ]
    details_df = dedupe_columns(merged[details_cols].copy())

    raw_diff = pd.DataFrame({
        "SPEC_DOMAIN": merged["SPEC_DOMAIN"],
        "JOIN_DOMAIN": merged["JOIN_DOMAIN"],
        "DOMAIN": merged["DOMAIN"],
        "VARIABLE": merged["VARIABLE"],
        "missing_in_spec_vs_assigned": [list_to_str(x) for x in missing_lists],  # what assigned expects but spec lacks
        "extra_in_spec_vs_assigned":   [list_to_str(x) for x in extra_lists],    # what spec has beyond assigned
        "raw_set_status": merged["raw_set_status"],
        "match_status":   merged["match_status"]
    })

    # --- Assigned-based domain summary ---
    group_domain = "SPEC_DOMAIN"

    # Assigned universe per domain
    assigned_universe = (
        details_df[details_df["RAW_INPUTS_ASSIGNED"].notna()]
        .groupby(group_domain)["VARIABLE"].nunique()
        .rename("assigned_var_count").reset_index()
    )

    # Exact matches counted against assigned
    exact_counts = (
        details_df[details_df["match_status"] == "Exact"]
        .groupby(group_domain)["VARIABLE"].nunique()
        .rename("exact_var_count").reset_index()
    )

    # NotInSpec: present in assigned but not in spec
    not_in_spec_counts = (
        details_df[details_df["match_status"] == "NotInSpec"]
        .groupby(group_domain)["VARIABLE"].nunique()
        .rename("not_in_spec_var_count").reset_index()
    )

    # Mismatch: present in both but raw sets differ
    mismatch_counts = (
        details_df[details_df["match_status"] == "Mismatch"]
        .groupby(group_domain)["VARIABLE"].nunique()
        .rename("mismatch_var_count").reset_index()
    )

    domain_summary = (
        pd.DataFrame({group_domain: sorted(details_df[group_domain].unique())})
        .merge(assigned_universe, on=group_domain, how="left")
        .merge(exact_counts, on=group_domain, how="left")
        .merge(not_in_spec_counts, on=group_domain, how="left")
        .merge(mismatch_counts, on=group_domain, how="left")
        .fillna(0)
    ).rename(columns={group_domain: "DOMAIN"})

    # Accuracy (assigned-standard): exact / assigned
    domain_summary["accuracy_pct_assigned"] = np.where(
        domain_summary["assigned_var_count"] > 0,
        domain_summary["exact_var_count"] / domain_summary["assigned_var_count"],
        0.0
    )
    # Spec coverage vs assigned: (matched in both) / assigned
    matched_in_both = domain_summary["assigned_var_count"] - domain_summary["not_in_spec_var_count"]
    domain_summary["coverage_pct_spec_vs_assigned"] = np.where(
        domain_summary["assigned_var_count"] > 0,
        matched_in_both / domain_summary["assigned_var_count"],
        0.0
    )

    # Overall
    total_assigned = int(domain_summary["assigned_var_count"].sum())
    total_exact    = int(domain_summary["exact_var_count"].sum())
    total_notinspec= int(domain_summary["not_in_spec_var_count"].sum())
    total_mismatch = int(domain_summary["mismatch_var_count"].sum())

    overall_accuracy = (total_exact / total_assigned) if total_assigned else 0.0
    overall_coverage = ((total_assigned - total_notinspec) / total_assigned) if total_assigned else 0.0

    overall_df = pd.DataFrame({
        "metric": [
            "total_assigned_vars", "total_exact_matches", "total_not_in_spec",
            "total_mismatch", "overall_accuracy_pct_assigned", "overall_coverage_pct_spec_vs_assigned"
        ],
        "value": [
            total_assigned, total_exact, total_notinspec,
            total_mismatch, overall_accuracy, overall_coverage
        ]
    })

    unmatched_in_spec     = details_df[details_df["match_status"] == "NotMappedAssigned"].copy()
    unmatched_in_assigned = details_df[details_df["match_status"] == "NotInSpec"].copy()

    return details_df, domain_summary, overall_df, unmatched_in_spec, unmatched_in_assigned, raw_diff

# ---------- Report writer ----------
def write_report(spec_single, details_df, domain_summary, overall_df, unmatched_in_spec, unmatched_in_assigned, raw_diff):
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = f"mapping_accuracy_assigned_standard_{ts}.xlsx"
    with pd.ExcelWriter(out_path, engine=EXCEL_ENGINE) as writer:
        details_df.to_excel(writer, sheet_name="accuracy_by_variable", index=False)
        domain_summary.to_excel(writer, sheet_name="accuracy_by_domain", index=False)
        unmatched_in_spec.to_excel(writer, sheet_name="unmatched_in_spec", index=False)
        unmatched_in_assigned.to_excel(writer, sheet_name="unmatched_in_assigned", index=False)
        raw_diff.to_excel(writer, sheet_name="raw_diff_details", index=False)
        spec_single.to_excel(writer, sheet_name="spec_single", index=False)
        overall_df.to_excel(writer, sheet_name="summary_overall", index=False)
    return out_path

# ---------- Main ----------
def main():
    if len(sys.argv) < 3:
        print("Usage: python sdtm_accuracy_assigned_standard.py \"spec.xlsx\" \"assigned.xlsx\"")
        sys.exit(1)

    spec_path     = sys.argv[1]
    assigned_path = sys.argv[2]

    # Read active datasets from TOC (spec only)
    active_datasets = read_active_datasets(spec_path)

    # Build spec for ACTIVE datasets
    spec_single = read_spec_active(spec_path, active_datasets)

    # Read assigned (gold standard)
    assigned_df = read_assigned(assigned_path, ASSIGNED_SHEET)

    # Filter assigned to ACTIVE join domains + always keep QNAM
    active_norm = [normalize_text(d) for d in active_datasets]
    assigned_df = assigned_df[assigned_df["JOIN_DOMAIN"].isin(active_norm + ["qnam"])].copy()

    # Compare (assigned standard)
    details_df, domain_summary, overall_df, unmatched_in_spec, unmatched_in_assigned, raw_diff = compare_spec_vs_assigned(
        spec_single, assigned_df
    )

    # Write report
    out_path = write_report(spec_single, details_df, domain_summary, overall_df, unmatched_in_spec, unmatched_in_assigned, raw_diff)

    # Console summary (assigned standard)
    print("\n=== Domain-wise Accuracy (Assigned Standard) ===")
    for _, r in domain_summary.sort_values("DOMAIN").iterrows():
        print(
            f"{r['DOMAIN']}: assigned={int(r['assigned_var_count'])}, "
            f"exact={int(r['exact_var_count'])}, not_in_spec={int(r['not_in_spec_var_count'])}, mismatch={int(r['mismatch_var_count'])}, "
            f"accuracy(assigned)={r['accuracy_pct_assigned']:.2%}, coverage(spec vs assigned)={r['coverage_pct_spec_vs_assigned']:.2%}"
        )

    overall = dict(zip(overall_df["metric"], overall_df["value"]))
    print("\n=== Overall (Assigned Standard) ===")
    print(f"Total Assigned Vars: {int(overall['total_assigned_vars'])}")
    print(f"Total Exact Matches: {int(overall['total_exact_matches'])}")
    print(f"Total Not In Spec: {int(overall['total_not_in_spec'])}")
    print(f"Total Mismatch: {int(overall['total_mismatch'])}")
    print(f"Overall Accuracy (Assigned): {float(overall['overall_accuracy_pct_assigned']):.2%}")
    print(f"Overall Coverage (Spec vs Assigned): {float(overall['overall_coverage_pct_spec_vs_assigned']):.2%}")
    print(f"\nReport written to: {out_path}\n")

if __name__ == "__main__":
    pd.set_option("display.max_columns", 200)
    pd.set_option("display.width", 200)
    main()
