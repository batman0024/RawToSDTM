#!/usr/bin/env python3
"""
Raw→SDTM matching with spec write-back — preserves original Excel formatting.

**Updates v0.18 (hotfix):**
- **Preserve the input spec extension** when saving the updated workbook:
  - If input is `.xlsx` → output is `.xlsx`
  - If input is `.xlsm` → output is `.xlsm`
- Use `keep_vba=True` **only for `.xlsm`** specs; otherwise `keep_vba=False`.
- All other functionality remains from v0.17.
"""
from __future__ import annotations
import sys
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import pandas as pd
import numpy as np
from difflib import SequenceMatcher
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except Exception:
    TQDM_AVAILABLE = False
try:
    import pyreadstat
    PYREADSTAT_AVAILABLE = True
except Exception:
    PYREADSTAT_AVAILABLE = False
try:
    from openpyxl import load_workbook
    OPENPYXL_AVAILABLE = True
except Exception:
    OPENPYXL_AVAILABLE = False

THRESHOLD = 0.92
CONCAT_ORDER = "alpha"
DEDUP = True
MASTER_PATH = Path("master_mapping.xlsx")
DEFAULT_SPEC_PATH = Path("spec/SDTMIGV3.3 Mapping Specifications-CORE-define21-V1.2.xlsx")
SUFFIX_EQUIV = {"MM", "DD", "YYYY", "RAW", "STD"}

# ---------------------------------------------------------------------------- #
def timestamp_suffix() -> str:
    return datetime.now().strftime("_%Y%m%d_%H%M")

def derive_prefix_from_input(input_path: Path) -> str:
    stem = input_path.stem
    prefix = stem.split("_", 1)[0] if "_" in stem else stem
    prefix = re.sub(r"[^A-Za-z0-9]+", "_", prefix).strip("_")
    return prefix or "input"

def ensure_output_dir() -> Path:
    out_dir = Path("output")
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir

# ----------------------------- Normalization utils ---------------------------- #
def _norm(s: str) -> str:
    s = re.sub(r"[^\w]", "_", str(s))
    s = re.sub(r"_+", "_", s)
    return s.upper().strip("_")

def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()

def parse_raw_token(token: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    if token is None:
        return None, None
    s = str(token).strip().upper()
    parts = [p for p in re.split(r"[.\s:]\+", s) if p]
    if len(parts) >= 3 and parts[0] == "RAW":
        return parts[1], parts[2]
    if len(parts) == 2 and re.fullmatch(r"[A-Z]{2,3}", parts[0]):
        return parts[0], parts[1]
    if len(parts) == 1:
        return None, parts[0]
    for i in range(len(parts) - 1):
        dom, var = parts[i], parts[i + 1]
        if re.fullmatch(r"[A-Z]{2,3}", dom):
            return dom, var
    return None, parts[-1]

# ------------------------------- Master loader -------------------------------- #
def load_master_mapping(master_xlsx: Path) -> pd.DataFrame:
    df = pd.read_excel(master_xlsx, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]
    for col in ["DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE", "MAPPING_ACTION"]:
        if col not in df.columns:
            df[col] = None
    if DEDUP:
        df = df.drop_duplicates(subset=["DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE", "MAPPING_ACTION"]) 
    df["DOMAIN"] = df["DOMAIN"].astype(str).str.strip()
    df["SDTM_VARIABLE"] = df["SDTM_VARIABLE"].astype(str).str.strip()
    df["RAW_VARIABLE"] = df["RAW_VARIABLE"].apply(lambda x: str(x).strip() if pd.notna(x) else None)
    df = df.sort_values(["DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE"]).reset_index(drop=True)
    return df

# ---------------------- Raw loader (registry or workbook) --------------------- #
def build_raw_registry_from_workbook(raw_xlsx: Path) -> pd.DataFrame:
    xl = pd.ExcelFile(raw_xlsx, engine="openpyxl")
    try:
        reg = pd.read_excel(raw_xlsx, sheet_name=0, engine="openpyxl")
        reg.columns = [str(c).strip() for c in reg.columns]
        lower = [c.lower() for c in reg.columns]
        if ("raw_variable" in lower) and (("raw dataset" in lower) or ("raw_dataset" in lower)) and ("variable" in lower):
            ren = {}
            for c in reg.columns:
                lc = c.lower()
                if lc in ("raw dataset", "raw_dataset"): ren[c] = "RAW_DATASET"
                elif lc == "raw_variable": ren[c] = "RAW_VARIABLE"
                elif lc == "variable": ren[c] = "VARIABLE"
                elif lc == "label": ren[c] = "LABEL"
                elif lc == "format": ren[c] = "FORMAT"
            reg = reg.rename(columns=ren)
            for opt in ["LABEL", "FORMAT"]:
                if opt not in reg.columns: reg[opt] = None
            reg["RAW_DATASET_UP"] = reg["RAW_DATASET"].astype(str).str.upper()
            reg["VARIABLE_UP"] = reg["VARIABLE"].astype(str).str.upper()
            reg["RAW_VARIABLE_UP"] = reg["RAW_VARIABLE"].astype(str).str.upper()
            reg["PAIR"] = reg["RAW_DATASET_UP"] + "." + reg["VARIABLE_UP"]
            reg["SHEET_COL_ORIG"] = reg["RAW_DATASET"].astype(str) + "." + reg["VARIABLE"].astype(str)
            return reg
    except Exception:
        pass
    rows = []
    for sheet in xl.sheet_names:
        try:
            df0 = pd.read_excel(raw_xlsx, sheet_name=sheet, nrows=0, engine="openpyxl")
        except Exception:
            df0 = pd.DataFrame()
        cols = [str(c).strip() for c in df0.columns]
        for col in cols:
            raw_var = f"RAW.{sheet}.{col}"
            rows.append({"RAW_VARIABLE": raw_var, "RAW_DATASET": sheet, "VARIABLE": col})
    if not rows:
        raise ValueError("Unable to read raw workbook.")
    reg = pd.DataFrame(rows)
    for opt in ["LABEL", "FORMAT"]: reg[opt] = None
    reg["RAW_DATASET_UP"] = reg["RAW_DATASET"].astype(str).str.upper()
    reg["VARIABLE_UP"] = reg["VARIABLE"].astype(str).str.upper()
    reg["RAW_VARIABLE_UP"] = reg["RAW_VARIABLE"].astype(str).str.upper()
    reg["PAIR"] = reg["RAW_DATASET_UP"] + "." + reg["VARIABLE_UP"]
    reg["SHEET_COL_ORIG"] = reg["RAW_DATASET"].astype(str) + "." + reg["VARIABLE"].astype(str)
    return reg

# ---------------------------- Matching engine --------------------------------- #
def find_candidates(var_hint: Optional[str], domain_hint: Optional[str], raw_reg: pd.DataFrame,
                    top_k: int = 5, threshold: float = THRESHOLD) -> List[Tuple[str, str, float, str]]:
    if not var_hint: return []
    vh_norm = _norm(var_hint)
    candidates: List[Tuple[str, str, float, str]] = []
    pool_dom = raw_reg[raw_reg["RAW_DATASET_UP"] == (domain_hint or "")] if domain_hint else pd.DataFrame()
    if domain_hint and not pool_dom.empty:
        exact = pool_dom[pool_dom["VARIABLE_UP"] == var_hint]
        for _, mr in exact.iterrows(): candidates.append((mr["RAW_DATASET"], mr["VARIABLE"], 0.99, "case"))
        pool_dom = pool_dom.copy(); pool_dom["VAR_NORM"] = pool_dom["VARIABLE"].apply(_norm)
        eq = pool_dom[pool_dom["VAR_NORM"] == vh_norm]
        for _, mr in eq.iterrows(): candidates.append((mr["RAW_DATASET"], mr["VARIABLE"], 0.98, "norm"))
    glob_case = raw_reg[raw_reg["VARIABLE_UP"] == var_hint]
    for _, mr in glob_case.iterrows(): candidates.append((mr["RAW_DATASET"], mr["VARIABLE"], 0.95, "case"))
    raw_reg = raw_reg.copy(); raw_reg["VAR_NORM"] = raw_reg["VARIABLE"].apply(_norm)
    glob_norm = raw_reg[raw_reg["VAR_NORM"] == vh_norm]
    for _, mr in glob_norm.iterrows(): candidates.append((mr["RAW_DATASET"], mr["VARIABLE"], 0.93, "norm"))
    def add_sim(pool: pd.DataFrame):
        pool = pool.copy()
        pool["VAR_SIM"] = pool["VARIABLE"].apply(lambda x: similarity(_norm(x), vh_norm))
        pool = pool.sort_values("VAR_SIM", ascending=False)
        for _, mr in pool.iterrows():
            sc = float(mr["VAR_SIM"])
            if sc >= threshold: candidates.append((mr["RAW_DATASET"], mr["VARIABLE"], sc, "similar"))
    if domain_hint and not pool_dom.empty: add_sim(pool_dom)
    add_sim(raw_reg)
    candidates.sort(key=lambda x: (x[3] != "case", x[3] != "norm", -x[2]))
    seen, uniq = set(), []
    for (sheet, col, sc, mt) in candidates:
        key = (sheet, col)
        if key not in seen:
            seen.add(key); uniq.append((sheet, col, sc, mt))
    return uniq[:top_k]


def match_master_to_raw(master_df: pd.DataFrame, raw_reg: pd.DataFrame,
                        threshold: float = THRESHOLD, concat_order: str = CONCAT_ORDER) -> Dict[str, pd.DataFrame]:
    raw_by_exact = {rv: idx for idx, rv in enumerate(raw_reg["RAW_VARIABLE_UP"])}
    rows_direct, rows_fuzzy, rows_unresolved = [], [], []
    iterator = master_df.iterrows(); total = master_df.shape[0]
    if TQDM_AVAILABLE: iterator = tqdm(iterator, total=total, desc="Matching master to raw", unit="row")
    processed = 0
    for _, r in iterator:
        spec_domain = str(r.get("DOMAIN") or "").strip()
        sdtm_var = str(r.get("SDTM_VARIABLE") or "").strip()
        raw_tok = r.get("RAW_VARIABLE")
        dom_hint, var_hint = parse_raw_token(raw_tok)
        dom_pref = dom_hint or (spec_domain.upper() if re.fullmatch(r"[A-Z]{2,3}", spec_domain.upper()) else None)
        base = {"SPEC_DOMAIN": spec_domain, "SDTM_VARIABLE": sdtm_var, "SPEC_RAW_VARIABLE": raw_tok, "DOM_HINT": dom_pref}
        # STUDYID rule
        if sdtm_var.upper() == "STUDYID":
            if spec_domain.upper() == "DM":
                processed += 1; continue
            else:
                rows_direct.append({
                    **base,
                    "RAW_SHEET": "SDTM.DM",
                    "RAW_VARIABLE_ASSIGNED": "STUDYID",
                    "MATCH_TYPE": "rule",
                    "MATCH_SCORE": 1.0,
                })
                processed += 1; continue
        # exact key
        best: Optional[Tuple[str, str, str, float, str]] = None
        if raw_tok and str(raw_tok).strip() != "":
            key = str(raw_tok).strip().upper()
            if key in raw_by_exact:
                m = raw_reg.iloc[raw_by_exact[key]]
                best = ("token", m["RAW_DATASET"], m["VARIABLE"], 1.0, "exact")
        alt_cands = []
        if best is None and var_hint:
            cands = find_candidates(var_hint, dom_pref, raw_reg, top_k=5, threshold=max(0.80, min(threshold, 0.99)))
            if cands:
                sheet, col, score, mtype = cands[0]
                best = ("cand", sheet, col, float(score), mtype)
                alt_cands = [f"{s}.{c}:{round(sc, 3)}" for (s, c, sc, mt) in cands[1:4]]
        if best is not None:
            _, sheet, col, score, mtype = best
            if mtype in ("exact", "case", "norm") and score >= 0.93:
                rows_direct.append({**base, "RAW_SHEET": sheet, "RAW_VARIABLE_ASSIGNED": col, "MATCH_TYPE": mtype, "MATCH_SCORE": round(score, 4)})
            else:
                rows_fuzzy.append({**base, "RAW_SHEET": sheet, "RAW_VARIABLE_ASSIGNED": col, "MATCH_TYPE": mtype, "MATCH_SCORE": round(score, 4), "ALT_CANDIDATES": "; ".join(alt_cands) or None})
        else:
            hints = []
            if var_hint:
                vh_norm = _norm(var_hint)
                pool = raw_reg[raw_reg["RAW_DATASET_UP"] == (dom_pref or "")]
                if pool.empty: pool = raw_reg
                pool = pool.copy(); pool["VAR_SIM"] = pool["VARIABLE"].apply(lambda x: similarity(_norm(x), vh_norm))
                pool = pool.sort_values("VAR_SIM", ascending=False)
                for _, mr in pool.head(5).iterrows(): hints.append(f"{mr['RAW_DATASET']}.{mr['VARIABLE']}:{round(float(mr['VAR_SIM']), 3)}")
            rows_unresolved.append({**base, "TOP_CANDIDATES": "; ".join(hints) or None})
        processed += 1
        if not TQDM_AVAILABLE and processed % max(1, total // 10 or 1) == 0:
            pct = int(processed * 100 / total) if total else 100
            print(f"[Progress] {processed}/{total} ({pct}%)")

    expected_cols = ["SPEC_DOMAIN", "SDTM_VARIABLE", "SPEC_RAW_VARIABLE", "DOM_HINT", "RAW_SHEET", "RAW_VARIABLE_ASSIGNED", "MATCH_TYPE", "MATCH_SCORE"]
    assigned_direct = pd.DataFrame(rows_direct) if rows_direct else pd.DataFrame(columns=expected_cols)
    assigned_fuzzy = pd.DataFrame(rows_fuzzy) if rows_fuzzy else pd.DataFrame(columns=expected_cols + ["ALT_CANDIDATES"])
    unresolved = pd.DataFrame(rows_unresolved) if rows_unresolved else pd.DataFrame(columns=["SPEC_DOMAIN", "SDTM_VARIABLE", "SPEC_RAW_VARIABLE", "DOM_HINT", "TOP_CANDIDATES"])
    if not assigned_direct.empty: assigned_direct = assigned_direct.sort_values(["SPEC_DOMAIN", "SDTM_VARIABLE"]).reset_index(drop=True)
    if not assigned_fuzzy.empty: assigned_fuzzy = assigned_fuzzy.sort_values(["SPEC_DOMAIN", "SDTM_VARIABLE", "MATCH_SCORE"], ascending=[True, True, False]).reset_index(drop=True)
    if not unresolved.empty: unresolved = unresolved.sort_values(["SPEC_DOMAIN", "SDTM_VARIABLE"]).reset_index(drop=True)

    # --- Concatenation views (BEST_SCORE only) ---
    def concat_view(df: pd.DataFrame, label: str) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame(columns=[
                "SPEC_DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLES_ASSIGNED",
                "COUNT_ASSIGNED", "MATCH_TYPES", "BEST_SCORE", "SOURCE"
            ]).assign(SOURCE=label)
        t = df.copy(); t["PAIR"] = t["RAW_SHEET"].astype(str) + "." + t["RAW_VARIABLE_ASSIGNED"].astype(str)
        if concat_order.lower() == "spec":
            agg = (t.groupby(["SPEC_DOMAIN", "SDTM_VARIABLE"]).agg(
                    RAW_VARIABLES_ASSIGNED=("PAIR", lambda x: ", ".join(list(dict.fromkeys(list(x))))),
                    COUNT_ASSIGNED=("PAIR", "nunique"),
                    MATCH_TYPES=("MATCH_TYPE", lambda x: ", ".join(sorted(set(map(str, x))))),
                    BEST_SCORE=("MATCH_SCORE", "max"))
                    .reset_index())
        else:
            agg = (t.groupby(["SPEC_DOMAIN", "SDTM_VARIABLE"]).agg(
                    RAW_VARIABLES_ASSIGNED=("PAIR", lambda x: ", ".join(sorted(set(x)))),
                    COUNT_ASSIGNED=("PAIR", "nunique"),
                    MATCH_TYPES=("MATCH_TYPE", lambda x: ", ".join(sorted(set(map(str, x))))),
                    BEST_SCORE=("MATCH_SCORE", "max"))
                    .reset_index())
        agg["BEST_SCORE"] = agg["BEST_SCORE"].round(4)
        agg["SOURCE"] = label
        return agg

    direct_concat = concat_view(assigned_direct, "direct")
    fuzzy_concat = concat_view(assigned_fuzzy, "fuzzy")

    # Final concat: prefer direct; else fuzzy
    if not direct_concat.empty and not fuzzy_concat.empty:
        keys = set(map(tuple, direct_concat[["SPEC_DOMAIN", "SDTM_VARIABLE"]].values))
        fuzzy_only = fuzzy_concat[~fuzzy_concat.apply(lambda r: (r["SPEC_DOMAIN"], r["SDTM_VARIABLE"]) in keys, axis=1)]
        final_concat = pd.concat([direct_concat, fuzzy_only], ignore_index=True)
    elif not direct_concat.empty:
        final_concat = direct_concat.copy()
    else:
        final_concat = fuzzy_concat.copy()

    # --- Simple RAW prefixing for final concat (except SDTM.DM.STUDYID) ---
    if not final_concat.empty:
        def add_raw_prefix_simple(s: str) -> str:
            tokens = [p.strip() for p in str(s).split(",") if p.strip()]
            out = []
            for tok in tokens:
                up = tok.upper()
                if up == "SDTM.DM.STUDYID":
                    out.append("SDTM.DM.STUDYID")
                else:
                    if up.startswith("RAW."):
                        out.append(tok)
                    else:
                        out.append(f"RAW.{tok}")
            return ", ".join(out)
        final_concat = final_concat.copy()
        final_concat["RAW_VARIABLES_ASSIGNED"] = final_concat["RAW_VARIABLES_ASSIGNED"].apply(add_raw_prefix_simple)

    # --- Raw pairs unmapped (suffix-aware) ---
    mapped_pairs = set()
    for df in (assigned_direct, assigned_fuzzy):
        if not df.empty:
            mapped_pairs.update((df["RAW_SHEET"].astype(str) + "." + df["RAW_VARIABLE_ASSIGNED"].astype(str)).str.upper())

    raw_reg = raw_reg.copy()
    raw_reg["VAR_BASE"] = raw_reg["VARIABLE_UP"].apply(lambda v: v.split("_", 1)[0] if "_" in v else v)
    raw_reg["SUFFIX"] = raw_reg["VARIABLE_UP"].apply(lambda v: v.split("_", 1)[1] if "_" in v else "")
    raw_reg["SUFFIX_IN_EQUIV"] = raw_reg["SUFFIX"].str.upper().isin(SUFFIX_EQUIV)

    raw_unmapped = raw_reg[~raw_reg["PAIR"].str.upper().isin(mapped_pairs)].copy()

    def drop_variants_if_any_mapped(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty: return df
        grp = raw_reg.groupby(["RAW_DATASET_UP", "VAR_BASE"]) 
        to_drop_idx = []
        for (ds, base_name), reg_group in grp:
            pairs_upper = set((reg_group["RAW_DATASET_UP"] + "." + reg_group["VARIABLE_UP"]).str.upper())
            if pairs_upper & mapped_pairs:
                mask = (df["RAW_DATASET_UP"] == ds) & (df["VAR_BASE"] == base_name)
                to_drop_idx.extend(df[mask].index.tolist())
        return df.drop(index=to_drop_idx)

    raw_unmapped = drop_variants_if_any_mapped(raw_unmapped)

    raw_unmapped = raw_unmapped[["RAW_DATASET", "VARIABLE", "RAW_VARIABLE", "LABEL", "FORMAT"]].sort_values(["RAW_DATASET", "VARIABLE"]).reset_index(drop=True)
    ds_total = (raw_reg.groupby("RAW_DATASET").size().reset_index(name="TOTAL_RAW_PAIRS"))
    ds_unmapped = (raw_unmapped.groupby("RAW_DATASET").size().reset_index(name="UNMAPPED_PAIRS"))
    raw_unmapped_summary = ds_total.merge(ds_unmapped, on="RAW_DATASET", how="left").fillna(0)
    raw_unmapped_summary["UNMAPPED_PAIRS"] = raw_unmapped_summary["UNMAPPED_PAIRS"].astype(int)
    raw_unmapped_summary["UNMAPPED_%"] = (100.0 * raw_unmapped_summary["UNMAPPED_PAIRS"] / raw_unmapped_summary["TOTAL_RAW_PAIRS"]).round(2)
    raw_unmapped_summary = raw_unmapped_summary.sort_values("RAW_DATASET").reset_index(drop=True)

    # Coverage summary
    total_master = master_df.shape[0]
    total_raw_pairs = raw_reg.shape[0]
    raw_pairs_mapped = len(mapped_pairs)
    coverage_summary = pd.DataFrame([{
        "TOTAL_MASTER_ROWS": total_master,
        "ASSIGNED_DIRECT": assigned_direct.shape[0],
        "ASSIGNED_FUZZY": assigned_fuzzy.shape[0],
        "UNRESOLVED": unresolved.shape[0],
        "COVERAGE_%": round(100.0 * (assigned_direct.shape[0] + assigned_fuzzy.shape[0]) / total_master, 2) if total_master else 0.0,
        "RAW_PAIRS_TOTAL": total_raw_pairs,
        "RAW_PAIRS_MAPPED": raw_pairs_mapped,
        "RAW_PAIRS_UNMAPPED": max(0, total_raw_pairs - raw_pairs_mapped),
        "RAW_PAIRS_MAPPED_%": round(100.0 * raw_pairs_mapped / total_raw_pairs, 2) if total_raw_pairs else 0.0,
    }])

    cov_by_domain = (master_df.groupby("DOMAIN").size().reset_index(name="MASTER_ROWS")
                     .merge(assigned_direct.groupby("SPEC_DOMAIN").size().reset_index(name="DIRECT").rename(columns={"SPEC_DOMAIN": "DOMAIN"}), on="DOMAIN", how="left")
                     .merge(assigned_fuzzy.groupby("SPEC_DOMAIN").size().reset_index(name="FUZZY").rename(columns={"SPEC_DOMAIN": "DOMAIN"}), on="DOMAIN", how="left"))
    cov_by_domain["DIRECT"] = cov_by_domain["DIRECT"].fillna(0).astype(int)
    cov_by_domain["FUZZY"] = cov_by_domain["FUZZY"].fillna(0).astype(int)
    cov_by_domain["ASSIGNED"] = cov_by_domain["DIRECT"] + cov_by_domain["FUZZY"]
    cov_by_domain["COVERAGE_%"] = (100.0 * cov_by_domain["ASSIGNED"] / cov_by_domain["MASTER_ROWS"]).round(2)
    cov_by_domain = cov_by_domain.sort_values(["DOMAIN"]).reset_index(drop=True)

    return {
        "assigned_direct": assigned_direct,
        "assigned_fuzzy": assigned_fuzzy,
        "unresolved": unresolved,
        "coverage_summary": coverage_summary,
        "coverage_by_domain": cov_by_domain,
        "assigned_direct_concat": direct_concat,
        "assigned_fuzzy_concat": fuzzy_concat,
        "assigned_final_concat": final_concat,
        "raw_unmapped": raw_unmapped,
        "raw_unmapped_summary": raw_unmapped_summary,
    }

# ------------------------------- IO helpers ----------------------------------- #
def _shorten_for_xpt(df: pd.DataFrame) -> pd.DataFrame:
    col_map = {
        "SPEC_DOMAIN":"DOMAIN",
        "SDTM_VARIABLE":"SDTMVAR",
        "RAW_VARIABLES_ASSIGNED":"RAWASSGN",
        "COUNT_ASSIGNED":"CNTASSGN",
        "MATCH_TYPES":"MTYPES",
        "BEST_SCORE":"BESTSCOR",
        "SOURCE":"SRC"
    }
    safe = df.copy(); safe = safe.rename(columns={c: col_map[c] for c in col_map if c in safe.columns})
    safe.columns = [str(c).upper()[:8] for c in safe.columns]
    for col in safe.columns:
        if pd.api.types.is_object_dtype(safe[col]): safe[col] = safe[col].astype(str)
    return safe

def write_sas_xpt(df: pd.DataFrame, out_path: Path) -> Optional[Path]:
    if df is None or df.empty:
        print("[XPT] assigned_final_concat empty; skipping export."); return None
    if not PYREADSTAT_AVAILABLE:
        print("[XPT] pyreadstat not installed; skipping export. Install: pip install pyreadstat"); return None
    safe_df = _shorten_for_xpt(df)
    pyreadstat.write_xport(safe_df, str(out_path), table_name="AFCONCAT")
    print(f"[XPT] Wrote: {out_path}"); return out_path

def safe_write_excel(dfs: Dict[str, pd.DataFrame], out_path: Path, xpt_path: Optional[Path], master_path: Path, input_path: Path) -> Path:
    with pd.ExcelWriter(out_path, engine="openpyxl") as w:
        for name, df in dfs.items(): df.to_excel(w, sheet_name=name, index=False)
        # index tab
        rows = [{"Sheet": name, "Rows": int(df.shape[0])} for name, df in dfs.items()]
        rows.append({"Sheet": "(XPT)", "Rows": -1 if xpt_path is None else int(dfs["assigned_final_concat"].shape[0])})
        meta = pd.DataFrame(rows)
        settings = pd.DataFrame([{
            "Generated": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "Threshold": THRESHOLD,
            "Concat order": CONCAT_ORDER,
            "Dedup": DEDUP,
            "Master": str(master_path.resolve()),
            "Raw Input": str(input_path.resolve()),
            "Excel Path": str(out_path.resolve()),
            "XPT Path": "" if xpt_path is None else str(xpt_path.resolve()),
            "Score aggregation": "BEST (max)"
        }])
        blank = pd.DataFrame([{ "Sheet": "", "Rows": "" }])
        idx_df = pd.concat([meta, blank, settings], axis=0, ignore_index=True)
        idx_df.to_excel(w, sheet_name="index", index=False)
    print(f"[Excel] Wrote: {out_path}"); return out_path

# ----------------------------- Spec write-back via openpyxl ------------------- #
def update_spec_preserve_formatting(spec_path: Path, outputs: Dict[str, pd.DataFrame], out_dir: Path, in_prefix: str) -> Tuple[Optional[Path], Optional[Path]]:
    """Update Input Variables & Mapping Action across ALL sheets, preserving formatting (openpyxl)."""
    if not OPENPYXL_AVAILABLE:
        print("[Spec] openpyxl not available. Cannot preserve formatting.")
        return None, None

    final_concat = outputs.get("assigned_final_concat")
    if final_concat is None or final_concat.empty:
        print("[Spec] assigned_final_concat empty; skipping spec update.")
        return None, None

    # Build assignment & mode maps
    final = final_concat.copy()
    final["DOMAIN_UP"] = final["SPEC_DOMAIN"].astype(str).str.strip().str.upper()
    final["VARIABLE_UP"] = final["SDTM_VARIABLE"].astype(str).str.strip().str.upper()
    assigned_map = { (row.DOMAIN_UP, row.VARIABLE_UP): str(row.RAW_VARIABLES_ASSIGNED) for _, row in final.iterrows() }
    mode_map     = { (row.DOMAIN_UP, row.VARIABLE_UP): str(row.SOURCE).lower() for _, row in final.iterrows() }

    # Helpers
    def parse_tokens(s: Optional[str]) -> List[str]:
        if s is None: return []
        st = str(s).strip()
        if not st: return []
        return [t.strip() for t in st.split(",") if t.strip()]
    def ensure_raw_prefix(tok: str) -> str:
        up = tok.upper()
        if up == "SDTM.DM.STUDYID": return "SDTM.DM.STUDYID"
        return tok if up.startswith("RAW.") else f"RAW.{tok}"
    def header_match(text: str, targets: List[str]) -> bool:
        if text is None: return False
        t = str(text).strip().lower()
        return t in [x.lower() for x in targets]

    # Load workbook respecting extension
    ext = spec_path.suffix.lower()
    is_macro = (ext == ".xlsm")
    wb = load_workbook(spec_path, data_only=False, keep_vba=is_macro)

    conflicts, drops, final_not_in_spec = [], [], []
    spec_keys_all = set()

    # Column targets
    dataset_hdr = ["Dataset", "Domain", "SDTM.Domain", "SDTM Domain"]
    variable_hdr = ["Variable", "SDTM.Variable", "SDTM Variable"]
    input_hdr    = ["Input Variables", "Input Variable", "Source", "Raw Mapping"]
    map_hdr      = ["Mapping Action", "Mapping_Action"]
    core_hdr     = ["Gilead Core", "Gilead_Core", "Core"]

    for ws in wb.worksheets:
        # Find header row by scanning first 10 rows
        header_row = None
        col_idx = {}
        max_scan_rows = min(ws.max_row, 10)
        for r in range(1, max_scan_rows+1):
            row_vals = [ws.cell(row=r, column=c).value for c in range(1, ws.max_column+1)]
            ds_col = None; var_col = None; in_col = None; map_col = None; core_col = None
            for c, val in enumerate(row_vals, start=1):
                if ds_col is None and header_match(val, dataset_hdr): ds_col = c
                if var_col is None and header_match(val, variable_hdr): var_col = c
                if in_col is None and header_match(val, input_hdr): in_col = c
                if map_col is None and header_match(val, map_hdr): map_col = c
                if core_col is None and header_match(val, core_hdr): core_col = c
            if ds_col and var_col and in_col:
                header_row = r
                col_idx = {"dataset": ds_col, "variable": var_col, "input": in_col, "map": map_col, "core": core_col}
                break
        if header_row is None:
            continue

        # Walk rows and update only values
        for r in range(header_row+1, ws.max_row+1):
            ds_val = ws.cell(row=r, column=col_idx["dataset"]).value
            var_val = ws.cell(row=r, column=col_idx["variable"]).value
            if (ds_val is None) and (var_val is None):
                continue
            dom_up = str(ds_val or "").strip().upper()
            var_up = str(var_val or "").strip().upper()
            spec_keys_all.add((dom_up, var_up))

            in_cell = ws.cell(row=r, column=col_idx["input"]) if col_idx["input"] else None
            existing_tokens = parse_tokens(in_cell.value if in_cell else None)
            preserved_sdtm  = [t for t in existing_tokens if t.upper().startswith("SDTM.")]

            assigned_tokens = parse_tokens(assigned_map.get((dom_up, var_up)))
            assigned_tokens = [ensure_raw_prefix(t) for t in assigned_tokens]

            new_tokens = preserved_sdtm + assigned_tokens
            seen, uniq = set(), []
            for t in new_tokens:
                if t not in seen:
                    seen.add(t); uniq.append(t)
            new_val = ", ".join(uniq) if uniq else None
            if in_cell is not None:
                in_cell.value = new_val

            # DROP rule
            if (not assigned_tokens) and col_idx["core"]:
                core_val = ws.cell(row=r, column=col_idx["core"]).value
                if str(core_val or "").strip().lower() != "required":
                    if col_idx["map"]:
                        ws.cell(row=r, column=col_idx["map"]).value = "DROP"
                    drops.append({"Sheet": ws.title, "Dataset": ds_val, "Variable": var_val, "Reason": "No assignment; Core not Required"})

            # Conflicts
            mode = mode_map.get((dom_up, var_up))
            if mode == "fuzzy":
                conflicts.append({"Sheet": ws.title, "Dataset": ds_val, "Variable": var_val, "Updated_Input": new_val, "Conflict": "Fuzzy-only match (no direct)"})
            if preserved_sdtm:
                conflicts.append({"Sheet": ws.title, "Dataset": ds_val, "Variable": var_val, "Updated_Input": new_val, "Conflict": f"Preserved SDTM tokens: {', '.join(preserved_sdtm)}"})

    # Info: final assignments not in spec
    final_keys = set(assigned_map.keys())
    not_in_spec = final_keys - spec_keys_all
    for dom_up, var_up in not_in_spec:
        final_not_in_spec.append({"Domain": dom_up, "Variable": var_up, "RAW_VARIABLES_ASSIGNED": assigned_map[(dom_up, var_up)]})

    # Save workbook to output preserving formatting and extension
    out_spec = out_dir / f"spec_updated__{in_prefix}{timestamp_suffix()}{ext}"
    wb.save(out_spec)

    # Consolidated report via pandas
    out_report = out_dir / f"spec_update_report__{in_prefix}{timestamp_suffix()}.xlsx"
    with pd.ExcelWriter(out_report, engine="openpyxl") as w:
        pd.DataFrame(conflicts).to_excel(w, sheet_name="conflicts", index=False)
        pd.DataFrame(drops).to_excel(w, sheet_name="dropped_rows", index=False)
        pd.DataFrame(final_not_in_spec).to_excel(w, sheet_name="final_not_in_spec", index=False)

    print(f"[Spec] Updated (format preserved): {out_spec}")
    print(f"[Spec] Report: {out_report}")
    return out_spec, out_report

# ----------------------------------- Main ------------------------------------- #
def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__); sys.exit(0)
    raw_xlsx = Path(args[0])
    master_override = None
    spec_path = None
    if "--master" in args:
        try:
            mi = args.index("--master"); master_override = Path(args[mi+1])
        except Exception:
            print("[WARN] --master provided without a path. Using default MASTER_PATH.")
    if "--spec" in args:
        try:
            si = args.index("--spec"); spec_path = Path(args[si+1])
        except Exception:
            spec_path = None
    master_xlsx = master_override or MASTER_PATH
    if not master_xlsx.exists():
        print(f"[ERROR] Master mapping not found at: {master_xlsx}. Place your file or use --master <path>."); sys.exit(1)

    # Default spec if none provided
    if spec_path is None:
        spec_path = DEFAULT_SPEC_PATH
    if not spec_path.exists():
        print(f"[ERROR] Spec not found at: {spec_path}. Provide --spec <path> or place file at default."); sys.exit(1)

    out_dir = ensure_output_dir()

    # Load inputs & match
    master_df = load_master_mapping(master_xlsx)
    if master_df.empty:
        print("[WARN] Master mapping produced zero rows."); sys.exit(0)
    raw_reg = build_raw_registry_from_workbook(raw_xlsx)
    outputs = match_master_to_raw(master_df, raw_reg, threshold=THRESHOLD, concat_order=CONCAT_ORDER)

    # Name outputs with input prefix, under output/
    in_prefix = derive_prefix_from_input(raw_xlsx)
    out_xlsx_ts = out_dir / f"matched_mapping__{in_prefix}{timestamp_suffix()}.xlsx"
    xpt_ts      = out_dir / f"assigned_final_concat__{in_prefix}{timestamp_suffix()}.xpt"

    xpt_path = write_sas_xpt(outputs["assigned_final_concat"], xpt_ts)
    written_xlsx = safe_write_excel(outputs, out_xlsx_ts, xpt_path=xpt_path, master_path=master_xlsx, input_path=raw_xlsx)

    print(f"[Done] Excel: {written_xlsx.resolve()}")
    if xpt_path: print(f"[Done] SAS XPORT: {xpt_path.resolve()}")

    # Spec write-back with formatting preserved
    update_spec_preserve_formatting(spec_path, outputs, out_dir, in_prefix)

if __name__ == "__main__":
    main()
