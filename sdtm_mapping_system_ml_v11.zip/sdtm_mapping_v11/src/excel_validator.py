"""
excel_validator.py
==================
Pre/post writeback Excel validation module.

Captures a "before" snapshot of a spec workbook, then after writeback
compares the "after" state and produces a structured validation report
matching the ExcelValidationReport JSON schema.

Checks performed:
  CHK_001  Sheet structure integrity          (sheets added/removed)
  CHK_002  Named ranges integrity             (named ranges dropped/added)
  CHK_003  Data validation rules              (dropdown/validation rules per sheet)
  CHK_004  Merged cells integrity             (merged cell ranges)
  CHK_005  Hidden sheet integrity             (sheets whose visibility changed)
  CHK_006  Workbook load test                 (can openpyxl open the file)
  CHK_007  Formula integrity                  (broken #REF!/#NAME? formulas)

Usage:
    from excel_validator import ExcelValidator
    v = ExcelValidator(baseline_path)           # capture before-state
    v.validate_after(after_path)               # compare and produce report
    report = v.report                          # dict matching JSON schema
    ok     = v.allow_writeback                 # bool — safe to write?
"""

from __future__ import annotations

import hashlib
import datetime
import re
import warnings
from pathlib import Path
from typing import Any

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")
from openpyxl import load_workbook


# ---------------------------------------------------------------------------
# SDTM domain class groupings (for anti-hallucination domain proximity)
# ---------------------------------------------------------------------------
DOMAIN_CLASS: dict[str, str] = {
    # General Observation Classes
    "AE": "Events",       "CE": "Events",   "DS": "Events",
    "DV": "Events",       "HO": "Events",   "MH": "Events",
    "CM": "Interventions","EC": "Interventions","EX": "Interventions",
    "ML": "Interventions","PR": "Interventions","SU": "Interventions",
    "EG": "Findings",     "IE": "Findings", "IS": "Findings",
    "LB": "Findings",     "MB": "Findings", "MI": "Findings",
    "MK": "Findings",     "MS": "Findings", "NV": "Findings",
    "OE": "Findings",     "PC": "Findings", "PE": "Findings",
    "PP": "Findings",     "QS": "Findings", "RE": "Findings",
    "RS": "Findings",     "SC": "Findings", "TR": "Findings",
    "TU": "Findings",     "UR": "Findings", "VS": "Findings",
    # Special purpose
    "DM": "Special",      "SE": "Special",  "SM": "Special",
    "SV": "Special",      "CO": "Special",
    # Trial design
    "TA": "Trial",        "TE": "Trial",    "TI": "Trial",
    "TV": "Trial",        "TS": "Trial",    "TD": "Trial",
}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return "sha256:" + h.hexdigest()
    except Exception:
        return "sha256:error"


def _load_wb(path: Path):
    ext = path.suffix.lower()
    try:
        return load_workbook(str(path), data_only=False,
                             keep_vba=(ext == ".xlsm")), None
    except Exception as e:
        return None, str(e)


def _capture_snapshot(wb) -> dict:
    """Capture a hashable snapshot of workbook structure."""
    if wb is None:
        return {}

    snap: dict[str, Any] = {
        "sheets":        [ws.title for ws in wb.worksheets],
        "hidden_sheets": [ws.title for ws in wb.worksheets
                          if ws.sheet_state != "visible"],
        "named_ranges":  {},
        "data_validations": {},
        "merged_cells":  {},
        "formulas":      {},
    }

    # Named ranges
    for name, defn in wb.defined_names.items():
        snap["named_ranges"][name] = str(defn.attr_text or "")

    # Per-sheet checks
    for ws in wb.worksheets:
        sn = ws.title

        # Data validations
        dvs = []
        try:
            for dv in ws.data_validations.dataValidation:
                dvs.append({
                    "type":     dv.type,
                    "formula1": str(dv.formula1 or ""),
                    "sqref":    str(dv.sqref),
                })
        except Exception:
            pass
        snap["data_validations"][sn] = dvs

        # Merged cells
        try:
            snap["merged_cells"][sn] = [str(r) for r in ws.merged_cells.ranges]
        except Exception:
            snap["merged_cells"][sn] = []

        # Formulas (cells containing = formulas)
        formulas = {}
        try:
            for row in ws.iter_rows():
                for cell in row:
                    if cell.value and isinstance(cell.value, str) and cell.value.startswith("="):
                        formulas[cell.coordinate] = cell.value
        except Exception:
            pass
        snap["formulas"][sn] = formulas

    return snap


def _is_broken_formula(formula: str) -> list[str]:
    errors = []
    for err in ("#REF!", "#NAME?", "#VALUE!", "#DIV/0!", "#NULL!"):
        if err in formula.upper():
            errors.append(err)
    return errors


# ---------------------------------------------------------------------------
# Main validator class
# ---------------------------------------------------------------------------

class ExcelValidator:
    """
    Capture before-state, run writeback, then validate after-state.

    Usage:
        v = ExcelValidator(spec_path)          # snapshot before
        # ... run writeback ...
        v.validate_after(out_path)             # compare after
        report = v.report
        if not v.allow_writeback:
            # block or warn
    """

    VERSION = "2.0"

    def __init__(self, spec_path: Path, baseline_path: Path | None = None):
        self.spec_path     = Path(spec_path)
        self.baseline_path = Path(baseline_path) if baseline_path else self.spec_path
        self.before_hash   = _sha256(self.spec_path)
        self._before_snap  = {}
        self._load_before()

    def _load_before(self):
        wb, err = _load_wb(self.spec_path)
        if wb is None:
            self._before_snap = {"load_error": err}
        else:
            self._before_snap = _capture_snapshot(wb)
            wb.close()

    def validate_after(self, out_path: Path) -> dict:
        """Compare out_path against the before-snapshot. Returns full report dict."""
        t0 = datetime.datetime.utcnow()
        out_path = Path(out_path)

        after_hash  = _sha256(out_path)
        wb_after, load_err = _load_wb(out_path)
        after_snap  = _capture_snapshot(wb_after) if wb_after else {}
        if wb_after:
            wb_after.close()

        checks  = []
        issues  = []
        recs    = []

        # ---- CHK_001 Sheet structure ----
        b_sheets = self._before_snap.get("sheets", [])
        a_sheets = after_snap.get("sheets", [])
        chk001_pass = b_sheets == a_sheets
        checks.append({
            "check_id":   "CHK_001",
            "check_name": "Sheet Structure Integrity",
            "category":   "structure",
            "status":     "PASS" if chk001_pass else "FAIL",
            "severity":   "LOW" if chk001_pass else "HIGH",
            "details": {
                "before": b_sheets,
                "after":  a_sheets,
                "added":   [s for s in a_sheets if s not in b_sheets],
                "removed": [s for s in b_sheets if s not in a_sheets],
            },
        })
        if not chk001_pass:
            issues.append({
                "severity": "HIGH", "category": "structure",
                "issue": "Sheet structure changed",
                "impact": f"Sheets removed: {[s for s in b_sheets if s not in a_sheets]}",
                "root_cause": "Writeback added or removed sheets unexpectedly",
            })

        # ---- CHK_002 Named ranges ----
        b_nr = self._before_snap.get("named_ranges", {})
        a_nr = after_snap.get("named_ranges", {})
        missing_ranges = [k for k in b_nr if k not in a_nr]
        new_ranges     = [k for k in a_nr if k not in b_nr
                          and not k.startswith("_OPENPYXL")]
        spurious       = [k for k in a_nr if k.startswith("_OPENPYXL")]
        nr_pass = not missing_ranges and not spurious
        nr_status = "PASS" if nr_pass else ("WARN" if not missing_ranges else "FAIL")
        nr_severity = "LOW" if nr_pass else ("MEDIUM" if not missing_ranges else "CRITICAL")
        checks.append({
            "check_id":   "CHK_002",
            "check_name": "Named Ranges Integrity",
            "category":   "structure",
            "status":     nr_status,
            "severity":   nr_severity,
            "details": {
                "before_count":     len(b_nr),
                "after_count":      len(a_nr),
                "missing_ranges":   missing_ranges,
                "new_ranges":       spurious,
                "preserved_ranges": [k for k in b_nr if k in a_nr],
            },
        })
        if missing_ranges:
            issues.append({
                "severity": "HIGH", "category": "structure",
                "issue": "Named ranges missing",
                "impact": "Macros or validations dependent on named ranges may fail",
                "missing_ranges": missing_ranges,
                "root_cause": "Named ranges dropped or not reattached during writeback",
            })
            recs.append({
                "action": "Restore missing named ranges",
                "target": missing_ranges,
                "auto_fix_possible": True,
                "auto_fix_action": "Copy named ranges from baseline workbook",
            })

        # ---- CHK_003 Data validation rules ----
        b_dvs = self._before_snap.get("data_validations", {})
        a_dvs = after_snap.get("data_validations", {})
        dv_sheet_results = []
        dv_any_fail = False
        for sn in b_dvs:
            b_count = len(b_dvs.get(sn, []))
            a_count = len(a_dvs.get(sn, []))
            lost = []
            if b_count > a_count:
                # Find which rules are missing by formula comparison
                a_formulas = {dv["formula1"] for dv in a_dvs.get(sn, [])}
                lost = [dv["formula1"] for dv in b_dvs.get(sn, [])
                        if dv["formula1"] not in a_formulas and dv["formula1"]]
            sheet_pass = b_count <= a_count
            if not sheet_pass:
                dv_any_fail = True
            dv_sheet_results.append({
                "sheet":        sn,
                "before_count": b_count,
                "after_count":  a_count,
                "status":       "PASS" if sheet_pass else "FAIL",
                "lost_rules":   lost,
            })
        checks.append({
            "check_id":   "CHK_003",
            "check_name": "Data Validation Rules",
            "category":   "validation",
            "status":     "FAIL" if dv_any_fail else "PASS",
            "severity":   "CRITICAL" if dv_any_fail else "LOW",
            "sheet_level": dv_sheet_results,
        })
        if dv_any_fail:
            failed_sheets = [r["sheet"] for r in dv_sheet_results if r["status"] == "FAIL"]
            issues.append({
                "severity": "HIGH", "category": "validation",
                "sheet": ", ".join(failed_sheets),
                "issue": "Data validation rules reduced",
                "impact": "Dropdowns may be broken; controlled vocabulary enforcement lost",
                "root_cause": "Validation rules not preserved during writeback",
            })
            recs.append({
                "action": "Reapply data validation rules",
                "target": failed_sheets,
                "auto_fix_possible": True,
                "auto_fix_action": "Recreate validation from baseline template",
            })

        # ---- CHK_004 Merged cells ----
        b_mc = self._before_snap.get("merged_cells", {})
        a_mc = after_snap.get("merged_cells", {})
        mc_sheet_results = []
        mc_any_warn = False
        for sn in b_mc:
            b_ranges = set(b_mc.get(sn, []))
            a_ranges = set(a_mc.get(sn, []))
            changed  = list(b_ranges - a_ranges)
            sheet_ok = not changed
            if not sheet_ok:
                mc_any_warn = True
            mc_sheet_results.append({
                "sheet":        sn,
                "before_count": len(b_ranges),
                "after_count":  len(a_ranges),
                "status":       "PASS" if sheet_ok else "WARN",
                "removed_merges": changed,
            })
        checks.append({
            "check_id":   "CHK_004",
            "check_name": "Merged Cells Integrity",
            "category":   "formatting",
            "status":     "WARN" if mc_any_warn else "PASS",
            "severity":   "MEDIUM" if mc_any_warn else "LOW",
            "sheet_level": mc_sheet_results,
        })
        if mc_any_warn:
            issues.append({
                "severity": "MEDIUM", "category": "formatting",
                "issue": "Merged cell ranges changed",
                "impact": "Layout misalignment possible; header rows may not align",
                "root_cause": "Row insertion or deletion during writeback",
            })
            recs.append({
                "action": "Review merged cell alignment",
                "target": [r["sheet"] for r in mc_sheet_results if r["status"] == "WARN"],
                "auto_fix_possible": False,
            })

        # ---- CHK_005 Hidden sheets ----
        b_hidden = set(self._before_snap.get("hidden_sheets", []))
        a_hidden = set(after_snap.get("hidden_sheets", []))
        hidden_changed = list(b_hidden.symmetric_difference(a_hidden))
        checks.append({
            "check_id":   "CHK_005",
            "check_name": "Hidden Sheet Integrity",
            "category":   "structure",
            "status":     "PASS" if not hidden_changed else "WARN",
            "severity":   "LOW",
            "details":    {"changed_sheets": hidden_changed},
        })

        # ---- CHK_006 Workbook load test ----
        chk006_pass = load_err is None
        checks.append({
            "check_id":   "CHK_006",
            "check_name": "Workbook Load Test",
            "category":   "stability",
            "status":     "PASS" if chk006_pass else "FAIL",
            "severity":   "CRITICAL" if not chk006_pass else "LOW",
            "details": {
                "load_success": chk006_pass,
                "errors":       load_err,
            },
        })
        if not chk006_pass:
            issues.append({
                "severity": "HIGH", "category": "stability",
                "issue": "Workbook cannot be opened",
                "impact": "Output file is corrupt or unreadable",
                "root_cause": load_err,
            })

        # ---- CHK_007 Formula integrity ----
        b_forms = self._before_snap.get("formulas", {})
        a_forms = after_snap.get("formulas", {})
        broken, verified, new_errors = [], [], set()
        for sn in a_forms:
            for coord, formula in a_forms[sn].items():
                errs = _is_broken_formula(formula)
                if errs:
                    new_errors.update(errs)
                    orig_formula = b_forms.get(sn, {}).get(coord, "")
                    broken.append({
                        "cell":     f"{sn}!{coord}",
                        "original": orig_formula,
                        "current":  formula,
                        "reason":   f"Formula contains: {', '.join(errs)}",
                    })
                else:
                    # Verify formulas that existed before still match
                    orig = b_forms.get(sn, {}).get(coord)
                    if orig and orig == formula:
                        verified.append({"cell": f"{sn}!{coord}", "formula": formula})
        b_formula_count = sum(len(v) for v in b_forms.values())
        a_formula_count = sum(len(v) for v in a_forms.values())
        chk007_pass = not broken
        checks.append({
            "check_id":   "CHK_007",
            "check_name": "Formula Integrity",
            "category":   "calculation",
            "status":     "PASS" if chk007_pass else "FAIL",
            "severity":   "CRITICAL" if broken else "LOW",
            "details": {
                "total_formulas_before": b_formula_count,
                "total_formulas_after":  a_formula_count,
                "broken_formulas":       broken,
                "verified_formulas":     verified[:5],
                "new_errors":            list(new_errors),
            },
        })
        if broken:
            issues.append({
                "severity": "HIGH", "category": "calculation",
                "issue": f"Broken formulas detected ({len(broken)})",
                "impact": "Derived variables may compute incorrectly",
                "broken_count": len(broken),
                "root_cause": "Named range or cell reference dependency missing",
            })
            recs.append({
                "action": "Fix broken formulas",
                "target": [b["cell"] for b in broken],
                "auto_fix_possible": True,
                "auto_fix_action": "Rebind named ranges and refresh formula references",
            })

        # ---- Summary ----
        status_counts = {"PASS": 0, "WARN": 0, "FAIL": 0}
        for ch in checks:
            status_counts[ch["status"]] = status_counts.get(ch["status"], 0) + 1

        failed      = status_counts.get("FAIL", 0)
        warned      = status_counts.get("WARN", 0)
        overall     = "PASS" if failed == 0 and warned == 0 else \
                      "WARN" if failed == 0 else "FAIL"

        # Risk score: weighted by severity
        sev_weight = {"CRITICAL": 0.35, "HIGH": 0.20, "MEDIUM": 0.10, "LOW": 0.02}
        risk = min(sum(sev_weight.get(ch["severity"], 0.05)
                       for ch in checks if ch["status"] in ("FAIL", "WARN")), 1.0)
        risk = round(risk, 2)

        # Diff summary
        # Count cell modifications from the change_log if passed; else estimate
        elapsed_ms = int((datetime.datetime.utcnow() - t0).total_seconds() * 1000)

        report = {
            "report_metadata": {
                "report_name":       "Excel Validation Report",
                "generated_at":      t0.isoformat(timespec="seconds"),
                "source_file":       self.spec_path.name,
                "baseline_file":     self.baseline_path.name,
                "baseline_hash":     self.before_hash,
                "output_file":       out_path.name,
                "validator_version": self.VERSION,
            },
            "validation_signature": {
                "validated_by":       f"ExcelValidator v{self.VERSION}",
                "validation_time_ms": elapsed_ms,
                "environment":        "streamlit_pipeline",
            },
            "summary": {
                "overall_status": overall,
                "total_checks":   len(checks),
                "passed":         status_counts.get("PASS", 0),
                "warnings":       status_counts.get("WARN", 0),
                "failed":         status_counts.get("FAIL", 0),
                "risk_score":     risk,
            },
            "execution_decision": {
                "allow_writeback":         failed == 0,
                "allow_submission":        failed == 0 and warned == 0,
                "requires_manual_review":  failed > 0 or warned > 0,
            },
            "diff_summary": {
                "sheets_modified": list({
                    r["sheet"] for r in dv_sheet_results if r["status"] != "PASS"
                } | {
                    r["sheet"] for r in mc_sheet_results if r["status"] != "PASS"
                }),
            },
            "checks":          checks,
            "issues":          issues,
            "recommendations": recs,
            "traceability": {
                "before_file_hash":  self.before_hash,
                "after_file_hash":   after_hash,
                "comparison_method": "metadata_diff_v2",
            },
        }

        self.report          = report
        self.allow_writeback = failed == 0
        return report


def render_validation_report(report: dict) -> str:
    """
    Return a compact HTML summary of the validation report for embedding
    in the Streamlit UI (use st.markdown(..., unsafe_allow_html=True)).
    """
    summary = report.get("summary", {})
    dec     = report.get("execution_decision", {})
    status  = summary.get("overall_status", "UNKNOWN")
    risk    = summary.get("risk_score", 0.0)

    color   = {"PASS": "#3fb950", "WARN": "#e3b341", "FAIL": "#f85149"}.get(status, "#8b949e")
    icon    = {"PASS": "✅", "WARN": "⚠️", "FAIL": "❌"}.get(status, "❓")

    rows = ""
    for ch in report.get("checks", []):
        sev_color = {
            "CRITICAL": "#f85149", "HIGH": "#e3b341",
            "MEDIUM": "#8b949e",   "LOW": "#3fb950",
        }.get(ch.get("severity",""), "#8b949e")
        st_color = {"PASS":"#3fb950","WARN":"#e3b341","FAIL":"#f85149"}.get(ch.get("status",""),"#8b949e")
        rows += (
            f"<tr>"
            f"<td style='font-family:monospace;color:#8b949e'>{ch['check_id']}</td>"
            f"<td>{ch['check_name']}</td>"
            f"<td style='color:{st_color};font-weight:700'>{ch['status']}</td>"
            f"<td style='color:{sev_color}'>{ch.get('severity','')}</td>"
            f"</tr>"
        )

    allow_wb  = "✅ Allowed"  if dec.get("allow_writeback")  else "❌ Blocked"
    allow_sub = "✅ Allowed"  if dec.get("allow_submission") else "❌ Blocked"
    needs_rev = "⚠️ Required" if dec.get("requires_manual_review") else "✅ Not required"

    return f"""
<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:18px 22px;margin:12px 0">
  <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
    <span style="font-size:22px">{icon}</span>
    <span style="font-size:18px;font-weight:700;color:{color}">
      Validation {status} — Risk Score {risk:.0%}
    </span>
  </div>
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
    <div style="background:#0d1117;border-radius:6px;padding:10px;text-align:center">
      <div style="font-size:20px;font-weight:700;color:#3fb950">{summary.get('passed',0)}</div>
      <div style="font-size:11px;color:#8b949e">Passed</div>
    </div>
    <div style="background:#0d1117;border-radius:6px;padding:10px;text-align:center">
      <div style="font-size:20px;font-weight:700;color:#e3b341">{summary.get('warnings',0)}</div>
      <div style="font-size:11px;color:#8b949e">Warnings</div>
    </div>
    <div style="background:#0d1117;border-radius:6px;padding:10px;text-align:center">
      <div style="font-size:20px;font-weight:700;color:#f85149">{summary.get('failed',0)}</div>
      <div style="font-size:11px;color:#8b949e">Failed</div>
    </div>
  </div>
  <table style="width:100%;border-collapse:collapse;font-size:12px;margin-bottom:14px">
    <thead>
      <tr style="background:#0d1117">
        <th style="padding:6px 10px;text-align:left;color:#58a6ff;font-size:10px;text-transform:uppercase">ID</th>
        <th style="padding:6px 10px;text-align:left;color:#58a6ff;font-size:10px;text-transform:uppercase">Check</th>
        <th style="padding:6px 10px;text-align:left;color:#58a6ff;font-size:10px;text-transform:uppercase">Status</th>
        <th style="padding:6px 10px;text-align:left;color:#58a6ff;font-size:10px;text-transform:uppercase">Severity</th>
      </tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>
  <div style="font-size:11px;color:#8b949e;display:flex;gap:24px">
    <span>Write-back: <strong style="color:#e6edf3">{allow_wb}</strong></span>
    <span>Submission: <strong style="color:#e6edf3">{allow_sub}</strong></span>
    <span>Review: <strong style="color:#e6edf3">{needs_rev}</strong></span>
  </div>
</div>
"""
