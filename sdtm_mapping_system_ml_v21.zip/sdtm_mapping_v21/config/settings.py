"""
config/settings.py
==================
Settings management for the SDTM Mapping System.
Uses pydantic-settings when available; falls back to python-dotenv + dataclass.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

APP_DIR = Path(__file__).parent.parent.resolve()

# ── Try pydantic-settings (preferred) ─────────────────────────────────────────
try:
    from pydantic_settings import BaseSettings
    from pydantic import Field

    class Settings(BaseSettings):
        JWT_SECRET: str = Field(default="")
        JWT_EXPIRY_HOURS: int = 8
        MAGIC_LINK_TTL_MINUTES: int = 15
        MAGIC_LINK_RATE_LIMIT: int = 3
        MAGIC_LINK_RATE_WINDOW_MINUTES: int = 10
        ALLOWED_EMAIL_DOMAINS: List[str] = []
        SMTP_HOST: str = "localhost"
        SMTP_PORT: int = 587
        SMTP_USER: str = ""
        SMTP_PASSWORD: str = ""
        SMTP_USE_TLS: bool = True
        EMAIL_FROM: str = "noreply@sdtm-mapper.local"
        BASE_URL: str = "http://localhost:8000"
        ENVIRONMENT: str = "development"
        LOG_LEVEL: str = "INFO"
        LOG_FORMAT: str = "text"
        TEMP_DIR: str = str(APP_DIR / "tmp")
        ENABLE_FASTAPI: bool = False
        ENABLE_AUTH: bool = False
        AUTO_ACCEPT_THRESHOLD: float = 0.82
        REVIEW_THRESHOLD: float = 0.55
        CANDIDATE_MIN_SCORE: float = 0.35
        CONFIG_YAML: str = str(APP_DIR / "src" / "config.yaml")
        LOG_FILE: str = ""

        class Config:
            env_file = str(APP_DIR / ".env")
            env_file_encoding = "utf-8"
            case_sensitive = True
            extra = "ignore"

        def is_production(self) -> bool:
            return self.ENVIRONMENT.lower() == "production"

        def validate_for_production(self) -> None:
            """Raise ValueError if security-critical settings are missing."""
            if not self.is_development() and not self.JWT_SECRET:
                raise ValueError(
                    f"JWT_SECRET must be set in {self.ENVIRONMENT!r} environment. "
                    "Set it in your .env file or as an environment variable."
                )

        def is_development(self) -> bool:
            return self.ENVIRONMENT.lower() == "development"

    settings = Settings()

except ImportError:
    # ── Fallback: plain dataclass + os.environ ────────────────────────────────
    import json
    from dataclasses import dataclass, field

    def _load_dotenv(path: Path) -> None:
        if not path.exists():
            return
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())

    _load_dotenv(APP_DIR / ".env")

    def _env(key: str, default: str = "") -> str:
        return os.environ.get(key, default)

    def _env_int(key: str, default: int) -> int:
        try:
            return int(os.environ.get(key, str(default)))
        except (ValueError, TypeError):
            return default

    def _env_bool(key: str, default: bool) -> bool:
        return os.environ.get(key, str(default)).lower() in ("true", "1", "yes")

    def _env_list(key: str, default: list) -> list:
        raw = os.environ.get(key, "")
        if not raw:
            return default
        try:
            return json.loads(raw)
        except Exception:
            return [x.strip() for x in raw.split(",") if x.strip()]

    @dataclass
    class Settings:
        JWT_SECRET: str = field(default_factory=lambda: _env("JWT_SECRET", ""))
        JWT_EXPIRY_HOURS: int = field(default_factory=lambda: _env_int("JWT_EXPIRY_HOURS", 8))
        MAGIC_LINK_TTL_MINUTES: int = field(default_factory=lambda: _env_int("MAGIC_LINK_TTL_MINUTES", 15))
        MAGIC_LINK_RATE_LIMIT: int = field(default_factory=lambda: _env_int("MAGIC_LINK_RATE_LIMIT", 3))
        MAGIC_LINK_RATE_WINDOW_MINUTES: int = field(default_factory=lambda: _env_int("MAGIC_LINK_RATE_WINDOW_MINUTES", 10))
        ALLOWED_EMAIL_DOMAINS: List[str] = field(default_factory=lambda: _env_list("ALLOWED_EMAIL_DOMAINS", []))
        SMTP_HOST: str = field(default_factory=lambda: _env("SMTP_HOST", "localhost"))
        SMTP_PORT: int = field(default_factory=lambda: _env_int("SMTP_PORT", 587))
        SMTP_USER: str = field(default_factory=lambda: _env("SMTP_USER", ""))
        SMTP_PASSWORD: str = field(default_factory=lambda: _env("SMTP_PASSWORD", ""))
        SMTP_USE_TLS: bool = field(default_factory=lambda: _env_bool("SMTP_USE_TLS", True))
        EMAIL_FROM: str = field(default_factory=lambda: _env("EMAIL_FROM", "noreply@sdtm-mapper.local"))
        BASE_URL: str = field(default_factory=lambda: _env("BASE_URL", "http://localhost:8000"))
        ENVIRONMENT: str = field(default_factory=lambda: _env("ENVIRONMENT", "development"))
        LOG_LEVEL: str = field(default_factory=lambda: _env("LOG_LEVEL", "INFO"))
        LOG_FORMAT: str = field(default_factory=lambda: _env("LOG_FORMAT", "text"))
        TEMP_DIR: str = field(default_factory=lambda: _env("TEMP_DIR", str(APP_DIR / "tmp")))
        ENABLE_FASTAPI: bool = field(default_factory=lambda: _env_bool("ENABLE_FASTAPI", False))
        ENABLE_AUTH: bool = field(default_factory=lambda: _env_bool("ENABLE_AUTH", False))
        AUTO_ACCEPT_THRESHOLD: float = field(default_factory=lambda: float(_env("AUTO_ACCEPT_THRESHOLD", "0.82")))
        REVIEW_THRESHOLD: float = field(default_factory=lambda: float(_env("REVIEW_THRESHOLD", "0.55")))
        CANDIDATE_MIN_SCORE: float = field(default_factory=lambda: float(_env("CANDIDATE_MIN_SCORE", "0.35")))
        CONFIG_YAML: str = field(default_factory=lambda: _env("CONFIG_YAML", str(APP_DIR / "src" / "config.yaml")))
        LOG_FILE: str = field(default_factory=lambda: _env("LOG_FILE", ""))

        def is_production(self) -> bool:
            return self.ENVIRONMENT.lower() == "production"

        def validate_for_production(self) -> None:
            """Raise ValueError if security-critical settings are missing."""
            if not self.is_development() and not self.JWT_SECRET:
                raise ValueError(
                    f"JWT_SECRET must be set in {self.ENVIRONMENT!r} environment. "
                    "Set it in your .env file or as an environment variable."
                )

        def is_development(self) -> bool:
            return self.ENVIRONMENT.lower() == "development"

    settings = Settings()
