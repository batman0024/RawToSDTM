COMPARE_PAGE = r'''
# ===========================================================================
# PAGE: Compare Specs — side-by-side diff of original vs mapped spec
# ===========================================================================

elif page == "Compare Specs":
    st.markdown("## Compare Specs — Side-by-Side Review")
    st.info(
        "Upload the original (standard) spec and the mapped spec produced by Write Back. "
        "Differences in Input Variables, Mapping Action, and Origin are highlighted inline. "
        "Only changed rows are shown by default."
    )

    cmp_col_l, cmp_col_r = st.columns(2)
    with cmp_col_l:
        st.markdown('<div class="card"><div class="card-title">Original / Standard Spec</div>', unsafe_allow_html=True)
        orig_spec_upload = st.file_uploader("Original spec Excel", type=["xlsx","xlsm"], key="cmp_orig")
        st.markdown("</div>", unsafe_allow_html=True)
    with cmp_col_r:
        st.markdown('<div class="card"><div class="card-title">Mapped Spec (from Write Back)</div>', unsafe_allow_html=True)
        mapped_spec_upload = st.file_uploader("Mapped spec Excel", type=["xlsx","xlsm"], key="cmp_mapped")
        st.markdown("</div>", unsafe_allow_html=True)

    show_all_rows = st.checkbox("Show all rows (not just changed)", value=False)
    domain_filter_cmp = st.text_input("Filter by domain/sheet (leave blank = all)", placeholder="DM, AE, CM...")

    COMPARE_COLS = {
        "input variables":   "INPUT_VARIABLES",
        "input variable":    "INPUT_VARIABLES",
        "input_variables":   "INPUT_VARIABLES",
        "mapping action":    "MAPPING_ACTION",
        "mapping_action":    "MAPPING_ACTION",
        "origin":            "ORIGIN",
        "variable":          "VARIABLE",
        "label":             "LABEL",
    }
    DIFF_COLS = ["INPUT_VARIABLES", "MAPPING_ACTION", "ORIGIN"]

    def _read_spec_sheets(uploaded_file):
        """Read all domain sheets from a spec Excel, return {sheet: df}."""
        import io as _io
        wb_bytes = _io.BytesIO(uploaded_file.read())
        uploaded_file.seek(0)
        result = {}
        try:
            xl = pd.ExcelFile(wb_bytes, engine="openpyxl")
            skip = {"study","standards","toc","<ds>","ta","te","ti","tv","ts","td",
                    "ta-data","te-data","maintenance","valuelist"}
            for sn in xl.sheet_names:
                if sn.lower().strip() in skip:
                    continue
                try:
                    df = pd.read_excel(wb_bytes, sheet_name=sn, header=None,
                                       engine="openpyxl", dtype=str)
                    df = df.fillna("")
                    # Find header row
                    hdr_row = None
                    col_map = {}
                    for ri in range(min(15, len(df))):
                        row = df.iloc[ri]
                        found = {}
                        for ci, val in enumerate(row):
                            vl = str(val).strip().lower()
                            if vl in COMPARE_COLS:
                                found[COMPARE_COLS[vl]] = ci
                            if vl in ("variable","sdtm variable","varname"):
                                found["VARIABLE"] = ci
                            if vl in ("dataset","domain"):
                                found["DOMAIN"] = ci
                        if "VARIABLE" in found and "INPUT_VARIABLES" in found:
                            hdr_row = ri
                            col_map = found
                            break
                    if hdr_row is None:
                        continue
                    data_df = df.iloc[hdr_row+1:].reset_index(drop=True)
                    out = {}
                    for col_name, ci in col_map.items():
                        out[col_name] = data_df.iloc[:, ci].astype(str).str.strip()
                    sheet_df = pd.DataFrame(out)
                    sheet_df["SHEET"] = sn
                    sheet_df = sheet_df[sheet_df["VARIABLE"].str.strip().astype(bool)]
                    result[sn] = sheet_df
                except Exception:
                    continue
        except Exception as e:
            st.error(f"Could not read spec: {e}")
        return result

    if orig_spec_upload and mapped_spec_upload:
        with st.spinner("Reading specs..."):
            orig_sheets   = _read_spec_sheets(orig_spec_upload)
            mapped_sheets = _read_spec_sheets(mapped_spec_upload)

        if not orig_sheets or not mapped_sheets:
            st.error("Could not read one or both spec files. Check that they have standard domain sheets with Variable and Input Variables columns.")
        else:
            # Filter by domain if requested
            domain_filter_list = [d.strip().upper() for d in domain_filter_cmp.split(",") if d.strip()]

            all_diff_rows = []
            all_same_rows = []

            for sn, orig_df in orig_sheets.items():
                if domain_filter_list and sn.upper() not in domain_filter_list:
                    continue
                mapped_df = mapped_sheets.get(sn)
                if mapped_df is None:
                    continue

                # Merge on VARIABLE
                merged = orig_df.merge(
                    mapped_df, on="VARIABLE", suffixes=("_ORIG", "_MAPPED"), how="outer"
                )
                merged["SHEET"] = sn

                for col in DIFF_COLS:
                    orig_c   = col + "_ORIG"
                    mapped_c = col + "_MAPPED"
                    if orig_c not in merged.columns:
                        merged[orig_c]   = ""
                    if mapped_c not in merged.columns:
                        merged[mapped_c] = ""
                    merged[orig_c]   = merged[orig_c].fillna("").str.strip()
                    merged[mapped_c] = merged[mapped_c].fillna("").str.strip()

                def _norm_tokens(s):
                    return ", ".join(sorted(
                        t.strip().lower() for t in str(s).replace(";",",").split(",") if t.strip()
                    ))

                # Detect changes
                merged["_ANY_DIFF"] = False
                for col in DIFF_COLS:
                    orig_c, mapped_c = col+"_ORIG", col+"_MAPPED"
                    merged["_ANY_DIFF"] |= (
                        merged[orig_c].apply(_norm_tokens) != merged[mapped_c].apply(_norm_tokens)
                    )

                diff_rows = merged[merged["_ANY_DIFF"]].copy()
                same_rows = merged[~merged["_ANY_DIFF"]].copy()
                all_diff_rows.append(diff_rows)
                all_same_rows.append(same_rows)

            if all_diff_rows or all_same_rows:
                diff_df = pd.concat(all_diff_rows, ignore_index=True) if all_diff_rows else pd.DataFrame()
                same_df = pd.concat(all_same_rows, ignore_index=True) if all_same_rows else pd.DataFrame()

                st.markdown("---")
                # Summary metrics
                d_n_cmp = len(diff_df)
                s_n_cmp = len(same_df)
                t_n_cmp = d_n_cmp + s_n_cmp
                cmp_pills = (
                    '<div class="metric-row">'
                    + metric_html(t_n_cmp,  "Total Variables", "")
                    + metric_html(d_n_cmp,  "Changed",  "amber")
                    + metric_html(s_n_cmp,  "Unchanged", "green")
                    + metric_html(
                        f"{round(100*d_n_cmp/t_n_cmp)}%" if t_n_cmp else "0%",
                        "Change Rate", "amber"
                    )
                    + '</div>'
                )
                st.markdown(cmp_pills, unsafe_allow_html=True)

                display_df = pd.concat([diff_df, same_df], ignore_index=True) if show_all_rows else diff_df

                if display_df.empty:
                    st.success("No differences found between the two specs.")
                else:
                    # Build side-by-side display columns
                    view_cols = ["SHEET","VARIABLE"]
                    for col in DIFF_COLS:
                        oc, mc = col+"_ORIG", col+"_MAPPED"
                        if oc in display_df.columns: view_cols.append(oc)
                        if mc in display_df.columns: view_cols.append(mc)

                    view_df = display_df[[c for c in view_cols if c in display_df.columns]].copy()

                    # Rename columns for display
                    rename = {}
                    for col in DIFF_COLS:
                        rename[col+"_ORIG"]   = col + " (Original)"
                        rename[col+"_MAPPED"] = col + " (Mapped)"
                    view_df = view_df.rename(columns=rename)

                    # Color-code changed cells using Streamlit's built-in column config
                    # (highlight changed INPUT_VARIABLES rows)
                    iv_orig   = "INPUT_VARIABLES (Original)"
                    iv_mapped = "INPUT_VARIABLES (Mapped)"

                    # Add DIFF flag column for visual reference
                    if iv_orig in view_df.columns and iv_mapped in view_df.columns:
                        def _norm_t(s):
                            return sorted(t.strip().lower() for t in str(s).replace(";",",").split(",") if t.strip())
                        view_df["Δ Input Variables"] = view_df.apply(
                            lambda r: "✏️ Changed" if _norm_t(r[iv_orig]) != _norm_t(r[iv_mapped]) else "✓ Same",
                            axis=1
                        )
                        view_df["Δ Input Variables"] = view_df["Δ Input Variables"].fillna("")

                    for col in ["MAPPING_ACTION (Original)", "MAPPING_ACTION (Mapped)"]:
                        if col in view_df.columns:
                            view_df[col.replace("(Original)","Δ action")] = view_df.apply(
                                lambda r, oc=col.replace("Mapped","Original"), mc=col.replace("Original","Mapped"):
                                    "✏️" if oc in r.index and mc in r.index and str(r[oc]).strip().upper() != str(r[mc]).strip().upper() else "",
                                axis=1
                            ) if False else ""

                    st.markdown(f"**{len(view_df)} rows** ({d_n_cmp} with differences)")

                    # Per-domain breakdown
                    if "SHEET" in view_df.columns:
                        sheet_tabs_labels = sorted(view_df["SHEET"].dropna().unique().tolist())
                        if len(sheet_tabs_labels) > 1:
                            sheet_tabs_labels = ["All Domains"] + sheet_tabs_labels
                            s_tabs = st.tabs(sheet_tabs_labels)
                            for si, slabel in enumerate(sheet_tabs_labels):
                                with s_tabs[si]:
                                    sdf = view_df if slabel == "All Domains" else view_df[view_df["SHEET"] == slabel]
                                    st.dataframe(
                                        sdf.drop(columns=["SHEET"], errors="ignore"),
                                        use_container_width=True, hide_index=True,
                                    )
                        else:
                            st.dataframe(
                                view_df.drop(columns=["SHEET"], errors="ignore"),
                                use_container_width=True, hide_index=True,
                            )
                    else:
                        st.dataframe(view_df, use_container_width=True, hide_index=True)

                    # Download comparison as Excel
                    st.markdown("---")
                    excel_download_button(
                        {"Differences": diff_df, "All Variables": same_df if show_all_rows else pd.DataFrame()},
                        "spec_comparison.xlsx",
                        "Download Comparison Excel",
                    )
            else:
                st.warning("No matching sheets found between the two specs.")
    else:
        st.info("Upload both the original spec and the mapped spec to begin comparison.")
'''
print(len(COMPARE_PAGE), "chars")
