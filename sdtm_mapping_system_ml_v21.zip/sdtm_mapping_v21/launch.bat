@echo off
setlocal EnableDelayedExpansion

:: ============================================================
:: SDTM Master Mapping System v18 - Windows Launcher
:: ============================================================
:: Usage:
::   launch.bat            - Start Streamlit + FastAPI (default ports)
::   launch.bat --install  - Force reinstall of dependencies
::   SET PORT=8502 && launch.bat  - Override Streamlit port
::   SET API_PORT=8001 && launch.bat  - Override FastAPI port
:: ============================================================

title SDTM Mapping System v18

:: ── Configurable ports ────────────────────────────────────────────────────────
if not defined PORT     set PORT=8501
if not defined API_PORT set API_PORT=8000

set ROOT_DIR=%~dp0
set VENV_DIR=%ROOT_DIR%venv
set REQUIREMENTS=%ROOT_DIR%requirements.txt
set APP_ENTRY=%ROOT_DIR%app.py
set API_ENTRY=api.main:app
set ENV_FILE=%ROOT_DIR%.env

echo.
echo ============================================================
echo   SDTM Master Mapping System v18
echo ============================================================
echo   Root:       %ROOT_DIR%
echo   Streamlit:  http://localhost:%PORT%
echo   FastAPI:    http://localhost:%API_PORT%
echo   API Docs:   http://localhost:%API_PORT%/docs
echo ============================================================
echo.

:: ── Check Python ─────────────────────────────────────────────────────────────
echo [1/5] Checking Python installation...
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo.
    echo ERROR: Python is not installed or not on PATH.
    echo        Download from https://python.org (version 3.9 or newer required)
    echo.
    pause
    exit /b 1
)

:: Capture Python version and check >= 3.9
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
    set PYMAJ=%%a
    set PYMIN=%%b
)
if %PYMAJ% LSS 3 (
    echo ERROR: Python 3.9+ required. Found: %PYVER%
    pause & exit /b 1
)
if %PYMAJ% EQU 3 if %PYMIN% LSS 9 (
    echo ERROR: Python 3.9+ required. Found: %PYVER%
    pause & exit /b 1
)
echo        Python %PYVER% found. OK

:: ── Load .env if present ──────────────────────────────────────────────────────
echo [2/5] Loading environment variables...
if exist "%ENV_FILE%" (
    for /f "usebackq tokens=1,* delims==" %%a in ("%ENV_FILE%") do (
        set LINE=%%a
        if not "!LINE:~0,1!"=="#" (
            if not "%%a"=="" (
                set %%a=%%b
            )
        )
    )
    echo        Loaded variables from .env
) else (
    echo        No .env file found at %ENV_FILE% (optional)
)

:: ── Create virtual environment ────────────────────────────────────────────────
echo [3/5] Checking virtual environment...
set FORCE_INSTALL=0
if "%1"=="--install" set FORCE_INSTALL=1

if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo        Creating virtual environment at %VENV_DIR% ...
    python -m venv "%VENV_DIR%"
    if %ERRORLEVEL% neq 0 (
        echo ERROR: Failed to create virtual environment.
        pause & exit /b 1
    )
    set FORCE_INSTALL=1
    echo        Virtual environment created.
) else (
    echo        Virtual environment exists.
)

:: ── Activate venv ─────────────────────────────────────────────────────────────
call "%VENV_DIR%\Scripts\activate.bat"
if %ERRORLEVEL% neq 0 (
    echo ERROR: Failed to activate virtual environment.
    pause & exit /b 1
)
echo        Virtual environment activated.

:: ── Install dependencies ──────────────────────────────────────────────────────
echo [4/5] Checking dependencies...
if %FORCE_INSTALL%==1 (
    echo        Installing from requirements.txt ...
    pip install -r "%REQUIREMENTS%" --quiet
    if %ERRORLEVEL% neq 0 (
        echo ERROR: pip install failed. Check requirements.txt and internet connection.
        pause & exit /b 1
    )
    echo        Dependencies installed.
) else (
    echo        Skipping install (use --install flag to force reinstall)
)

:: ── Create tmp directory ──────────────────────────────────────────────────────
if not exist "%ROOT_DIR%tmp" mkdir "%ROOT_DIR%tmp"

:: ── Launch FastAPI (background window) ───────────────────────────────────────
echo [5/5] Starting services...

:: Only start FastAPI if ENABLE_FASTAPI is true in environment
set START_API=0
if /I "%ENABLE_FASTAPI%"=="true"  set START_API=1
if /I "%ENABLE_FASTAPI%"=="True"  set START_API=1
if /I "%ENABLE_FASTAPI%"=="1"     set START_API=1

if %START_API%==1 (
    echo        Starting FastAPI on port %API_PORT% ...
    start "SDTM API - Port %API_PORT%" cmd /k "cd /d %ROOT_DIR% && call %VENV_DIR%\Scripts\activate.bat && uvicorn %API_ENTRY% --host 0.0.0.0 --port %API_PORT% --reload"
    echo        FastAPI started in background window.
    echo        API Docs: http://localhost:%API_PORT%/docs
) else (
    echo        FastAPI disabled (set ENABLE_FASTAPI=true in .env to enable)
)

:: ── Launch Streamlit ──────────────────────────────────────────────────────────
echo.
echo        Starting Streamlit on port %PORT% ...
echo        Open: http://localhost:%PORT%
echo.
echo        Press Ctrl+C to stop.
echo ============================================================
echo.

streamlit run "%APP_ENTRY%" ^
    --server.port %PORT% ^
    --server.headless true ^
    --browser.gatherUsageStats false

if %ERRORLEVEL% neq 0 (
    echo.
    echo ERROR: Streamlit exited with code %ERRORLEVEL%
    pause
    exit /b %ERRORLEVEL%
)

endlocal
