"""
auth/session_store.py
=====================
Abstract token store + default in-memory implementation.
Redis backend can be substituted by implementing AbstractTokenStore.
"""
from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
from typing import Optional

from models.auth_models import TokenRecord


class AbstractTokenStore(ABC):
    """Interface that all token store backends must implement."""

    @abstractmethod
    def save(self, token: str, record: TokenRecord) -> None: ...

    @abstractmethod
    def get(self, token: str) -> Optional[TokenRecord]: ...

    @abstractmethod
    def mark_used(self, token: str) -> None: ...

    @abstractmethod
    def delete(self, token: str) -> None: ...


class InMemoryTokenStore(AbstractTokenStore):
    """
    Thread-safe in-memory token store.
    Suitable for single-process deployments and testing.
    Does NOT survive process restart.
    """

    def __init__(self) -> None:
        self._store: dict[str, TokenRecord] = {}
        self._lock = threading.Lock()

    def save(self, token: str, record: TokenRecord) -> None:
        with self._lock:
            self._store[token] = record

    def get(self, token: str) -> Optional[TokenRecord]:
        with self._lock:
            return self._store.get(token)

    def mark_used(self, token: str) -> None:
        with self._lock:
            if token in self._store:
                rec = self._store[token]
                self._store[token] = rec.model_copy(update={"used": True})

    def delete(self, token: str) -> None:
        with self._lock:
            self._store.pop(token, None)

    def purge_expired(self) -> int:
        """Remove all expired tokens. Returns count removed."""
        now = datetime.now(timezone.utc)
        with self._lock:
            expired = [
                t for t, r in self._store.items()
                if r.expires_at.replace(tzinfo=timezone.utc) < now
            ]
            for t in expired:
                del self._store[t]
        return len(expired)


# Singleton instance — swapped in tests or when Redis is configured
_default_store: AbstractTokenStore = InMemoryTokenStore()


def get_token_store() -> AbstractTokenStore:
    return _default_store


def set_token_store(store: AbstractTokenStore) -> None:
    global _default_store
    _default_store = store
