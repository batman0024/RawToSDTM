"""
auth/email_sender.py
====================
Abstract email sender + SMTP default implementation.
SendGrid or any other backend can be substituted.
"""
from __future__ import annotations

import logging
import smtplib
from abc import ABC, abstractmethod
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

log = logging.getLogger("sdtm_app.auth.email")


class AbstractEmailSender(ABC):
    """Interface all email backends must implement."""

    @abstractmethod
    def send_magic_link(self, to_email: str, magic_link: str) -> None:
        """Send the magic-link email. Raises on failure."""
        ...


class SMTPEmailSender(AbstractEmailSender):
    """SMTP email sender. Supports TLS (STARTTLS) and plain connections."""

    def __init__(
        self,
        host: str,
        port: int,
        user: str,
        password: str,
        from_address: str,
        use_tls: bool = True,
    ) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.from_address = from_address
        self.use_tls = use_tls

    def send_magic_link(self, to_email: str, magic_link: str) -> None:
        subject = "Your SDTM Mapper login link"
        html_body = f"""
        <html><body>
        <p>Click the link below to log in to the SDTM Master Mapping System.</p>
        <p><a href="{magic_link}">Log in to SDTM Mapper</a></p>
        <p>This link expires in 15 minutes and can only be used once.</p>
        <p>If you did not request this, ignore this email.</p>
        </body></html>
        """
        plain_body = (
            f"Log in to SDTM Mapper: {magic_link}\n\n"
            "This link expires in 15 minutes and can only be used once.\n"
            "If you did not request this, ignore this email."
        )

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = self.from_address
        msg["To"] = to_email
        msg.attach(MIMEText(plain_body, "plain"))
        msg.attach(MIMEText(html_body, "html"))

        try:
            if self.use_tls:
                with smtplib.SMTP(self.host, self.port, timeout=10) as server:
                    server.ehlo()
                    server.starttls()
                    if self.user:
                        server.login(self.user, self.password)
                    server.sendmail(self.from_address, [to_email], msg.as_string())
            else:
                with smtplib.SMTP(self.host, self.port, timeout=10) as server:
                    if self.user:
                        server.login(self.user, self.password)
                    server.sendmail(self.from_address, [to_email], msg.as_string())
            log.info("Magic link sent to %s", to_email)
        except smtplib.SMTPException as exc:
            log.error("SMTP error sending to %s: %s", to_email, exc)
            raise


class ConsoleEmailSender(AbstractEmailSender):
    """
    Development-mode sender that prints links to stdout instead of sending email.
    Set ENVIRONMENT=development to use automatically.
    """

    def send_magic_link(self, to_email: str, magic_link: str) -> None:
        log.info(
            "[DEV EMAIL] Magic link for %s:\n  %s\n  (not actually sent — dev mode)",
            to_email,
            magic_link,
        )
        print(f"\n[DEV] Magic link for {to_email}:\n  {magic_link}\n")


def build_email_sender(settings) -> AbstractEmailSender:
    """Factory: returns ConsoleEmailSender in development, SMTPEmailSender otherwise."""
    if settings.ENVIRONMENT.lower() == "development" or not settings.SMTP_HOST or settings.SMTP_HOST == "localhost":
        return ConsoleEmailSender()
    return SMTPEmailSender(
        host=settings.SMTP_HOST,
        port=settings.SMTP_PORT,
        user=settings.SMTP_USER,
        password=settings.SMTP_PASSWORD,
        from_address=settings.EMAIL_FROM,
        use_tls=settings.SMTP_USE_TLS,
    )
