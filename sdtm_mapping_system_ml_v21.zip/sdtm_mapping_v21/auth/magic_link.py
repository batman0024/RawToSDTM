"""
auth/magic_link.py
==================
Magic-link token generation, validation, JWT issuance, and rate limiting.
No FastAPI dependencies — pure business logic.
"""
from __future__ import annotations

import logging
import secrets
import threading
import time
import uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Tuple

import jwt as pyjwt

from exceptions.domain_exceptions import (
    AuthError,
    DomainNotAllowedError,
    InvalidJWTError,
    RateLimitError,
    TokenAlreadyUsedError,
    TokenExpiredError,
    TokenNotFoundError,
)
from models.auth_models import JWTPayload, TokenRecord
from auth.session_store import AbstractTokenStore

log = logging.getLogger("sdtm_app.auth.magic_link")


class RateLimiter:
    """
    In-memory per-email rate limiter.
    Tracks timestamps of requests; enforces max N per window.
    """

    def __init__(self, max_requests: int, window_minutes: int) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_minutes * 60
        self._store: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()

    def check_and_record(self, email: str) -> None:
        """
        Check rate limit for email. Raises RateLimitError if exceeded.
        Records the request if allowed.
        """
        now = time.time()
        cutoff = now - self.window_seconds
        with self._lock:
            timestamps = [t for t in self._store[email] if t > cutoff]
            if len(timestamps) >= self.max_requests:
                raise RateLimitError(
                    f"Too many login requests for {email}. "
                    f"Max {self.max_requests} per {self.window_seconds // 60} minutes."
                )
            timestamps.append(now)
            self._store[email] = timestamps


class MagicLinkService:
    """
    Orchestrates magic-link token lifecycle and JWT issuance.
    Injected with a token store and settings so it is fully testable.
    """

    def __init__(
        self,
        store: AbstractTokenStore,
        jwt_secret: str,
        jwt_expiry_hours: int,
        ttl_minutes: int,
        allowed_domains: List[str],
        base_url: str,
        rate_limiter: RateLimiter,
    ) -> None:
        self._store = store
        self._jwt_secret = jwt_secret
        self._jwt_expiry_hours = jwt_expiry_hours
        self._ttl_minutes = ttl_minutes
        self._allowed_domains = [d.lower() for d in allowed_domains]
        self._base_url = base_url.rstrip("/")
        self._rate_limiter = rate_limiter

    # ── Public API ────────────────────────────────────────────────────────

    def request_link(self, email: str) -> str:
        """
        Validate email, check rate limit, generate token, return magic link URL.
        Callers should send the URL via email — not return it directly to the client.
        """
        email = email.strip().lower()
        self._check_domain(email)
        self._rate_limiter.check_and_record(email)

        token = secrets.token_urlsafe(32)
        expires_at = datetime.now(timezone.utc) + timedelta(minutes=self._ttl_minutes)
        record = TokenRecord(email=email, expires_at=expires_at)
        self._store.save(token, record)

        magic_link = f"{self._base_url}/auth/verify?token={token}"
        log.info("Magic link generated for %s (expires %s)", email, expires_at.isoformat())
        return magic_link

    def verify_token(self, token: str) -> str:
        """
        Validate a magic-link token.
        Returns a signed JWT access token string on success.
        Raises TokenNotFoundError, TokenExpiredError, or TokenAlreadyUsedError.
        """
        record = self._store.get(token)
        if record is None:
            log.warning("Token verify failed: not found")
            raise TokenNotFoundError("Login link is invalid.")

        now = datetime.now(timezone.utc)
        expires = record.expires_at
        if not expires.tzinfo:
            expires = expires.replace(tzinfo=timezone.utc)

        if now > expires:
            self._store.delete(token)
            log.warning("Token verify failed: expired (email=%s)", record.email)
            raise TokenExpiredError("Login link has expired. Please request a new one.")

        if record.used:
            log.warning("Token verify failed: already used (email=%s)", record.email)
            raise TokenAlreadyUsedError("Login link has already been used. Please request a new one.")

        self._store.mark_used(token)
        jwt_token = self._issue_jwt(record.email)
        log.info("Token verified successfully for %s", record.email)
        return jwt_token

    def decode_jwt(self, token: str) -> str:
        """Decode and validate a JWT. Returns the email (sub claim) on success."""
        try:
            payload = pyjwt.decode(
                token,
                self._jwt_secret,
                algorithms=["HS256"],
                options={"require": ["exp", "sub", "iat", "jti"]},
            )
            return payload["sub"]
        except pyjwt.ExpiredSignatureError:
            raise InvalidJWTError("Session has expired. Please log in again.")
        except pyjwt.InvalidTokenError as exc:
            raise InvalidJWTError(f"Invalid session token: {exc}")

    # ── Private helpers ───────────────────────────────────────────────────

    def _check_domain(self, email: str) -> None:
        if not self._allowed_domains:
            return
        domain = email.split("@")[-1].lower() if "@" in email else ""
        if domain not in self._allowed_domains:
            raise DomainNotAllowedError(
                f"Email domain '{domain}' is not authorised for this system."
            )

    def _issue_jwt(self, email: str) -> str:
        now = time.time()
        payload = {
            "sub": email,
            "iat": now,
            "exp": now + self._jwt_expiry_hours * 3600,
            "jti": str(uuid.uuid4()),
        }
        return pyjwt.encode(payload, self._jwt_secret, algorithm="HS256")
