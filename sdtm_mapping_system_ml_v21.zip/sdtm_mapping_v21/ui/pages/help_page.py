"""
Help page
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)

def render():
    """Render this page."""
    st.markdown("## Help & Quick Reference")

    tab1, tab2, tab3, tab4 = st.tabs(["Workflow", "File Formats", "Thresholds", "CLI Usage"])

    with tab1:
        st.markdown("""
### Three-Phase Workflow

**Phase 1 - Build Master**

Upload every completed and QC-approved SDTM spec Excel file from previous studies.
The system extracts all `DOMAIN | SDTM_VARIABLE | Input Variables` mappings and
builds a frequency-weighted, recency-decayed confidence score for each.
Sponsor standard specs receive a 3x study-count boost so they always take priority.

Add studies incrementally using Append Mode - no need to rebuild from scratch each time.

---

**Phase 2 - Map New Study**

Upload the new study's raw variable catalog (typically a SAS PROC CONTENTS output
exported to Excel or CSV). The system:

1. Builds a group-aware index of the master mapping
2. Builds a TF-IDF label similarity index over raw variable labels
3. Scores every SDTM variable using a 4-signal composite scorer:
   - Name exact match (35%)
   - Name fuzzy similarity (20%)
   - Label TF-IDF cosine (25%)
   - Master confidence / frequency (20%)
4. Classifies each result as Direct, Review, or Unresolved

---

**Phase 3 - Write Back**

Upload the new study SDTM spec (blank Input Variables). The results from Phase 2
are written into the correct cells while preserving all original formatting.
Origin is written using priority: CRF > Derived > Protocol > eDT > Assigned.
Review rows are highlighted with bold text + fill color (GREEN bold = auto-accepted, AMBER bold = needs review).
A change-log sheet is appended listing every updated cell with tier, score, and notes.
        """)

    with tab2:
        st.markdown("""
### Expected File Formats

**Completed Study Spec (Phase 1 input)**
- Excel workbook with one sheet per SDTM domain
- Must have a TOC sheet with Dataset and Active columns
- Only domains where Active = Y/YES are processed
- Trial domains (TA TE TI TV TS TD) always excluded even if Active=Y
- Required columns per domain sheet: Variable, Input Variables, Mapping Action
- Optional columns: Label, Origin, Codelist, Core, SAS Type, SAS Length

**Raw Variable Catalog (Phase 2 input)**
- PROC CONTENTS output exported to Excel or CSV
- Required columns: MEMNAME (dataset), NAME (variable)
- Optional: LABEL, FORMAT, TYPE

**New Study Spec (Phase 3 input)**
- Same format as completed study spec
- Input Variables, Mapping Action, Origin columns should be blank
- The write-back populates them based on Phase 2 results
        """)

    with tab3:
        st.markdown("""
### Confidence Score & Thresholds

The composite score (0 to 1.0) combines four signals:

| Signal | Default Weight | Description |
|---|---|---|
| Name exact | 35% | Exact slug match between SDTM var name and raw var name |
| Name fuzzy | 20% | Best of seq_ratio / token_sort / token_set similarity |
| Label TF-IDF | 25% | Cosine similarity of variable labels |
| Master freq | 20% | Historical confidence from master_mapping |

**Thresholds (configurable in config.yaml and UI sliders):**

| Tier | Default | Action |
|---|---|---|
| Direct | >= 0.82 | Written to spec immediately | GREEN bold |
| Review | >= 0.55 | Flagged for human review | AMBER bold |
| Cross-Dataset | name >= 0.75 | Variable name match across differently-named dataset | AMBER bold (manual review) |
| Unresolved | < 0.55 | Not written; manual assignment required | — |

**Partial-group penalty:** If a multi-token group (e.g. date+time) has only
some tokens found in the raw catalog, the group score is penalised proportionally.
Default penalty factor: 0.70 (configurable).
        """)

    with tab4:
        st.markdown("""
### CLI Usage (without the UI)

All phases are also available as standalone Python scripts:

```bash
# Phase 1: Build master from completed studies
python pipeline.py build \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --out     master_mapping.xlsx

# Append a new study to existing master
python pipeline.py build \\
    --specs    studies/study_c.xlsx \\
    --existing master_mapping.xlsx \\
    --out      master_mapping.xlsx

# Phase 2: Map new study
python pipeline.py map \\
    --master master_mapping.xlsx \\
    --raw    new_study/proc_contents.xlsx \\
    --spec   new_study/sdtm_spec.xlsx \\
    --out    new_study/mapping_results.xlsx

# Phase 3: Write-back
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx

# Dry-run preview
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx \\
    --dry-run

# Full pipeline (all three phases)
python pipeline.py full \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --raw     new_study/proc_contents.xlsx \\
    --spec    new_study/sdtm_spec.xlsx
```
        """)
