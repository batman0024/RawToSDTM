"""
View Master page
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)

def render():
    """Render this page."""
    st.markdown("## View Master Mapping")

    col_l, col_r = st.columns([2, 1])
    with col_l:
        master_view_file = st.file_uploader(
            "Upload master_mapping.xlsx to explore",
            type=["xlsx"],
            key="master_view",
        )
    with col_r:
        if st.session_state.get("master_built"):
            if st.button("Load master from Phase 1"):
                st.session_state["master_view_bytes"] = st.session_state["master_xlsx_bytes"]

    view_bytes = None
    if master_view_file:
        view_bytes = master_view_file.read()
    elif st.session_state.get("master_view_bytes"):
        view_bytes = st.session_state["master_view_bytes"]

    if view_bytes:
        try:
            master_all = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_all",
                                       engine="openpyxl", dtype=object)
            master_top = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_top",
                                       engine="openpyxl", dtype=object)

            if "MASTER_CONFIDENCE" in master_all.columns:
                master_all["MASTER_CONFIDENCE"] = pd.to_numeric(
                    master_all["MASTER_CONFIDENCE"], errors="coerce"
                )

            # Metrics
            pills = (
                '<div class="metric-row">'
                + metric_html(master_all["SDTM_VARIABLE"].nunique() if not master_all.empty else 0, "SDTM Variables")
                + metric_html(master_all["DOMAIN"].nunique()        if not master_all.empty else 0, "Domains")
                + metric_html(len(master_all), "Total Rows")
                + metric_html(
                    int((master_all["MASTER_CONFIDENCE"] >= 0.82).sum()) if "MASTER_CONFIDENCE" in master_all.columns else 0,
                    "High Conf (>=82%)", "green"
                  )
                + '</div>'
            )
            st.markdown(pills, unsafe_allow_html=True)

            st.markdown("---")

            # Filter controls
            fc1, fc2, fc3 = st.columns([1, 1, 2])
            with fc1:
                domains = sorted(master_all["DOMAIN"].dropna().unique().tolist()) if not master_all.empty else []
                domain_filter = st.multiselect("Filter by Domain", options=domains, default=domains)
            with fc2:
                tier_filter = st.multiselect(
                    "Confidence tier",
                    options=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                    default=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                )
            with fc3:
                search_var = st.text_input("Search SDTM Variable", placeholder="e.g. AESTDTC")

            filtered = master_top.copy() if not master_top.empty else master_all.copy()
            if "DOMAIN" in filtered.columns and domain_filter:
                filtered = filtered[filtered["DOMAIN"].isin(domain_filter)]
            if search_var and "SDTM_VARIABLE" in filtered.columns:
                filtered = filtered[
                    filtered["SDTM_VARIABLE"].str.contains(search_var.upper(), na=False)
                ]
            if "MASTER_CONFIDENCE" in filtered.columns:
                conf = pd.to_numeric(filtered["MASTER_CONFIDENCE"], errors="coerce")
                masks = []
                if "High (>=82%)"    in tier_filter: masks.append(conf >= 0.82)
                if "Medium (55-82%)" in tier_filter: masks.append((conf >= 0.55) & (conf < 0.82))
                if "Low (<55%)"      in tier_filter: masks.append(conf < 0.55)
                if masks:
                    import functools
                    combined = functools.reduce(lambda a, b: a | b, masks)
                    filtered = filtered[combined]

            st.markdown(f"**{len(filtered)} rows shown**")
            display_cols = [
                c for c in
                ["DOMAIN","SDTM_VARIABLE","SDTM_LABEL","INPUT_VARIABLES",
                 "MAPPING_ACTION","ORIGIN","N_STUDIES","MASTER_CONFIDENCE",
                 "IS_SPONSOR_STD","SOURCE_FILES"]
                if c in filtered.columns
            ]
            st.dataframe(filtered[display_cols], use_container_width=True, hide_index=True)

        except Exception as exc:
            st.error(f"Could not read master mapping: {exc}")

    else:
        st.info("Upload a master_mapping.xlsx or build one in Phase 1.")


# ===========================================================================
# PAGE: Help
# ===========================================================================

