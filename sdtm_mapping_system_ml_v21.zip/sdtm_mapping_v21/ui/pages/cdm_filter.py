"""
CDM Variable Filter page
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)

def render():
    """Render this page."""
    cfg_path_input = st.session_state.get(
        "cfg_path_input",
        str(APP_DIR / "src" / "config.yaml")
    )
    st.markdown("## CDM Variable Filter")
    st.info(
        "CDM-generated variables (audit trail fields, system IDs, query fields) "
        "should not be mapped to SDTM. Define which raw variables and entire datasets "
        "to exclude before running the mapping. All lists are editable and saved for the session."
    )

    from cdm_filter import CdmFilter
    flt      = CdmFilter.from_dict(st.session_state.get("cdm_filter_dict", {}))

    # Live preview
    st.markdown("### Preview Filter on Your Raw Catalog")
    preview_raw = st.file_uploader(
        "Upload raw catalog (Excel or CSV) to see what would be excluded",
        type=["xlsx", "csv"], key="cdm_preview",
    )
    if preview_raw:
        tmpd = _make_tmpdir()
        try:
            import yaml as _y, logging as _lg
            rp = save_upload(preview_raw, tmpd)
            with open(cfg_path_input) as _f:
                _cfg = _y.safe_load(_f)
            _log = _lg.getLogger("sdtm_pipeline")
            from mapper import read_raw_catalog as _rrc
            raw_prev = _rrc(rp, _cfg, _log)
            usable, excluded = flt.filter_catalog(raw_prev)
            cv1, cv2 = st.columns(2)
            with cv1:
                st.markdown(
                    f'<div class="card"><div class="card-title">Usable ({len(usable)})</div>',
                    unsafe_allow_html=True,
                )
                if not usable.empty:
                    st.dataframe(
                        usable[["RAW_DATASET","VARIABLE","LABEL"]],
                        use_container_width=True, hide_index=True,
                    )
                st.markdown("</div>", unsafe_allow_html=True)
            with cv2:
                st.markdown(
                    f'<div class="card"><div class="card-title">Excluded ({len(excluded)})</div>',
                    unsafe_allow_html=True,
                )
                if not excluded.empty:
                    st.dataframe(
                        excluded[["RAW_DATASET","VARIABLE","LABEL"]],
                        use_container_width=True, hide_index=True,
                    )
                else:
                    st.success("No variables excluded by current filter.")
                st.markdown("</div>", unsafe_allow_html=True)
        except Exception as _exc:
            st.error(f"Preview failed: {_exc}")
        finally:
            _rm_tmpdir(tmpd)

    st.markdown("---")
    tab_vars, tab_ds, tab_sfx, tab_custom = st.tabs([
        "Variable Names", "Dataset Names", "Suffix Patterns", "Custom Regex",
    ])

    with tab_vars:
        st.markdown("##### Excluded Variable Names")
        st.caption(
            "These exact variable names are excluded regardless of which dataset they appear in. "
            "Common examples: CREATEDDTM, MODIFIEDDTM, FORMOID, LOCKED."
        )
        var_text = st.text_area(
            "One variable name per line (uppercase)",
            value="\n".join(sorted(flt.cdm_variables)),
            height=320,
            key="cdm_var_edit",
        )
        vc1, vc2, vc3 = st.columns([2, 2, 1])
        with vc1:
            new_var = st.text_input("Add variable", key="add_cdm_var")
        with vc2:
            del_var = st.text_input("Remove variable", key="del_cdm_var")
        with vc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key="save_vars"):
                new_set = {v.strip().upper() for v in var_text.splitlines() if v.strip()}
                if new_var.strip():
                    new_set.add(new_var.strip().upper())
                if del_var.strip():
                    new_set.discard(del_var.strip().upper())
                flt.cdm_variables = new_set
                st.session_state["cdm_filter_dict"] = flt.to_dict()
                st.success(f"Saved: {len(new_set)} variable exclusions")

    with tab_ds:
        st.markdown("##### Excluded Dataset Names")
        st.caption(
            "All variables from these datasets are excluded entirely. "
            "Examples: AUDIT, QUERIES, BATCHLOG."
        )
        ds_text = st.text_area(
            "One dataset name per line (uppercase MEMNAME)",
            value="\n".join(sorted(flt.cdm_datasets)),
            height=220,
            key="cdm_ds_edit",
        )
        dc1, dc2, dc3 = st.columns([2, 2, 1])
        with dc1:
            new_ds = st.text_input("Add dataset", key="add_cdm_ds")
        with dc2:
            del_ds = st.text_input("Remove dataset", key="del_cdm_ds")
        with dc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Save", key="save_ds"):
                new_set = {d.strip().upper() for d in ds_text.splitlines() if d.strip()}
                if new_ds.strip():
                    new_set.add(new_ds.strip().upper())
                if del_ds.strip():
                    new_set.discard(del_ds.strip().upper())
                flt.cdm_datasets = new_set
                st.session_state["cdm_filter_dict"] = flt.to_dict()
                st.success(f"Saved: {len(new_set)} dataset exclusions")

    with tab_sfx:
        st.markdown("##### Excluded Variable Suffixes")
        st.caption("Variables ending with these suffixes are excluded (CDM backup copies).")
        sfx_text = st.text_area(
            "One suffix per line (e.g. _PREV)",
            value="\n".join(flt.cdm_suffixes),
            height=160,
            key="cdm_sfx_edit",
        )
        if st.button("Save Suffixes"):
            new_sfx = [s.strip().upper() for s in sfx_text.splitlines() if s.strip()]
            flt.cdm_suffixes = new_sfx
            st.session_state["cdm_filter_dict"] = flt.to_dict()
            st.success(f"Saved: {len(new_sfx)} suffix patterns")

    with tab_custom:
        st.markdown("##### Custom Regex Patterns")
        st.caption("Python regex patterns matched against variable names. e.g. ^SYS_ excludes SYS_* variables.")
        custom_text = st.text_area(
            "One regex per line",
            value="\n".join(flt.custom_patterns),
            height=140,
            key="cdm_custom_edit",
        )
        if st.button("Save Patterns"):
            import re as _re
            valid, invalid = [], []
            for p in custom_text.splitlines():
                p = p.strip()
                if not p:
                    continue
                try:
                    _re.compile(p)
                    valid.append(p)
                except _re.error:
                    invalid.append(p)
            flt.custom_patterns = valid
            st.session_state["cdm_filter_dict"] = flt.to_dict()
            if invalid:
                st.warning(f"Invalid patterns skipped: {invalid}")
            st.success(f"Saved: {len(valid)} custom patterns")

    st.markdown("---")
    st.info(
        "The CDM filter is applied automatically during Phase 2 (Map New Study). "
        "Excluded variables appear in the Excluded tab of the results and are never "
        "written to the spec."
    )

