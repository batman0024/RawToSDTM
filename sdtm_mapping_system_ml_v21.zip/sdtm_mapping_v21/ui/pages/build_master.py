"""
Build Master page — Phase 1
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)
from ui.session import _file_hash, _scan_watch_folder

def render():
    """Render this page."""
    cfg_path_input = st.session_state.get(
        "cfg_path_input",
        str(APP_DIR / "src" / "config.yaml")
    )
    st.markdown("## Phase 1 - Build Master Mapping")
    st.info(
        "Upload completed study spec Excel files. Each study added improves "
        "accuracy for future mappings. Sponsor standard specs get a confidence "
        "priority boost and supersede conflicting study mappings.",
    )

    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Completed Study Specs</div>', unsafe_allow_html=True)
        study_files = st.file_uploader(
            "Upload one or more completed study spec Excel files",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="study_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Sponsor Standard Specs (optional)</div>', unsafe_allow_html=True)
        sponsor_files = st.file_uploader(
            "Upload sponsor standard / template spec(s). These take priority over study mappings.",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="sponsor_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Existing Master (Append Mode)</div>', unsafe_allow_html=True)
        existing_master_file = st.file_uploader(
            "Optional: upload an existing master_mapping.xlsx to append new studies",
            type=["xlsx"],
            key="existing_master",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Study Dates (optional)</div>', unsafe_allow_html=True)
        st.caption("Older studies get a recency decay. Format: filename=YYYY-MM-DD (one per line)")
        dates_text = st.text_area(
            "Study dates",
            placeholder="study_a.xlsx=2022-06-01\nstudy_b.xlsx=2023-11-15\nsponsor_std.xlsx=2024-01-01",
            height=120,
            label_visibility="collapsed",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Conflict Strategy</div>', unsafe_allow_html=True)
        conflict_strategy = st.selectbox(
            "How to resolve conflicting mappings across studies",
            options=["sponsor_priority", "most_frequent"],
            index=0,
            help="sponsor_priority: sponsor standard wins. most_frequent: highest N_STUDIES wins.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">SDTMIG Version & Therapeutic Area</div>', unsafe_allow_html=True)
        st.caption(
            "Auto-detected from each spec Study tab. Override here if needed. "
            "Version-matched studies get higher confidence weight in the master."
        )
        target_ig_version = st.selectbox(
            "Target SDTMIG Version (for this master)",
            options=["Auto-detect from specs", "3.4", "3.3", "3.2", "3.1.3", "3.1.2"],
            index=0,
            help="Studies from the same SDTMIG version get full weight. Older versions are down-weighted.",
        )
        target_ta = st.multiselect(
            "Therapeutic Area filter (leave empty = all TAs pooled)",
            options=[
                "ONCOLOGY", "CARDIOLOGY", "NEUROLOGY", "RESPIRATORY",
                "IMMUNOLOGY", "RHEUMATOLOGY", "NEPHROLOGY", "OPHTHALMOLOGY",
                "HEMATOLOGY", "ENDOCRINOLOGY", "INFECTIOUS_DISEASE",
                "DERMATOLOGY", "GASTROENTEROLOGY", "MUSCULOSKELETAL",
            ],
            default=[],
            help="If selected, only studies matching these TAs are used for scoring that domain.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    run_build = st.button(
        "Build Master Mapping",
        disabled=(not study_files and not sponsor_files),
    )

    if run_build:
        try:
            import yaml, re
            with open(cfg_path_input) as f:
                cfg_data = yaml.safe_load(f)
            cfg_data["master_build"]["conflict_strategy"] = conflict_strategy
            # Write temp config
            tmp_cfg = Path(tempfile.mkdtemp()) / "config.yaml"
            import yaml as _yaml
            with open(tmp_cfg, "w") as f:
                _yaml.dump(cfg_data, f, default_flow_style=False, allow_unicode=False)

            tmpdir = _make_tmpdir()
            spec_paths    = [save_upload(f, tmpdir) for f in (study_files or [])]
            sponsor_paths = [save_upload(f, tmpdir) for f in (sponsor_files or [])]
            existing_path = None
            if existing_master_file:
                existing_path = save_upload(existing_master_file, tmpdir)

            study_dates = {}
            for line in dates_text.strip().splitlines():
                line = line.strip()
                if "=" in line:
                    fn, date = line.split("=", 1)
                    study_dates[fn.strip()] = date.strip()

            out_master = Path(tmpdir) / "master_mapping.xlsx"

            st.markdown("### Building...")
            master_df, log_lines = run_build_with_progress(
                spec_paths=spec_paths,
                sponsor_paths=sponsor_paths,
                existing_master=existing_path,
                out_path=out_master,
                config_path=tmp_cfg,
                study_dates=study_dates,
            )

            if master_df is not None and not master_df.empty:
                st.success(
                    f"Master mapping built: {len(master_df):,} rows | "
                    f"{master_df['SDTM_VARIABLE'].nunique()} SDTM variables | "
                    f"{master_df['DOMAIN'].nunique()} domains"
                )

                # Metrics
                top_df = master_df[master_df["IS_TOP_GROUP"]]
                high_n = int((top_df["MASTER_CONFIDENCE"] >= 0.82).sum())
                mid_n  = int(((top_df["MASTER_CONFIDENCE"] >= 0.55) & (top_df["MASTER_CONFIDENCE"] < 0.82)).sum())
                low_n  = int((top_df["MASTER_CONFIDENCE"] < 0.55).sum())

                pills = (
                    '<div class="metric-row">'
                    + metric_html(master_df["SDTM_VARIABLE"].nunique(), "SDTM Variables")
                    + metric_html(master_df["DOMAIN"].nunique(), "Domains", "")
                    + metric_html(int((master_df["IS_SPONSOR_STD"] == True).sum()), "Sponsor-Std Rows", "purple")
                    + metric_html(high_n, "High Conf (>=82%)", "green")
                    + metric_html(mid_n,  "Medium Conf",       "amber")
                    + metric_html(low_n,  "Low Conf (<55%)",   "red")
                    + '</div>'
                )
                st.markdown(pills, unsafe_allow_html=True)

                # Domain summary table
                st.markdown("#### Domain Summary")
                dom_sum = (
                    top_df.groupby("DOMAIN")
                    .agg(
                        SDTM_VARS=("SDTM_VARIABLE", "nunique"),
                        AVG_CONF=("MASTER_CONFIDENCE", "mean"),
                        HIGH_CONF=("MASTER_CONFIDENCE", lambda x: int((x >= 0.82).sum())),
                    )
                    .reset_index()
                    .round({"AVG_CONF": 3})
                )
                st.dataframe(dom_sum, use_container_width=True, hide_index=True)

                # Download
                st.markdown("#### Download")
                file_download_button(out_master, "Download master_mapping.xlsx")

                # Store in session state for next phase
                st.session_state["master_xlsx_bytes"] = out_master.read_bytes()
                st.session_state["master_built"]      = True

        except Exception as exc:
            st.error(f"Build failed: {exc}")
            st.code(traceback.format_exc(), language="text")
        finally:
            _rm_tmpdir(tmpdir)

    # ---- Auto-update watcher UI ----
    st.markdown("---")
    st.markdown("#### Auto-Update: Watch Folder for New/Changed Specs")
    st.caption(
        "Point to a local folder. When a spec Excel file changes or a new one appears, "
        "the master mapping is automatically rebuilt and session state is updated."
    )
    watch_folder = st.text_input(
        "Watch folder path (leave blank to disable)",
        value=st.session_state.get("watch_folder", ""),
        placeholder="/path/to/completed_specs/",
        key="watch_folder_input",
    )
    wcol1, wcol2 = st.columns([1, 3])
    with wcol1:
        check_now = st.button("Check for Changes")
    with wcol2:
        if st.session_state.get("auto_update_log"):
            st.caption("Last auto-update: " + st.session_state["auto_update_log"][-1])

    if watch_folder and (check_now or st.session_state.get("watch_folder") != watch_folder):
        st.session_state["watch_folder"] = watch_folder
        current_hashes = _scan_watch_folder(watch_folder)
        old_hashes     = st.session_state.get("watch_hashes", {})
        changed = [fn for fn, h in current_hashes.items() if old_hashes.get(fn) != h]
        if changed and st.session_state.get("master_built"):
            st.warning(f"Changes detected in: {', '.join(changed)} — rebuilding master...")
            try:
                import yaml as _yw
                with open(cfg_path_input) as _fw:
                    _cfw = _yw.safe_load(_fw)
                _tmpd = _make_tmpdir()
                _spec_paths = [Path(watch_folder) / fn for fn in current_hashes]
                _out = Path(_tmpd) / "master_mapping.xlsx"
                _existing = None
                if st.session_state.get("master_built"):
                    _existing = Path(_tmpd) / "existing_master.xlsx"
                    _existing.write_bytes(st.session_state["master_xlsx_bytes"])
                _cfg_tmp = Path(_tmpd) / "config.yaml"
                with open(_cfg_tmp, "w") as _f:
                    _yw.dump(_cfw, _f)
                _mdf, _ll = run_build_with_progress(
                    spec_paths=_spec_paths, sponsor_paths=[],
                    existing_master=_existing, out_path=_out,
                    config_path=_cfg_tmp, study_dates={},
                )
                if _mdf is not None:
                    st.session_state["master_xlsx_bytes"] = _out.read_bytes()
                    st.session_state["master_built"] = True
                    _msg = f"{dt.datetime.now():%H:%M:%S} — auto-rebuilt from {len(changed)} changed file(s)"
                    st.session_state["auto_update_log"].append(_msg)
                    st.success(f"Master auto-updated: {_msg}")
                _rm_tmpdir(_tmpd)
            except Exception as _e:
                st.error(f"Auto-update failed: {_e}")
        elif changed:
            st.info(f"Changed files detected ({', '.join(changed)}) — run Build Master first to create initial master.")
        else:
            st.success("No changes detected in watch folder.")
        st.session_state["watch_hashes"] = current_hashes


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================

