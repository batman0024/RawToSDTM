"""
Compare Specs page
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

from ui.helpers import (
    save_upload, _bytes_to_file, metric_html, log_html, _render_xai_bar,
    excel_download_button, file_download_button, coverage_chart_bytes,
    run_build_with_progress, run_map_with_progress, run_writeback_with_progress,
    _make_tmpdir, _rm_tmpdir, APP_DIR, SRC_DIR,
)

def render():
    """Render this page."""
    st.markdown("## Compare Specs — Side-by-Side Review")
    st.info(
        "Upload the original (standard) spec and the mapped spec from Write Back. "
        "Differences in Input Variables, Mapping Action, and Origin are shown side by side. "
        "Only changed rows are shown by default."
    )

    cmp_col_l, cmp_col_r = st.columns(2)
    with cmp_col_l:
        st.markdown('<div class="card"><div class="card-title">Original / Standard Spec</div>', unsafe_allow_html=True)
        orig_spec_upload = st.file_uploader("Original spec Excel", type=["xlsx","xlsm"], key="cmp_orig")
        if orig_spec_upload is not None:
            st.session_state["cmp_orig_bytes"] = (orig_spec_upload.name, orig_spec_upload.getbuffer().tobytes())
        elif st.session_state.get("cmp_orig_bytes"):
            st.caption(f"✓ Cached: {st.session_state['cmp_orig_bytes'][0]}")
        st.markdown("</div>", unsafe_allow_html=True)
    with cmp_col_r:
        st.markdown('<div class="card"><div class="card-title">Mapped Spec (Write Back output)</div>', unsafe_allow_html=True)
        mapped_spec_upload = st.file_uploader("Mapped spec Excel", type=["xlsx","xlsm"], key="cmp_mapped")
        if mapped_spec_upload is not None:
            st.session_state["cmp_mapped_bytes"] = (mapped_spec_upload.name, mapped_spec_upload.getbuffer().tobytes())
        elif st.session_state.get("cmp_mapped_bytes"):
            st.caption(f"✓ Cached: {st.session_state['cmp_mapped_bytes'][0]}")
        st.markdown("</div>", unsafe_allow_html=True)

    cmp_opt_l, cmp_opt_r = st.columns(2)
    with cmp_opt_l:
        show_all_rows    = st.checkbox("Show all rows (not just changed)", value=False)
    with cmp_opt_r:
        domain_filter_cmp = st.text_input("Filter domains (comma-separated, blank = all)", placeholder="DM, AE, CM")

    _SKIP_SHEETS = {"study","standards","toc","<ds>","ta","te","ti","tv","ts","td",
                    "ta-data","te-data","maintenance","valuelist","suppqual"}
    _HDR_VAR  = ["variable","sdtm variable","varname","var"]
    _HDR_DS   = ["dataset","domain","sdtm dataset"]
    _HDR_INP  = ["input variables","input variable","input_variables","raw inputs","source variables"]
    _HDR_ACT  = ["mapping action","mapping_action","derivation","algorithm","action"]
    _HDR_ORIG = ["origin","data origin","source type"]

    def _read_spec_for_compare(uploaded_file):
        import io as _io
        raw_bytes = uploaded_file.read()
        uploaded_file.seek(0)
        result = {}
        try:
            xl = pd.ExcelFile(_io.BytesIO(raw_bytes), engine="openpyxl")
            for sn in xl.sheet_names:
                if sn.lower().strip() in _SKIP_SHEETS:
                    continue
                try:
                    df = pd.read_excel(_io.BytesIO(raw_bytes), sheet_name=sn,
                                       header=None, engine="openpyxl", dtype=str).fillna("")
                    hdr_row, col_map = None, {}
                    for ri in range(min(15, len(df))):
                        row_vals = df.iloc[ri].tolist()
                        found = {}
                        for ci, v in enumerate(row_vals):
                            vl = str(v).strip().lower()
                            if vl in _HDR_VAR  and "VAR"  not in found: found["VAR"]    = ci
                            if vl in _HDR_DS   and "DS"   not in found: found["DS"]     = ci
                            if vl in _HDR_INP  and "INP"  not in found: found["INP"]    = ci
                            if vl in _HDR_ACT  and "ACT"  not in found: found["ACT"]    = ci
                            if vl in _HDR_ORIG and "ORIG" not in found: found["ORIG"]   = ci
                        if "VAR" in found and "INP" in found:
                            hdr_row, col_map = ri, found
                            break
                    if hdr_row is None:
                        continue
                    data = df.iloc[hdr_row + 1:].reset_index(drop=True)
                    rows = []
                    for _, drow in data.iterrows():
                        var = str(drow.iloc[col_map["VAR"]]).strip()
                        if not var or var.lower() == "nan":
                            continue
                        rows.append({
                            "VARIABLE":       var.upper(),
                            "DOMAIN":         str(drow.iloc[col_map["DS"]]).strip().upper() if "DS" in col_map else sn.upper(),
                            "INPUT_VARIABLES":str(drow.iloc[col_map["INP"]]).strip()  if "INP"  in col_map else "",
                            "MAPPING_ACTION": str(drow.iloc[col_map["ACT"]]).strip()  if "ACT"  in col_map else "",
                            "ORIGIN":         str(drow.iloc[col_map["ORIG"]]).strip() if "ORIG" in col_map else "",
                        })
                    if rows:
                        result[sn] = pd.DataFrame(rows)
                except Exception:
                    continue
        except Exception as exc:
            st.error(f"Could not read spec: {exc}")
        return result

    def _norm_tokens_cmp(s):
        import re as _re_nc
        # Flatten all separators: newlines, semicolons → comma
        flat = _re_nc.sub(r"[\n\r;]+", ",", str(s) if s is not None else "")
        return sorted(
            t.strip().lower().lstrip("raw.")  # normalise raw. prefix for comparison
            for t in flat.split(",")
            if t.strip() and t.strip().lower() not in ("nan", "none", "", "null")
        )

    # Use cached bytes if upload widgets are empty
    _cmp_orig_src   = orig_spec_upload   or (st.session_state.get("cmp_orig_bytes")   and _bytes_to_file(st.session_state["cmp_orig_bytes"]))
    _cmp_mapped_src = mapped_spec_upload or (st.session_state.get("cmp_mapped_bytes") and _bytes_to_file(st.session_state["cmp_mapped_bytes"]))

    if _cmp_orig_src and _cmp_mapped_src:
        with st.spinner("Reading and comparing specs..."):
            orig_sheets   = _read_spec_for_compare(_cmp_orig_src)
            mapped_sheets = _read_spec_for_compare(_cmp_mapped_src)

        if not orig_sheets or not mapped_sheets:
            st.error("Could not read one or both specs.")
        else:
            filter_list = [d.strip().upper() for d in domain_filter_cmp.split(",") if d.strip()]
            diff_rows_all, same_rows_all = [], []

            for sn, orig_df in orig_sheets.items():
                if filter_list and sn.upper() not in filter_list:
                    continue
                mapped_df = mapped_sheets.get(sn)
                if mapped_df is None:
                    continue

                merged = orig_df.merge(mapped_df, on="VARIABLE", suffixes=("_O","_M"), how="outer").fillna("")
                merged["SHEET"] = sn

                for col in ("INPUT_VARIABLES","MAPPING_ACTION","ORIGIN"):
                    for sfx in ("_O","_M"):
                        k = col + sfx
                        if k not in merged.columns:
                            merged[k] = ""
                        merged[k] = merged[k].astype(str).str.strip()

                def _iv_changed(row):
                    return _norm_tokens_cmp(row["INPUT_VARIABLES_O"]) != _norm_tokens_cmp(row["INPUT_VARIABLES_M"])
                def _clean(v):
                    v = str(v) if v is not None else ""
                    return v.strip().upper().replace("NAN","").replace("NONE","")
                def _act_changed(row):
                    return _clean(row.get("MAPPING_ACTION_O")) != _clean(row.get("MAPPING_ACTION_M"))
                def _orig_changed(row):
                    # Normalise origin separators: | and / are equivalent
                    o1 = _clean(row.get("ORIGIN_O")).replace("|","/")
                    o2 = _clean(row.get("ORIGIN_M")).replace("|","/")
                    return o1 != o2

                merged["IV_DIFF"]   = merged.apply(_iv_changed, axis=1)
                merged["ACT_DIFF"]  = merged.apply(_act_changed, axis=1)
                merged["ORIG_DIFF"] = merged.apply(_orig_changed, axis=1)
                merged["ANY_DIFF"]  = merged["IV_DIFF"] | merged["ACT_DIFF"] | merged["ORIG_DIFF"]

                diff_rows_all.append(merged[merged["ANY_DIFF"]])
                same_rows_all.append(merged[~merged["ANY_DIFF"]])

            diff_df_all = pd.concat(diff_rows_all, ignore_index=True) if diff_rows_all else pd.DataFrame()
            same_df_all = pd.concat(same_rows_all, ignore_index=True) if same_rows_all else pd.DataFrame()
            total_cmp   = len(diff_df_all) + len(same_df_all)

            st.markdown("---")
            cmp_pills = (
                '<div class="metric-row">'
                + metric_html(total_cmp,        "Total Variables", "")
                + metric_html(len(diff_df_all), "Changed",   "amber")
                + metric_html(len(same_df_all), "Unchanged", "green")
                + metric_html(
                    f"{round(100*len(diff_df_all)/total_cmp)}%" if total_cmp else "0%",
                    "Change Rate", "amber"
                )
                + '</div>'
            )
            st.markdown(cmp_pills, unsafe_allow_html=True)

            display_df = pd.concat([diff_df_all, same_df_all], ignore_index=True) if show_all_rows else diff_df_all

            if display_df.empty:
                st.success("No differences found between the two specs.")
            else:
                # Build readable view
                def _flag(b):
                    return "✏️" if b else "✓"

                view_rows = []
                for _, row in display_df.iterrows():
                    iv_o = row.get("INPUT_VARIABLES_O","")
                    iv_m = row.get("INPUT_VARIABLES_M","")
                    act_o = row.get("MAPPING_ACTION_O","")
                    act_m = row.get("MAPPING_ACTION_M","")
                    orig_o = row.get("ORIGIN_O","")
                    orig_m = row.get("ORIGIN_M","")
                    view_rows.append({
                        "Sheet":           row.get("SHEET",""),
                        "Variable":        row.get("VARIABLE",""),
                        "Status":          "✏️ Changed" if row.get("ANY_DIFF") else "✓ Same",
                        "IV — Original":   iv_o,
                        "IV — Mapped":     iv_m,
                        "IV Δ":            _flag(row.get("IV_DIFF",False)),
                        "Action — Orig":   act_o,
                        "Action — Mapped": act_m,
                        "Origin — Orig":   orig_o,
                        "Origin — Mapped": orig_m,
                    })
                view_df = pd.DataFrame(view_rows)

                # Color-grade with st.dataframe column config
                def _highlight_status(val):
                    if val == "✏️ Changed":
                        return "background-color:#FFF2CC;color:#7D6608;font-weight:bold"
                    return "background-color:#C6EFCE;color:#276221"

                st.markdown(f"**Showing {len(view_df)} rows** — {len(diff_df_all)} with differences")

                # Per-domain tabs
                domain_tabs_list = sorted(view_df["Sheet"].dropna().unique().tolist())
                if len(domain_tabs_list) > 1:
                    all_tab_labels = ["🗂 All Domains"] + domain_tabs_list
                    dtabs = st.tabs(all_tab_labels)
                    for dti, dlabel in enumerate(all_tab_labels):
                        with dtabs[dti]:
                            sub = view_df if dlabel == "🗂 All Domains" else view_df[view_df["Sheet"] == dlabel]
                            st.dataframe(
                                sub.drop(columns=["Sheet"], errors="ignore").style.applymap(
                                    _highlight_status, subset=["Status"]
                                ),
                                use_container_width=True, hide_index=True,
                            )
                else:
                    st.dataframe(
                        view_df.drop(columns=["Sheet"], errors="ignore").style.applymap(
                            _highlight_status, subset=["Status"]
                        ),
                        use_container_width=True, hide_index=True,
                    )

                st.markdown("---")
                excel_download_button(
                    {"Changed": diff_df_all[["SHEET","VARIABLE","INPUT_VARIABLES_O","INPUT_VARIABLES_M",
                                             "MAPPING_ACTION_O","MAPPING_ACTION_M","ORIGIN_O","ORIGIN_M"]]
                                if not diff_df_all.empty else pd.DataFrame(),
                     "All":     display_df[["SHEET","VARIABLE","INPUT_VARIABLES_O","INPUT_VARIABLES_M",
                                            "MAPPING_ACTION_O","MAPPING_ACTION_M"]].head(5000)},
                    "spec_comparison.xlsx",
                    "📥 Download Comparison Excel",
                )
    else:
        missing = []
        if not _cmp_orig_src:   missing.append("Original spec")
        if not _cmp_mapped_src: missing.append("Mapped spec")
        st.markdown(
            f'<div class="card" style="text-align:center;padding:40px">'
            f'<div style="font-size:48px">📊</div>'
            f'<div class="card-title" style="font-size:14px;margin-top:12px">Upload both specs to start comparison</div>'
            f'<div style="font-size:12px;color:#8b949e;margin-top:6px">'
            f'Still needed: {", ".join(missing)}</div>'
            '</div>',
            unsafe_allow_html=True,
        )

