"""
ui/pages/review_approve.py
===========================
Review & Approve Mappings page.
"""
import streamlit as st

def render():
    """Render the Review & Approve page."""
    st.markdown("## Review & Approve Mappings")
    # Import here to avoid circular deps — _render_review_panel lives in helpers
    from ui.helpers import _render_review_panel
    _render_review_panel()
