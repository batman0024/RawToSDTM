"""
ui/styles.py
============
Dark theme CSS for the SDTM Master Mapping System.
Import and apply with:
    from ui.styles import apply_theme
    apply_theme()
"""
import streamlit as st

DARK_CSS = """
<style>
/* ============================================================
   BASE — works on both dark (#0d1117 bg) and Streamlit light theme
   Key: use rgba() with enough opacity so they show on any bg
   ============================================================ */
html, body, [data-testid="stAppViewContainer"] {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif;
}
[data-testid="stSidebar"] {
    background-color: #161b22;
    border-right: 1px solid #30363d;
}
[data-testid="stSidebar"] * { color: #e6edf3 !important; }

/* ---- Header bar ---- */
.main-header {
    background: linear-gradient(135deg, #161b22 0%, #1c2330 100%);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px 28px 16px 28px;
    margin-bottom: 20px;
}
.main-header h1 {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    margin: 0 0 4px 0; letter-spacing: -0.02em;
}
.main-header p { font-size: 13px; color: #8b949e; margin: 0; }

/* ---- Cards ---- */
.card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    padding: 16px 18px;
    margin-bottom: 12px;
}
.card-title {
    font-size: 12px; font-weight: 600; color: #58a6ff;
    letter-spacing: 0.06em; text-transform: uppercase;
    margin-bottom: 10px;
}

/* ---- Metric pills ---- */
.metric-row { display: flex; gap: 10px; flex-wrap: wrap; margin: 12px 0; }
.metric-pill {
    background: #1c2330; border: 1px solid #30363d;
    border-radius: 6px; padding: 10px 16px; text-align: center;
    min-width: 100px; flex: 1;
    transition: transform 0.1s; cursor: default;
}
.metric-pill:hover { transform: translateY(-2px); }
.metric-pill .val {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    font-family: 'IBM Plex Mono', monospace; line-height: 1.2;
}
.metric-pill .val.green  { color: #3fb950; }
.metric-pill .val.amber  { color: #e3b341; }
.metric-pill .val.red    { color: #f85149; }
.metric-pill .val.purple { color: #bc8cff; }
.metric-pill .lbl { font-size: 11px; color: #8b949e; margin-top: 3px; }

/* ---- Status badges ---- */
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 3px;
    font-size: 11px; font-weight: 600; font-family: monospace;
}
.badge-direct  { background: rgba(63,185,80,0.18);  color: #3fb950;  border: 1px solid rgba(63,185,80,0.4);  }
.badge-review  { background: rgba(227,179,65,0.18); color: #e3b341;  border: 1px solid rgba(227,179,65,0.4); }
.badge-unres   { background: rgba(248,81,73,0.18);  color: #f85149;  border: 1px solid rgba(248,81,73,0.4);  }
.badge-cross   { background: rgba(188,140,255,0.18);color: #bc8cff;  border: 1px solid rgba(188,140,255,0.4);}
.badge-info    { background: rgba(88,166,255,0.14); color: #58a6ff;  border: 1px solid rgba(88,166,255,0.4); }

/* ---- Inputs & buttons ---- */
[data-testid="stFileUploader"] {
    background: #161b22; border: 1px dashed #30363d !important;
    border-radius: 6px; padding: 8px;
}
.stButton > button {
    background: #238636 !important; color: #ffffff !important;
    border: none !important; border-radius: 6px !important;
    font-weight: 600 !important; padding: 10px 24px !important;
    font-size: 13px !important; width: 100% !important;
    transition: background 0.2s !important;
}
.stButton > button:hover { background: #2ea043 !important; }
.stButton > button:disabled { background: #21262d !important; color: #8b949e !important; }

/* ---- Sidebar buttons (smaller, muted) ---- */
[data-testid="stSidebar"] .stButton > button {
    background: #21262d !important;
    color: #8b949e !important;
    border: 1px solid #30363d !important;
    font-size: 11px !important;
    padding: 4px 8px !important;
    width: 100% !important;
}
[data-testid="stSidebar"] .stButton > button:hover {
    background: #30363d !important;
    color: #e6edf3 !important;
}

/* ---- Progress bar ---- */
[data-testid="stProgress"] > div > div { background-color: #238636 !important; }

/* ---- Tables — improved alternating rows & hover ---- */
[data-testid="stDataFrame"] { border: 1px solid #30363d; border-radius: 6px; }
[data-testid="stDataFrame"] table { font-size: 12px !important; }
thead th {
    background-color: #161b22 !important; color: #58a6ff !important;
    font-size: 11px !important; text-transform: uppercase !important;
    letter-spacing: 0.04em !important;
}
[data-testid="stDataFrame"] tbody tr:nth-child(even) {
    background-color: rgba(88,166,255,0.04) !important;
}
[data-testid="stDataFrame"] tbody tr:hover {
    background-color: rgba(88,166,255,0.10) !important;
}

/* ---- Tabs — more readable ---- */
[data-testid="stTabs"] [role="tablist"] {
    border-bottom: 2px solid #30363d;
    gap: 2px;
    flex-wrap: wrap;
}
[data-testid="stTabs"] [role="tab"] {
    color: #8b949e !important;
    font-size: 12px !important;
    padding: 7px 14px !important;
    border-radius: 6px 6px 0 0 !important;
    transition: background 0.15s, color 0.15s;
}
[data-testid="stTabs"] [role="tab"]:hover {
    background: rgba(88,166,255,0.08) !important;
    color: #c9d1d9 !important;
}
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: #58a6ff !important;
    background: rgba(88,166,255,0.10) !important;
    border-bottom: 2px solid #58a6ff !important;
    font-weight: 700 !important;
}

/* ---- Alerts ---- */
.stSuccess { background: rgba(63,185,80,0.12) !important;  border-left: 4px solid #3fb950 !important; color: #3fb950 !important; }
.stWarning { background: rgba(227,179,65,0.12) !important; border-left: 4px solid #e3b341 !important; }
.stError   { background: rgba(248,81,73,0.12) !important;  border-left: 4px solid #f85149 !important; }
.stInfo    { background: rgba(88,166,255,0.10) !important; border-left: 4px solid #58a6ff !important; color: #8b949e !important; }

/* ---- Code blocks ---- */
code, pre { background: #161b22 !important; color: #a5d6ff !important; border: 1px solid #30363d !important; }

/* ---- Log area ---- */
.log-box {
    background: #0d1117; border: 1px solid #30363d; border-radius: 5px;
    padding: 14px; font-family: 'IBM Plex Mono', monospace;
    font-size: 13px; line-height: 1.6; color: #c9d1d9;
    max-height: 420px; overflow-y: auto;
    white-space: pre-wrap;
    scroll-behavior: smooth;
}
.log-box .log-ok   { color: #3fb950; font-weight: 600; }
.log-box .log-warn { color: #e3b341; }
.log-box .log-err  { color: #f85149; font-weight: 600; }
.log-info  { color: #8b949e; }
.log-ok    { color: #3fb950; }
.log-warn  { color: #e3b341; }
.log-err   { color: #f85149; }

/* ---- Sidebar labels ---- */
.sidebar-section {
    font-size: 10px; font-weight: 600; letter-spacing: 0.1em;
    text-transform: uppercase; color: #6e7681; padding: 12px 0 4px 0;
    border-bottom: 1px solid #30363d; margin-bottom: 8px;
}

/* ---- Divider ---- */
hr { border-color: #30363d !important; }

/* ---- Compare page: diff row colors ---- */
/* Applied via pandas Styler — these are fallbacks */
.diff-changed { background: rgba(227,179,65,0.18) !important; }
.diff-same    { background: rgba(63,185,80,0.10) !important;  }

/* ---- Tier color indicators ---- */
.tier-direct { color:#3fb950; font-weight:700; font-size:11px; }
.tier-review { color:#e3b341; font-weight:700; font-size:11px; }
.tier-cross  { color:#bc8cff; font-weight:700; font-size:11px; }
.tier-unres  { color:#f85149; font-weight:700; font-size:11px; }

/* ---- Score monospace coloring ---- */
.score-high   { color:#3fb950; font-weight:700; font-family:monospace; }
.score-medium { color:#e3b341; font-weight:700; font-family:monospace; }
.score-low    { color:#f85149; font-weight:700; font-family:monospace; }

/* ---- Raw->SDTM mapping table monospace ---- */
.raw-ds-name { color:#58a6ff; font-family:monospace; font-weight:600; }
.sdtm-domain { color:#3fb950; font-family:monospace; font-weight:600; }
</style>
"""

st.markdown(DARK_CSS, unsafe_allow_html=True)

def apply_theme():
    """Inject the dark CSS theme into the Streamlit app."""
    st.markdown(DARK_CSS, unsafe_allow_html=True)
