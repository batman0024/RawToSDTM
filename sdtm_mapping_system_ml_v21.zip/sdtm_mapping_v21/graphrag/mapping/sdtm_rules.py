"""
graphrag/mapping/sdtm_rules.py
================================
SDTM structural rules and domain knowledge for the knowledge graph.
Mirrors src/sdtm_knowledge.py but shaped for graph population.
No Streamlit imports.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

# ── Domain class map (Events / Findings / Interventions / Special / Trial) ────
DOMAIN_CLASS: Dict[str, str] = {
    "AE": "Events",   "CE": "Events",   "DS": "Events",   "DV": "Events",
    "HO": "Events",   "MH": "Events",
    "CM": "Interventions", "EC": "Interventions", "EX": "Interventions",
    "ML": "Interventions", "PR": "Interventions", "SU": "Interventions",
    "EG": "Findings", "IE": "Findings", "IS": "Findings", "LB": "Findings",
    "MB": "Findings", "MI": "Findings", "MK": "Findings", "MS": "Findings",
    "NV": "Findings", "OE": "Findings", "PC": "Findings", "PE": "Findings",
    "PP": "Findings", "QS": "Findings", "RE": "Findings", "RS": "Findings",
    "SC": "Findings", "TR": "Findings", "TU": "Findings", "UR": "Findings",
    "VS": "Findings",
    "DM": "Special",  "SE": "Special",  "SM": "Special",
    "SV": "Special",  "CO": "Special",
    "TA": "Trial",    "TE": "Trial",    "TI": "Trial",
    "TV": "Trial",    "TS": "Trial",    "TD": "Trial",
}

# ── Variable class patterns ────────────────────────────────────────────────────
_VAR_CLASS_RULES: List[tuple[str, List[str]]] = [
    ("identifier", [r"^STUDYID$", r"^DOMAIN$", r"^USUBJID$", r"^SUBJID$",
                    r"^SITEID$", r"^INVID$"]),
    ("sequence",   [r"SEQ$"]),
    ("timing",     [r"(ST|EN|OC|DC|RF)(DT|TM|DTC|DTM)$",
                    r"^(RFSTDTC|RFENDTC|RFICDTC|RFPENDTC)$",
                    r"DY$", r"^VISITNUM$", r"^EPOCH$"]),
    ("result",     [r"ORRES(U?)$", r"STRESC$", r"STRESN$", r"STRESU$",
                    r"TESTCD$", r"^TEST$"]),
    ("flag",       [r"FL$", r"IND$"]),
    ("derived",    [r"CHG$", r"PCHG$", r"^BASE$", r"SHIFT$",
                    r"ANRIND$", r"BNRIND$"]),
    ("codelist",   [r"SEV$", r"SCAT$", r"REAS$", r"ACN$", r"REL$",
                    r"OUT$", r"TOXGR$", r"GRADE$", r"STAT$"]),
    ("free_text",  [r"DECOD$", r"MODIFY$", r"VERBATIM$", r"SPEC$"]),
]

# Always-derived: no raw source expected
ALWAYS_DERIVED: frozenset[str] = frozenset({
    "USUBJID", "AGE", "AGEU", "AESEQ", "CMSEQ", "LBSEQ", "VSSEQ",
    "EXSEQ", "MHSEQ", "DSSEQ", "EGSEQ", "PESEQ", "VISITNUM",
})

# Protocol-sourced: hardcoded from study protocol
PROTOCOL_VARS: frozenset[str] = frozenset({
    "STUDYID", "DOMAIN", "ARM", "ACTARM", "ARMCD", "ACTARMCD",
    "EPOCH", "TRTPN", "TRTAN", "TRTP", "TRTA",
})

# SUPPQUAL structural variables
SUPP_STRUCTURAL: frozenset[str] = frozenset({
    "QNAM", "QLABEL", "QVAL", "QORIG", "QEVAL", "IDVAR", "IDVARVAL",
})


def classify_sdtm_var(variable: str, domain: str = "") -> str:
    """Return variable class string for graph node attribution."""
    v = variable.upper().strip()
    if v in ALWAYS_DERIVED:
        return "derived"
    if v in PROTOCOL_VARS:
        return "protocol"
    if v in SUPP_STRUCTURAL:
        return "supp_structural"
    for class_name, patterns in _VAR_CLASS_RULES:
        for pat in patterns:
            if re.search(pat, v):
                return class_name
    return "general"


# ── SDTM mapping rule library ──────────────────────────────────────────────────
# Each rule describes a common raw→SDTM mapping pattern.
# Used to pre-populate the graph with known mapping relationships
# before any master_mapping.xlsx data is loaded.

SDTM_MAPPING_RULES: List[Dict] = [
    {
        "id": "DEMO_IDENTIFIERS",
        "when": ["subject id", "usubjid", "subjid", "studyid", "siteid"],
        "sdtm_domain": "DM",
        "sdtm_vars": ["USUBJID", "SUBJID", "STUDYID", "SITEID"],
        "typical_raw": ["SUBJID", "USUBJID", "PATID", "SUBJECT", "SUBJECTID",
                        "PTNO", "STUDYID"],
        "action": "DERIVE",
        "desc": "Subject and study identifiers. USUBJID always derived from STUDYID+SUBJID.",
    },
    {
        "id": "AE_TERM",
        "when": ["adverse event", "aeterm", "aedecod", "ae term", "verbatim term"],
        "sdtm_domain": "AE",
        "sdtm_vars": ["AETERM", "AEDECOD", "AEBODSYS", "AESEV", "AESER"],
        "typical_raw": ["AETERM", "ADVERSE_EVENT", "AEDESC", "AE_TERM",
                        "VERBATIM", "AETXT", "AESEV", "SEVERITY"],
        "action": "ASSIGN",
        "desc": "Adverse event verbatim and coded terms. AEDECOD from MedDRA coding.",
    },
    {
        "id": "AE_DATES",
        "when": ["ae start date", "ae end date", "aestdtc", "aeendtc"],
        "sdtm_domain": "AE",
        "sdtm_vars": ["AESTDTC", "AEENDTC"],
        "typical_raw": ["AESTDT", "AESTDTC", "AEENDT", "AEENDTC",
                        "AESTDAT", "AEENDAT", "AESTTIME", "AESTTM"],
        "action": "ISO8601_DATETIME",
        "desc": "AE start/end dates concatenated and converted to ISO 8601.",
    },
    {
        "id": "LB_RESULTS",
        "when": ["lab result", "lbstresn", "lborres", "laboratory result"],
        "sdtm_domain": "LB",
        "sdtm_vars": ["LBTESTCD", "LBTEST", "LBORRES", "LBORRESU",
                      "LBSTRESN", "LBSTRESC", "LBSTRESU"],
        "typical_raw": ["LBTESTCD", "LBTEST", "LBORRES", "RESULT",
                        "LBSTRESN", "LBVAL", "TESTVAL", "NUMVAL"],
        "action": "ASSIGN",
        "desc": "Lab test results: original and standardized numeric/character values.",
    },
    {
        "id": "VS_RESULTS",
        "when": ["vital sign", "vsstresn", "blood pressure", "weight", "bmi"],
        "sdtm_domain": "VS",
        "sdtm_vars": ["VSTESTCD", "VSTEST", "VSORRES", "VSORRESU",
                      "VSSTRESN", "VSSTRESC"],
        "typical_raw": ["VSTESTCD", "VSTEST", "VSORRES", "VSVAL",
                        "VSSTRESN", "RESULT", "VALUE"],
        "action": "ASSIGN",
        "desc": "Vital sign measurements: original and standardized values.",
    },
    {
        "id": "EX_DOSE",
        "when": ["exposure", "dose", "treatment", "exstdtc", "exdose"],
        "sdtm_domain": "EX",
        "sdtm_vars": ["EXTRT", "EXDOSE", "EXDOSU", "EXROUTE",
                      "EXSTDTC", "EXENDTC", "EXDOSFRQ"],
        "typical_raw": ["EXTRT", "EXDOSE", "DOSE", "TRTNAME", "EXROUTE",
                        "EXSTDT", "EXENDT", "EXSTDTC"],
        "action": "ASSIGN",
        "desc": "Drug exposure: treatment name, dose, route, start/end dates.",
    },
    {
        "id": "CM_MED",
        "when": ["concomitant", "medication", "cmtrt", "cmdecod"],
        "sdtm_domain": "CM",
        "sdtm_vars": ["CMTRT", "CMDECOD", "CMCAT", "CMSTDTC", "CMENDTC"],
        "typical_raw": ["CMTRT", "MEDNAME", "CMDECOD", "CMCAT",
                        "CMSTDT", "CMENDT", "MEDICATION"],
        "action": "ASSIGN",
        "desc": "Concomitant and prior medications with start/end dates.",
    },
    {
        "id": "DM_DEMOGRAPHICS",
        "when": ["demographics", "age", "sex", "race", "dmage"],
        "sdtm_domain": "DM",
        "sdtm_vars": ["AGE", "SEX", "RACE", "ETHNIC", "ARMCD", "ARM",
                      "RFSTDTC", "RFENDTC"],
        "typical_raw": ["AGE", "SEX", "GENDER", "RACE", "ETHNIC",
                        "ARMCD", "TRTCD", "RFSTDT"],
        "action": "ASSIGN",
        "desc": "Demographic variables: age, sex, race, treatment arm.",
    },
    {
        "id": "DS_DISPOSITION",
        "when": ["disposition", "completion", "dsterm", "dsdecod"],
        "sdtm_domain": "DS",
        "sdtm_vars": ["DSTERM", "DSDECOD", "DSCAT", "DSSCAT", "DSSTDTC"],
        "typical_raw": ["DSTERM", "REASON", "DSDECOD", "COMPFL",
                        "DSSTDT", "DISCREAS", "DISCREASON"],
        "action": "ASSIGN",
        "desc": "Disposition events: completion/discontinuation terms and dates.",
    },
]


def match_sdtm_rule(question: str, domain: Optional[str] = None) -> Optional[Dict]:
    """Find the best matching SDTM mapping rule for a natural-language query."""
    q = question.lower()
    best_rule, best_score = None, 0.0

    for rule in SDTM_MAPPING_RULES:
        score = 0.0
        for kw in rule.get("when", []):
            if kw in q:
                score += 2.0 if " " in kw else 1.0
        if domain and rule.get("sdtm_domain", "").upper() == domain.upper():
            score += 1.5
        for tv in rule.get("sdtm_vars", []):
            if tv.lower() in q:
                score += 2.0
        if score > best_score:
            best_score = score
            best_rule = rule

    return best_rule if best_score > 0 else None


def get_rules_for_domain(domain: str) -> List[Dict]:
    return [r for r in SDTM_MAPPING_RULES
            if r.get("sdtm_domain", "").upper() == domain.upper()]
