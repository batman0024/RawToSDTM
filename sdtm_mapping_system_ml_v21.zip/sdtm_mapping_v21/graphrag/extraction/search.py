"""
graphrag/extraction/search.py
==============================
BM25 full-text search over master mapping text chunks.
Adapted from graphrag_adam project's search.py — domain-agnostic.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from typing import Dict, List

TOKEN_RE = re.compile(r"[A-Za-z0-9_./%-]+")


def tokenize(text: str) -> List[str]:
    return [t.lower() for t in TOKEN_RE.findall(text)]


K1 = 1.5
B  = 0.75


class SDTMIndexer:
    """BM25 search index over SDTM master mapping chunks."""

    def __init__(self, chunks: List[Dict]) -> None:
        self.chunks = chunks
        self.N = len(chunks)
        self.doc_tokens  = [tokenize(c.get("text", ""))   for c in chunks]
        self.hdr_tokens  = [tokenize(c.get("header", "")) for c in chunks]
        self.avg_dl = sum(len(t) for t in self.doc_tokens) / max(self.N, 1)
        self.dfs: Dict[str, int] = defaultdict(int)
        for toks in self.doc_tokens:
            for t in set(toks):
                self.dfs[t] += 1

    def _bm25(self, q_tokens: List[str], doc_idx: int) -> float:
        toks = self.doc_tokens[doc_idx]
        if not toks:
            return 0.0
        tf = Counter(toks)
        dl = len(toks)
        score = 0.0
        for t in q_tokens:
            if t not in tf:
                continue
            df = self.dfs.get(t, 1)
            idf = math.log((self.N - df + 0.5) / (df + 0.5) + 1.0)
            tf_norm = (tf[t] * (K1 + 1)) / (
                tf[t] + K1 * (1 - B + B * dl / max(self.avg_dl, 1))
            )
            score += idf * tf_norm
        return score

    def _header_boost(self, q_tokens: List[str], doc_idx: int) -> float:
        hdr = set(self.hdr_tokens[doc_idx])
        return sum(4.0 for t in q_tokens if t in hdr)

    def score(self, q_tokens: List[str], doc_idx: int) -> float:
        return self._bm25(q_tokens, doc_idx) + self._header_boost(q_tokens, doc_idx)

    def search(self, query: str, topk: int = 10) -> List[Dict]:
        q_toks = tokenize(query)
        scored = [(i, self.score(q_toks, i)) for i in range(self.N)]
        scored.sort(key=lambda x: x[1], reverse=True)
        results = []
        for i, sc in scored[:topk]:
            c = self.chunks[i].copy()
            c["score"] = round(sc, 4)
            results.append(c)
        return [r for r in results if r["score"] > 0]
