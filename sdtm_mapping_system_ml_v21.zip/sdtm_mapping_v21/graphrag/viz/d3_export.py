"""
graphrag/viz/d3_export.py
==========================
Generates an interactive D3.js HTML visualization of the SDTM Knowledge Graph.
Adapted from graphrag_adam project's d3_html.py with SDTM-specific node types,
colours, and edge labels.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any


# ── Node/Edge colour configuration ───────────────────────────────────────────
NODE_COLORS: Dict[str, str] = {
    "raw_var":       "#f97316",   # orange  — raw study variables
    "sdtm_var":      "#4a9eff",   # blue    — SDTM target variables
    "raw_dataset":   "#fb923c",   # light orange — raw datasets
    "sdtm_domain":   "#38bdf8",   # cyan    — SDTM domains
    "mapping_group": "#a78bfa",   # purple  — mapping groups
    "study":         "#4ade80",   # green   — source studies
}

NODE_SHAPES: Dict[str, str] = {
    "raw_var":       "circle",
    "sdtm_var":      "circle",
    "raw_dataset":   "rect",
    "sdtm_domain":   "rect",
    "mapping_group": "diamond",
    "study":         "triangle",
}

NODE_SIZES: Dict[str, int] = {
    "raw_var":       8,
    "sdtm_var":      10,
    "raw_dataset":   20,
    "sdtm_domain":   22,
    "mapping_group": 12,
    "study":         16,
}

EDGE_COLORS: Dict[str, str] = {
    "MAPS_TO":        "#f9731660",
    "IN_GROUP":       "#a78bfa40",
    "GOVERNS":        "#4a9eff50",
    "MEMBER_OF_RAW":  "#fb923c30",
    "MEMBER_OF_DOM":  "#38bdf830",
    "SEEN_IN":        "#4ade8030",
    "CO_MAPPED_WITH": "#e2e8f020",
    "SAME_CLASS":     "#94a3b820",
}


def kg_to_d3_json(kg) -> Dict[str, Any]:
    """Convert SDTMKnowledgeGraph to D3-compatible JSON."""
    nodes, links = [], []

    for nid, data in kg.G.nodes(data=True):
        kind = data.get("kind", "unknown")
        nodes.append({
            "id":    nid,
            "kind":  kind,
            "label": data.get("label_display", nid.split("::")[-1])[:40],
            "color": NODE_COLORS.get(kind, "#64748b"),
            "size":  NODE_SIZES.get(kind, 8),
            "shape": NODE_SHAPES.get(kind, "circle"),
            # Extra data for detail panel
            "domain":   data.get("domain", ""),
            "variable": data.get("variable", ""),
            "dataset":  data.get("dataset", ""),
            "action":   data.get("mapping_action", ""),
            "conf":     data.get("confidence", 0),
            "n_studies":data.get("n_studies", 0),
            "var_class":data.get("var_class", ""),
            "core":     data.get("core", ""),
        })

    for u, v, data in kg.G.edges(data=True):
        etype = data.get("type", "")
        score = data.get("score", data.get("weight", 1.0))
        links.append({
            "source": u,
            "target": v,
            "type":   etype,
            "color":  EDGE_COLORS.get(etype, "#1e2d4540"),
            "weight": round(float(score or 0), 3),
            "label":  etype.replace("_", " "),
        })

    return {"nodes": nodes, "links": links}


def generate_d3_html(kg, title: str = "SDTM Mapping Knowledge Graph") -> str:
    """Generate complete standalone D3.js HTML visualisation."""
    import json as _json
    data = kg_to_d3_json(kg)
    stats = kg.stats()
    data_json = _json.dumps(data, ensure_ascii=True)

    # Stats bar
    stats_parts = []
    for k, v in stats.get("node_kinds", {}).items():
        c = NODE_COLORS.get(k, "#94a3b8")
        lbl = k.replace("_", " ")
        stats_parts.append(
            '<span class="stat-badge" style="color:' + c + '">&#9632; '
            + str(v) + " " + lbl + "</span>"
        )
    stats_html = " &middot; ".join(stats_parts)

    # Edge filter checkboxes
    edge_types = sorted(set(
        d.get("type", "") for _, _, d in kg.G.edges(data=True) if d.get("type")
    ))
    edge_filter_parts = []
    for et in edge_types:
        c = EDGE_COLORS.get(et, "#94a3b840")
        lbl = et.replace("_", " ")
        edge_filter_parts.append(
            '<label class="edge-toggle">'
            '<input type="checkbox" class="edge-cb" data-etype="' + et + '" checked>'
            '<span style="color:' + c + ';font-size:16px">&#9473;</span> ' + lbl
            + "</label>"
        )
    edge_filter_html = "".join(edge_filter_parts)

    # Legend
    legend_parts = []
    for k, c in NODE_COLORS.items():
        lbl = k.replace("_", " ")
        legend_parts.append(
            '<div class="legend-item">'
            '<span class="legend-dot" style="background:' + c + '"></span>'
            + lbl + "</div>"
        )
    legend_html = "".join(legend_parts)

    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>""" + title + """</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#080c14;--bg2:#0d1422;--bg3:#121b2e;
  --panel:#0d1422;--border:#1e2d45;--border2:#253550;
  --text:#e2eaf5;--muted:#7a93b4;
  --accent:#f97316;--mono:'Courier New',monospace;
}
html,body{height:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:var(--mono);display:flex;flex-direction:column;}
#topbar{display:flex;align-items:center;gap:10px;padding:8px 14px;background:var(--bg2);border-bottom:1px solid var(--border);flex-shrink:0;flex-wrap:wrap;}
.logo{font-size:13px;font-weight:700;color:var(--accent);}
.sep{width:1px;height:20px;background:var(--border2);}
#searchBox{background:var(--bg3);border:1px solid var(--border2);border-radius:4px;color:var(--text);font-family:var(--mono);font-size:11px;padding:5px 10px;width:200px;outline:none;}
#searchBox:focus{border-color:var(--accent);}
.stat-badge{font-size:10px;margin-right:6px;}
.btn{background:var(--bg3);border:1px solid var(--border2);border-radius:4px;color:var(--text);font-size:10px;padding:4px 10px;cursor:pointer;}
.btn:hover{border-color:var(--accent);color:var(--accent);}
#main{display:flex;flex:1;overflow:hidden;}
#graphArea{flex:1;position:relative;overflow:hidden;}
#canvas{width:100%;height:100%;}
#rightPanel{width:280px;background:var(--panel);border-left:1px solid var(--border);overflow-y:auto;flex-shrink:0;display:flex;flex-direction:column;}
#edgeFilters,#legendPanel,#detailPanel{padding:12px;border-bottom:1px solid var(--border);}
h3.panel-hdr{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px;}
.edge-toggle{display:flex;align-items:center;gap:6px;font-size:10px;cursor:pointer;margin-bottom:4px;}
.legend-item{display:flex;align-items:center;gap:6px;font-size:10px;margin-bottom:3px;}
.legend-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;}
.detail-key{color:var(--muted);}
.detail-val{color:var(--text);word-break:break-all;}
.node{cursor:pointer;}
.link{stroke-opacity:.5;}
.link.hidden{display:none;}
#tooltip{position:absolute;background:var(--bg2);border:1px solid var(--border2);border-radius:6px;padding:8px 12px;font-size:11px;pointer-events:none;opacity:0;transition:opacity .15s;max-width:220px;z-index:100;}
</style>
</head>
<body>
<div id="topbar">
  <span class="logo">&#129516; SDTM Mapping Knowledge Graph</span>
  <div class="sep"></div>
  <input id="searchBox" type="text" placeholder="search nodes..."/>
  <div class="sep"></div>
  <span id="statsBar">""" + stats_html + """</span>
  <div class="sep"></div>
  <button class="btn" onclick="resetZoom()">Reset</button>
  <button class="btn" onclick="toggleLabels()">Labels</button>
</div>
<div id="main">
  <div id="graphArea">
    <svg id="canvas"></svg>
    <div id="tooltip"></div>
  </div>
  <div id="rightPanel">
    <div id="edgeFilters">
      <h3 class="panel-hdr">Edge Types</h3>""" + edge_filter_html + """
    </div>
    <div id="legendPanel">
      <h3 class="panel-hdr">Node Types</h3>""" + legend_html + """
    </div>
    <div id="detailPanel">
      <h3 class="panel-hdr">Node Details</h3>
      <div id="detailContent"><span style="color:var(--muted)">Click a node</span></div>
    </div>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
<script>
const GRAPH = """ + data_json + """;
let showLabels = true;
const svg = d3.select('#canvas');
const g   = svg.append('g');
const zoom = d3.zoom().scaleExtent([0.05,8]).on('zoom',e=>g.attr('transform',e.transform));
svg.call(zoom);
function resetZoom(){svg.transition().duration(400).call(zoom.transform,d3.zoomIdentity.translate(window.innerWidth/2,window.innerHeight/2).scale(0.6));}
function toggleLabels(){showLabels=!showLabels;g.selectAll('.nlabel').style('display',showLabels?'block':'none');}
const sim = d3.forceSimulation(GRAPH.nodes)
  .force('link',d3.forceLink(GRAPH.links).id(d=>d.id).distance(90).strength(0.4))
  .force('charge',d3.forceManyBody().strength(-200))
  .force('center',d3.forceCenter(0,0))
  .force('collision',d3.forceCollide(d=>(d.size||8)+5));
const linkSel = g.append('g').selectAll('line').data(GRAPH.links).join('line')
  .attr('class','link').attr('data-etype',d=>d.type)
  .attr('stroke',d=>d.color||'#1e2d4540')
  .attr('stroke-width',d=>Math.max(0.5,(d.weight||0.5)*1.5));
const nodeSel = g.append('g').selectAll('.node').data(GRAPH.nodes).join('g')
  .attr('class','node')
  .call(d3.drag()
    .on('start',(e,d)=>{if(!e.active)sim.alphaTarget(0.3).restart();d.fx=d.x;d.fy=d.y;})
    .on('drag', (e,d)=>{d.fx=e.x;d.fy=e.y;})
    .on('end',  (e,d)=>{if(!e.active)sim.alphaTarget(0);})
  )
  .on('click',(e,d)=>showDetail(d))
  .on('mouseover',(e,d)=>showTip(e,d))
  .on('mouseout',()=>hideTip());
nodeSel.each(function(d){
  const el=d3.select(this),s=d.size||8,c=d.color||'#64748b';
  if(d.shape==='rect'){
    el.append('rect').attr('x',-s).attr('y',-s*.6).attr('width',s*2).attr('height',s*1.2).attr('rx',3).attr('fill',c+'22').attr('stroke',c);
  } else if(d.shape==='diamond'){
    const pts=[[0,-s],[s*.7,0],[0,s],[-s*.7,0]].map(p=>p.join(',')).join(' ');
    el.append('polygon').attr('points',pts).attr('fill',c+'22').attr('stroke',c);
  } else if(d.shape==='triangle'){
    const pts=[[0,-s],[s*.8,s*.5],[-s*.8,s*.5]].map(p=>p.join(',')).join(' ');
    el.append('polygon').attr('points',pts).attr('fill',c+'22').attr('stroke',c);
  } else {
    el.append('circle').attr('r',s).attr('fill',c+'22').attr('stroke',c);
  }
  el.append('text').attr('class','nlabel').attr('dy','1.5em').attr('text-anchor','middle')
    .attr('fill','#e2eaf5').attr('font-size',9).text(d.label||'');
});
sim.on('tick',()=>{
  linkSel.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
  nodeSel.attr('transform',d=>'translate('+d.x+','+d.y+')');
});
document.querySelectorAll('.edge-cb').forEach(cb=>{
  cb.addEventListener('change',()=>{
    g.selectAll('[data-etype="'+cb.dataset.etype+'"]').classed('hidden',!cb.checked);
  });
});
document.getElementById('searchBox').addEventListener('input',function(){
  const q=this.value.toLowerCase();
  nodeSel.style('opacity',d=>(!q||d.label.toLowerCase().includes(q)||(d.variable||'').toLowerCase().includes(q))?1:0.1);
});
const tip=document.getElementById('tooltip');
function showTip(e,d){
  tip.style.opacity=1;
  tip.innerHTML='<b style="color:'+d.color+'">'+d.kind+'</b><br>'
    +(d.domain?'<b>Domain:</b> '+d.domain+'<br>':'')
    +(d.variable?'<b>Var:</b> '+d.variable+'<br>':'')
    +(d.conf?'<b>Conf:</b> '+d.conf+'<br>':'')
    +(d.n_studies?'<b>Studies:</b> '+d.n_studies:'');
  tip.style.left=(e.offsetX+12)+'px';tip.style.top=(e.offsetY-10)+'px';
}
function hideTip(){tip.style.opacity=0;}
function showDetail(d){
  const rows=[['Kind',d.kind],['Domain',d.domain],['Variable',d.variable],['Dataset',d.dataset],
    ['Action',d.action],['Confidence',d.conf],['Studies',d.n_studies],['Class',d.var_class],['Core',d.core]]
    .filter(([,v])=>v);
  document.getElementById('detailContent').innerHTML=rows.map(
    ([k,v])=>'<div><span class="detail-key">'+k+': </span><span class="detail-val">'+v+'</span></div>'
  ).join('');
}
setTimeout(()=>svg.call(zoom.transform,d3.zoomIdentity.translate(window.innerWidth/2,window.innerHeight/2).scale(0.6)),200);
</script>
</body>
</html>"""


def export_graph_html(kg, out_path: Path,
                      title: str = "SDTM Mapping Knowledge Graph") -> Path:
    """Write the D3 HTML to a file."""
    html = generate_d3_html(kg, title)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")
    return out_path
