"""
graphrag/ingestion/master_ingestion.py
=======================================
Ingests master_mapping.xlsx into the SDTMKnowledgeGraph.
Also converts master data into BM25-searchable text chunks.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Optional, Any

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

import pandas as pd


def load_master_to_graph(master_path: Path, kg=None):
    """
    Load master_mapping.xlsx and populate a SDTMKnowledgeGraph.

    Args:
        master_path: Path to master_mapping.xlsx
        kg:          Existing SDTMKnowledgeGraph (creates new if None)

    Returns:
        Populated SDTMKnowledgeGraph
    """
    from graphrag.graph.sdtm_kg import SDTMKnowledgeGraph
    from graphrag.mapping.sdtm_rules import SDTM_MAPPING_RULES

    if kg is None:
        kg = SDTMKnowledgeGraph()

    # Load master sheet
    try:
        master_df = pd.read_excel(
            master_path, sheet_name="master_all",
            engine="openpyxl", dtype=object
        )
    except Exception:
        try:
            master_df = pd.read_excel(master_path, engine="openpyxl", dtype=object)
        except Exception as exc:
            raise ValueError(f"Cannot load master from {master_path}: {exc}")

    master_df["MASTER_CONFIDENCE"] = pd.to_numeric(
        master_df.get("MASTER_CONFIDENCE", 0), errors="coerce"
    ).fillna(0.0)

    # Pre-populate with structural SDTM rules
    for rule in SDTM_MAPPING_RULES:
        dom = rule.get("sdtm_domain", "")
        for sv in rule.get("sdtm_vars", []):
            kg.add_sdtm_var(dom, sv, var_class="general")

    # Populate from master data
    kg.populate_from_master(master_df)

    return kg


def load_raw_catalog_to_graph(raw_df: pd.DataFrame, kg) -> None:
    """
    Add raw variable nodes from a raw catalog DataFrame to an existing graph.
    Nodes will be linked when master data provides MAPS_TO edges.
    """
    for _, row in raw_df.iterrows():
        dataset = str(row.get("RAW_DATASET", "") or "").strip().upper()
        variable = str(row.get("VARIABLE", "") or "").strip().upper()
        label = str(row.get("LABEL", "") or "").strip()
        fmt = str(row.get("FORMAT", "") or "").strip()
        vtype = str(row.get("TYPE", "") or "").strip()

        if dataset and variable:
            kg.add_raw_var(dataset, variable, label, fmt, vtype)


def master_to_chunks(master_path: Path) -> List[Dict]:
    """
    Convert master_mapping data into text chunks for BM25 indexing.
    Each chunk represents one SDTM variable's full mapping history.
    """
    try:
        master_df = pd.read_excel(
            master_path, sheet_name="master_all",
            engine="openpyxl", dtype=object
        )
    except Exception:
        return []

    chunks: List[Dict] = []
    grouped = master_df.groupby(["DOMAIN", "SDTM_VARIABLE"])

    for (domain, sdtm_var), grp in grouped:
        raw_vars = [
            str(r).strip() for r in grp.get("RAW_VARIABLE", []).dropna()
            if str(r).strip() not in ("", "NAN")
        ]
        labels = list(set(
            str(r).strip() for r in grp.get("SDTM_LABEL", []).dropna()
            if str(r).strip()
        ))
        actions = list(set(
            str(r).strip() for r in grp.get("MAPPING_ACTION", []).dropna()
            if str(r).strip()
        ))
        conf = float(grp["MASTER_CONFIDENCE"].max() if "MASTER_CONFIDENCE" in grp else 0)

        text_parts = [
            f"SDTM variable {domain}.{sdtm_var}.",
            f"Label: {', '.join(labels)}." if labels else "",
            f"Raw source variables: {', '.join(raw_vars)}." if raw_vars else "",
            f"Mapping actions: {', '.join(actions)}." if actions else "",
            f"Master confidence: {conf:.2f}.",
            f"Appears in {len(grp)} historical mappings.",
        ]
        text = " ".join(p for p in text_parts if p)

        chunks.append({
            "id": f"MASTER::{domain}::{sdtm_var}",
            "doc": str(master_path.name),
            "doc_type": "master",
            "header": f"{domain}.{sdtm_var}",
            "text": text,
            "domain": domain,
            "sdtm_var": sdtm_var,
            "raw_vars": raw_vars,
            "confidence": conf,
        })

    return chunks
