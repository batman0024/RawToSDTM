"""
graphrag/graph/builder.py
==========================
Orchestrates SDTM Knowledge Graph construction from master data.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger("sdtm_app.graphrag.builder")


def build_sdtm_knowledge_graph(
    master_path: Path,
    raw_df=None,
    mapping_results: Optional[dict] = None,
):
    """
    Build the full SDTMKnowledgeGraph.

    Steps:
      1. Pre-populate structural SDTM rules (domains, variable classes)
      2. Ingest master_mapping.xlsx (raw→SDTM historical pairs)
      3. Add raw catalog variables if provided
      4. Overlay fresh mapping results if provided

    Args:
        master_path:     Path to master_mapping.xlsx
        raw_df:          Optional raw catalog DataFrame
        mapping_results: Optional results dict from mapper.run_mapping()

    Returns:
        (SDTMKnowledgeGraph, List[chunk_dicts])
    """
    from graphrag.ingestion.master_ingestion import (
        load_master_to_graph, load_raw_catalog_to_graph, master_to_chunks
    )
    from graphrag.graph.sdtm_kg import SDTMKnowledgeGraph

    log.info("Building SDTM Knowledge Graph from %s", master_path.name)

    kg = SDTMKnowledgeGraph()

    # Step 1+2: Structural rules + master data
    kg = load_master_to_graph(master_path, kg)
    stats = kg.stats()
    log.info("After master ingestion: %d nodes, %d edges",
             stats["total_nodes"], stats["total_edges"])

    # Step 3: Raw catalog
    if raw_df is not None and not raw_df.empty:
        load_raw_catalog_to_graph(raw_df, kg)
        log.info("After raw catalog: %d nodes", kg.G.number_of_nodes())

    # Step 4: Fresh mapping results overlay
    if mapping_results:
        kg.populate_from_mapping_results(mapping_results)
        log.info("After mapping results overlay: %d edges", kg.G.number_of_edges())

    # Build text chunks for BM25 search
    chunks = master_to_chunks(master_path)
    log.info("Graph build complete. %d chunks for BM25 index.", len(chunks))

    return kg, chunks
