"""
api/main.py
===========
FastAPI application factory for the SDTM Mapping System API.
Activated only when ENABLE_FASTAPI=true in settings.

Run standalone:
    uvicorn api.main:app --reload --port 8000

Or via launch.bat which starts it in a separate window.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

# Ensure src/ is importable when running directly
_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(_ROOT / "src"))
sys.path.insert(0, str(_ROOT))

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config.settings import settings
from exceptions.domain_exceptions import (
    AuthError,
    MappingError,
    MasterBuildError,
    SDTMBaseError,
    WritebackError,
)
from logging_config.setup import configure_logging

# Configure logging on import
configure_logging(level=settings.LOG_LEVEL, fmt=settings.LOG_FORMAT)
log = logging.getLogger("sdtm_app.api")


def create_app() -> FastAPI:
    """Application factory — returns a configured FastAPI instance."""

    app = FastAPI(
        title="SDTM Master Mapping System API",
        description=(
            "REST API for the SDTM Master Mapping System. "
            "Provides programmatic access to the build, map, and writeback pipeline. "
            "Uses magic-link email authentication (no passwords)."
        ),
        version="18.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # ── CORS ─────────────────────────────────────────────────────────────────
    streamlit_origin = "http://localhost:8501"
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[streamlit_origin, settings.BASE_URL],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Exception handlers ────────────────────────────────────────────────────

    @app.exception_handler(AuthError)
    async def auth_error_handler(request: Request, exc: AuthError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"detail": exc.message},
        )

    @app.exception_handler(MappingError)
    async def mapping_error_handler(request: Request, exc: MappingError) -> JSONResponse:
        log.error("MappingError: %s", exc.message)
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"detail": exc.message},
        )

    @app.exception_handler(MasterBuildError)
    async def master_error_handler(request: Request, exc: MasterBuildError) -> JSONResponse:
        log.error("MasterBuildError: %s", exc.message)
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"detail": exc.message},
        )

    @app.exception_handler(WritebackError)
    async def writeback_error_handler(request: Request, exc: WritebackError) -> JSONResponse:
        log.error("WritebackError: %s", exc.message)
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"detail": exc.message},
        )

    @app.exception_handler(SDTMBaseError)
    async def sdtm_base_error_handler(request: Request, exc: SDTMBaseError) -> JSONResponse:
        log.error("SDTMBaseError: %s", exc.message)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": exc.message},
        )

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
        log.error("Unhandled error on %s: %s", request.url, exc, exc_info=True)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "An internal error occurred. Check server logs."},
        )

    # ── Routers ───────────────────────────────────────────────────────────────
    from api.routers.health import router as health_router
    from api.routers.auth import router as auth_router
    from api.routers.mapping import router as mapping_router

    app.include_router(health_router)
    app.include_router(auth_router)
    app.include_router(mapping_router)

    @app.on_event("startup")
    async def startup_event() -> None:
        # Validate critical settings in production
        try:
            settings.validate_for_production()
        except ValueError as exc:
            log.critical("Startup validation failed: %s", exc)
            raise RuntimeError(str(exc)) from exc

        # Ensure temp directory exists
        Path(settings.TEMP_DIR).mkdir(parents=True, exist_ok=True)
        log.info(
            "SDTM Mapping API started. env=%s auth=%s",
            settings.ENVIRONMENT, settings.ENABLE_AUTH,
        )

    return app


app = create_app()
