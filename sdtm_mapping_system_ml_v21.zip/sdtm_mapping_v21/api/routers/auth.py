"""
api/routers/auth.py
===================
Magic-link email authentication endpoints.

Flow:
  POST /auth/request-link  -> validates email, sends magic link, returns generic message
  GET  /auth/verify        -> validates token, returns signed JWT
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status

from api.dependencies import get_email_sender, get_magic_link_service
from auth.email_sender import AbstractEmailSender
from auth.magic_link import MagicLinkService
from exceptions.domain_exceptions import (
    AuthError,
    DomainNotAllowedError,
    RateLimitError,
    TokenAlreadyUsedError,
    TokenExpiredError,
    TokenNotFoundError,
)
from models.auth_models import MagicLinkRequest, MagicLinkResponse, TokenVerifyResponse
from config.settings import settings

router = APIRouter(prefix="/auth", tags=["authentication"])
log = logging.getLogger("sdtm_app.api.auth")


def _send_link_background(
    email: str,
    magic_link: str,
    sender: AbstractEmailSender,
) -> None:
    """Background task: send magic link email. Errors are logged, not re-raised."""
    try:
        sender.send_magic_link(email, magic_link)
    except Exception as exc:
        log.error("Failed to send magic link to %s: %s", email, exc)


@router.post(
    "/request-link",
    response_model=MagicLinkResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Request a magic login link",
    description=(
        "Submit an email address. If the domain is allowed, a one-time login link "
        "is sent to that address. Always returns the same generic message to prevent "
        "email enumeration."
    ),
)
async def request_magic_link(
    body: MagicLinkRequest,
    background_tasks: BackgroundTasks,
    svc: MagicLinkService = Depends(get_magic_link_service),
    sender: AbstractEmailSender = Depends(get_email_sender),
) -> MagicLinkResponse:
    log.info("Magic link requested for: %s", body.email)
    try:
        magic_link = svc.request_link(str(body.email))
        # Fire-and-forget email send — never block the response on SMTP
        background_tasks.add_task(_send_link_background, str(body.email), magic_link, sender)
    except RateLimitError as exc:
        # Surface rate limit to caller (not a secret)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=exc.message,
        )
    except DomainNotAllowedError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=exc.message,
        )
    except AuthError:
        # All other auth errors: return generic message (no enumeration)
        pass
    # Always return same message — never reveal whether email exists
    return MagicLinkResponse()


@router.get(
    "/verify",
    response_model=TokenVerifyResponse,
    summary="Verify magic link token",
    description=(
        "Validate a one-time magic-link token. "
        "Returns a signed JWT access token on success."
    ),
)
async def verify_magic_link(
    token: str = Query(..., description="One-time magic link token from email"),
    svc: MagicLinkService = Depends(get_magic_link_service),
) -> TokenVerifyResponse:
    try:
        jwt_token = svc.verify_token(token)
    except TokenExpiredError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=exc.message)
    except TokenAlreadyUsedError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=exc.message)
    except TokenNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=exc.message)
    except AuthError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=exc.message)

    return TokenVerifyResponse(
        access_token=jwt_token,
        expires_in_seconds=settings.JWT_EXPIRY_HOURS * 3600,
        email=svc.decode_jwt(jwt_token),
    )
