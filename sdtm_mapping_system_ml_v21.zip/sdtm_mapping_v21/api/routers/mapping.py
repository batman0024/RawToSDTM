"""
api/routers/mapping.py
=======================
Authenticated mapping pipeline endpoints.
All three pipeline operations (build, map, writeback) run as background jobs
and return a job_id immediately. Clients poll /status/{id}.
"""
from __future__ import annotations

import logging
import os
import shutil
import threading
import uuid
from pathlib import Path
from typing import Annotated

from fastapi import (
    APIRouter, BackgroundTasks, Depends, File, HTTPException,
    Query, UploadFile, status,
)
from fastapi.responses import FileResponse

from api.dependencies import get_current_user, get_job_store
from api.job_store import JobStore
from config.settings import settings
from exceptions.domain_exceptions import MappingError, MasterBuildError, WritebackError
from models.mapping_models import JobResponse, JobStatus

router = APIRouter(prefix="/api/v1/mapping", tags=["mapping"])
log = logging.getLogger("sdtm_app.api.mapping")


def _ensure_tmp(subdir: str = "") -> Path:
    base = Path(settings.TEMP_DIR)
    p = base / subdir if subdir else base
    p.mkdir(parents=True, exist_ok=True)
    return p


def _save_upload(upload: UploadFile, dest: Path) -> Path:
    # Sanitise filename: strip any path components to prevent path traversal
    # e.g. "../../etc/cron.d/evil" -> "evil"  (security fix, v20)
    raw_name  = upload.filename or f"upload_{uuid.uuid4().hex}"
    safe_name = Path(raw_name).name or f"upload_{uuid.uuid4().hex}"
    target    = dest / safe_name
    with open(target, "wb") as f:
        shutil.copyfileobj(upload.file, f)
    return target


# ── Background workers ────────────────────────────────────────────────────────

def _run_build_job(job_id: str, spec_paths, sponsor_paths, existing_master, out_path, jobs: JobStore):
    from services.master_service import build_master
    jobs.set_running(job_id)
    try:
        result = build_master(
            spec_paths=spec_paths,
            sponsor_paths=sponsor_paths,
            existing_master=existing_master,
            out_path=out_path,
        )
        jobs.set_completed(job_id, str(result))
        log.info("Build job %s completed: %s", job_id, result)
    except MasterBuildError as exc:
        jobs.set_failed(job_id, exc.message)
        log.error("Build job %s failed: %s", job_id, exc.message)
    except Exception as exc:
        jobs.set_failed(job_id, str(exc))
        log.error("Build job %s unexpected error: %s", job_id, exc, exc_info=True)


def _run_map_job(job_id: str, master_path, raw_path, spec_path, out_path, jobs: JobStore):
    from services.mapping_service import run_mapping
    jobs.set_running(job_id)
    try:
        summary = run_mapping(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=spec_path,
            out_path=out_path,
        )
        jobs.set_completed(job_id, str(out_path), summary)
        log.info("Map job %s completed: direct=%d review=%d", job_id,
                 summary.direct_count, summary.review_count)
    except MappingError as exc:
        jobs.set_failed(job_id, exc.message)
        log.error("Map job %s failed: %s", job_id, exc.message)
    except Exception as exc:
        jobs.set_failed(job_id, str(exc))
        log.error("Map job %s unexpected error: %s", job_id, exc, exc_info=True)


def _run_writeback_job(job_id: str, spec_path, results_path, out_path, jobs: JobStore):
    from services.writeback_service import write_back_to_spec
    jobs.set_running(job_id)
    try:
        written_path, _ = write_back_to_spec(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
        )
        jobs.set_completed(job_id, str(written_path))
        log.info("Writeback job %s completed: %s", job_id, written_path)
    except WritebackError as exc:
        jobs.set_failed(job_id, exc.message)
        log.error("Writeback job %s failed: %s", job_id, exc.message)
    except Exception as exc:
        jobs.set_failed(job_id, str(exc))
        log.error("Writeback job %s unexpected error: %s", job_id, exc, exc_info=True)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post(
    "/build",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Build master mapping from completed study specs",
)
async def build_master(
    background_tasks: BackgroundTasks,
    specs: list[UploadFile] = File(..., description="Completed study spec Excel files"),
    sponsors: list[UploadFile] = File(default=[], description="Sponsor standard specs (optional)"),
    current_user: str = Depends(get_current_user),
    jobs: JobStore = Depends(get_job_store),
) -> dict:
    job_id = jobs.create()
    run_dir = _ensure_tmp(job_id)

    spec_paths = [_save_upload(f, run_dir) for f in specs if f.filename]
    sponsor_paths = [_save_upload(f, run_dir) for f in sponsors if f.filename]
    out_path = run_dir / "master_mapping.xlsx"

    background_tasks.add_task(
        _run_build_job, job_id, spec_paths, sponsor_paths, None, out_path, jobs
    )
    log.info("Build job %s submitted by %s (%d specs)", job_id, current_user, len(spec_paths))
    return {"job_id": job_id, "status": "pending"}


@router.post(
    "/run",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Map raw variables to SDTM using master mapping",
)
async def run_mapping(
    background_tasks: BackgroundTasks,
    master: UploadFile = File(..., description="master_mapping.xlsx"),
    raw: UploadFile = File(..., description="Raw variable catalog (Excel/CSV/XPT)"),
    spec: UploadFile = File(default=None, description="New study SDTM spec (optional)"),
    current_user: str = Depends(get_current_user),
    jobs: JobStore = Depends(get_job_store),
) -> dict:
    job_id = jobs.create()
    run_dir = _ensure_tmp(job_id)

    master_path = _save_upload(master, run_dir)
    raw_path    = _save_upload(raw, run_dir)
    spec_path   = _save_upload(spec, run_dir) if spec and spec.filename else None
    out_path    = run_dir / "mapping_results.xlsx"

    background_tasks.add_task(
        _run_map_job, job_id, master_path, raw_path, spec_path, out_path, jobs
    )
    log.info("Map job %s submitted by %s", job_id, current_user)
    return {"job_id": job_id, "status": "pending"}


@router.post(
    "/writeback",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Write mapping results back into the SDTM spec",
)
async def writeback(
    background_tasks: BackgroundTasks,
    spec: UploadFile = File(..., description="Original SDTM spec Excel"),
    results: UploadFile = File(..., description="mapping_results.xlsx"),
    current_user: str = Depends(get_current_user),
    jobs: JobStore = Depends(get_job_store),
) -> dict:
    job_id = jobs.create()
    run_dir = _ensure_tmp(job_id)

    spec_path    = _save_upload(spec, run_dir)
    results_path = _save_upload(results, run_dir)
    out_path     = run_dir / f"{spec_path.stem}_mapped.xlsx"

    background_tasks.add_task(
        _run_writeback_job, job_id, spec_path, results_path, out_path, jobs
    )
    log.info("Writeback job %s submitted by %s", job_id, current_user)
    return {"job_id": job_id, "status": "pending"}


@router.get(
    "/status/{job_id}",
    response_model=JobResponse,
    summary="Poll job status",
)
async def get_job_status(
    job_id: str,
    current_user: str = Depends(get_current_user),
    jobs: JobStore = Depends(get_job_store),
) -> JobResponse:
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    return job


@router.get(
    "/results/{job_id}",
    summary="Download completed job result file",
)
async def download_results(
    job_id: str,
    current_user: str = Depends(get_current_user),
    jobs: JobStore = Depends(get_job_store),
) -> FileResponse:
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    if job.status != JobStatus.completed:
        raise HTTPException(
            status_code=409,
            detail=f"Job is {job.status.value}. Results only available when completed.",
        )
    result_path = Path(job.result_path)
    if not result_path.exists():
        raise HTTPException(status_code=404, detail="Result file not found on server.")
    return FileResponse(
        path=str(result_path),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=result_path.name,
    )
