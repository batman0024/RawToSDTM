"""
api/routers/health.py
=====================
Unauthenticated health check endpoint.
"""
from __future__ import annotations

from fastapi import APIRouter
from models.mapping_models import HealthResponse
from config.settings import settings

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    return HealthResponse(environment=settings.ENVIRONMENT)
