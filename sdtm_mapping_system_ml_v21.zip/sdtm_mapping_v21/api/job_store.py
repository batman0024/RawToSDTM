"""
api/job_store.py
================
In-memory async job store for long-running pipeline operations.
Thread-safe. Returns JobResponse Pydantic models.
"""
from __future__ import annotations

import threading
import uuid
from datetime import datetime
from typing import Dict, Optional

from models.mapping_models import JobResponse, JobStatus, MappingResultSummary


class JobStore:
    """Thread-safe in-memory job registry."""

    def __init__(self) -> None:
        self._jobs: Dict[str, JobResponse] = {}
        self._lock = threading.Lock()

    def create(self) -> str:
        """Create a new job record, return job_id."""
        job_id = str(uuid.uuid4())
        with self._lock:
            self._jobs[job_id] = JobResponse(
                job_id=job_id,
                status=JobStatus.pending,
                created_at=datetime.utcnow(),
            )
        return job_id

    def set_running(self, job_id: str) -> None:
        with self._lock:
            if job_id in self._jobs:
                j = self._jobs[job_id]
                self._jobs[job_id] = j.model_copy(
                    update={"status": JobStatus.running, "started_at": datetime.utcnow()}
                )

    def set_completed(
        self,
        job_id: str,
        result_path: str,
        summary: Optional[MappingResultSummary] = None,
    ) -> None:
        with self._lock:
            if job_id in self._jobs:
                j = self._jobs[job_id]
                self._jobs[job_id] = j.model_copy(update={
                    "status": JobStatus.completed,
                    "completed_at": datetime.utcnow(),
                    "result_path": result_path,
                    "summary": summary,
                })

    def set_failed(self, job_id: str, error: str) -> None:
        with self._lock:
            if job_id in self._jobs:
                j = self._jobs[job_id]
                self._jobs[job_id] = j.model_copy(update={
                    "status": JobStatus.failed,
                    "completed_at": datetime.utcnow(),
                    "error": error,
                })

    def get(self, job_id: str) -> Optional[JobResponse]:
        with self._lock:
            return self._jobs.get(job_id)

    def all_jobs(self) -> list[JobResponse]:
        with self._lock:
            return list(self._jobs.values())


# Singleton
_job_store = JobStore()


def get_job_store() -> JobStore:
    return _job_store
