"""
models/mapping_models.py
========================
Pydantic models for mapping service I/O.
Falls back to dataclasses if pydantic is not installed.
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional
import copy

try:
    from pydantic import BaseModel, Field

    class MatchTier(str, Enum):
        direct = "direct"
        review = "review"
        cross_dataset = "cross_dataset_match"
        unresolved = "unresolved"

    class JobStatus(str, Enum):
        pending = "pending"
        running = "running"
        completed = "completed"
        failed = "failed"

    class BuildMasterRequest(BaseModel):
        spec_paths: List[str] = Field(..., description="Paths to completed study spec Excel files")
        sponsor_paths: List[str] = Field(default_factory=list)
        existing_master: Optional[str] = None
        out_path: str = "master_mapping.xlsx"
        config_path: Optional[str] = None

    class MapStudyRequest(BaseModel):
        master_path: str = Field(...)
        raw_path: str = Field(...)
        spec_path: Optional[str] = None
        out_path: str = "mapping_results.xlsx"
        config_path: Optional[str] = None

    class WritebackRequest(BaseModel):
        spec_path: str = Field(...)
        results_path: str = Field(...)
        out_path: str = Field(...)
        highlight_review: bool = True
        populate_origin: bool = True
        populate_action: bool = True
        dry_run: bool = False
        config_path: Optional[str] = None

    class CoverageRow(BaseModel):
        domain: str
        total: int
        direct: int
        review: int
        unresolved: int
        auto_pct: float
        total_coverage_pct: float

    class MappingResultSummary(BaseModel):
        direct_count: int
        review_count: int
        unresolved_count: int
        unmapped_raw_count: int
        cross_dataset_count: int
        coverage: List[CoverageRow]
        result_path: str

    class JobResponse(BaseModel):
        job_id: str
        status: JobStatus
        created_at: datetime
        started_at: Optional[datetime] = None
        completed_at: Optional[datetime] = None
        result_path: Optional[str] = None
        error: Optional[str] = None
        summary: Optional[MappingResultSummary] = None

        def model_copy(self, update: dict = None, **kwargs):
            try:
                return super().model_copy(update=update or {})
            except AttributeError:
                return self.copy(update=update or {})

    class HealthResponse(BaseModel):
        status: str = "ok"
        version: str = "18"
        environment: str
        timestamp: datetime = Field(default_factory=datetime.utcnow)

except ImportError:
    from dataclasses import dataclass, field

    class MatchTier(str, Enum):
        direct = "direct"
        review = "review"
        cross_dataset = "cross_dataset_match"
        unresolved = "unresolved"

    class JobStatus(str, Enum):
        pending = "pending"
        running = "running"
        completed = "completed"
        failed = "failed"

    @dataclass
    class CoverageRow:
        domain: str = ""
        total: int = 0
        direct: int = 0
        review: int = 0
        unresolved: int = 0
        auto_pct: float = 0.0
        total_coverage_pct: float = 0.0

    @dataclass
    class MappingResultSummary:
        direct_count: int = 0
        review_count: int = 0
        unresolved_count: int = 0
        unmapped_raw_count: int = 0
        cross_dataset_count: int = 0
        coverage: list = field(default_factory=list)
        result_path: str = ""

    @dataclass
    class JobResponse:
        job_id: str = ""
        status: JobStatus = JobStatus.pending
        created_at: datetime = field(default_factory=datetime.utcnow)
        started_at: Optional[datetime] = None
        completed_at: Optional[datetime] = None
        result_path: Optional[str] = None
        error: Optional[str] = None
        summary: Optional[MappingResultSummary] = None

        def model_copy(self, update: dict = None, **kwargs):
            obj = copy.copy(self)
            for k, v in (update or {}).items():
                setattr(obj, k, v)
            return obj

    @dataclass
    class HealthResponse:
        status: str = "ok"
        version: str = "18"
        environment: str = "development"
        timestamp: datetime = field(default_factory=datetime.utcnow)

    @dataclass
    class BuildMasterRequest:
        spec_paths: list = field(default_factory=list)
        sponsor_paths: list = field(default_factory=list)
        existing_master: Optional[str] = None
        out_path: str = "master_mapping.xlsx"
        config_path: Optional[str] = None

    @dataclass
    class MapStudyRequest:
        master_path: str = ""
        raw_path: str = ""
        spec_path: Optional[str] = None
        out_path: str = "mapping_results.xlsx"
        config_path: Optional[str] = None

    @dataclass
    class WritebackRequest:
        spec_path: str = ""
        results_path: str = ""
        out_path: str = ""
        highlight_review: bool = True
        populate_origin: bool = True
        populate_action: bool = True
        dry_run: bool = False
        config_path: Optional[str] = None
