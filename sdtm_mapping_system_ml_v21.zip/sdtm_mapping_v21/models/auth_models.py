"""
models/auth_models.py
=====================
Pydantic models for magic-link email authentication flows.
Falls back to dataclasses if pydantic is not installed.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

try:
    from pydantic import BaseModel, Field
    try:
        from pydantic import EmailStr
    except ImportError:
        EmailStr = str  # type: ignore

    class MagicLinkRequest(BaseModel):
        email: EmailStr = Field(..., description="Email address to send the magic link to")

    class MagicLinkResponse(BaseModel):
        message: str = "If this email is registered, a login link has been sent."

    class TokenVerifyResponse(BaseModel):
        access_token: str
        token_type: str = "bearer"
        expires_in_seconds: int
        email: str

    class TokenRecord(BaseModel):
        """Internal token store record — never exposed via API."""
        email: str
        expires_at: datetime
        used: bool = False
        created_at: datetime = Field(default_factory=datetime.utcnow)

        def model_copy(self, update: dict = None, **kwargs):
            """Compatibility shim for both pydantic v1 and v2."""
            try:
                return super().model_copy(update=update or {})
            except AttributeError:
                # pydantic v1
                return self.copy(update=update or {})

    class JWTPayload(BaseModel):
        sub: str
        exp: float
        iat: float
        jti: str

except ImportError:
    # Fallback: stdlib dataclasses (used in sandbox testing only)
    from dataclasses import dataclass, field
    import copy

    EmailStr = str  # type: ignore

    @dataclass
    class MagicLinkRequest:
        email: str

    @dataclass
    class MagicLinkResponse:
        message: str = "If this email is registered, a login link has been sent."

    @dataclass
    class TokenVerifyResponse:
        access_token: str
        token_type: str = "bearer"
        expires_in_seconds: int = 0
        email: str = ""

    @dataclass
    class TokenRecord:
        email: str
        expires_at: datetime
        used: bool = False
        created_at: datetime = field(default_factory=datetime.utcnow)

        def model_copy(self, update: dict = None, **kwargs):
            obj = copy.copy(self)
            for k, v in (update or {}).items():
                setattr(obj, k, v)
            return obj

    @dataclass
    class JWTPayload:
        sub: str
        exp: float
        iat: float
        jti: str
