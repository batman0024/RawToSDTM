"""
utils.py
========
Shared utility functions for the SDTM mapping pipeline.

Centralises string normalisation helpers (_norm, _slug) that were
previously duplicated in mapper.py, ml_scorer.py, master_builder.py,
study_metadata.py, and spec_writeback.py.

Also provides config loading and a shared RE-based token stripper.
All output is plain ASCII; no Unicode.
"""

from __future__ import annotations

import re
import math
from pathlib import Path


# ---------------------------------------------------------------------------
# String normalisation — single canonical implementation
# ---------------------------------------------------------------------------

def norm(s) -> str:
    """Uppercase, collapse whitespace, return empty string for null/NaN."""
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip()).upper()


def slug(s) -> str:
    """Alphanumeric uppercase only — used as comparison key."""
    return re.sub(r"[^A-Z0-9]", "", norm(s))


# Keep underscore-prefixed aliases so existing call sites need no changes.
_norm = norm
_slug = slug


# ---------------------------------------------------------------------------
# Config loader (shared between mapper, master_builder, pipeline, writeback)
# ---------------------------------------------------------------------------

def load_cfg(p) -> dict:
    """
    Load a YAML config file.
    If the given path does not exist, fall back to resolving the filename
    relative to this module's directory (i.e. src/).
    """
    import yaml
    p = Path(p)
    if not p.exists():
        candidate = Path(__file__).parent / p.name
        if candidate.exists():
            p = candidate
    with open(p, encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Suffix-based reverse index builder (shared between mapper Phase-1 and Phase-3)
# ---------------------------------------------------------------------------

def build_suffix4_index(slug_index: dict[str, list]) -> dict[str, list]:
    """
    Build a 4-char suffix bucket index from an existing slug->entries dict.
    Used for near-miss lookup when exact slug matching fails.

    Args:
        slug_index: {bare_slug: [entries]}

    Returns:
        {last4chars: [entries]}  (entries deduplicated within each bucket)
    """
    suffix4: dict[str, list] = {}
    for sl, entries in slug_index.items():
        if len(sl) >= 4:
            key = sl[-4:]
            bucket = suffix4.setdefault(key, [])
            for entry in entries:
                if entry not in bucket:
                    bucket.append(entry)
    return suffix4
