"""
cdm_filter.py
=============
Defines and applies filters for CDM-generated, administrative, and
non-SDTM-usable variables in the raw catalog.

These are variables that exist in raw SAS datasets but should never
be mapped to SDTM because they are:
  - EDC system / audit trail fields (created by Rave, Veeva, InForm etc.)
  - CDM administrative variables (row IDs, timestamps, status flags)
  - Query management fields
  - Dataset-level metadata injected by the CDM system

All lists are editable at runtime via the UI or by editing this file.
"""

from __future__ import annotations

import re
from typing import Set

# ---------------------------------------------------------------------------
# Default CDM variable name list  (exact uppercase match after slug)
# ---------------------------------------------------------------------------

DEFAULT_CDM_VARIABLES: set = {
    # EDC audit trail / version control
    "CREATEDAT",    "CREATEDBY",    "CREATEDDTM",   "CREATED_BY",   "CREATED_DATE",
    "UPDATEDAT",    "UPDATEDBY",    "UPDATEDDTM",   "MODIFIED_BY",  "MODIFIED_DATE",
    "DELETEDAT",    "DELETEDBY",    "LASTMODIFIED",  "LASTMODBY",    "MODIFIEDDTM",
    # EDC record identifiers
    "FORMOID",      "STUDYOID",     "SITEOID",      "SUBJECTOID",   "EVENTOID",
    "ITEMOID",      "ITEMGROUPOID", "STUDYEVENTOID","INSTANCEID",   "ANNOTATIONOID",
    "FORMREPEATKEY","GROUPID",      "INSTANCEREPEATKEY","STUDYEVENTREPEATKEY",
    # Lock / archive / verification flags
    "LOCKED",       "ARCHIVED",     "VERIFIED",     "RECSTATUS",    "ROWSTATUS",
    # Medidata Rave
    "STUDYDATAENTRYDATE","STUDYEVENTDATE","MINCREATEDDTM","MAXMODIFIEDDTM",
    "DATACOLLECTEDFL","DCDT","DCID","INSTANCENAME",
    # Oracle Clinical / InForm
    "DCMSUBINST",   "DCMORDER",     "PAGENUMBER",   "PAGEID",       "QUESTIONID",
    "PAGENUM",      "PAGENAME",
    # Veeva / generic EDC
    "VAULTID",      "DOCID",        "DOCNUM",       "MAJORVERSION", "MINORVERSION",
    # Administrative row tracking
    "ROWNUM",       "RECID",        "SEQNUM_ADM",   "BATCHID",      "ENTRYDT",
    "FLAGGED",      "FLAG_REASON",
    # Query management
    "QUERYID",      "QUERYDATE",    "QUERYTEXT",    "QUERYRESPONSE","QUERYRESOLVED",
    # Null/missing flags injected by CDM
    "NULLFLAVOR",   "NULLFL",       "MISSINGFL",    "UNKNOWN_FL",
    # Randomisation/dispensation admin (not SDTM EX)
    "KITNUM",       "KITID",        "RANDNUM",      "RANDDT",       "TRTCODE",
    # --- EDC system fields visible in raw catalogs (Medidata/Veeva/InForm/Rave) ---
    "RECORDPOSITION","RECORDID",    "RECORDDATE",    "DATAPAGEID",   "DATAPAGENAME",
    "PAGEREPEATNUMBER","INSTANCEREPEATNUMBER","MINCREATED","MAXUPDATED",
    "DLASTMOD",     "DLASTMODDT",  "FOLDERNAME",    "FOLDERMNEMONIC",
    "FORMREPEATKEY","INSTANCENAME","INSTANCEREPEATKEY","MINCREATEDDTM","MAXMODIFIEDDTM",
    "PROJECT",      "SUBJECTID",   "SUBJINIT",      "SITENUMBER",
    "STUDYENVSITENUMBER","STUDYSITEID","STUDYENVSITENUMBER",
    "SRCFILEID",    "SRCFILEOID",  "WORKFLOWSTATE", "TRANSTATUS",
    "REVIEWSTATUS", "SIGNSTATUS",  "ISDELETED",     "ISARCHIVED",
    "ENTEREDBY",    "ENTEREDDT",   "SUBMITTEDBY",   "SUBMITTEDDT",
    "PAGENUM",      "FORMMNEMONIC","FOLDERSEQ",     "FORMSEQ",
    "VAULTID",      "OBJECTTYPE",  "LIFECYCLESTATE","DOCUMENTNUMBER",
    "DATACOLLECTEDFL","GROUPSEQ",  "ITEMSEQ",
}

# ---------------------------------------------------------------------------
# Default CDM dataset name list  (exact uppercase match of MEMNAME)
# ---------------------------------------------------------------------------

DEFAULT_CDM_DATASETS: set = {
    # Audit / log datasets
    "AUDIT",        "AUDITTRAIL",   "BATCHLOG",     "BATCH",
    # Query datasets
    "QUERIES",      "QUERYDATA",    "QUERYLOG",
    # Admin / metadata
    "ADMIN",        "ADMINISTRATIVE","METADATA",    "METAQUERY",    "COMMENTS",
    "COMMENTS2",
    # Lock / freeze / signature datasets
    "LOCKS",        "FREEZES",      "REVIEWS",      "SIGNATURES",
    # Randomisation / dispensation (non-SDTM)
    "RANDOMIZATION","DISPENSATION", "ACCOUNTABILITY",
    # Screening / administrative cohorts (raw, pre-SDTM)
    "SCREEN",       "SCREENFAIL",   "PRERANDOM",    "POSTRANDOM",
    # Medidata Rave system datasets
    "ARCHIVE",      "SITEARCHIVE", "STUDYARCHIVE",
    # Workflow / eSignature
    "ESIGNATURES",  "WORKFLOW",    "WORKFLOWSTEP",
    # Data transfer / extract logs
    "EXTRACT",      "TRANSFER",    "TRANSFERLOG",   "DATAEXPORT",
}

# ---------------------------------------------------------------------------
# Suffix patterns that indicate CDM-generated duplicates of real variables
# (e.g. AESTDAT_PREV, AESTDAT_OLD  are backup copies made by CDM)
# ---------------------------------------------------------------------------

DEFAULT_CDM_SUFFIXES: list = [
    "_PREV",  "_OLD",  "_ORIG_CDM",  "_BCK",  "_BACKUP",
    "_COPY",  "_TEMP", "_TMP",       "_DRAFT","_PENDING",
]


# ---------------------------------------------------------------------------
# Filter class
# ---------------------------------------------------------------------------

class CdmFilter:
    """
    Stateful filter that classifies raw variables as CDM/unusable or usable.
    All lists are editable at runtime.
    """

    def __init__(
        self,
        cdm_variables: set | None = None,
        cdm_datasets:  set | None = None,
        cdm_suffixes:  list | None = None,
        custom_patterns: list | None = None,
    ):
        self.cdm_variables  = set(v.upper().strip() for v in (cdm_variables or DEFAULT_CDM_VARIABLES))
        self.cdm_datasets   = set(d.upper().strip() for d in (cdm_datasets  or DEFAULT_CDM_DATASETS))
        self.cdm_suffixes   = [s.upper().strip()    for s in (cdm_suffixes  or DEFAULT_CDM_SUFFIXES)]
        self.custom_patterns = list(custom_patterns or [])

    # ---- Classification ------------------------------------------------

    def is_cdm_variable(self, variable: str, dataset: str = "") -> bool:
        """Return True if this variable should be excluded from SDTM mapping."""
        v  = variable.upper().strip()
        ds = dataset.upper().strip()

        # 1. Whole dataset is CDM/admin
        if ds and ds in self.cdm_datasets:
            return True

        # 2. Exact variable name match
        if v in self.cdm_variables:
            return True

        # 3. Suffix patterns
        for sfx in self.cdm_suffixes:
            if v.endswith(sfx):
                return True

        # 4. Custom regex patterns (user-defined)
        for pattern in self.custom_patterns:
            try:
                if re.search(pattern, v, re.IGNORECASE):
                    return True
            except re.error:
                pass

        return False

    def filter_catalog(self, raw_df) -> tuple:
        """
        Split raw_df into (usable_df, excluded_df).
        Returns two DataFrames with the same columns.
        """
        import pandas as pd
        mask = raw_df.apply(
            lambda r: self.is_cdm_variable(
                str(r.get("VARIABLE", "") or ""),
                str(r.get("RAW_DATASET", "") or ""),
            ),
            axis=1,
        )
        return raw_df[~mask].reset_index(drop=True), raw_df[mask].reset_index(drop=True)

    # ---- Editable serialisation ----------------------------------------

    def to_dict(self) -> dict:
        return {
            "cdm_variables":   sorted(self.cdm_variables),
            "cdm_datasets":    sorted(self.cdm_datasets),
            "cdm_suffixes":    self.cdm_suffixes,
            "custom_patterns": self.custom_patterns,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CdmFilter":
        return cls(
            cdm_variables   = set(d.get("cdm_variables",   [])),
            cdm_datasets    = set(d.get("cdm_datasets",    [])),
            cdm_suffixes    = d.get("cdm_suffixes",    []),
            custom_patterns = d.get("custom_patterns", []),
        )

    def add_variable(self, name: str):
        self.cdm_variables.add(name.upper().strip())

    def remove_variable(self, name: str):
        self.cdm_variables.discard(name.upper().strip())

    def add_dataset(self, name: str):
        self.cdm_datasets.add(name.upper().strip())

    def remove_dataset(self, name: str):
        self.cdm_datasets.discard(name.upper().strip())
