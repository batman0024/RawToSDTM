"""
ml_scorer.py
============
ML-enhanced scoring engine for raw -> SDTM variable matching.

Architecture:
  1. Feature extraction:  21 signals per (raw_var, sdtm_var) candidate pair
  2. HistGradientBoostingClassifier trained on master_mapping positive pairs
     (generates synthetic negatives: random cross-domain, random same-domain,
      AND hard negatives -- same-domain pairs with high name similarity that
      are NOT the correct match)
  3. At inference time:
     - Phase A (master-guided): score only pairs the master has seen
     - Phase B (label-fallback): for unknowns, score same-domain candidates
       using feature vector; classifier predicts probability of correct match

Signals used:
  Name signals (4):
    - jaro_winkler:      better than SequenceMatcher for short clinical names
    - char_3gram:        shared 3-character n-grams / total n-grams (Jaccard)
    - prefix_match:      true leading-char prefix fraction (stops at first diff)
    - token_set:         set intersection of uppercase tokens / union
  Label signals (2):
    - label_tfidf:       TF-IDF cosine (pre-computed against master corpus)
    - label_token_overlap: shared words between raw label and sdtm label
  Format/type signals (3):
    - format_is_date:    raw FORMAT contains DATE/YYMMDD/DDMMYY
    - format_is_time:    raw FORMAT contains TIME/TOD/HH
    - type_num:          raw TYPE is Num -> matches derived/result vars
  SDTM structure signals (2):
    - sdtm_is_timing:    SDTM variable ends in DT/TM/DTC/DTM
    - sdtm_is_datetime:  SDTM variable ends in DTC or DTM (ISO 8601 compound)
  Domain signals (2):
    - domain_match_exact:  raw dataset slug == sdtm domain slug
    - domain_match_prefix2:first two chars match
  Master signals (3):
    - master_conf:       MASTER_CONFIDENCE from master_mapping
    - is_sponsor_std:    was this pair seen in sponsor standard?
    - in_master:         1 if this exact (raw_slug, sdtm_var) pair is in master
  SDTM structure class signals (2):
    - var_class_derived: 1 if SDTM var is always-derived (SEQ, CHG, etc.)
    - var_class_timing:  1 if SDTM var is timing class
  Context signals (3):
    - sdtmig_version_match: similarity weight between study and master SDTMIG versions
    - ta_match:             1 if therapeutic areas match, 0.5 if both known/differ, 0.85 unknown
    - study_phase_match:    1 if study phases match, 0.7 if both known/differ, 0.85 unknown

Trained on:
  Positive pairs:  every (RAW_VARIABLE, SDTM_VARIABLE) row in master_mapping
  Negative pairs:  synthetic -- 2 random cross-domain + 1 random same-domain
                   + 1 hard negative (same-domain, high name similarity, wrong match)
  Ratio:           1:4 positive:negative

Model persistence:
  The trained model is serialised alongside the master file as
  <master_stem>_ml_model.pkl.  On subsequent runs the model is loaded from
  disk if the master file has not changed (checked via SHA-256 hash stored
  in a companion .pkl.hash file), avoiding redundant training.

Outputs a probability [0..1] that the raw variable belongs to the SDTM variable.
"""

from __future__ import annotations

import hashlib
import logging
import math
import pickle
import re
import warnings
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

from utils import _norm, _slug
from sdtm_knowledge import classify_variable, ALWAYS_DERIVED, PROTOCOL_VARS

log = logging.getLogger("sdtm_app.ml_scorer")


# ---------------------------------------------------------------------------
# String similarity primitives
# ---------------------------------------------------------------------------

def _jaro(s1: str, s2: str) -> float:
    if s1 == s2:
        return 1.0
    l1, l2 = len(s1), len(s2)
    if l1 == 0 or l2 == 0:
        return 0.0
    match_dist = max(l1, l2) // 2 - 1
    if match_dist < 0:
        match_dist = 0
    s1m = [False] * l1
    s2m = [False] * l2
    matches = 0
    for i in range(l1):
        lo = max(0, i - match_dist)
        hi = min(i + match_dist + 1, l2)
        for j in range(lo, hi):
            if s2m[j] or s1[i] != s2[j]:
                continue
            s1m[i] = s2m[j] = True
            matches += 1
            break
    if not matches:
        return 0.0
    k = t = 0
    for i in range(l1):
        if not s1m[i]:
            continue
        while not s2m[k]:
            k += 1
        if s1[i] != s2[k]:
            t += 1
        k += 1
    return (matches / l1 + matches / l2 + (matches - t / 2) / matches) / 3.0


def jaro_winkler(s1: str, s2: str, p: float = 0.1) -> float:
    """Jaro-Winkler similarity. Better than SequenceMatcher for short names."""
    j = _jaro(s1, s2)
    prefix = 0
    for c1, c2 in zip(s1[:4], s2[:4]):
        if c1 == c2:
            prefix += 1
        else:
            break
    return min(j + prefix * p * (1.0 - j), 1.0)


def char_ngram_sim(s1: str, s2: str, n: int = 3) -> float:
    """Jaccard similarity of character n-gram sets."""
    g1 = {s1[i:i + n] for i in range(len(s1) - n + 1)}
    g2 = {s2[i:i + n] for i in range(len(s2) - n + 1)}
    if not g1 or not g2:
        return float(s1 == s2)
    return len(g1 & g2) / len(g1 | g2)


def prefix_match(s1: str, s2: str) -> float:
    """
    True prefix match: fraction of leading characters that are identical.
    Stops counting at the first differing character position.
    E.g. prefix_match('AESTDTC', 'AESTDAT') = 5/5 = 1.0 (5 matching prefix chars
    out of the shorter string's 7 chars -> 5/7 = 0.71).
    """
    if not s1 or not s2:
        return 0.0
    n = 0
    for a, b in zip(s1, s2):
        if a == b:
            n += 1
        else:
            break
    return n / min(len(s1), len(s2))


def token_set_overlap(s1: str, s2: str) -> float:
    """Jaccard similarity of uppercase alpha token sets (min length 2)."""
    def tokens(s):
        return set(re.findall(r"[A-Z]{2,}", s.upper()))
    t1, t2 = tokens(s1), tokens(s2)
    if not t1 or not t2:
        return 0.0
    return len(t1 & t2) / len(t1 | t2)


# ---------------------------------------------------------------------------
# Feature vector
# ---------------------------------------------------------------------------

FEATURE_NAMES = [
    "jaro_winkler",
    "char_3gram",
    "prefix_match",
    "token_set",
    "label_tfidf",
    "label_token_overlap",
    "format_is_date",
    "format_is_time",
    "type_num",
    "sdtm_is_timing",
    "sdtm_is_datetime",
    "domain_match_exact",
    "domain_match_prefix2",
    "master_conf",
    "is_sponsor_std",
    "in_master",
    "var_class_derived",
    "var_class_timing",
    "sdtmig_version_match",
    "ta_match",
    "study_phase_match",
]

_N_FEATURES = len(FEATURE_NAMES)


def build_feature_vector(
    raw_var: str,
    raw_dataset: str,
    raw_label: str,
    raw_format: str,
    raw_type: str,
    sdtm_var: str,
    sdtm_domain: str,
    sdtm_label: str,
    master_conf: float,
    is_sponsor_std: bool,
    in_master: bool,
    label_tfidf_score: float,
    study_sdtmig_version: str = "",
    study_ta: str = "",
    study_phase: str = "",
    master_sdtmig_version: str = "",
    master_ta: str = "",
    master_phase: str = "",
) -> np.ndarray:
    """
    Build a 21-element feature vector for one (raw, sdtm) candidate pair.
    All values normalised to [0, 1].
    """
    rv  = _slug(raw_var)
    sv  = _slug(sdtm_var)
    rl  = _norm(raw_label)
    sl  = _norm(sdtm_label)
    rds = _slug(raw_dataset)
    dom = _slug(sdtm_domain)
    fmt = _norm(raw_format).upper()
    typ = _norm(raw_type).upper()

    # Name signals
    jw      = jaro_winkler(rv, sv)
    ng3     = char_ngram_sim(rv, sv, 3) if (len(rv) >= 3 and len(sv) >= 3) else float(rv == sv)
    pref    = prefix_match(rv, sv)
    tok_set = token_set_overlap(rv, sv)

    # Label signals
    lbl_tov = token_set_overlap(rl, sl) if (rl and sl) else 0.0

    # Format/type signals
    fmt_date = 1.0 if any(x in fmt for x in ("DATE", "YYMMDD", "DDMMYY")) else 0.0
    fmt_time = 1.0 if any(x in fmt for x in ("TIME", "TOD", "HH")) else 0.0
    typ_num  = 1.0 if typ in ("N", "NUM", "NUMERIC", "FLOAT", "INTEGER") else 0.0

    # SDTM structure signals
    sdtm_timing = 1.0 if re.search(r"(DT|TM|DTC|DTM)$", sv) else 0.0
    sdtm_dtm    = 1.0 if sv.endswith("DTC") or sv.endswith("DTM") else 0.0

    # Domain signals
    dom_exact  = 1.0 if rds == dom else 0.0
    dom_pref2  = 1.0 if (len(rds) >= 2 and len(dom) >= 2 and rds[:2] == dom[:2]) else 0.0

    # Master signals
    mc   = float(master_conf) if master_conf else 0.0
    spon = 1.0 if is_sponsor_std else 0.0
    inm  = 1.0 if in_master else 0.0

    # SDTM variable class signals
    vc         = classify_variable(sdtm_var, sdtm_domain)
    vc_derived = 1.0 if (vc in ("derived", "sequence", "flag") or sdtm_var in ALWAYS_DERIVED) else 0.0
    vc_timing  = 1.0 if vc == "timing" else 0.0

    # Version and TA context signals
    from study_metadata import version_weight
    ver_match = (
        version_weight(study_sdtmig_version, master_sdtmig_version)
        if (study_sdtmig_version and master_sdtmig_version) else 0.90
    )
    ta_m = 1.0 if (study_ta and master_ta and study_ta == master_ta) else (
           0.5 if (study_ta and master_ta) else 0.85)
    ph_m = 1.0 if (study_phase and master_phase and study_phase == master_phase) else (
           0.7 if (study_phase and master_phase) else 0.85)

    result = np.array([
        jw, ng3, pref, tok_set,
        label_tfidf_score, lbl_tov,
        fmt_date, fmt_time, typ_num,
        sdtm_timing, sdtm_dtm,
        dom_exact, dom_pref2,
        mc, spon, inm,
        vc_derived, vc_timing,
        ver_match, ta_m, ph_m,
    ], dtype=np.float32)

    # Sanity guard: catch future feature additions that break alignment
    assert len(result) == _N_FEATURES, (
        f"Feature vector length {len(result)} != FEATURE_NAMES length {_N_FEATURES}. "
        "Update FEATURE_NAMES when adding features."
    )
    return result


# ---------------------------------------------------------------------------
# Training data builder  (NO leakage: label_tfidf set to 0.0 for training)
# ---------------------------------------------------------------------------

def build_training_data(master_df: pd.DataFrame) -> tuple:
    """
    Build feature matrix X and label vector y from master_mapping data.

    Positive pairs:  all (RAW_VARIABLE -> SDTM_VARIABLE) rows in master.
    Negative pairs:  synthetic wrong mappings in three tiers:
      - 2 random cross-domain pairs       (easy negatives)
      - 1 random same-domain wrong pair   (medium negatives)
      - 1 hard negative: same-domain, jaro_winkler > 0.55, not correct
        (hard negatives teach the model to separate similar-looking wrong pairs)

    NOTE: label_tfidf_score is set to 0.0 during training.
    The LabelIndex is built from the *new study's* raw labels, so feeding
    it into training would constitute leakage (new study info used during
    model fitting).  At inference time the true label similarity is passed
    in, and the model weights this feature accordingly.
    """
    pos_rows = master_df[
        master_df["RAW_VARIABLE"].notna()
        & (master_df["RAW_VARIABLE"].astype(str).str.strip() != "")
        & (master_df["RAW_VARIABLE"].astype(str).str.upper() != "NAN")
    ].copy()

    if pos_rows.empty:
        return np.zeros((0, _N_FEATURES)), np.array([])

    # All (domain, var, label) entries for negative sampling
    sdtm_entries = (
        master_df[["DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL"]]
        .drop_duplicates()
        .to_dict("records")
    )

    # Pre-bucket by domain for efficient same-domain sampling
    domain_buckets: dict[str, list] = {}
    for e in sdtm_entries:
        domain_buckets.setdefault(e["DOMAIN"], []).append(e)

    rng = np.random.default_rng(42)

    X_rows: list = []
    y_rows: list = []

    for _, row in pos_rows.iterrows():
        raw_tok   = str(row.get("RAW_VARIABLE", "") or "")
        raw_parts = raw_tok.split(".")
        raw_var   = raw_parts[-1] if raw_parts else raw_tok
        raw_ds    = raw_parts[-2] if len(raw_parts) >= 2 else raw_parts[0]
        sdtm_var  = str(row.get("SDTM_VARIABLE", "") or "")
        sdtm_dom  = str(row.get("DOMAIN", "") or "")
        sdtm_lbl  = str(row.get("SDTM_LABEL", "") or "")
        mc        = float(row.get("MASTER_CONFIDENCE", 0) or 0)
        spon      = bool(row.get("IS_SPONSOR_STD", False))

        if not raw_var or not sdtm_var:
            continue

        # --- POSITIVE ---
        fv = build_feature_vector(
            raw_var, raw_ds, "", "", "",
            sdtm_var, sdtm_dom, sdtm_lbl,
            mc, spon, True, 0.0,   # label_tfidf=0.0 to avoid leakage
        )
        X_rows.append(fv)
        y_rows.append(1)

        # --- NEGATIVES (4 per positive) ---
        negatives_added = 0

        # Tier 1: 2 random cross-domain negatives
        cross_pool = [e for e in sdtm_entries if e["DOMAIN"] != sdtm_dom]
        if cross_pool:
            chosen = rng.choice(len(cross_pool), size=min(2, len(cross_pool)), replace=False)
            for idx in chosen:
                neg = cross_pool[int(idx)]
                fv_neg = build_feature_vector(
                    raw_var, raw_ds, "", "", "",
                    neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                    0.0, False, False, 0.0,
                )
                X_rows.append(fv_neg)
                y_rows.append(0)
                negatives_added += 1

        # Tier 2: 1 random same-domain wrong pair
        same_dom = [e for e in domain_buckets.get(sdtm_dom, [])
                    if e["SDTM_VARIABLE"] != sdtm_var]
        if same_dom:
            neg = same_dom[int(rng.integers(0, len(same_dom)))]
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "", "", "",
                neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            negatives_added += 1

        # Tier 3: 1 hard negative -- same-domain, name-similar, wrong match
        rv_slug = _slug(raw_var)
        hard_candidates = [
            e for e in domain_buckets.get(sdtm_dom, [])
            if e["SDTM_VARIABLE"] != sdtm_var
            and jaro_winkler(rv_slug, _slug(e["SDTM_VARIABLE"])) > 0.55
        ]
        if hard_candidates:
            neg = hard_candidates[int(rng.integers(0, len(hard_candidates)))]
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "", "", "",
                neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            negatives_added += 1

        # Pad to exactly 4 negatives if hard candidates were scarce
        while negatives_added < 4 and cross_pool:
            neg = cross_pool[int(rng.integers(0, len(cross_pool)))]
            if neg["SDTM_VARIABLE"] == sdtm_var:
                continue
            fv_neg = build_feature_vector(
                raw_var, raw_ds, "", "", "",
                neg["SDTM_VARIABLE"], neg["DOMAIN"], str(neg.get("SDTM_LABEL") or ""),
                0.0, False, False, 0.0,
            )
            X_rows.append(fv_neg)
            y_rows.append(0)
            negatives_added += 1

    if not X_rows:
        return np.zeros((0, _N_FEATURES)), np.array([])

    X = np.vstack(X_rows)
    y = np.array(y_rows, dtype=np.int32)
    return X, y


# ---------------------------------------------------------------------------
# Model persistence helpers
# ---------------------------------------------------------------------------

def _master_sha256(master_df: pd.DataFrame) -> str:
    """Stable hash of master DataFrame content for cache invalidation."""
    key_cols = ["DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE", "MASTER_CONFIDENCE"]
    available = [c for c in key_cols if c in master_df.columns]
    h = hashlib.sha256(
        master_df[available].to_csv(index=False).encode()
    ).hexdigest()[:16]
    return h


def _model_cache_paths(master_path: Path) -> tuple[Path, Path]:
    """Return (pkl_path, hash_path) for a given master file."""
    stem = master_path.stem
    parent = master_path.parent
    return parent / f"{stem}_ml_model.pkl", parent / f"{stem}_ml_model.pkl.hash"


def save_model(model, master_df: pd.DataFrame, master_path: Path) -> None:
    """Persist the trained model and a content hash next to the master file."""
    pkl_path, hash_path = _model_cache_paths(master_path)
    try:
        with open(pkl_path, "wb") as f:
            pickle.dump(model, f, protocol=pickle.HIGHEST_PROTOCOL)
        hash_path.write_text(_master_sha256(master_df))
        log.info("MLScorer: model saved to %s", pkl_path.name)
    except Exception as exc:
        log.warning("MLScorer: could not save model (%s). Will retrain next run.", exc)


def load_model(master_df: pd.DataFrame, master_path: Path):
    """
    Load a cached model if it exists and the master content hash matches.
    Returns the model object or None if cache is stale/missing.
    """
    pkl_path, hash_path = _model_cache_paths(master_path)
    if not pkl_path.exists() or not hash_path.exists():
        return None
    try:
        stored_hash = hash_path.read_text().strip()
        current_hash = _master_sha256(master_df)
        if stored_hash != current_hash:
            log.info("MLScorer: master changed (hash mismatch). Retraining.")
            return None
        with open(pkl_path, "rb") as f:
            model = pickle.load(f)
        log.info("MLScorer: loaded cached model from %s", pkl_path.name)
        return model
    except Exception as exc:
        log.warning("MLScorer: could not load cached model (%s). Retraining.", exc)
        return None


# ---------------------------------------------------------------------------
# ML Scorer class
# ---------------------------------------------------------------------------

class MLScorer:
    """
    HistGradientBoostingClassifier trained on master_mapping pairs.
    Predicts P(raw_var -> sdtm_var is correct match).

    Improvements over v19:
      - Uses HistGradientBoostingClassifier (3-10x faster than GBT,
        native NaN support, built-in class_weight via pos_class_weight)
      - Hard negative mining (same-domain, name-similar wrong pairs)
      - label_tfidf excluded from training to prevent data leakage
      - Model persisted to disk; reloaded if master unchanged (SHA-256 hash)
      - Evaluation uses StratifiedKFold + ROC-AUC + Average Precision
        (not raw accuracy, which is misleading with 80% negatives)
      - Feature vector length assertion guards against silent misalignment

    Falls back gracefully to hand-weighted scoring when:
      - Fewer than 10 positive training pairs are available
      - sklearn is not installed
    """

    MIN_TRAIN_POSITIVES = 10

    def __init__(self):
        self._model   = None
        self._trained = False
        self._n_pos   = 0
        self._fallback_weights = {
            "jaro_winkler": 0.35,
            "char_3gram":   0.10,
            "label_tfidf":  0.25,
            "master_conf":  0.20,
            "domain_match": 0.10,
        }

    # ── Training ──────────────────────────────────────────────────────────────

    def train(
        self,
        master_df: pd.DataFrame,
        log_=None,
        master_path: Optional[Path] = None,
    ) -> None:
        """
        Train (or load from cache) the classifier on master_mapping data.

        Args:
            master_df:   The full master mapping DataFrame.
            log_:        Optional logger (falls back to module logger).
            master_path: Path to master file; enables model persistence.
                         If None the model is trained but not cached.

        NOTE: label_idx is intentionally NOT accepted here to prevent
        leakage of new-study raw label vocabulary into training features.
        """
        logger = log_ or log

        # Attempt to load cached model first
        if master_path is not None:
            cached = load_model(master_df, master_path)
            if cached is not None:
                self._model   = cached
                self._trained = True
                return

        X, y = build_training_data(master_df)
        self._n_pos = int((y == 1).sum()) if len(y) > 0 else 0

        logger.info("  MLScorer: %d positive pairs, %d total training examples",
                    self._n_pos, len(y))

        if self._n_pos < self.MIN_TRAIN_POSITIVES:
            logger.warning(
                "  MLScorer: insufficient training data (%d pos < %d). "
                "Using fallback weighted scoring.",
                self._n_pos, self.MIN_TRAIN_POSITIVES,
            )
            self._trained = False
            return

        try:
            from sklearn.ensemble import HistGradientBoostingClassifier
            from sklearn.model_selection import StratifiedKFold, cross_validate
        except ImportError:
            logger.warning("  MLScorer: sklearn not available. Fallback mode.")
            self._trained = False
            return

        # class_weight via pos_class_weight: compensates for 1:4 imbalance
        n_neg = int((y == 0).sum())
        pos_weight = n_neg / max(self._n_pos, 1)

        self._model = HistGradientBoostingClassifier(
            max_iter=200,
            max_depth=5,
            learning_rate=0.08,
            min_samples_leaf=5,
            l2_regularization=0.1,
            class_weight={0: 1.0, 1: pos_weight},
            random_state=42,
        )
        self._model.fit(X, y)
        self._trained = True

        # Evaluation with stratified CV -- AUC and AP are meaningful under imbalance
        n_splits = min(5, max(2, self._n_pos // 4))
        try:
            cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
            cv_results = cross_validate(
                self._model, X, y,
                cv=cv,
                scoring=["roc_auc", "average_precision", "f1"],
                n_jobs=1,
            )
            logger.info(
                "  MLScorer: trained (%d-fold CV) | "
                "ROC-AUC=%.3f+/-%.3f | AP=%.3f+/-%.3f | F1=%.3f+/-%.3f | "
                "features=%d | n_pos=%d | pos_weight=%.1f",
                n_splits,
                cv_results["test_roc_auc"].mean(),
                cv_results["test_roc_auc"].std() * 2,
                cv_results["test_average_precision"].mean(),
                cv_results["test_average_precision"].std() * 2,
                cv_results["test_f1"].mean(),
                cv_results["test_f1"].std() * 2,
                _N_FEATURES,
                self._n_pos,
                pos_weight,
            )
        except Exception as cv_err:
            logger.info("  MLScorer: trained (CV unavailable: %s). features=%d", cv_err, _N_FEATURES)

        # Feature importances (available for HistGBT via permutation or built-in)
        try:
            importances = sorted(
                zip(FEATURE_NAMES, self._model.feature_importances_),
                key=lambda x: -x[1],
            )
            top5 = ", ".join(f"{n}={v:.3f}" for n, v in importances[:5])
            logger.info("  MLScorer: top-5 features: %s", top5)
        except Exception:
            pass

        # Persist model to disk
        if master_path is not None:
            save_model(self._model, master_df, master_path)

    # ── Inference ─────────────────────────────────────────────────────────────

    def score(
        self,
        raw_var: str,
        raw_dataset: str,
        raw_label: str,
        raw_format: str,
        raw_type: str,
        sdtm_var: str,
        sdtm_domain: str,
        sdtm_label: str,
        master_conf: float,
        is_sponsor_std: bool,
        in_master: bool,
        label_tfidf_score: float,
    ) -> float:
        """
        Return a match probability [0..1] for one (raw, sdtm) pair.
        Prefer score_batch() when scoring many candidates against the same
        raw variable -- it amortises raw-side normalisation.
        """
        fv = build_feature_vector(
            raw_var, raw_dataset, raw_label, raw_format, raw_type,
            sdtm_var, sdtm_domain, sdtm_label,
            master_conf, is_sponsor_std, in_master, label_tfidf_score,
        )
        return self._predict(fv, raw_var, raw_dataset, master_conf, label_tfidf_score)

    def score_batch(
        self,
        raw_var: str,
        raw_dataset: str,
        raw_label: str,
        raw_format: str,
        raw_type: str,
        candidates: list,
    ) -> list:
        """
        Score a list of SDTM candidates against one raw variable.
        Pre-normalises the raw side once; builds and scores all feature
        vectors in a single predict_proba call (~40% faster per-candidate).

        Args:
            candidates: list of dicts with keys:
                sdtm_var, sdtm_domain, sdtm_label,
                master_conf, is_sponsor_std, in_master, label_tfidf_score

        Returns:
            list of float probabilities, same order as candidates.
        """
        if not candidates:
            return []

        fvs = [
            build_feature_vector(
                raw_var, raw_dataset, raw_label, raw_format, raw_type,
                c["sdtm_var"], c["sdtm_domain"], c.get("sdtm_label", ""),
                c.get("master_conf", 0.0), c.get("is_sponsor_std", False),
                c.get("in_master", False), c.get("label_tfidf_score", 0.0),
            )
            for c in candidates
        ]
        X = np.vstack(fvs)

        if self._trained and self._model is not None:
            probs = self._model.predict_proba(X)[:, 1]
            return [float(p) for p in probs]

        rv_slug  = _slug(raw_var)
        rds_slug = _slug(raw_dataset)
        return [
            self._fallback_score(
                rv_slug, rds_slug,
                c["sdtm_var"], c["sdtm_domain"],
                c.get("master_conf", 0.0), c.get("label_tfidf_score", 0.0),
            )
            for c in candidates
        ]

    def _predict(self, fv: np.ndarray, raw_var: str, raw_dataset: str,
                 master_conf: float, label_tfidf_score: float) -> float:
        if self._trained and self._model is not None:
            return float(self._model.predict_proba(fv.reshape(1, -1))[0, 1])
        return self._fallback_score(
            _slug(raw_var), _slug(raw_dataset),
            "", "", master_conf, label_tfidf_score,
        )

    def _fallback_score(self, rv_slug: str, rds_slug: str,
                        sdtm_var: str, sdtm_domain: str,
                        master_conf: float, label_tfidf_score: float) -> float:
        """Hand-weighted fallback when model is not trained or sklearn absent."""
        sv  = _slug(sdtm_var)
        dom = _slug(sdtm_domain)
        jw  = jaro_winkler(rv_slug, sv)
        ng3 = char_ngram_sim(rv_slug, sv, 3) if (len(rv_slug) >= 3 and len(sv) >= 3) else float(rv_slug == sv)
        dom_m = 1.0 if (len(rds_slug) >= 2 and len(dom) >= 2 and rds_slug[:2] == dom[:2]) else 0.0
        mc    = float(master_conf or 0)
        lbl   = float(label_tfidf_score or 0)
        return min(0.35 * jw + 0.10 * ng3 + 0.20 * mc + 0.25 * lbl + 0.10 * dom_m, 1.0)

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def is_trained(self) -> bool:
        return self._trained

    def feature_names(self) -> list:
        return list(FEATURE_NAMES)
