"""
spec_writeback.py
=================
Write mapping results back into the new study SDTM spec Excel.
Preserves ALL original formatting (fonts, colors, borders, dropdowns).
Only cell values are written.

Columns updated where found in each domain sheet:
  Input Variables   RAW.DATASET.VARIABLE tokens (comma-separated, ordered)
  Mapping Action    controlled action keyword (only if currently blank)
  Origin            CRF / Derived / Assigned / Protocol / eDT
                    (priority-aware: CRF outranks all, will overwrite lower)

Review-tier rows are amber-highlighted.
A change-log sheet is appended to the updated workbook.

Usage:
    python spec_writeback.py \\
        --spec     new_study_spec.xlsx \\
        --results  mapping_results.xlsx \\
        --out      new_study_spec_mapped.xlsx

    # Dry-run: preview changes without writing
    python spec_writeback.py \\
        --spec    new_study_spec.xlsx \\
        --results mapping_results.xlsx \\
        --out     new_study_spec_mapped.xlsx \\
        --dry-run
"""

from __future__ import annotations

import re
import sys
import math
import warnings
import datetime as dt
import argparse
from pathlib import Path

import pandas as pd
import yaml

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

from utils import _norm, _slug
from logger import get_logger
from excel_validator import ExcelValidator, render_validation_report
from master_builder import (read_origin_values_from_spec,
                             normalize_origin_to_cdisc)


# ---------------------------------------------------------------------------
# Column header target lists (all lowercase for comparison)
# ---------------------------------------------------------------------------

DATASET_HDR   = ["dataset", "domain", "sdtm dataset", "sdtm domain", "dataset*"]
VARIABLE_HDR  = ["variable", "sdtm variable", "sdtm_variable", "var", "varname"]
INPUT_HDR     = [
    "input variables", "input variable", "input_variables",
    "raw inputs", "source variables", "raw variables",
    "input_variable", "raw", "source", "raw input",
]
ACTION_HDR    = [
    "mapping action", "mapping_action", "derivation",
    "algorithm", "rule", "method", "action", "mapping rule",
]
ORIGIN_HDR    = ["origin", "data origin", "source type", "data source"]
CORE_HDR      = ["gilead core", "core", "cdisc core", "required", "sponsor core"]

# Origin priority (lower number = higher priority)
ORIGIN_PRIORITY = {
    "CRF":      1,
    "DERIVED":  2,
    "PROTOCOL": 3,
    "EDT":      4,
    "ASSIGNED": 5,
}

FILL_REVIEW  = PatternFill(patternType="solid", fgColor="FFF2CC")   # amber - review tier
FILL_DIRECT  = PatternFill(patternType="solid", fgColor="C6EFCE")   # bright green - auto-accepted
FILL_UNRES   = PatternFill(patternType="solid", fgColor="FFC7CE")   # bright red   - unresolved
FILL_HEADER  = PatternFill(patternType="solid", fgColor="1F3864")
FONT_HEADER  = Font(bold=True, color="FFFFFF", size=10)
FONT_UPDATED = Font(bold=True, color="000000")   # Bold text for updated cells


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------




def _hdr(val, targets):
    """Return True if cell value matches any header target (case-insensitive)."""
    if val is None:
        return False
    return str(val).strip().lower() in targets


def _origin_priority(val):
    """Return numeric priority for an origin value (lower = higher priority)."""
    return ORIGIN_PRIORITY.get(str(val).upper().strip(), 9)


# ---------------------------------------------------------------------------
# Results loader
# ---------------------------------------------------------------------------

def load_results(results_path, log):
    """
    Load direct + review sheets from mapping_results.xlsx.
    Returns {(DOMAIN, SDTM_VARIABLE): row_dict}.
    Direct rows overwrite review rows for the same key.
    """
    combined = {}
    for sheet in ("review", "direct", "cross_dataset_match"):
        try:
            df = pd.read_excel(results_path, sheet_name=sheet,
                               engine="openpyxl", dtype=object)
            if df.empty:
                continue
            for _, r in df.iterrows():
                dom = _norm(r.get("DOMAIN",        ""))
                var = _norm(r.get("SDTM_VARIABLE", ""))
                if not dom or not var:
                    continue
                raw_val = r.get("RAW_VARIABLES_ASSIGNED", "")
                if raw_val is None or (isinstance(raw_val, float) and math.isnan(raw_val)):
                    raw_val = ""
                # cross_dataset_match rows are treated as review tier so they
                # get amber + bold highlight and appear in the change-log
                effective_tier = "review" if sheet == "cross_dataset_match" else sheet
                combined[(dom, var)] = {
                    "raw":    str(raw_val).strip(),
                    "action": str(r.get("MAPPING_ACTION",         "") or ""),
                    "origin": str(r.get("ORIGIN",                 "") or ""),
                    "score":  float(r.get("COMPOSITE_SCORE",   0.0) or 0.0),
                    "tier":   effective_tier,
                    "note":   str(r.get("MATCH_NOTE", "") or ""),
                }
        except Exception as exc:
            log.warning("  Could not load sheet '%s': %s", sheet, exc)

    direct_n = sum(1 for v in combined.values() if v["tier"] == "direct")
    review_n = sum(1 for v in combined.values() if v["tier"] == "review")
    log.info(
        "  Loaded %d mapped variables (%d direct, %d review/cross-dataset)",
        len(combined), direct_n, review_n,
    )
    return combined


# ---------------------------------------------------------------------------
# Main write-back
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Token helpers — defined once at module level (not per-row)
# ---------------------------------------------------------------------------

_BARE_PREFIX_RE = re.compile(r"^(RAW|SDTM|WORK)\.", re.IGNORECASE)
_BARE_SUFFIX_RE = re.compile(
    r"_(RAW|STD|ORIG|CLEAN|MOD|ADJ|IMPUTE|UNMOD|RECODED|DECODE|IMP)$",
    re.IGNORECASE,
)
_NORM_INP_SEP_RE = re.compile(r"[\n\r;]+")


def bare(tok: str) -> str:
    """Bare variable name for comparison: strip prefixes, dataset, and clean suffixes."""
    t = _BARE_PREFIX_RE.sub("", tok.strip().upper())
    parts = t.split(".")
    varname = parts[-1] if parts else t
    return _BARE_SUFFIX_RE.sub("", varname).upper()


def _is_preserve_token(tok: str) -> bool:
    """Return True for tokens that must always be kept (sdtm.*, work.*, plain identifiers)."""
    t = tok.strip().upper()
    if not t or t in ("NAN", "NONE", "NULL"):
        return False
    if len(t) > 1000:
        return False
    if t.startswith("SDTM.") or t.startswith("WORK."):
        return True
    if "." not in t and " " not in tok.strip() and len(tok.strip()) <= 80:
        return True
    return False


def _is_raw_token(tok: str) -> bool:
    return tok.strip().upper().startswith("RAW.")


def _is_garbage(tok: str) -> bool:
    """Detect free-text notes or junk that ended up in Input Variables cells."""
    t = tok.strip()
    if not t or t.lower() == "nan":
        return True
    if " " in t or len(t) > 1000:
        return True
    return False


def _norm_inp(s: str) -> str:
    """Normalise Input Variables cell for change-detection (order-insensitive)."""
    flat = _NORM_INP_SEP_RE.sub(",", str(s))
    tokens = sorted(
        t.strip().upper()
        for t in flat.split(",")
        if t.strip() and t.strip().upper() not in ("", "NAN")
    )
    return "|".join(tokens)



def write_back(
    spec_path,
    results_path,
    out_path,
    highlight_review=True,
    populate_origin=True,
    populate_action=True,
    dry_run=False,
    config_path="config.yaml",
):
    """
    Update Input Variables (and optionally Origin, Mapping Action) in the
    spec workbook without touching any formatting.

    Args:
        spec_path:        original spec Excel
        results_path:     mapping_results.xlsx from mapper.py
        out_path:         output path for updated spec
        highlight_review: amber-highlight review-tier rows
        populate_origin:  write Origin column
        populate_action:  write Mapping Action (only if currently blank)
        dry_run:          preview changes to log without writing any file
        config_path:      config.yaml path

    Returns:
        path to updated spec (or None if dry_run)
    """
    try:
        cfg_p = Path(config_path)
        if not cfg_p.exists():
            module_dir = Path(__file__).parent
            candidate  = module_dir / cfg_p.name
            if candidate.exists():
                cfg_p = candidate
        with open(cfg_p) as f:
            cfg = yaml.safe_load(f)
    except Exception:
        cfg = {}

    log_cfg = cfg.get("logging", {})
    log     = get_logger(log_cfg.get("log_file", ""), log_cfg.get("level", "INFO"))

    if dry_run:
        log.info("[WRITEBACK] DRY-RUN mode - no file will be written")

    log.info("[WRITEBACK] Loading results: %s", results_path.name)
    mapping = load_results(results_path, log)
    if not mapping:
        log.warning("[WRITEBACK] No mapped variables - nothing to write")
        return None

    log.info("[WRITEBACK] Loading spec: %s", spec_path.name)
    ext      = spec_path.suffix.lower()
    is_macro = (ext == ".xlsm")
    wb       = load_workbook(spec_path, data_only=False, keep_vba=is_macro)

    # Capture before-state snapshot for post-writeback validation
    _validator = ExcelValidator(spec_path)

    # Read valid Origin values from Maintenance/Valuelist tab of this spec
    # so we normalize origins to the exact values the spec expects
    valid_origins = read_origin_values_from_spec(spec_path, {})
    if valid_origins:
        log.info("  Valid origin values from spec Maintenance tab: %s",
                 sorted(valid_origins))
    else:
        log.info("  No Maintenance tab found; using CDISC standard Origin values")

    change_log     = []
    skipped_sheets = []
    total_updates  = 0

    for ws in wb.worksheets:
        sn = ws.title
        # Skip non-domain sheets — never write into these
        _SKIP_WB = {
            "study", "standards", "toc", "<ds>", "ta", "te", "ti", "tv", "ts", "td",
            "ta-data", "te-data", "ti-data", "tv-data", "ts-data", "td-data",
            "maintenance", "valuelist", "value list", "history of revisions",
            "cover", "index", "readme",
        }
        if sn.strip().lower() in _SKIP_WB:
            continue
        # Skip any previously appended writeback change-log sheets
        if re.match(r"_Writeback_[0-9]{8}_[0-9]{4}$", sn.strip()):
            continue

        # Find header row
        hdr_row = None
        col_idx = {}
        for r in range(1, min(ws.max_row + 1, 15)):
            row_vals = {c: ws.cell(r, c).value for c in range(1, ws.max_column + 1)}
            ds = va = inp = act = orig = core = None
            for c, val in row_vals.items():
                if ds   is None and _hdr(val, DATASET_HDR):  ds   = c
                if va   is None and _hdr(val, VARIABLE_HDR): va   = c
                if inp  is None and _hdr(val, INPUT_HDR):    inp  = c
                if act  is None and _hdr(val, ACTION_HDR):   act  = c
                if orig is None and _hdr(val, ORIGIN_HDR):   orig = c
                if core is None and _hdr(val, CORE_HDR):     core = c
            if ds and va and inp:
                hdr_row = r
                col_idx = {"ds": ds, "var": va, "inp": inp,
                           "act": act, "orig": orig, "core": core}
                break

        if hdr_row is None:
            skipped_sheets.append(sn)
            continue

        # ---- Strip conditional formatting that covers Input Variables column ----
        # Excel CF rules override cell-level PatternFill, making highlights invisible.
        # Removing CF rules on the inp column lets our bold+fill take effect.
        try:
            from openpyxl.utils import range_boundaries
            inp_ci = col_idx["inp"]
            keys_to_del = []
            for cf_sqref in list(ws.conditional_formatting._cf_rules.keys()):
                try:
                    # sqref may be multiple ranges e.g. "K1:K200 M1:M200"
                    for rng in str(cf_sqref).split():
                        mn_c, _, mx_c, _ = range_boundaries(rng)
                        if mn_c <= inp_ci <= mx_c:
                            keys_to_del.append(cf_sqref)
                            break
                except Exception:
                    pass
            for k in keys_to_del:
                try:
                    del ws.conditional_formatting._cf_rules[k]
                except Exception:
                    pass
        except Exception:
            pass

        sheet_updates = 0

        for r in range(hdr_row + 1, ws.max_row + 1):
            ds_val  = ws.cell(r, col_idx["ds"]).value
            var_val = ws.cell(r, col_idx["var"]).value
            if ds_val is None and var_val is None:
                continue

            dom = _norm(ds_val)
            var = _norm(var_val)
            if not var:
                continue

            # Lookup by (domain, var) then by var alone as fallback
            key = (dom, var) if (dom, var) in mapping else \
                  next((k for k in mapping if k[1] == var), None)
            if key is None:
                continue

            m    = mapping[key]
            tier = m["tier"]
            sc   = m["score"]

            # ---- Input Variables ----------------------------------------
            inp_cell = ws.cell(r, col_idx["inp"])
            old_inp  = str(inp_cell.value or "").strip()

            # Parse existing tokens in the spec cell
            existing_tokens = [
                t.strip() for t in old_inp.replace(";", ",").split(",")
                if t.strip()
            ] if old_inp else []

            # Build new Input Variables value
            new_raw = m["raw"]
            new_tokens = [
                t.strip() for t in new_raw.replace(";", ",").split(",")
                if t.strip() and not _is_garbage(t.strip())
            ] if new_raw else []

            # Merge: keep any existing non-RAW tokens (SDTM.*, WORK.*, plain)
            # then add the new RAW.* tokens from the mapping result
            keep = [t for t in existing_tokens if _is_preserve_token(t) and not _is_raw_token(t)]
            merged = keep + [t for t in new_tokens if t not in keep]

            new_inp_str = ", ".join(merged)

            inp_changed = _norm_inp(new_inp_str) != _norm_inp(old_inp)

            if inp_changed and new_inp_str:
                # Choose fill colour by tier
                if tier == "direct":
                    cell_fill = FILL_DIRECT
                elif tier == "review":
                    cell_fill = FILL_REVIEW
                else:
                    cell_fill = FILL_UNRES

                inp_cell.value = new_inp_str
                if highlight_review or tier == "direct":
                    inp_cell.fill = cell_fill
                    inp_cell.font = FONT_UPDATED

                change_log.append({
                    "Sheet":     sn,
                    "Domain":    dom,
                    "Variable":  var,
                    "Column":    "Input Variables",
                    "Old_Value": old_inp,
                    "New_Value": new_inp_str,
                    "Tier":      tier,
                    "Score":     round(sc, 4),
                    "Note":      m.get("note", ""),
                })
                sheet_updates += 1
                total_updates  += 1

            # ---- Origin -------------------------------------------------
            if populate_origin and col_idx.get("orig"):
                orig_cell = ws.cell(r, col_idx["orig"])
                old_orig  = str(orig_cell.value or "").strip()
                new_orig  = m["origin"]

                # Resolve to CDISC-canonical value if a valid list was found
                if valid_origins:
                    new_orig = normalize_origin_to_cdisc(new_orig, valid_origins)

                orig_higher_priority = (
                    _origin_priority(new_orig) < _origin_priority(old_orig)
                    or not old_orig
                )

                if new_orig and orig_higher_priority and new_orig != old_orig:
                    orig_cell.value = new_orig
                    change_log.append({
                        "Sheet":     sn,
                        "Domain":    dom,
                        "Variable":  var,
                        "Column":    "Origin",
                        "Old_Value": old_orig,
                        "New_Value": new_orig,
                        "Tier":      tier,
                        "Score":     round(sc, 4),
                        "Note":      "",
                    })
                    total_updates += 1

            # ---- Mapping Action -----------------------------------------
            if populate_action and col_idx.get("act"):
                act_cell = ws.cell(r, col_idx["act"])
                old_act  = str(act_cell.value or "").strip()
                new_act  = m["action"]
                # Only write if currently blank
                if new_act and not old_act:
                    act_cell.value = new_act
                    change_log.append({
                        "Sheet":     sn,
                        "Domain":    dom,
                        "Variable":  var,
                        "Column":    "Mapping Action",
                        "Old_Value": old_act,
                        "New_Value": new_act,
                        "Tier":      tier,
                        "Score":     round(sc, 4),
                        "Note":      "",
                    })
                    total_updates += 1

        if sheet_updates:
            log.info("  [%s] %d cell update(s)", sn, sheet_updates)

    if skipped_sheets:
        log.info("  Skipped (no variable header found): %s", skipped_sheets)

    # Preview in dry-run mode
    if dry_run:
        log.info("\n  DRY-RUN PREVIEW - %d changes would be made:", len(change_log))
        for entry in change_log[:30]:
            log.info(
                "    [%s] %s.%s -> %s: '%s' -> '%s'",
                entry["Tier"], entry["Domain"], entry["Variable"],
                entry["Column"], entry["Old_Value"], entry["New_Value"],
            )
        if len(change_log) > 30:
            log.info("    ... and %d more changes", len(change_log) - 30)
        return None

    # Append change-log sheet
    if change_log:
        ts_str  = dt.datetime.now().strftime("%Y%m%d_%H%M")
        log_sn  = ("_Writeback_" + ts_str)[:31]
        log_ws  = wb.create_sheet(log_sn)
        headers = ["Sheet", "Domain", "Variable", "Column",
                   "Old_Value", "New_Value", "Tier", "Score", "Note"]
        for ci, h in enumerate(headers, 1):
            c = log_ws.cell(1, ci, h)
            c.fill = FILL_HEADER
            c.font = FONT_HEADER
            c.alignment = Alignment(horizontal="center")
        for ri, entry in enumerate(change_log, 2):
            for ci, h in enumerate(headers, 1):
                log_ws.cell(ri, ci, entry.get(h, ""))
        log_ws.freeze_panes = "A2"
        log_ws.auto_filter.ref = (
            "A1:" + get_column_letter(len(headers)) + str(len(change_log) + 1)
        )
        for ci in range(1, len(headers) + 1):
            log_ws.column_dimensions[get_column_letter(ci)].width = 22

    wb.save(out_path)

    log.info(
        "[WRITEBACK]  %d total cell updates  |  %d change-log entries  ->  %s",
        total_updates, len(change_log), out_path,
    )

    # Run post-writeback validation
    validation_report = None
    try:
        validation_report = _validator.validate_after(out_path)
        overall = validation_report["summary"]["overall_status"]
        risk    = validation_report["summary"]["risk_score"]
        log.info("[VALIDATE]  status=%s  risk=%.0f%%  checks=%d  failed=%d",
                 overall, risk*100,
                 validation_report["summary"]["total_checks"],
                 validation_report["summary"]["failed"])
        for issue in validation_report.get("issues", []):
            log.warning("  [%s] %s — %s",
                        issue["severity"], issue["issue"], issue.get("root_cause",""))
    except Exception as _ve:
        log.warning("[VALIDATE]  Validation step failed: %s", _ve)

    return out_path, validation_report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Write mapping results into SDTM spec Excel.")
    ap.add_argument("--spec",         required=True)
    ap.add_argument("--results",      required=True)
    ap.add_argument("--out",          required=True)
    ap.add_argument("--no-origin",    action="store_true")
    ap.add_argument("--no-action",    action="store_true")
    ap.add_argument("--no-highlight", action="store_true")
    ap.add_argument("--dry-run",      action="store_true",
                    help="Preview changes without writing any file")
    ap.add_argument("--config",       default="config.yaml")
    args = ap.parse_args()
    write_back(
        spec_path=Path(args.spec),
        results_path=Path(args.results),
        out_path=Path(args.out),
        highlight_review=not args.no_highlight,
        populate_origin=not args.no_origin,
        populate_action=not args.no_action,
        dry_run=args.dry_run,
        config_path=args.config,
    )
