"""
logger.py
=========
Centralised logging for the SDTM mapping pipeline.
Writes to both console and an optional log file.
All output is plain ASCII; no Unicode box-drawing characters.

Thread-safe: uses a threading.Lock so concurrent Streamlit sessions
each get a correctly configured logger without races on _configured.
"""

import logging
import sys
import threading
from pathlib import Path


_LOGGER_NAME = "sdtm_pipeline"
_lock        = threading.Lock()
_configured  = False


def get_logger(log_file: str = "", level: str = "INFO") -> logging.Logger:
    """
    Return the pipeline logger.  Configures it on first call; subsequent
    calls return the already-configured logger unchanged.

    Thread-safe: concurrent callers block on a Lock until configuration
    is complete, then all return the same Logger instance.

    Args:
        log_file: path to log file; empty string = console only
        level:    DEBUG | INFO | WARNING
    """
    global _configured

    logger = logging.getLogger(_LOGGER_NAME)

    if _configured:
        return logger

    with _lock:
        if _configured:
            return logger

        level_map = {
            "DEBUG":   logging.DEBUG,
            "INFO":    logging.INFO,
            "WARNING": logging.WARNING,
        }
        log_level = level_map.get(str(level).upper(), logging.INFO)
        logger.setLevel(log_level)

        fmt = logging.Formatter(
            fmt="%(asctime)s  %(levelname)-7s  %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(log_level)
        ch.setFormatter(fmt)
        logger.addHandler(ch)

        if log_file:
            try:
                fh = logging.FileHandler(log_file, encoding="ascii", errors="replace")
                fh.setLevel(log_level)
                fh.setFormatter(fmt)
                logger.addHandler(fh)
            except Exception as exc:
                logger.warning("Cannot open log file %s: %s", log_file, exc)

        _configured = True

    return logger


def reset_logger() -> None:
    """
    Reset the logger configuration.  Intended for use in tests and
    multi-run Streamlit scenarios where a fresh logger is required.
    """
    global _configured
    with _lock:
        logger = logging.getLogger(_LOGGER_NAME)
        for handler in list(logger.handlers):
            try:
                handler.close()
            except Exception:
                pass
            logger.removeHandler(handler)
        _configured = False
