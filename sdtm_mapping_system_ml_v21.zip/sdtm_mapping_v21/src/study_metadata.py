"""
study_metadata.py
=================
Reads study-level metadata from the Study and Standards tabs of a
SDTM mapping specification workbook.

Based on the standard Gilead/sponsor spec layout (Images 1 and 2):
  Study tab:     row-based key-value pairs (col A = field name, col B = value)
  Standards tab: structured table (ID, Name, Type, PublishingSet, Version, Status)

Extracts:
  - SDTMIG version (3.2 / 3.3 / 3.4) from Mapping Specification IG field
  - Therapeutic area from TA Specific Mapping Spec field
  - Study phase from Study Description / TA spec filename
  - Study name, protocol number, MedDRA version, CT version
  - Define XML version

Auto-detection rules:
  - Version regex: SDTMIGV{major}.{minor} or V{major}.{minor} in filenames
  - TA keywords: ONCOLOGY, CARDIOLOGY, NEUROLOGY, RESPIRATORY, IMMUNOLOGY,
                 NEPHROLOGY, OPHTHALMOLOGY, PHASE1, PHASE2, PHASE3 etc.
"""

from __future__ import annotations

import re
import math
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

KNOWN_SDTMIG_VERSIONS = ["3.1.1", "3.1.2", "3.1.3", "3.2", "3.3", "3.4"]

# TA keyword -> canonical TA code
TA_KEYWORD_MAP = {
    "ONCOLOGY":      "ONCOLOGY",
    "ONCO":          "ONCOLOGY",
    "CANCER":        "ONCOLOGY",
    "TUMOR":         "ONCOLOGY",
    "TUMOUR":        "ONCOLOGY",
    "CARDIOLOGY":    "CARDIOLOGY",
    "CARDIAC":       "CARDIOLOGY",
    "CARDIOVASCULAR":"CARDIOLOGY",
    "CV":            "CARDIOLOGY",
    "NEUROLOGY":     "NEUROLOGY",
    "NEURO":         "NEUROLOGY",
    "CNS":           "NEUROLOGY",
    "RESPIRATORY":   "RESPIRATORY",
    "PULMONARY":     "RESPIRATORY",
    "RESP":          "RESPIRATORY",
    "IMMUNOLOGY":    "IMMUNOLOGY",
    "IMMUNE":        "IMMUNOLOGY",
    "RHEUMATOLOGY":  "RHEUMATOLOGY",
    "RHEUM":         "RHEUMATOLOGY",
    "NEPHROLOGY":    "NEPHROLOGY",
    "RENAL":         "NEPHROLOGY",
    "OPHTHALMOLOGY": "OPHTHALMOLOGY",
    "OPHTHALM":      "OPHTHALMOLOGY",
    "RETINAL":       "OPHTHALMOLOGY",
    "HEMATOLOGY":    "HEMATOLOGY",
    "HAEMATOLOGY":   "HEMATOLOGY",
    "ENDOCRINOLOGY": "ENDOCRINOLOGY",
    "DIABETES":      "ENDOCRINOLOGY",
    "INFECTIOUS":    "INFECTIOUS_DISEASE",
    "VIROLOGY":      "INFECTIOUS_DISEASE",
    "HIV":           "INFECTIOUS_DISEASE",
    "ANTIVIRAL":     "INFECTIOUS_DISEASE",
    "DERMATOLOGY":   "DERMATOLOGY",
    "DERM":          "DERMATOLOGY",
    "GASTROENTEROLOGY": "GASTROENTEROLOGY",
    "GI":            "GASTROENTEROLOGY",
    "HEPATOLOGY":    "GASTROENTEROLOGY",
    "MUSCULOSKELETAL":"MUSCULOSKELETAL",
    "MSK":           "MUSCULOSKELETAL",
    "QRS":           "QRS",          # QRS = questionnaire/ratings scales TA supplement
}

# Study phase keyword -> canonical phase
PHASE_KEYWORD_MAP = {
    "PHASE1":   "PHASE1",
    "PHASE 1":  "PHASE1",
    "PHASE-1":  "PHASE1",
    "PHASE I":  "PHASE1",
    "PHASE2":   "PHASE2",
    "PHASE 2":  "PHASE2",
    "PHASE-2":  "PHASE2",
    "PHASE II": "PHASE2",
    "PHASE3":   "PHASE3",
    "PHASE 3":  "PHASE3",
    "PHASE-3":  "PHASE3",
    "PHASE III":"PHASE3",
    "PHASE4":   "PHASE4",
    "PHASE 4":  "PHASE4",
    "PHASE IV": "PHASE4",
}

# Study tab: field name aliases (case-insensitive contains match)
STUDY_FIELD_ALIASES = {
    "sdtmig_version":     ["mapping specification ig", "ig version", "sdtmig", "ig name"],
    "ta_spec":            ["ta specific", "therapeutic area", "ta mapping", "taug"],
    "study_name":         ["study name", "study id", "studyid"],
    "protocol_number":    ["protocol number", "protocol id", "protocol"],
    "study_description":  ["study description", "description"],
    "meddra_version":     ["meddra", "med dra", "meddra dictionary"],
    "whodrug_version":    ["whodrug", "who drug"],
    "define_xml_version": ["define xml", "define-xml"],
    "glib_version":       ["glib version", "glib"],
    "template_date":      ["standards template date", "template date"],
    "data_package":       ["data package"],
    "context":            ["context"],
    "ct_version":         ["ct version", "controlled terminology"],
}


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------

@dataclass
class StudyMetadata:
    """Structured metadata extracted from Study and Standards tabs."""

    # Core versioning
    sdtmig_version:      str = ""          # e.g. "3.3"
    sdtmig_version_raw:  str = ""          # raw value from spec
    ct_version:          str = ""          # e.g. "2024-03-29"
    define_xml_version:  str = ""          # e.g. "2.1.0"
    glib_version:        str = ""          # e.g. "2023 Core 2.0"

    # Study identity
    study_name:          str = ""
    protocol_number:     str = ""
    study_description:   str = ""
    template_date:       str = ""

    # TA and phase
    therapeutic_area:    str = ""          # e.g. "ONCOLOGY"
    study_phase:         str = ""          # e.g. "PHASE1"
    ta_spec_raw:         str = ""          # raw TA Specific Mapping Spec value

    # Dictionaries
    meddra_version:      str = ""
    whodrug_version:     str = ""

    # Standards registry (from Standards tab)
    standards:           list = field(default_factory=list)

    # Source
    source_file:         str = ""
    parse_warnings:      list = field(default_factory=list)

    def is_complete(self) -> bool:
        return bool(self.sdtmig_version and self.study_name)

    def summary(self) -> str:
        parts = []
        if self.sdtmig_version:
            parts.append(f"SDTMIG {self.sdtmig_version}")
        if self.therapeutic_area:
            parts.append(self.therapeutic_area)
        if self.study_phase:
            parts.append(self.study_phase)
        if self.study_name:
            parts.append(self.study_name)
        if self.meddra_version:
            parts.append(f"MedDRA {self.meddra_version}")
        return " | ".join(parts) if parts else "No metadata found"


# ---------------------------------------------------------------------------
# Version detection
# ---------------------------------------------------------------------------

def detect_ig_version(text: str) -> str:
    """
    Extract SDTMIG version number from a filename or free-text string.

    Examples:
      'SDTMIGV3.3 Mapping Specifications...' -> '3.3'
      'SDTMIG v3.4' -> '3.4'
      'Version 3.2' -> '3.2'
      '3.3' -> '3.3'
    """
    if not text:
        return ""
    text_up = text.upper().strip()

    # Pattern 1: SDTMIGV{version} or SDTMIG-V{version} or SDTMIG V{version}
    m = re.search(r"SDTMIG[-\s]?V?(\d+\.\d+(?:\.\d+)?)", text_up)
    if m:
        return m.group(1)

    # Pattern 2: IG-V{version} in filename
    m = re.search(r"IG[-\s]?V(\d+\.\d+)", text_up)
    if m:
        return m.group(1)

    # Pattern 2b: standalone V{version} at word boundary (e.g. "V3.2 Mapping Guide")
    m = re.search(r"\bV(\d+\.\d+(?:\.\d+)?)\b", text_up)
    if m:
        v = m.group(1)
        parts = v.split(".")
        if len(parts) >= 2 and 3 <= int(parts[0]) <= 4 and 0 <= int(parts[1]) <= 9:
            return v

    # Pattern 3: bare version number like "3.3" or "3.3.0"
    m = re.search(r"\b(\d+\.\d+(?:\.\d+)?)\b", text)
    if m:
        v = m.group(1)
        # Validate it looks like a plausible SDTMIG version
        parts = v.split(".")
        if len(parts) >= 2 and 3 <= int(parts[0]) <= 4 and 0 <= int(parts[1]) <= 9:
            return v

    return ""


def detect_therapeutic_area(text: str) -> str:
    """
    Extract therapeutic area from a TA Specific Mapping Spec filename or any text.
    Returns the canonical TA code or empty string. Does NOT return phase info.
    """
    if not text:
        return ""
    text_up = text.upper().replace("-", " ").replace("_", " ")

    # TA keywords only (phases handled separately by detect_study_phase)
    for keyword, canonical in sorted(TA_KEYWORD_MAP.items(), key=lambda x: -len(x[0])):
        if keyword.upper() in text_up:
            return canonical

    return ""


def detect_study_phase(text: str) -> str:
    """Extract study phase from description or TA spec filename."""
    if not text:
        return ""
    text_up = text.upper()
    for keyword, canonical in sorted(PHASE_KEYWORD_MAP.items(), key=lambda x: -len(x[0])):
        if keyword.upper() in text_up:
            return canonical
    return ""


# ---------------------------------------------------------------------------
# Study tab reader
# ---------------------------------------------------------------------------

def _norm_key(s) -> str:
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip()).lower()


def _norm_val(s) -> str:
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip())


def _read_study_tab(xl: pd.ExcelFile) -> dict:
    """
    Read the Study tab (key-value layout, col A = key, col B = value).
    Returns a dict of {field_alias_key: raw_value}.
    """
    study_sheet = None
    for sn in xl.sheet_names:
        if sn.strip().lower() in ("study", "study info", "study metadata", "metadata"):
            study_sheet = sn
            break

    if study_sheet is None:
        return {}

    try:
        df = xl.parse(study_sheet, header=None, dtype=object)
    except Exception:
        return {}

    # Build raw dict: normalised_key -> first non-blank value in that row
    raw = {}
    for _, row in df.iterrows():
        vals = [_norm_val(v) for v in row if _norm_val(v)]
        if len(vals) >= 2:
            key = vals[0].lower().strip()
            val = vals[1]
            raw[key] = val
        elif len(vals) == 1:
            raw[vals[0].lower().strip()] = ""

    # Map to standardised keys using aliases
    result = {}
    for std_key, aliases in STUDY_FIELD_ALIASES.items():
        for alias in aliases:
            for raw_key, raw_val in raw.items():
                if alias in raw_key:
                    result[std_key] = raw_val
                    break
            if std_key in result:
                break

    return result


def _read_standards_tab(xl: pd.ExcelFile) -> list:
    """
    Read the Standards tab (structured table with ID, Name, Type, Version, Status).
    Returns a list of dicts.
    """
    standards_sheet = None
    for sn in xl.sheet_names:
        if sn.strip().lower() in ("standards", "standard", "standards registry"):
            standards_sheet = sn
            break

    if standards_sheet is None:
        return []

    try:
        df = xl.parse(standards_sheet, dtype=object)
        if df.empty:
            return []

        # Normalise column names
        df.columns = [_norm_key(c) for c in df.columns]
        records = []
        for _, row in df.iterrows():
            rec = {k: _norm_val(v) for k, v in row.items() if _norm_val(v)}
            if rec:
                records.append(rec)
        return records
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Main public function
# ---------------------------------------------------------------------------

def read_study_metadata(spec_path, log=None) -> StudyMetadata:
    """
    Read study metadata from the Study and Standards tabs of a spec workbook.

    Args:
        spec_path:  path to the spec Excel workbook
        log:        optional Python logger

    Returns:
        StudyMetadata dataclass (fields are empty strings if not found)
    """
    spec_path = Path(spec_path)
    meta      = StudyMetadata(source_file=spec_path.name)

    try:
        xl = pd.ExcelFile(spec_path, engine="openpyxl")
    except Exception as exc:
        if log:
            log.warning("  Cannot open %s for metadata: %s", spec_path.name, exc)
        return meta

    # ---- Study tab ----
    study_data = _read_study_tab(xl)

    # SDTMIG version
    ig_raw = study_data.get("sdtmig_version", "")
    meta.sdtmig_version_raw = ig_raw
    meta.sdtmig_version     = detect_ig_version(ig_raw)

    # If not found in Mapping Spec IG, try GLIB version or Data Package
    if not meta.sdtmig_version:
        for fallback_key in ("glib_version", "data_package"):
            v = detect_ig_version(study_data.get(fallback_key, ""))
            if v:
                meta.sdtmig_version = v
                break

    # Therapeutic area and phase
    ta_raw = study_data.get("ta_spec", "")
    meta.ta_spec_raw       = ta_raw
    meta.therapeutic_area  = detect_therapeutic_area(ta_raw)
    meta.study_phase       = detect_study_phase(ta_raw)

    # If TA not found in ta_spec, try study_description
    if not meta.therapeutic_area:
        meta.therapeutic_area = detect_therapeutic_area(
            study_data.get("study_description", "")
        )
    if not meta.study_phase:
        meta.study_phase = detect_study_phase(
            study_data.get("study_description", "")
        )

    # Other fields
    meta.study_name         = study_data.get("study_name", "")
    meta.protocol_number    = study_data.get("protocol_number", "")
    meta.study_description  = study_data.get("study_description", "")
    meta.meddra_version     = study_data.get("meddra_version", "")
    meta.whodrug_version    = study_data.get("whodrug_version", "")
    meta.define_xml_version = study_data.get("define_xml_version", "")
    meta.glib_version       = study_data.get("glib_version", "")
    meta.template_date      = study_data.get("template_date", "")

    # ---- Standards tab ----
    standards = _read_standards_tab(xl)
    meta.standards = standards

    # CT version from Standards tab
    for rec in standards:
        type_val    = rec.get("type", "").upper()
        version_val = rec.get("version", "")
        if type_val == "CT" and version_val:
            meta.ct_version = version_val
            break

    # If SDTMIG version not yet found, try Standards tab
    if not meta.sdtmig_version:
        for rec in standards:
            type_val = rec.get("type", "").upper()
            name_val = rec.get("name", "").upper()
            ver_val  = rec.get("version", "")
            if type_val == "IG" and ("SDTMIG" in name_val or "SDTM" in name_val):
                v = detect_ig_version(ver_val)
                if v:
                    meta.sdtmig_version = v
                    break

    if log and meta.sdtmig_version:
        log.info(
            "  Study metadata: SDTMIG=%s  TA=%s  Phase=%s  Study=%s",
            meta.sdtmig_version,
            meta.therapeutic_area or "unknown",
            meta.study_phase or "unknown",
            meta.study_name or spec_path.name,
        )

    return meta


# ---------------------------------------------------------------------------
# Version comparison helpers
# ---------------------------------------------------------------------------

def version_tuple(v: str) -> tuple:
    """Convert '3.3' to (3, 3, 0) for comparison."""
    try:
        parts = [int(x) for x in v.split(".")]
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])
    except (ValueError, AttributeError):
        return (0, 0, 0)


def versions_compatible(v1: str, v2: str, tolerance: int = 0) -> bool:
    """
    Return True if two SDTMIG versions are compatible for cross-study pooling.
    tolerance=0: must be identical minor version (3.3 == 3.3)
    tolerance=1: same major, adjacent minor (3.2 and 3.3 ok, 3.1 and 3.3 not)
    tolerance=2: same major (3.x and 3.y always ok)
    """
    t1 = version_tuple(v1)
    t2 = version_tuple(v2)
    if not t1[0] or not t2[0]:
        return True   # unknown version -> allow
    if t1[0] != t2[0]:
        return False  # different major version -> incompatible
    if tolerance == 0:
        return t1[:2] == t2[:2]
    if tolerance == 1:
        return abs(t1[1] - t2[1]) <= 1
    return True   # tolerance=2: same major is enough


def version_weight(study_version: str, target_version: str) -> float:
    """
    Return a weight multiplier [0.5 .. 1.0] for how well a study's
    SDTMIG version matches the target version.

    Same version        -> 1.00
    Adjacent minor      -> 0.85 (3.2 vs 3.3)
    2 minor apart       -> 0.70 (3.1 vs 3.3)
    Different major     -> 0.50 (2.x vs 3.x)
    Either unknown      -> 0.90 (give benefit of doubt)
    """
    if not study_version or not target_version:
        return 0.90
    t1 = version_tuple(study_version)
    t2 = version_tuple(target_version)
    if t1 == t2:
        return 1.00
    if t1[0] != t2[0]:
        return 0.50
    diff = abs(t1[1] - t2[1])
    return max(1.00 - diff * 0.15, 0.55)
