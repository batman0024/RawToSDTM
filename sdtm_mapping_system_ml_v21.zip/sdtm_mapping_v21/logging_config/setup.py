"""
logging_config/setup.py
=======================
Structured logging setup. Supports text and JSON formats.
Replaces src/logger.py for the new architecture layer;
src/logger.py remains unchanged for the pipeline core.
"""
from __future__ import annotations

import json
import logging
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


_lock = threading.Lock()
_configured = False
_APP_LOGGER = "sdtm_app"


class _JSONFormatter(logging.Formatter):
    """Emit log records as single-line JSON for structured log aggregators."""

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "module": record.module,
            "line": record.lineno,
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=True)


def configure_logging(
    level: str = "INFO",
    fmt: str = "text",
    log_file: str = "",
) -> logging.Logger:
    """
    Configure and return the application logger.
    Thread-safe; subsequent calls return the existing logger.

    Args:
        level:    DEBUG | INFO | WARNING | ERROR
        fmt:      text | json
        log_file: path to log file; empty = console only
    """
    global _configured

    logger = logging.getLogger(_APP_LOGGER)

    if _configured:
        return logger

    with _lock:
        if _configured:
            return logger

        lvl = getattr(logging, level.upper(), logging.INFO)
        logger.setLevel(lvl)
        logger.propagate = False

        if fmt.lower() == "json":
            formatter: logging.Formatter = _JSONFormatter()
        else:
            formatter = logging.Formatter(
                fmt="%(asctime)s  %(levelname)-7s  [%(name)s]  %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )

        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(lvl)
        ch.setFormatter(formatter)
        logger.addHandler(ch)

        if log_file:
            try:
                fh = logging.FileHandler(log_file, encoding="utf-8", errors="replace")
                fh.setLevel(lvl)
                fh.setFormatter(formatter)
                logger.addHandler(fh)
            except OSError as exc:
                logger.warning("Cannot open log file %s: %s", log_file, exc)

        _configured = True

    return logger


def get_app_logger(name: Optional[str] = None) -> logging.Logger:
    """Return a child logger of the app logger."""
    root = logging.getLogger(_APP_LOGGER)
    if not _configured:
        configure_logging()
    return root.getChild(name) if name else root


def reset_logging() -> None:
    """Reset for tests / multi-run scenarios."""
    global _configured
    with _lock:
        logger = logging.getLogger(_APP_LOGGER)
        for h in list(logger.handlers):
            try:
                h.close()
            except Exception:
                pass
            logger.removeHandler(h)
        _configured = False
