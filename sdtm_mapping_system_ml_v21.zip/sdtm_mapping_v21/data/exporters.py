"""
data/exporters.py
=================
Results export utilities: Excel, JSON.
No Streamlit imports.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

from exceptions.domain_exceptions import DataLoadError

log = logging.getLogger("sdtm_app.data.exporters")


def export_excel(
    sheets: Dict[str, pd.DataFrame],
    out_path: Path,
    freeze_panes: bool = True,
) -> Path:
    """
    Write multiple DataFrames to a single Excel workbook (one sheet each).

    Args:
        sheets:       {sheet_name: DataFrame}
        out_path:     Output .xlsx path
        freeze_panes: Freeze first row on each sheet

    Returns:
        Path to written file

    Raises:
        DataLoadError on write failure
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
            for sheet_name, df in sheets.items():
                safe_name = sheet_name[:31]  # Excel sheet name limit
                if df is not None and not df.empty:
                    df.to_excel(writer, sheet_name=safe_name, index=False)
                    if freeze_panes:
                        ws = writer.sheets[safe_name]
                        ws.freeze_panes = "A2"
        log.info("Excel exported: %s (%d sheets)", out_path.name, len(sheets))
        return out_path
    except Exception as exc:
        raise DataLoadError(f"Excel export failed: {exc}", detail=str(exc)) from exc


def export_json(
    data: dict,
    out_path: Path,
    indent: int = 2,
) -> Path:
    """
    Write a dict to a JSON file.

    Returns:
        Path to written file

    Raises:
        DataLoadError on write failure
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, default=str, ensure_ascii=True)
        log.info("JSON exported: %s", out_path.name)
        return out_path
    except Exception as exc:
        raise DataLoadError(f"JSON export failed: {exc}", detail=str(exc)) from exc


def mapping_results_to_excel(results: dict, out_path: Path) -> Path:
    """
    Export run_mapping() results dict to a styled Excel workbook.
    Thin wrapper that extracts the standard sheets by key name.
    """
    sheet_map: Dict[str, pd.DataFrame] = {}
    for key in ("direct", "review", "cross_dataset_match", "unresolved", "unmapped_raw", "coverage"):
        df = results.get(key)
        if isinstance(df, pd.DataFrame) and not df.empty:
            sheet_map[key] = df

    return export_excel(sheet_map, out_path)
