"""
data/loaders.py
===============
Unified file loader with factory pattern.
Supports: CSV, Excel (XLSX/XLS), JSON, Parquet, SAS XPT/SAS7BDAT.
Returns pandas DataFrames with consistent column naming.
No Streamlit imports.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

import pandas as pd

from exceptions.domain_exceptions import DataLoadError

log = logging.getLogger("sdtm_app.data.loaders")

# ── Abstract base ─────────────────────────────────────────────────────────────

class BaseLoader(ABC):
    """Common interface for all file loaders."""

    @abstractmethod
    def load(self, path: Path, **kwargs) -> pd.DataFrame:
        """Load file and return DataFrame. Raises DataLoadError on failure."""
        ...

    @abstractmethod
    def can_load(self, path: Path) -> bool:
        """Return True if this loader handles the given file extension."""
        ...


# ── Concrete loaders ──────────────────────────────────────────────────────────

class CSVLoader(BaseLoader):
    EXTENSIONS = {".csv", ".tsv", ".txt"}

    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() in self.EXTENSIONS

    def load(self, path: Path, encoding: str = "utf-8", **kwargs) -> pd.DataFrame:
        sep = "\t" if path.suffix.lower() == ".tsv" else ","
        try:
            df = pd.read_csv(path, sep=sep, encoding=encoding, dtype=object, **kwargs)
            log.info("CSV loaded: %s — %d rows, %d cols", path.name, len(df), len(df.columns))
            return df
        except UnicodeDecodeError:
            df = pd.read_csv(path, sep=sep, encoding="latin-1", dtype=object, **kwargs)
            log.info("CSV loaded (latin-1): %s — %d rows", path.name, len(df))
            return df
        except Exception as exc:
            raise DataLoadError(f"Cannot load CSV {path.name}: {exc}", detail=str(exc)) from exc


class ExcelLoader(BaseLoader):
    EXTENSIONS = {".xlsx", ".xlsm", ".xls"}

    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() in self.EXTENSIONS

    def load(self, path: Path, sheet_name: int = 0, **kwargs) -> pd.DataFrame:
        engine = "openpyxl" if path.suffix.lower() in {".xlsx", ".xlsm"} else "xlrd"
        try:
            df = pd.read_excel(path, sheet_name=sheet_name, engine=engine, dtype=object, **kwargs)
            log.info("Excel loaded: %s — %d rows, %d cols", path.name, len(df), len(df.columns))
            return df
        except Exception as exc:
            raise DataLoadError(f"Cannot load Excel {path.name}: {exc}", detail=str(exc)) from exc


class JSONLoader(BaseLoader):
    EXTENSIONS = {".json", ".jsonl"}

    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() in self.EXTENSIONS

    def load(self, path: Path, **kwargs) -> pd.DataFrame:
        try:
            if path.suffix.lower() == ".jsonl":
                df = pd.read_json(path, lines=True, dtype=object, **kwargs)
            else:
                df = pd.read_json(path, dtype=object, **kwargs)
            log.info("JSON loaded: %s — %d rows", path.name, len(df))
            return df
        except Exception as exc:
            raise DataLoadError(f"Cannot load JSON {path.name}: {exc}", detail=str(exc)) from exc


class ParquetLoader(BaseLoader):
    EXTENSIONS = {".parquet", ".feather"}

    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() in self.EXTENSIONS

    def load(self, path: Path, **kwargs) -> pd.DataFrame:
        try:
            if path.suffix.lower() == ".feather":
                df = pd.read_feather(path, **kwargs)
            else:
                df = pd.read_parquet(path, **kwargs)
            log.info("Parquet/Feather loaded: %s — %d rows", path.name, len(df))
            return df
        except Exception as exc:
            raise DataLoadError(f"Cannot load {path.name}: {exc}", detail=str(exc)) from exc


class SASLoader(BaseLoader):
    EXTENSIONS = {".xpt", ".sas7bdat", ".sas"}

    def can_load(self, path: Path) -> bool:
        return path.suffix.lower() in self.EXTENSIONS

    def load(self, path: Path, **kwargs) -> pd.DataFrame:
        ext = path.suffix.lower()
        fmt = "xport" if ext == ".xpt" else "sas7bdat"
        try:
            df = pd.read_sas(str(path), format=fmt, encoding="latin-1", **kwargs)
            log.info("SAS loaded: %s — %d rows", path.name, len(df))
            return df
        except Exception as exc:
            raise DataLoadError(f"Cannot load SAS {path.name}: {exc}", detail=str(exc)) from exc


# ── Factory ───────────────────────────────────────────────────────────────────

_LOADERS: list[BaseLoader] = [
    CSVLoader(),
    ExcelLoader(),
    JSONLoader(),
    ParquetLoader(),
    SASLoader(),
]


def load_file(path: Path, **kwargs) -> pd.DataFrame:
    """
    Factory entry point: auto-detect format from extension and load.

    Args:
        path:   File path
        **kwargs: Forwarded to the underlying loader

    Returns:
        pandas DataFrame

    Raises:
        DataLoadError if format is unsupported or file cannot be read
    """
    path = Path(path)
    if not path.exists():
        raise DataLoadError(f"File not found: {path}", detail=str(path))

    for loader in _LOADERS:
        if loader.can_load(path):
            return loader.load(path, **kwargs)

    raise DataLoadError(
        f"Unsupported file format: '{path.suffix}'. "
        f"Supported: CSV, Excel, JSON, Parquet, Feather, SAS XPT/SAS7BDAT",
    )


def get_metadata(df: pd.DataFrame) -> dict:
    """
    Extract metadata from a loaded DataFrame.

    Returns dict with:
        row_count, col_count, columns, dtypes,
        null_counts, completeness, unique_counts,
        stats (numeric summary), sample_head, sample_tail
    """
    metadata: dict = {
        "row_count": len(df),
        "col_count": len(df.columns),
        "columns": list(df.columns),
        "dtypes": {col: str(df[col].dtype) for col in df.columns},
        "null_counts": df.isnull().sum().to_dict(),
        "completeness": {
            col: round((1 - df[col].isnull().mean()) * 100, 2)
            for col in df.columns
        },
        "unique_counts": {col: int(df[col].nunique()) for col in df.columns},
        "sample_head": df.head(5).to_dict(orient="records"),
        "sample_tail": df.tail(5).to_dict(orient="records"),
    }
    try:
        num_df = df.select_dtypes(include="number")
        if not num_df.empty:
            metadata["stats"] = num_df.describe().to_dict()
    except Exception:
        metadata["stats"] = {}
    return metadata
