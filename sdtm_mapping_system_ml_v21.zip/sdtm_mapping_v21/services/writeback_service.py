"""
services/writeback_service.py
==============================
Service wrapper around src/spec_writeback.py.
No Streamlit imports. Fully testable.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Optional, Tuple

_APP_DIR = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(_APP_DIR / "src"))
sys.path.insert(0, str(_APP_DIR))

from exceptions.domain_exceptions import WritebackError

log = logging.getLogger("sdtm_app.services.writeback")


def write_back_to_spec(
    spec_path: Path,
    results_path: Path,
    out_path: Path,
    highlight_review: bool = True,
    populate_origin: bool = True,
    populate_action: bool = True,
    dry_run: bool = False,
    config_path: Optional[Path] = None,
) -> Tuple[Path, dict]:
    """
    Write mapping results into the sponsor spec Excel workbook.

    Args:
        spec_path:        Original spec Excel
        results_path:     mapping_results.xlsx from mapper
        out_path:         Output path for updated spec
        highlight_review: Amber-highlight review-tier rows
        populate_origin:  Write Origin column
        populate_action:  Write Mapping Action (only if currently blank)
        dry_run:          Preview only — no file written
        config_path:      Optional config.yaml override

    Returns:
        (output_path, validation_report_dict)

    Raises:
        WritebackError on failure
    """
    from spec_writeback import write_back

    cfg = str(config_path) if config_path else str(_APP_DIR / "src" / "config.yaml")

    log.info(
        "Write-back: spec=%s results=%s dry_run=%s",
        spec_path.name, results_path.name, dry_run,
    )

    try:
        result = write_back(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
            highlight_review=highlight_review,
            populate_origin=populate_origin,
            populate_action=populate_action,
            dry_run=dry_run,
            config_path=cfg,
        )
    except Exception as exc:
        log.error("Write-back failed: %s", exc, exc_info=True)
        raise WritebackError(
            f"Write-back failed: {exc}",
            detail=str(exc),
        ) from exc

    if dry_run or result is None:
        log.info("Write-back dry-run complete (no file written)")
        return out_path, {}

    written_path, validation_report = result
    log.info("Write-back complete: %s", written_path)
    return Path(written_path), validation_report or {}
