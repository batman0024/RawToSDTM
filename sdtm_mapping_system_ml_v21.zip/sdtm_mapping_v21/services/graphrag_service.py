"""
services/graphrag_service.py
=============================
Service layer for GraphRAG operations.
Config-flag controlled (ENABLE_GRAPHRAG).
No Streamlit imports. Fully testable.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

log = logging.getLogger("sdtm_app.services.graphrag")


def build_graph(
    master_path: Path,
    raw_df=None,
    mapping_results: Optional[dict] = None,
):
    """
    Build or rebuild the SDTM Knowledge Graph.

    Args:
        master_path:     Path to master_mapping.xlsx
        raw_df:          Optional raw variable catalog DataFrame
        mapping_results: Optional run_mapping() results dict

    Returns:
        (SDTMKnowledgeGraph, SDTMGraphRAG, List[chunks])

    Raises:
        ImportError if networkx is not installed
        ValueError if master_path cannot be loaded
    """
    from graphrag.graph.builder import build_sdtm_knowledge_graph
    from graphrag.rag import SDTMGraphRAG

    log.info("Building SDTM Knowledge Graph from %s", master_path.name)

    try:
        kg, chunks = build_sdtm_knowledge_graph(
            master_path=master_path,
            raw_df=raw_df,
            mapping_results=mapping_results,
        )
    except Exception as exc:
        log.error("Graph build failed: %s", exc, exc_info=True)
        raise

    rag = SDTMGraphRAG(kg, chunks)
    stats = kg.stats()
    log.info(
        "Graph ready: %d nodes, %d edges, %d chunks",
        stats["total_nodes"], stats["total_edges"], len(chunks),
    )
    return kg, rag, chunks


def query_graph(rag, question: str) -> Dict[str, Any]:
    """Answer a natural-language mapping question using the GraphRAG engine."""
    log.info("GraphRAG query: %s", question[:80])
    return rag.answer(question)


def export_graph_html(kg, out_path: Path,
                      title: str = "SDTM Mapping Knowledge Graph") -> Path:
    """Export interactive D3.js HTML visualisation of the knowledge graph."""
    from graphrag.viz.d3_export import export_graph_html as _export
    result = _export(kg, out_path, title)
    log.info("Graph HTML exported: %s", result)
    return result


def get_domain_summary(rag, domain: str) -> Dict[str, Any]:
    """Get mapping coverage summary for a SDTM domain."""
    return rag.domain_summary(domain)


def get_raw_var_lineage(rag, dataset: str, variable: str) -> Dict[str, Any]:
    """Get full mapping lineage for a raw variable."""
    return rag.query_raw_var(dataset, variable)


def get_unmapped_variables(rag) -> List[Dict]:
    """Return SDTM variables with no raw source in the graph."""
    return rag.find_unmapped()
