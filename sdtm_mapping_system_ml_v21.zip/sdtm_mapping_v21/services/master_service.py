"""
services/master_service.py
==========================
Service wrapper around src/master_builder.py.
No Streamlit imports. Fully testable.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional

_APP_DIR = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(_APP_DIR / "src"))
sys.path.insert(0, str(_APP_DIR))

from exceptions.domain_exceptions import MasterBuildError

log = logging.getLogger("sdtm_app.services.master")


def build_master(
    spec_paths: List[Path],
    sponsor_paths: Optional[List[Path]] = None,
    existing_master: Optional[Path] = None,
    out_path: Optional[Path] = None,
    config_path: Optional[Path] = None,
    study_dates: Optional[Dict[str, str]] = None,
) -> Path:
    """
    Build or incrementally update master_mapping.xlsx.

    Args:
        spec_paths:      List of completed study spec Excel paths
        sponsor_paths:   Optional sponsor standard spec paths
        existing_master: Optional path to existing master (incremental mode)
        out_path:        Output path for master_mapping.xlsx
        config_path:     Optional config.yaml override
        study_dates:     Optional {filename: YYYY-MM-DD} study date overrides

    Returns:
        Path to the written master_mapping.xlsx

    Raises:
        MasterBuildError on failure
    """
    from master_builder import build_master_mapping

    out_path = out_path or Path("master_mapping.xlsx")
    sponsor_paths = sponsor_paths or []
    study_dates = study_dates or {}
    cfg = config_path or (_APP_DIR / "src" / "config.yaml")

    log.info(
        "Building master: %d specs, %d sponsor files, incremental=%s",
        len(spec_paths), len(sponsor_paths), existing_master is not None,
    )

    try:
        build_master_mapping(
            spec_paths=[str(p) for p in spec_paths],
            sponsor_paths=[str(p) for p in sponsor_paths],
            existing_master=existing_master,
            out_path=out_path,
            config_path=cfg,
            study_dates=study_dates,
        )
    except Exception as exc:
        log.error("Master build failed: %s", exc, exc_info=True)
        raise MasterBuildError(
            f"Failed to build master mapping: {exc}",
            detail=str(exc),
        ) from exc

    log.info("Master mapping written to %s", out_path)
    return out_path
