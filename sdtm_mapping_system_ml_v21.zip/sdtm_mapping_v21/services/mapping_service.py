"""
services/mapping_service.py
============================
Service wrapper around src/mapper.py.
No Streamlit imports. Returns typed Pydantic models.
Fully testable by mocking src.mapper.run.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Optional

# Ensure src/ is on path
_APP_DIR = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(_APP_DIR / "src"))
sys.path.insert(0, str(_APP_DIR))

import pandas as pd

from exceptions.domain_exceptions import MappingError
from models.mapping_models import CoverageRow, MappingResultSummary

log = logging.getLogger("sdtm_app.services.mapping")


def run_mapping(
    master_path: Path,
    raw_path: Path,
    spec_path: Optional[Path] = None,
    out_path: Optional[Path] = None,
    config_path: Optional[Path] = None,
) -> MappingResultSummary:
    """
    Execute the raw-to-SDTM mapping pipeline.

    Args:
        master_path:  Path to master_mapping.xlsx
        raw_path:     Path to raw variable catalog
        spec_path:    Optional path to new study SDTM spec
        out_path:     Output path for mapping_results.xlsx
        config_path:  Optional path to config.yaml override

    Returns:
        MappingResultSummary with counts and coverage

    Raises:
        MappingError on any pipeline failure
    """
    from mapper import run as _mapper_run

    out_path = out_path or Path("mapping_results.xlsx")
    cfg = str(config_path) if config_path else None

    log.info(
        "Starting mapping: master=%s raw=%s spec=%s out=%s",
        master_path.name, raw_path.name,
        spec_path.name if spec_path else "None",
        out_path,
    )

    try:
        results = _mapper_run(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=spec_path,
            out_path=out_path,
            config_path=Path(cfg) if cfg else None,
        )
    except Exception as exc:
        log.error("Mapping failed: %s", exc, exc_info=True)
        raise MappingError(
            f"Mapping pipeline failed: {exc}",
            detail=str(exc),
        ) from exc

    # Build summary
    direct_df = results.get("direct", pd.DataFrame())
    review_df = results.get("review", pd.DataFrame())
    unres_df  = results.get("unresolved", pd.DataFrame())
    unmapped  = results.get("unmapped_raw", pd.DataFrame())
    cross_df  = results.get("cross_dataset_match", pd.DataFrame())
    cov_df    = results.get("coverage", pd.DataFrame())

    coverage_rows: list[CoverageRow] = []
    for _, row in cov_df.iterrows():
        coverage_rows.append(CoverageRow(
            domain=str(row.get("DOMAIN", "")),
            total=int(row.get("TOTAL", 0)),
            direct=int(row.get("DIRECT", 0)),
            review=int(row.get("REVIEW", 0)),
            unresolved=int(row.get("UNRESOLVED", 0)),
            auto_pct=float(row.get("AUTO_PCT", 0.0)),
            total_coverage_pct=float(row.get("TOTAL_COVERAGE_PCT", 0.0)),
        ))

    summary = MappingResultSummary(
        direct_count=len(direct_df),
        review_count=len(review_df),
        unresolved_count=len(unres_df),
        unmapped_raw_count=len(unmapped),
        cross_dataset_count=len(cross_df),
        coverage=coverage_rows,
        result_path=str(out_path),
    )

    log.info(
        "Mapping complete: direct=%d review=%d unresolved=%d",
        summary.direct_count, summary.review_count, summary.unresolved_count,
    )
    return summary
