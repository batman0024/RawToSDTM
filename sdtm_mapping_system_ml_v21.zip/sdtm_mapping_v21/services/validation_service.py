"""
services/validation_service.py
================================
Service wrapper around src/excel_validator.py.
Provides pre- and post-writeback validation.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any, Dict

_APP_DIR = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(_APP_DIR / "src"))
sys.path.insert(0, str(_APP_DIR))

from exceptions.domain_exceptions import ValidationError

log = logging.getLogger("sdtm_app.services.validation")


def validate_spec(
    spec_path: Path,
    updated_spec_path: Path,
) -> Dict[str, Any]:
    """
    Run pre/post-writeback validation on a spec file pair.

    Returns:
        Validation report dict with keys:
          summary: {overall_status, risk_score, total_checks, failed}
          issues:  list of {severity, issue, root_cause}

    Raises:
        ValidationError if the validator itself errors
    """
    from excel_validator import ExcelValidator, render_validation_report

    log.info(
        "Validating spec: before=%s after=%s",
        spec_path.name, updated_spec_path.name,
    )

    try:
        validator = ExcelValidator(spec_path)
        report = validator.validate_after(updated_spec_path)
    except Exception as exc:
        log.error("Validation failed: %s", exc, exc_info=True)
        raise ValidationError(
            f"Spec validation failed: {exc}",
            detail=str(exc),
        ) from exc

    status = report.get("summary", {}).get("overall_status", "UNKNOWN")
    risk   = report.get("summary", {}).get("risk_score", 0.0)
    log.info("Validation result: status=%s risk=%.0f%%", status, risk * 100)
    return report
