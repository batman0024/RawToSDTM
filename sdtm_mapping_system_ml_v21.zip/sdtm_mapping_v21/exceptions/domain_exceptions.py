"""
exceptions/domain_exceptions.py
================================
Typed custom exceptions for the SDTM mapping pipeline.
"""
from __future__ import annotations


class SDTMBaseError(Exception):
    """Root exception for all SDTM mapping system errors."""
    def __init__(self, message: str, detail: str = "") -> None:
        self.message = message
        self.detail = detail
        super().__init__(message)


class MappingError(SDTMBaseError):
    """Raised when the raw to SDTM mapping phase fails."""


class MasterBuildError(SDTMBaseError):
    """Raised when building or updating the master mapping fails."""


class WritebackError(SDTMBaseError):
    """Raised when writing results back into the sponsor spec fails."""


class ValidationError(SDTMBaseError):
    """Raised when pre/post-writeback Excel validation fails critically."""


class DataLoadError(SDTMBaseError):
    """Raised when a file cannot be loaded or parsed."""


class AuthError(SDTMBaseError):
    """Base class for authentication errors."""


class TokenExpiredError(AuthError):
    """Magic-link token has passed its TTL."""


class TokenAlreadyUsedError(AuthError):
    """Magic-link token has already been consumed."""


class TokenNotFoundError(AuthError):
    """Magic-link token does not exist in the store."""


class RateLimitError(AuthError):
    """Too many magic-link requests from this email in the time window."""


class DomainNotAllowedError(AuthError):
    """Email domain is not in the allowed-domains whitelist."""


class InvalidJWTError(AuthError):
    """JWT token is malformed, expired, or has an invalid signature."""
