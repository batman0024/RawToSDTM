"""
tests/conftest.py
=================
Shared pytest fixtures for service and API tests.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Ensure all project paths are importable during tests
ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

# ── Auth fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture()
def mock_token_store():
    """Fresh in-memory token store for each test."""
    from auth.session_store import InMemoryTokenStore
    return InMemoryTokenStore()


@pytest.fixture()
def mock_email_sender():
    """Email sender that captures calls instead of sending."""
    from auth.email_sender import AbstractEmailSender

    class CapturingEmailSender(AbstractEmailSender):
        def __init__(self):
            self.sent: list[tuple[str, str]] = []

        def send_magic_link(self, to_email: str, magic_link: str) -> None:
            self.sent.append((to_email, magic_link))

    return CapturingEmailSender()


@pytest.fixture()
def magic_link_service(mock_token_store):
    """MagicLinkService with test settings injected."""
    from auth.magic_link import MagicLinkService, RateLimiter
    return MagicLinkService(
        store=mock_token_store,
        jwt_secret="test-secret-key-32-bytes-long!!!!",
        jwt_expiry_hours=8,
        ttl_minutes=15,
        allowed_domains=[],
        base_url="http://testserver",
        rate_limiter=RateLimiter(max_requests=10, window_minutes=10),
    )


@pytest.fixture()
def api_client(mock_token_store, mock_email_sender):
    """FastAPI TestClient with mocked auth dependencies."""
    import os
    os.environ.setdefault("JWT_SECRET", "test-secret-key-32-bytes-long!!!!")

    from fastapi.testclient import TestClient
    from api.main import create_app
    from api import dependencies

    # Patch dependency singletons for tests
    from auth.magic_link import MagicLinkService, RateLimiter
    test_svc = MagicLinkService(
        store=mock_token_store,
        jwt_secret="test-secret-key-32-bytes-long!!!!",
        jwt_expiry_hours=8,
        ttl_minutes=15,
        allowed_domains=[],
        base_url="http://testserver",
        rate_limiter=RateLimiter(max_requests=10, window_minutes=10),
    )
    dependencies._magic_link_service = test_svc

    app = create_app()
    app.dependency_overrides[dependencies.get_email_sender] = lambda: mock_email_sender

    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture()
def valid_jwt(magic_link_service) -> str:
    """Return a valid JWT for test user@example.com."""
    return magic_link_service._issue_jwt("user@example.com")
