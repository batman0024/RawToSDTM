"""
tests/test_services.py
======================
Unit tests for the service wrappers.
All src/ functions are mocked — no file I/O needed.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))


# ── mapping_service ───────────────────────────────────────────────────────────

class TestMappingService:
    def _make_mock_results(self):
        direct_df  = pd.DataFrame([{"DOMAIN":"AE","SDTM_VARIABLE":"AETERM","COMPOSITE_SCORE":0.9}])
        review_df  = pd.DataFrame([{"DOMAIN":"AE","SDTM_VARIABLE":"AESEV","COMPOSITE_SCORE":0.65}])
        unres_df   = pd.DataFrame([{"DOMAIN":"AE","SDTM_VARIABLE":"AEOUT","COMPOSITE_SCORE":0.2}])
        unmapped   = pd.DataFrame([{"RAW_DATASET":"AE","RAW_VARIABLE":"AELOCDET"}])
        cov_df     = pd.DataFrame([{
            "DOMAIN":"AE","TOTAL":3,"DIRECT":1,"REVIEW":1,"UNRESOLVED":1,
            "AUTO_PCT":33.3,"TOTAL_COVERAGE_PCT":66.7
        }])
        return {
            "direct": direct_df, "review": review_df, "unresolved": unres_df,
            "unmapped_raw": unmapped, "cross_dataset_match": pd.DataFrame(),
            "coverage": cov_df,
        }

    def test_run_mapping_success(self, tmp_path):
        with patch("services.mapping_service._mapper_run") as mock_run:
            mock_run.return_value = self._make_mock_results()
            from services.mapping_service import run_mapping
            summary = run_mapping(
                master_path=tmp_path / "master.xlsx",
                raw_path=tmp_path / "raw.xlsx",
                out_path=tmp_path / "results.xlsx",
            )
        assert summary.direct_count == 1
        assert summary.review_count == 1
        assert summary.unresolved_count == 1
        assert summary.unmapped_raw_count == 1
        assert len(summary.coverage) == 1
        assert summary.coverage[0].domain == "AE"

    def test_run_mapping_raises_mapping_error(self, tmp_path):
        with patch("services.mapping_service._mapper_run", side_effect=RuntimeError("disk full")):
            from services.mapping_service import run_mapping
            from exceptions.domain_exceptions import MappingError
            with pytest.raises(MappingError) as exc_info:
                run_mapping(
                    master_path=tmp_path / "master.xlsx",
                    raw_path=tmp_path / "raw.xlsx",
                )
            assert "disk full" in exc_info.value.message


# ── master_service ────────────────────────────────────────────────────────────

class TestMasterService:
    def test_build_master_success(self, tmp_path):
        out = tmp_path / "master.xlsx"
        with patch("services.master_service.build_master_mapping") as mock_build:
            mock_build.return_value = None
            from services.master_service import build_master
            result = build_master(
                spec_paths=[tmp_path / "study_a.xlsx"],
                out_path=out,
            )
        assert result == out
        mock_build.assert_called_once()

    def test_build_master_raises_on_failure(self, tmp_path):
        with patch("services.master_service.build_master_mapping", side_effect=IOError("read error")):
            from services.master_service import build_master
            from exceptions.domain_exceptions import MasterBuildError
            with pytest.raises(MasterBuildError):
                build_master(spec_paths=[tmp_path / "study.xlsx"])


# ── writeback_service ─────────────────────────────────────────────────────────

class TestWritebackService:
    def test_writeback_success(self, tmp_path):
        out = tmp_path / "spec_mapped.xlsx"
        with patch("services.writeback_service.write_back") as mock_wb:
            mock_wb.return_value = (str(out), {"summary": {"overall_status": "PASS"}})
            from services.writeback_service import write_back_to_spec
            written, report = write_back_to_spec(
                spec_path=tmp_path / "spec.xlsx",
                results_path=tmp_path / "results.xlsx",
                out_path=out,
            )
        assert written == out
        assert report["summary"]["overall_status"] == "PASS"

    def test_writeback_raises_on_failure(self, tmp_path):
        with patch("services.writeback_service.write_back", side_effect=ValueError("corrupt")):
            from services.writeback_service import write_back_to_spec
            from exceptions.domain_exceptions import WritebackError
            with pytest.raises(WritebackError):
                write_back_to_spec(
                    spec_path=tmp_path / "spec.xlsx",
                    results_path=tmp_path / "results.xlsx",
                    out_path=tmp_path / "out.xlsx",
                )

    def test_dry_run_returns_no_file(self, tmp_path):
        with patch("services.writeback_service.write_back") as mock_wb:
            mock_wb.return_value = None  # dry_run returns None
            from services.writeback_service import write_back_to_spec
            out = tmp_path / "out.xlsx"
            written, report = write_back_to_spec(
                spec_path=tmp_path / "spec.xlsx",
                results_path=tmp_path / "results.xlsx",
                out_path=out,
                dry_run=True,
            )
        assert report == {}


# ── data loaders ─────────────────────────────────────────────────────────────

class TestDataLoaders:
    def test_load_csv(self, tmp_path):
        csv = tmp_path / "test.csv"
        csv.write_text("VAR,LABEL\nAETERM,Adverse Event Term\nAESEV,Severity\n")
        from data.loaders import load_file
        df = load_file(csv)
        assert len(df) == 2
        assert "VAR" in df.columns

    def test_load_unsupported_raises(self, tmp_path):
        bad = tmp_path / "test.xyz"
        bad.write_text("data")
        from data.loaders import load_file
        from exceptions.domain_exceptions import DataLoadError
        with pytest.raises(DataLoadError):
            load_file(bad)

    def test_load_missing_raises(self, tmp_path):
        from data.loaders import load_file
        from exceptions.domain_exceptions import DataLoadError
        with pytest.raises(DataLoadError):
            load_file(tmp_path / "nonexistent.csv")

    def test_get_metadata(self, tmp_path):
        csv = tmp_path / "m.csv"
        csv.write_text("A,B\n1,x\n2,y\n")
        from data.loaders import load_file, get_metadata
        df = load_file(csv)
        meta = get_metadata(df)
        assert meta["row_count"] == 2
        assert meta["col_count"] == 2
        assert "A" in meta["columns"]
        assert meta["null_counts"]["A"] == 0
