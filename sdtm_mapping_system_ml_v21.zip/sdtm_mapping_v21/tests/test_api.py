"""
tests/test_api.py
=================
FastAPI endpoint tests: full auth flow + mapping endpoints.
Uses TestClient with mocked dependencies.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))


# ── Health ────────────────────────────────────────────────────────────────────

class TestHealth:
    def test_health_ok(self, api_client):
        resp = api_client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert "environment" in data

    def test_health_unauthenticated(self, api_client):
        """Health endpoint must not require auth."""
        resp = api_client.get("/health")
        assert resp.status_code == 200


# ── Auth flow ─────────────────────────────────────────────────────────────────

class TestAuthFlow:
    def test_request_link_returns_202(self, api_client, mock_email_sender):
        resp = api_client.post(
            "/auth/request-link",
            json={"email": "analyst@example.com"},
        )
        assert resp.status_code == 202
        assert "message" in resp.json()

    def test_request_link_always_same_message(self, api_client):
        """Prevent email enumeration — same response regardless."""
        r1 = api_client.post("/auth/request-link", json={"email": "real@example.com"})
        r2 = api_client.post("/auth/request-link", json={"email": "fake@nope.invalid.test"})
        assert r1.json()["message"] == r2.json()["message"]

    def test_request_link_invalid_email(self, api_client):
        resp = api_client.post("/auth/request-link", json={"email": "not-an-email"})
        assert resp.status_code == 422

    def test_full_auth_flow(self, api_client, magic_link_service, mock_email_sender):
        """Request link -> extract token -> verify -> get JWT -> use protected endpoint."""
        # Step 1: request link
        resp = api_client.post("/auth/request-link", json={"email": "user@example.com"})
        assert resp.status_code == 202

        # Step 2: extract token from sender's captured link
        assert len(mock_email_sender.sent) == 1
        _, magic_link = mock_email_sender.sent[0]
        token = magic_link.split("token=")[-1]

        # Step 3: verify token
        resp = api_client.get(f"/auth/verify?token={token}")
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
        assert data["email"] == "user@example.com"

    def test_verify_invalid_token(self, api_client):
        resp = api_client.get("/auth/verify?token=completely-invalid-token")
        assert resp.status_code == 401

    def test_verify_token_single_use(self, api_client, mock_email_sender):
        """Token should be rejected on second use."""
        api_client.post("/auth/request-link", json={"email": "once@example.com"})
        _, magic_link = mock_email_sender.sent[-1]
        token = magic_link.split("token=")[-1]

        # First use: success
        r1 = api_client.get(f"/auth/verify?token={token}")
        assert r1.status_code == 200

        # Second use: rejected
        r2 = api_client.get(f"/auth/verify?token={token}")
        assert r2.status_code == 401

    def test_rate_limiting(self, magic_link_service, mock_token_store):
        """More than RATE_LIMIT requests per window should raise RateLimitError."""
        from auth.magic_link import MagicLinkService, RateLimiter
        from exceptions.domain_exceptions import RateLimitError
        strict_svc = MagicLinkService(
            store=mock_token_store,
            jwt_secret="test-secret-key-32-bytes-long!!!!",
            jwt_expiry_hours=8,
            ttl_minutes=15,
            allowed_domains=[],
            base_url="http://testserver",
            rate_limiter=RateLimiter(max_requests=2, window_minutes=10),
        )
        strict_svc.request_link("ratelimit@example.com")
        strict_svc.request_link("ratelimit@example.com")
        with pytest.raises(RateLimitError):
            strict_svc.request_link("ratelimit@example.com")

    def test_domain_whitelist_blocks(self, mock_token_store):
        from auth.magic_link import MagicLinkService, RateLimiter
        from exceptions.domain_exceptions import DomainNotAllowedError
        svc = MagicLinkService(
            store=mock_token_store,
            jwt_secret="test-secret-key-32-bytes-long!!!!",
            jwt_expiry_hours=8,
            ttl_minutes=15,
            allowed_domains=["allowed.com"],
            base_url="http://testserver",
            rate_limiter=RateLimiter(max_requests=10, window_minutes=10),
        )
        with pytest.raises(DomainNotAllowedError):
            svc.request_link("user@blocked.com")
        # Allowed domain should pass
        link = svc.request_link("user@allowed.com")
        assert "token=" in link


# ── Protected endpoints (require valid JWT) ───────────────────────────────────

class TestProtectedEndpoints:
    def test_no_token_rejected(self, api_client):
        resp = api_client.get("/api/v1/mapping/status/some-job-id")
        assert resp.status_code == 403  # HTTPBearer returns 403 when no creds

    def test_invalid_token_rejected(self, api_client):
        resp = api_client.get(
            "/api/v1/mapping/status/some-job-id",
            headers={"Authorization": "Bearer invalid.jwt.token"},
        )
        assert resp.status_code == 401

    def test_status_not_found(self, api_client, valid_jwt):
        resp = api_client.get(
            "/api/v1/mapping/status/nonexistent-job",
            headers={"Authorization": f"Bearer {valid_jwt}"},
        )
        assert resp.status_code == 404

    def test_results_not_found(self, api_client, valid_jwt):
        resp = api_client.get(
            "/api/v1/mapping/results/nonexistent-job",
            headers={"Authorization": f"Bearer {valid_jwt}"},
        )
        assert resp.status_code == 404
