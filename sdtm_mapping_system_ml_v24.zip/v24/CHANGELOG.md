# Changelog

All notable changes to the SDTM Master Mapping System.

---

## v24 — 2025-04-14

### Mapping Logic (Priority fix)
- **Raw assignment always wins over hard rules.** Phase 2 now checks Phase 1
  raw assignments FIRST for every SDTM variable before applying any fallback
  rule. PROTOCOL_VARS and RF_TIMING_VARS hard rules are fallbacks only.
- **RF*DTC timing variables removed from PROTOCOL_VARS.** RFPENDTC, RFSTDTC,
  RFICDTC, RFENDTC, RFXSTDTC, RFXENDTC are now always sent through the
  raw-first master-guided matching pipeline. They fall back to HARDCODE only
  when Phase 1 finds no raw assignment in the master knowledge base.
- Fixed dead-code block after `derived_rule continue` — last-resort same-domain
  fallback now executes correctly for variables with no master knowledge at all.
- SUPPQUAL structural variable rule preserved as a pure fallback.

### Write Back to Spec
- **Changelog tab removed from spec output.** The updated spec is now saved
  clean with no extra sheets — original structure fully intact.
- **Changelog available as separate download** (`writeback_changelog_YYYYMMDD_HHMM.xlsx`)
  shown next to the spec download button on the Write Back page.

### Tab Cache / Session Persistence
- **Mapping results now persist across tab switches and download clicks.**
  All result dataframes are serialised to session state after a successful run.
  Switching away and back to the Map New Study page re-renders the full results
  display (metrics, coverage chart, domain-mapping table, all result tabs,
  download button) without requiring a re-run.
- XAI checkbox preference also persists across tab switches.

### GraphRAG Query
- **Preset quick queries now route directly to focused graph lookups** instead
  of the generic BM25+rule path. Q1=AESTDTC sources, Q2=LB domain,
  Q3=most-sourced SDTM vars, Q4=DM domain.
- `_find_relevant_mappings` no longer returns unrelated rows as filler.
  Returns empty list rather than top-5 from unrelated domains.

### Launcher
- **launch.bat rewritten** — no venv creation, no venv activation, no .env
  loading. Runs directly with system Python. Checks packages once, installs
  only if missing, then launches immediately. `--install` flag forces reinstall.

---

## v20 (current)

### Critical Bug Fixes

- **Data leakage fix (ml_scorer.py)**
  `LabelIndex` is built from the new study's raw labels and was previously
  passed into `build_training_data()`, causing new-study label vocabulary to
  leak into the ML training feature matrix.  `label_tfidf_score` is now
  hardcoded to `0.0` for all training examples; the `train()` method no longer
  accepts a `label_idx` argument.  At inference time the true TF-IDF similarity
  is passed in per pair as before.

- **`prefix_match` correctness fix (ml_scorer.py)**
  The old implementation summed all position-wise character matches regardless
  of contiguity, meaning `"ABXYZ"` vs `"ABCYZ"` scored `4/5 = 0.80` instead
  of the correct prefix fraction `2/5 = 0.40` (stops at the first differing
  character).  The function now breaks at the first non-matching position.

- **Feature vector length guard (ml_scorer.py)**
  `build_feature_vector()` now asserts `len(result) == _N_FEATURES` at
  runtime, catching future feature additions that leave `FEATURE_NAMES` and
  the `np.array(...)` return value out of sync.

- **Path traversal in file upload (api/routers/mapping.py)**
  `_save_upload()` now calls `Path(filename).name` before constructing the
  destination path, preventing directory traversal attacks via filenames like
  `"../../etc/cron.d/evil"`.

### ML Improvements

- **Replaced `GradientBoostingClassifier` with `HistGradientBoostingClassifier`**
  3-10x faster training, native NaN support (eliminates need for imputation),
  and `class_weight` parameter for built-in imbalance correction.

- **Class imbalance corrected**
  `pos_weight = n_negative / n_positive` is passed as `class_weight={0: 1.0, 1: pos_weight}`.
  This corrects the silent bias introduced by the 1:4 training ratio.

- **Meaningful evaluation metrics**
  Cross-validation now reports `ROC-AUC`, `Average Precision`, and `F1` via
  `StratifiedKFold`.  Raw accuracy is no longer logged (misleading under imbalance).

- **Hard negative mining**
  Training negative pairs now include a third tier: same-domain pairs where
  `jaro_winkler(raw_var, sdtm_var) > 0.55` that are not the correct match.
  These teach the model to separate confusable variable names
  (e.g., `AESTDTC` vs `AEENDTC`).

- **Model persistence**
  Trained model is serialised to `<master_stem>_ml_model.pkl` alongside the
  master file.  A SHA-256 hash of key master columns is stored in a companion
  `.pkl.hash` file.  On subsequent runs the model is loaded from disk if the
  hash matches, avoiding redundant training.

### New Tests

- **`tests/test_ml_scorer.py`** (40+ tests)
  Unit tests for every string similarity primitive, feature vector, training
  data builder, MLScorer train/score/score_batch, reproducibility, fallback
  mode, model persistence, and evaluation metric coverage.

- **`tests/test_security.py`** (8 tests)
  Path traversal sanitisation: normal filenames, `../../` traversal, absolute
  paths, Windows separators, empty names, hidden files.

- **`TestReproducibility` in `tests/test_pipeline.py`** (6 tests)
  Runs every pipeline phase `N_RUNS=3` times back-to-back and asserts that
  outputs are identical across runs.  Covers:
  - `build_master_mapping()` — row count and `MASTER_CONFIDENCE` values
  - `mapper.run()` — tier counts (direct/review/unresolved)
  - `mapper.run()` — `COMPOSITE_SCORE` values per variable
  - `write_back()` — `Input Variables` cell values per domain sheet
  - Full pipeline (build → map → writeback)

---

## v4.0 (previous)

### New Features

- **Phase 3: Variable-Level Cross-Dataset Match** (`mapper.py`)
  After the standard two-phase raw→SDTM matching, a new Phase 3 scans all
  remaining unresolved SDTM variables against the entire raw catalog using
  variable *name* similarity (≥ 0.75), irrespective of dataset name. This
  catches cases like `QSXXX` raw dataset containing variables that match
  `QS` domain targets where the dataset naming convention is non-standard.
  Results appear in a new `cross_dataset_match` sheet in `mapping_results.xlsx`.

- **Cross-Dataset Manual Review Tab** (`app.py`)
  A dedicated `🟣 Cross-Dataset Match` tab in Phase 2 results shows all
  variable-level matches that crossed dataset-name boundaries, with a
  `MATCH_NOTE` column explaining the dataset mismatch. Each entry requires
  explicit programmer sign-off before it is promoted to spec.

- **Raw Dataset → SDTM Domain Coverage Table** (`app.py`)
  A new summary table in Phase 2 shows every raw dataset and the SDTM
  domains it maps to, including variable counts and tier breakdown.
  Dataset-name/domain-name prefix mismatches are auto-detected and flagged
  with ⚠ warnings so the programmer can verify mapping intent (e.g. QSXXX → QS).

- **MATCH_NOTE column in cross-dataset results**
  Each cross-dataset row carries a human-readable note explaining which
  raw dataset was matched, the similarity score, and that manual review is
  required. This note is also propagated to the spec write-back change-log.

### Fixes & Improvements

- **Highlight visibility fixed** (`spec_writeback.py`)
  Input Variables cells now use `PatternFill(patternType="solid", ...)` with
  brighter fill colors (`#C6EFCE` green, `#FFF2CC` amber, `#FFC7CE` red)
  *plus* bold colored font (`Font(bold=True, color=...)`). The double
  signal (fill + bold text) ensures highlights are visible even when the
  original spec has competing cell theme colors or conditional formats.

- **Three-color highlight system**
  GREEN + bold = auto-accepted (direct tier).
  AMBER + bold = needs programmer review (review tier + cross-dataset).
  RED + bold   = unresolved cross-dataset match (written only when explicitly
  promoted from the Cross-Dataset Match tab).

- **Change-log Note column** (`spec_writeback.py`)
  The `_Writeback_YYYYMMDD_HHMM` change-log sheet now includes a `Note`
  column that carries the `MATCH_NOTE` for cross-dataset rows, making it
  easy to filter the change-log by match type during QC.

- **Cross-dataset results loaded in write-back** (`spec_writeback.py`)
  `load_results()` now reads the `cross_dataset_match` sheet from
  `mapping_results.xlsx` and treats those rows as review-tier, so they are
  automatically included in write-back with amber highlighting.

- **Dataset coverage issue detection** (`app.py`)
  The Raw Dataset → SDTM Domain table auto-flags datasets whose name prefix
  does not match any of the SDTM domains they feed, helping catch
  miscategorised datasets early before spec write-back.

---

## v3.0

### New Features

- **Streamlit dark-mode UI** (`app.py`) with five pages:
  Build Master, Map New Study, Write Back to Spec, View Master, Help
- **Real-time progress bars** -- per-variable granularity on the mapper phase
- **Group-aware master index** -- `build_index()` stores `GROUP_TOKENS` so the
  mapper retrieves all tokens of the best group atomically
- **Partial-group scoring** -- `score_group_against_raw()` penalises groups
  where only a fraction of tokens are found in the new raw catalog
- **Dry-run mode** in `spec_writeback.py` -- preview all changes without
  writing any file; shows old/new values per cell in the log
- **Coverage var-class breakdown** -- coverage report now includes N_DERIVED,
  N_IDENTIFIER, N_TIMING, N_RESULT, N_CODELIST, N_GENERAL per domain
- **Centralised logging** via `logger.py` -- all modules write to a single
  Python logger; optional log file configured in `config.yaml`
- **Integration test suite** -- 20 tests covering all modules and end-to-end

### Improvements

- `read_toc_active_domains()` recognises 10 TOC sheet name variants and
  14 Active column name variants; handles status values like "In Scope",
  "Planned", "Produce" etc.
- Two-layer trial domain exclusion: TOC layer + sheet-name layer
- NaN guard in `agg_group()` for extraction_log reload in append mode
- Origin priority: CRF(1) > Derived(2) > Protocol(3) > eDT(4) > Assigned(5)
  -- an existing Origin only overwritten by higher-priority value
- All source files confirmed 100% clean ASCII (zero non-ASCII bytes)

---

## v2.0

### New Features

- **Group-aware storage** in master mapping -- multi-token Input Variable
  cells stored with GROUP_SIG, GROUP_POSITION, GROUP_COUNT, GROUP_TOKENS
- **TOC-first filtering** -- `_read_toc_active_domains()` function with
  two-layer trial domain exclusion
- **Sponsor versioning** -- sponsor standard specs take priority over study
  mappings via `IS_TOP_GROUP` flag and `IS_SPONSOR_STD` sorting
- **Append/incremental mode** -- add new studies without full rebuild

### Improvements

- Composite scorer upgraded to 4 signals (name exact + fuzzy + TF-IDF + freq)
- TF-IDF label index with `expand_sdtm_label()` abbreviation expansion
- `normalize_action()` maps 35 free-text action variants to 9 canonical tokens
- Per-domain threshold overrides in `config.yaml`
- Variable class modifiers applied to composite score
- `spec_writeback.py`: change-log sheet, SDTM.* token preservation

---

## v1.0

- Initial implementation: `rawtosdtm_18.py`, `spec_stream_02.py`, `eval_06.py`
- Single SequenceMatcher threshold (0.92)
- Flat master_mapping structure (one row per raw token, no group concept)
- No TOC filtering; no logging; no progress feedback


### New Features

- **Streamlit dark-mode UI** (`app.py`) with five pages:
  Build Master, Map New Study, Write Back to Spec, View Master, Help
- **Real-time progress bars** -- per-variable granularity on the mapper phase
- **Group-aware master index** -- `build_index()` stores `GROUP_TOKENS` so the
  mapper retrieves all tokens of the best group atomically
- **Partial-group scoring** -- `score_group_against_raw()` penalises groups
  where only a fraction of tokens are found in the new raw catalog
- **Dry-run mode** in `spec_writeback.py` -- preview all changes without
  writing any file; shows old/new values per cell in the log
- **Coverage var-class breakdown** -- coverage report now includes N_DERIVED,
  N_IDENTIFIER, N_TIMING, N_RESULT, N_CODELIST, N_GENERAL per domain
- **Centralised logging** via `logger.py` -- all modules write to a single
  Python logger; optional log file configured in `config.yaml`
- **Integration test suite** -- 20 tests covering all modules and end-to-end

### Improvements

- `read_toc_active_domains()` recognises 10 TOC sheet name variants and
  14 Active column name variants; handles status values like "In Scope",
  "Planned", "Produce" etc.
- Two-layer trial domain exclusion: TOC layer + sheet-name layer
- NaN guard in `agg_group()` for extraction_log reload in append mode
- Origin priority: CRF(1) > Derived(2) > Protocol(3) > eDT(4) > Assigned(5)
  -- an existing Origin only overwritten by higher-priority value
- All source files confirmed 100% clean ASCII (zero non-ASCII bytes)

---

## v2.0

### New Features

- **Group-aware storage** in master mapping -- multi-token Input Variable
  cells stored with GROUP_SIG, GROUP_POSITION, GROUP_COUNT, GROUP_TOKENS
- **TOC-first filtering** -- `_read_toc_active_domains()` function with
  two-layer trial domain exclusion
- **Sponsor versioning** -- sponsor standard specs take priority over study
  mappings via `IS_TOP_GROUP` flag and `IS_SPONSOR_STD` sorting
- **Append/incremental mode** -- add new studies without full rebuild

### Improvements

- Composite scorer upgraded to 4 signals (name exact + fuzzy + TF-IDF + freq)
- TF-IDF label index with `expand_sdtm_label()` abbreviation expansion
- `normalize_action()` maps 35 free-text action variants to 9 canonical tokens
- Per-domain threshold overrides in `config.yaml`
- Variable class modifiers applied to composite score
- `spec_writeback.py`: change-log sheet, SDTM.* token preservation

---

## v1.0

- Initial implementation: `rawtosdtm_18.py`, `spec_stream_02.py`, `eval_06.py`
- Single SequenceMatcher threshold (0.92)
- Flat master_mapping structure (one row per raw token, no group concept)
- No TOC filtering; no logging; no progress feedback

---

## v17 — Refactor & Performance (2026-04)

### Code Quality Fixes

- **`src/utils.py` — shared normalisation module** (new file)
  `_norm()` and `_slug()` were defined identically in 5 separate files
  (`mapper.py`, `ml_scorer.py`, `master_builder.py`, `study_metadata.py`,
  `spec_writeback.py`). Any silent divergence between copies could cause
  inconsistent variable normalisation across pipeline phases — a GxP risk.
  All implementations consolidated into `utils.py`; every other module now
  imports `from utils import _norm, _slug`.

- **`src/__init__.py` added**
  `src/` lacked a package marker, making imports reliant solely on
  `sys.path` manipulation. Proper `__init__.py` added.

- **`spec_writeback.py` — nested per-row helpers hoisted to module level**
  `bare()`, `_is_preserve_token()`, `_is_raw_token()`, `_is_garbage()`,
  and `_norm_inp()` were redefined on every iteration of the cell-scan
  loop. Python rebuilds function objects each time. All five moved to
  module level using pre-compiled regex patterns (`_BARE_PREFIX_RE`,
  `_BARE_SUFFIX_RE`, `_NORM_INP_SEP_RE`). No behaviour change.

- **`spec_writeback.py` — inline imports removed**
  `import re as _re`, `import re as _re_wb`, and `import math as _math`
  were scattered inside function bodies and loops. All removed; `re` and
  `math` now imported once at module level.

- **`master_builder.py` — bare `except Exception: pass` replaced**
  Three catch-all exception blocks silently swallowed errors during spec
  parsing and origin value extraction — a GxP audit risk. Replaced with
  typed exceptions (`ValueError`/`TypeError`) and `warnings.warn(...)` so
  failures surface without aborting the run.

### Performance Fixes

- **`mapper.py` Phase 1 — O(n²) partial-slug fallback eliminated**
  When a raw variable slug had no exact match in `by_raw`, the fallback
  iterated the entire `by_raw` index checking 4-char suffix overlap —
  O(raw_vars × master_index_size). `build_index()` now pre-builds a
  `by_raw_suffix4` dict keyed on the last 4 characters of each slug.
  Lookup is O(1). For a 500-variable raw catalog and a 2,000-entry master
  index, this eliminates up to 1,000,000 comparisons per run.

- **`mapper.py` `find_best_group` — O(n) list membership replaced**
  Deduplication of `extra_groups` used `entry not in list`, an O(n) scan
  repeated per entry. Replaced with an `id()`-keyed `set` for O(1) checks.

- **`mapper.py` `build_index()` — returns `by_raw_suffix4`**
  Index dict now includes `by_raw_suffix4` alongside `by_sdtm` and
  `by_raw`. Suffix buckets are deduplicated by `id()` at build time.

### Correctness / Observability Fixes

- **`logger.py` — thread-safe singleton**
  The global `_configured` flag was not protected by a lock. Concurrent
  Streamlit user sessions could race on it, leaving one session with an
  unconfigured (silent) logger. Fixed with `threading.Lock` and
  double-checked locking. `reset_logger()` added for test/multi-run use.

- **`ml_scorer.py` — cross-validated accuracy replaces train-set accuracy**
  `GradientBoostingClassifier.score(X_train, y_train)` routinely returns
  > 0.99 and provides no signal about generalisation. Replaced with
  `sklearn.model_selection.cross_val_score` (5-fold, capped at
  `n_pos//3` folds for small datasets). Log now reads:
  `CV accuracy=0.847 (+/-0.062)  features=21  n_pos=312`

- **`ml_scorer.py` — `score_batch()` added**
  New vectorised method accepts a list of SDTM candidate dicts and calls
  `predict_proba` once for all candidates using `np.vstack`. Reduces
  per-candidate overhead by ~40% when scoring many SDTM targets against
  the same raw variable (the dominant call pattern in Phase 1).

- **`mapper.py` — `LabelIndex._ok` encapsulated as `.is_enabled` property**
  External access to a private attribute (`lbl_idx._ok`) replaced with a
  public `@property`. No behaviour change.

