"""
graphrag/rag.py
================
GraphRAG retrieval and answer engine for Raw → SDTM mapping queries.
Combines BM25 text search with multi-hop KG traversal.
No Streamlit imports.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from graphrag.extraction.search import SDTMIndexer
from graphrag.mapping.sdtm_rules import match_sdtm_rule, classify_sdtm_var


class SDTMGraphRAG:
    """
    GraphRAG engine for raw-to-SDTM mapping queries.

    Supports natural-language questions like:
      "What raw variables map to AESTDTC in domain AE?"
      "Show me all lab result variables across studies"
      "Which SDTM variables have no raw source?"
      "How is AESTDTC derived?"
    """

    def __init__(self, kg, chunks: List[Dict]) -> None:
        self.kg = kg
        self.chunks = chunks
        self.indexer = SDTMIndexer(chunks)

    def answer(self, question: str, topk_chunks: int = 8) -> Dict[str, Any]:
        """
        Answer a natural-language mapping question.

        Returns structured result with:
          - question
          - matched_rule (SDTM rule context)
          - graph_context (KG traversal results)
          - evidence (BM25 top-k chunks)
          - suggested_sdtm_vars
          - suggested_raw_vars
        """
        # BM25 retrieval
        hits = self.indexer.search(question, topk=topk_chunks)
        evidence = []
        candidate_sdtm = []
        candidate_raw   = []

        for h in hits:
            evidence.append({
                "chunk_id": h.get("id", ""),
                "header":   h.get("header", ""),
                "domain":   h.get("domain", ""),
                "sdtm_var": h.get("sdtm_var", ""),
                "score":    h.get("score", 0.0),
                "text":     h.get("text", "")[:200],
                "raw_vars": h.get("raw_vars", []),
            })
            if h.get("sdtm_var"):
                candidate_sdtm.append((h["domain"], h["sdtm_var"]))
            candidate_raw.extend(h.get("raw_vars", []))

        # Rule matching
        rule = match_sdtm_rule(question)

        # Graph context — try to find the most relevant SDTM var
        graph_ctx: Dict[str, Any] = {}
        if candidate_sdtm:
            dom, sv = candidate_sdtm[0]
            graph_ctx = self._get_sdtm_context(dom, sv)
        elif rule:
            dom = rule.get("sdtm_domain", "")
            vars_list = rule.get("sdtm_vars", [])
            if dom and vars_list:
                graph_ctx = self._get_sdtm_context(dom, vars_list[0])

        # High-confidence mappings related to question
        high_conf = self._find_relevant_mappings(question, candidate_sdtm)

        return {
            "question":          question,
            "matched_rule":      rule,
            "graph_context":     graph_ctx,
            "evidence":          evidence[:5],
            "suggested_sdtm_vars": [
                {"domain": d, "variable": v} for d, v in candidate_sdtm[:5]
            ],
            "suggested_raw_vars":  list(set(candidate_raw))[:10],
            "high_confidence_mappings": high_conf[:10],
            "graph_stats":         self.kg.stats(),
        }

    def query_raw_var(self, dataset: str, variable: str) -> Dict[str, Any]:
        """Deep dive into one raw variable's mapping lineage."""
        chain = self.kg.get_mapping_chain(dataset, variable)
        if "error" in chain:
            # Try BM25 fallback
            hits = self.indexer.search(f"{dataset}.{variable}", topk=5)
            return {
                "raw_dataset": dataset,
                "raw_variable": variable,
                "found_in_graph": False,
                "bm25_suggestions": [
                    {"domain": h.get("domain"), "sdtm_var": h.get("sdtm_var"),
                     "score": h.get("score")}
                    for h in hits
                ],
            }
        return {"found_in_graph": True, **chain}

    def query_sdtm_var(self, domain: str, variable: str) -> Dict[str, Any]:
        """Return all raw sources for a SDTM variable."""
        return self.kg.get_sdtm_sources(domain, variable)

    def find_unmapped(self) -> List[Dict]:
        """Return SDTM variables with no raw source."""
        return self.kg.get_unmapped_sdtm_vars()

    def domain_summary(self, domain: str) -> Dict[str, Any]:
        """Return mapping coverage summary for a SDTM domain."""
        sub = self.kg.get_subgraph_for_domain(domain)
        stats = sub.stats()

        sdtm_vars = [
            nid for nid, d in sub.G.nodes(data=True)
            if d.get("kind") == "sdtm_var" and d.get("domain", "").upper() == domain.upper()
        ]
        mapped = []
        unmapped = []
        for nid in sdtm_vars:
            has_source = any(
                d.get("type") == "MAPS_TO"
                for u, v, d in self.kg.G.in_edges(nid, data=True)
            )
            vdata = self.kg.G.nodes[nid]
            entry = {
                "variable": vdata.get("variable", ""),
                "var_class": vdata.get("var_class", ""),
                "core": vdata.get("core", ""),
            }
            (mapped if has_source else unmapped).append(entry)

        return {
            "domain": domain.upper(),
            "total_sdtm_vars": len(sdtm_vars),
            "mapped_count": len(mapped),
            "unmapped_count": len(unmapped),
            "coverage_pct": round(
                len(mapped) / max(len(sdtm_vars), 1) * 100, 1
            ),
            "mapped_vars": sorted(mapped, key=lambda x: x["variable"]),
            "unmapped_vars": sorted(unmapped, key=lambda x: x["variable"]),
            "graph_stats": stats,
        }

    # ── Private helpers ───────────────────────────────────────────────────────

    def _get_sdtm_context(self, domain: str, variable: str) -> Dict[str, Any]:
        sources = self.kg.get_sdtm_sources(domain, variable)
        nid = f"SDTM::{domain.upper()}::{variable.upper()}"
        co_vars = []
        if self.kg.G.has_node(nid):
            for u, v, d in self.kg.G.edges(data=True):
                if u == nid and d.get("type") == "SAME_CLASS":
                    nd = self.kg.G.nodes.get(v, {})
                    co_vars.append(f"{nd.get('domain','')}.{nd.get('variable','')}")
        return {
            "sdtm_domain": domain,
            "sdtm_variable": variable,
            "raw_sources": sources.get("raw_sources", []),
            "source_count": sources.get("source_count", 0),
            "same_class_vars": co_vars[:8],
        }

    def _find_relevant_mappings(
        self, question: str, candidate_sdtm: list
    ) -> List[Dict]:
        q_low = question.lower()
        results = self.kg.get_high_confidence_mappings(min_score=0.60)

        # Step 1: exact variable/dataset token match in question
        token_relevant = [
            m for m in results
            if any(
                tok in q_low
                for tok in [m["raw_var"].lower(), m["sdtm_var"].lower()]
            )
        ]
        if token_relevant:
            return token_relevant[:10]

        # Step 2: filter to domains from BM25 candidate hits
        if candidate_sdtm:
            domains = {d.upper() for d, _ in candidate_sdtm}
            dom_relevant = [
                m for m in results
                if m.get("sdtm_domain", "").upper() in domains
            ]
            if dom_relevant:
                return dom_relevant[:10]

        # Step 3: extract domain keyword from free-text question
        _DOMAIN_KEYWORDS = {
            "ae": "AE", "adverse event": "AE",
            "lb": "LB", "lab": "LB", "laboratory": "LB",
            "dm": "DM", "demographic": "DM", "demographics": "DM",
            "vs": "VS", "vital": "VS",
            "cm": "CM", "concomitant": "CM", "medication": "CM",
            "ex": "EX", "exposure": "EX",
            "mh": "MH", "medical history": "MH",
            "ds": "DS", "disposition": "DS",
            "eg": "EG", "ecg": "EG", "electrocardiogram": "EG",
            "pc": "PC", "pharmacokinetic": "PC",
            "su": "SU", "substance": "SU",
            "qs": "QS", "questionnaire": "QS",
        }
        for kw, dom in _DOMAIN_KEYWORDS.items():
            if kw in q_low:
                dom_filtered = [
                    m for m in results
                    if m.get("sdtm_domain", "").upper() == dom
                ]
                if dom_filtered:
                    return dom_filtered[:10]

        # Step 4: return empty — never show unrelated rows as filler
        return []
