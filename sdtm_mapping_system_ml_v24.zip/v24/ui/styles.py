"""
ui/styles.py
============
Dark theme CSS for the SDTM Master Mapping System.
"""
import streamlit as st

DARK_CSS = """
<style>
/* ============================================================
   BASE
   ============================================================ */
html, body, [data-testid="stAppViewContainer"] {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif;
}
[data-testid="stSidebar"] {
    background-color: #161b22;
    border-right: 1px solid #30363d;
}
[data-testid="stSidebar"] * { color: #e6edf3 !important; }

/* ---- Header bar ---- */
.main-header {
    background: linear-gradient(135deg, #161b22 0%, #1c2330 100%);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px 28px 16px 28px;
    margin-bottom: 20px;
}
.main-header h1 {
    font-size: 22px; font-weight: 700; color: #79c0ff;
    margin: 0 0 4px 0; letter-spacing: -0.02em;
}
.main-header p { font-size: 13px; color: #b1bac4; margin: 0; }

/* ---- Cards ---- */
.card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    padding: 16px 18px;
    margin-bottom: 12px;
}
.card-title {
    font-size: 12px; font-weight: 700; color: #79c0ff;
    letter-spacing: 0.06em; text-transform: uppercase;
    margin-bottom: 10px;
}

/* ---- Metric pills ---- */
.metric-row { display: flex; gap: 10px; flex-wrap: wrap; margin: 12px 0; }
.metric-pill {
    background: #1c2330; border: 1px solid #30363d;
    border-radius: 6px; padding: 10px 16px; text-align: center;
    min-width: 100px; flex: 1;
    transition: transform 0.1s; cursor: default;
}
.metric-pill:hover { transform: translateY(-2px); }
.metric-pill .val {
    font-size: 22px; font-weight: 700; color: #79c0ff;
    font-family: 'IBM Plex Mono', monospace; line-height: 1.2;
}
.metric-pill .val.green  { color: #56d364; }
.metric-pill .val.amber  { color: #f0c040; }
.metric-pill .val.red    { color: #ff7b72; }
.metric-pill .val.purple { color: #d2a8ff; }
.metric-pill .lbl { font-size: 11px; color: #b1bac4; margin-top: 3px; font-weight: 500; }

/* ---- Status badges ---- */
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 3px;
    font-size: 11px; font-weight: 600; font-family: monospace;
}
.badge-direct  { background: rgba(86,211,100,0.20);  color: #56d364;  border: 1px solid rgba(86,211,100,0.5);  }
.badge-review  { background: rgba(240,192,64,0.20);  color: #f0c040;  border: 1px solid rgba(240,192,64,0.5);  }
.badge-cross   { background: rgba(210,168,255,0.20); color: #d2a8ff;  border: 1px solid rgba(210,168,255,0.5); }
.badge-unres   { background: rgba(255,123,114,0.20); color: #ff7b72;  border: 1px solid rgba(255,123,114,0.5); }

/* ---- Streamlit native elements: ensure readable text ---- */
[data-testid="stMarkdownContainer"] p,
[data-testid="stMarkdownContainer"] li,
[data-testid="stMarkdownContainer"] span {
    color: #e6edf3;
}
/* Labels on widgets */
[data-testid="stWidgetLabel"] p,
label, .stSelectbox label, .stRadio label, .stCheckbox label {
    color: #c9d1d9 !important;
    font-weight: 500 !important;
}
/* Caption / small text */
[data-testid="stCaptionContainer"] p,
.stCaption p {
    color: #b1bac4 !important;
}

/* ---- Input / select boxes ---- */
[data-baseweb="input"] input,
[data-baseweb="textarea"] textarea,
[data-baseweb="select"] div {
    background-color: #21262d !important;
    color: #e6edf3 !important;
    border-color: #30363d !important;
}
[data-baseweb="input"] input::placeholder { color: #6e7681 !important; }

/* ---- Radio buttons ---- */
[data-testid="stRadio"] label { color: #c9d1d9 !important; }
[data-testid="stRadio"] [data-baseweb="radio"] div {
    border-color: #58a6ff !important;
}

/* ---- Checkboxes ---- */
[data-testid="stCheckbox"] label { color: #c9d1d9 !important; }

/* ---- Sliders ---- */
[data-testid="stSlider"] [data-baseweb="slider"] div[role="slider"] {
    background-color: #58a6ff !important;
}
[data-testid="stSliderThumbValue"] { color: #e6edf3 !important; }

/* ---- Buttons ---- */
[data-testid="stButton"] button {
    background-color: #21262d !important;
    color: #c9d1d9 !important;
    border: 1px solid #30363d !important;
    font-weight: 600 !important;
}
[data-testid="stButton"] button:hover {
    background-color: #30363d !important;
    color: #e6edf3 !important;
    border-color: #58a6ff !important;
}
[data-testid="stButton"] button[kind="primary"] {
    background-color: #1f6feb !important;
    color: #ffffff !important;
    border-color: #1f6feb !important;
}
[data-testid="stButton"] button[kind="primary"]:hover {
    background-color: #388bfd !important;
}

/* ---- Download buttons ---- */
[data-testid="stDownloadButton"] button {
    background-color: #238636 !important;
    color: #ffffff !important;
    border: 1px solid #2ea043 !important;
    font-weight: 600 !important;
}
[data-testid="stDownloadButton"] button:hover {
    background-color: #2ea043 !important;
}

/* ---- File uploader ---- */
[data-testid="stFileUploader"] {
    background-color: #161b22 !important;
    border: 2px dashed #30363d !important;
    border-radius: 8px !important;
}
[data-testid="stFileUploader"] label { color: #c9d1d9 !important; }
[data-testid="stFileUploaderDropzone"] { color: #8b949e !important; }

/* ---- Expanders ---- */
[data-testid="stExpander"] {
    background: #161b22 !important;
    border: 1px solid #30363d !important;
    border-radius: 6px !important;
}
[data-testid="stExpander"] summary { color: #c9d1d9 !important; }
[data-testid="stExpander"] summary:hover { color: #e6edf3 !important; }
[data-testid="stExpander"] [data-testid="stExpanderDetails"] {
    background: #0d1117 !important;
}

/* ---- DataFrames ---- */
[data-testid="stDataFrame"] { border: 1px solid #30363d !important; border-radius: 6px; }
[data-testid="stDataFrame"] table { font-size: 12px !important; }
thead th {
    background-color: #161b22 !important; color: #79c0ff !important;
    font-size: 11px !important; text-transform: uppercase !important;
    letter-spacing: 0.04em !important; font-weight: 700 !important;
}
[data-testid="stDataFrame"] tbody td { color: #e6edf3 !important; }
[data-testid="stDataFrame"] tbody tr:nth-child(even) {
    background-color: rgba(88,166,255,0.05) !important;
}
[data-testid="stDataFrame"] tbody tr:hover {
    background-color: rgba(88,166,255,0.12) !important;
}

/* ---- Tabs — more readable ---- */
[data-testid="stTabs"] [role="tablist"] {
    border-bottom: 2px solid #30363d;
    gap: 2px;
    flex-wrap: wrap;
}
[data-testid="stTabs"] [role="tab"] {
    color: #b1bac4 !important;
    font-size: 12px !important;
    font-weight: 500 !important;
    padding: 7px 14px !important;
    border-radius: 6px 6px 0 0 !important;
    transition: background 0.15s, color 0.15s;
}
[data-testid="stTabs"] [role="tab"]:hover {
    background: rgba(88,166,255,0.10) !important;
    color: #e6edf3 !important;
}
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: #79c0ff !important;
    background: rgba(88,166,255,0.14) !important;
    border-bottom: 2px solid #58a6ff !important;
    font-weight: 700 !important;
}

/* ---- Alerts ---- */
[data-testid="stSuccess"] {
    background: rgba(86,211,100,0.14) !important;
    border-left: 4px solid #56d364 !important;
    color: #56d364 !important;
}
[data-testid="stWarning"] {
    background: rgba(240,192,64,0.14) !important;
    border-left: 4px solid #f0c040 !important;
    color: #f0c040 !important;
}
[data-testid="stError"] {
    background: rgba(255,123,114,0.14) !important;
    border-left: 4px solid #ff7b72 !important;
    color: #ff7b72 !important;
}
[data-testid="stInfo"] {
    background: rgba(88,166,255,0.12) !important;
    border-left: 4px solid #58a6ff !important;
    color: #c9d1d9 !important;
}
[data-testid="stSuccess"] p,
[data-testid="stWarning"] p,
[data-testid="stError"] p,
[data-testid="stInfo"] p { color: inherit !important; }

/* ---- Code blocks ---- */
code, pre {
    background: #161b22 !important;
    color: #a5d6ff !important;
    border: 1px solid #30363d !important;
    border-radius: 4px !important;
}

/* ---- Log area ---- */
.log-box {
    background: #0d1117; border: 1px solid #30363d; border-radius: 5px;
    padding: 14px; font-family: 'IBM Plex Mono', monospace;
    font-size: 13px; line-height: 1.6; color: #c9d1d9;
    max-height: 420px; overflow-y: auto;
    white-space: pre-wrap;
    scroll-behavior: smooth;
}
.log-box .log-ok   { color: #56d364; font-weight: 600; }
.log-box .log-warn { color: #f0c040; }
.log-box .log-err  { color: #ff7b72; font-weight: 600; }
.log-info  { color: #b1bac4; }
.log-ok    { color: #56d364; }
.log-warn  { color: #f0c040; }
.log-err   { color: #ff7b72; }

/* ---- Sidebar labels ---- */
.sidebar-section {
    font-size: 10px; font-weight: 700; letter-spacing: 0.1em;
    text-transform: uppercase; color: #8b949e; padding: 12px 0 4px 0;
    border-bottom: 1px solid #30363d; margin-bottom: 8px;
}

/* ---- Divider ---- */
hr { border-color: #30363d !important; }

/* ---- Compare page: diff row colors ---- */
.diff-changed { background: rgba(240,192,64,0.18) !important; }
.diff-same    { background: rgba(86,211,100,0.10) !important; }

/* ---- Tier color indicators ---- */
.tier-direct { color:#56d364; font-weight:700; font-size:11px; }
.tier-review { color:#f0c040; font-weight:700; font-size:11px; }
.tier-cross  { color:#d2a8ff; font-weight:700; font-size:11px; }
.tier-unres  { color:#ff7b72; font-weight:700; font-size:11px; }

/* ---- Score monospace coloring ---- */
.score-high   { color:#56d364; font-weight:700; font-family:monospace; }
.score-medium { color:#f0c040; font-weight:700; font-family:monospace; }
.score-low    { color:#ff7b72; font-weight:700; font-family:monospace; }

/* ---- Raw->SDTM mapping table monospace ---- */
.raw-ds-name { color:#79c0ff; font-family:monospace; font-weight:600; }
.sdtm-domain { color:#56d364; font-family:monospace; font-weight:600; }

/* ---- Metrics (native Streamlit) ---- */
[data-testid="stMetricLabel"] { color: #b1bac4 !important; font-weight: 600 !important; }
[data-testid="stMetricValue"] { color: #e6edf3 !important; font-weight: 700 !important; }
[data-testid="stMetricDelta"] { color: #56d364 !important; }

/* ---- Progress bar ---- */
[data-testid="stProgressBar"] > div { background-color: #1f6feb !important; }

/* ---- Spinner ---- */
[data-testid="stSpinner"] p { color: #c9d1d9 !important; }
</style>
"""


def apply_theme():
    """Inject the dark CSS theme into the Streamlit app."""
    st.markdown(DARK_CSS, unsafe_allow_html=True)
