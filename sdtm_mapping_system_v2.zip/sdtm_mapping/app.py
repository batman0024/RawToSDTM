"""
app.py
======
SDTM Master Mapping System - Streamlit Application

Dark-mode interactive UI covering three pipeline phases:
  1. Build Master Mapping   (from completed study specs)
  2. Map New Study          (raw catalog -> SDTM variable mapping)
  3. Write Back to Spec     (populate Input Variables / Origin in spec Excel)

Run:
    streamlit run app.py
"""

import io
import os
import sys
import time
import math
import tempfile
import traceback
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).parent.resolve()
SRC_DIR = APP_DIR / 'src'
# Add both project root and src/ so all modules are importable
sys.path.insert(0, str(SRC_DIR))
sys.path.insert(0, str(APP_DIR))

# ---------------------------------------------------------------------------
# Page config - must be first Streamlit call
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="SDTM Master Mapping System",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Dark theme CSS
# ---------------------------------------------------------------------------
DARK_CSS = """
<style>
/* ---- Base ---- */
html, body, [data-testid="stAppViewContainer"] {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif;
}
[data-testid="stSidebar"] {
    background-color: #161b22;
    border-right: 1px solid #30363d;
}
[data-testid="stSidebar"] * { color: #e6edf3 !important; }

/* ---- Header bar ---- */
.main-header {
    background: linear-gradient(135deg, #161b22 0%, #1c2330 100%);
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px 28px 16px 28px;
    margin-bottom: 20px;
}
.main-header h1 {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    margin: 0 0 4px 0; letter-spacing: -0.02em;
}
.main-header p { font-size: 13px; color: #8b949e; margin: 0; }

/* ---- Cards ---- */
.card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 6px;
    padding: 16px 18px;
    margin-bottom: 12px;
}
.card-title {
    font-size: 12px; font-weight: 600; color: #58a6ff;
    letter-spacing: 0.06em; text-transform: uppercase;
    margin-bottom: 10px;
}

/* ---- Metric pills ---- */
.metric-row { display: flex; gap: 10px; flex-wrap: wrap; margin: 12px 0; }
.metric-pill {
    background: #1c2330; border: 1px solid #30363d;
    border-radius: 6px; padding: 10px 16px; text-align: center;
    min-width: 100px; flex: 1;
}
.metric-pill .val {
    font-size: 22px; font-weight: 700; color: #58a6ff;
    font-family: 'IBM Plex Mono', monospace; line-height: 1.2;
}
.metric-pill .val.green  { color: #3fb950; }
.metric-pill .val.amber  { color: #e3b341; }
.metric-pill .val.red    { color: #f85149; }
.metric-pill .val.purple { color: #bc8cff; }
.metric-pill .lbl { font-size: 11px; color: #8b949e; margin-top: 3px; }

/* ---- Status badges ---- */
.badge {
    display: inline-block; padding: 2px 8px; border-radius: 3px;
    font-size: 11px; font-weight: 600; font-family: monospace;
}
.badge-direct  { background: rgba(63,185,80,0.15);  color: #3fb950;  border: 1px solid rgba(63,185,80,0.3);  }
.badge-review  { background: rgba(227,179,65,0.15); color: #e3b341;  border: 1px solid rgba(227,179,65,0.3); }
.badge-unres   { background: rgba(248,81,73,0.15);  color: #f85149;  border: 1px solid rgba(248,81,73,0.3);  }
.badge-info    { background: rgba(88,166,255,0.12); color: #58a6ff;  border: 1px solid rgba(88,166,255,0.3); }

/* ---- Inputs & buttons ---- */
[data-testid="stFileUploader"] {
    background: #161b22; border: 1px dashed #30363d !important;
    border-radius: 6px; padding: 8px;
}
.stButton > button {
    background: #238636 !important; color: #ffffff !important;
    border: none !important; border-radius: 6px !important;
    font-weight: 600 !important; padding: 10px 24px !important;
    font-size: 13px !important; width: 100% !important;
    transition: background 0.2s !important;
}
.stButton > button:hover { background: #2ea043 !important; }
.stButton > button:disabled { background: #21262d !important; color: #8b949e !important; }

/* ---- Progress bar ---- */
[data-testid="stProgress"] > div > div { background-color: #238636 !important; }

/* ---- Tables ---- */
[data-testid="stDataFrame"] { border: 1px solid #30363d; border-radius: 6px; }
thead th {
    background-color: #161b22 !important; color: #58a6ff !important;
    font-size: 11px !important; text-transform: uppercase !important;
}

/* ---- Tabs ---- */
[data-testid="stTabs"] [role="tab"] { color: #8b949e !important; }
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: #58a6ff !important; border-bottom-color: #58a6ff !important;
}

/* ---- Alerts ---- */
.stSuccess { background: rgba(63,185,80,0.1) !important; border: 1px solid rgba(63,185,80,0.3) !important; color: #3fb950 !important; }
.stWarning { background: rgba(227,179,65,0.1) !important; border: 1px solid rgba(227,179,65,0.3) !important; }
.stError   { background: rgba(248,81,73,0.1)  !important; border: 1px solid rgba(248,81,73,0.3)  !important; }
.stInfo    { background: rgba(88,166,255,0.1)  !important; border: 1px solid rgba(88,166,255,0.3) !important; color: #58a6ff !important; }

/* ---- Code blocks ---- */
code, pre { background: #161b22 !important; color: #a5d6ff !important; border: 1px solid #30363d !important; }

/* ---- Log area ---- */
.log-box {
    background: #0d1117; border: 1px solid #30363d; border-radius: 5px;
    padding: 12px; font-family: 'IBM Plex Mono', monospace;
    font-size: 11px; color: #8b949e; max-height: 300px; overflow-y: auto;
    white-space: pre-wrap;
}
.log-info  { color: #8b949e; }
.log-ok    { color: #3fb950; }
.log-warn  { color: #e3b341; }
.log-err   { color: #f85149; }

/* ---- Sidebar labels ---- */
.sidebar-section {
    font-size: 10px; font-weight: 600; letter-spacing: 0.1em;
    text-transform: uppercase; color: #6e7681; padding: 12px 0 4px 0;
    border-bottom: 1px solid #30363d; margin-bottom: 8px;
}

/* ---- Divider ---- */
hr { border-color: #30363d !important; }
</style>
"""

st.markdown(DARK_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def save_upload(uploaded_file, dest_dir):
    """Save a Streamlit UploadedFile to dest_dir; return Path."""
    dest = Path(dest_dir) / uploaded_file.name
    dest.write_bytes(uploaded_file.getbuffer())
    return dest


def bytes_to_upload_mock(content_bytes, filename, dest_dir):
    """Write raw bytes to a file; return Path."""
    dest = Path(dest_dir) / filename
    dest.write_bytes(content_bytes)
    return dest


def metric_html(val, label, color=""):
    cls = "val " + color if color else "val"
    return (
        '<div class="metric-pill">'
        f'<div class="{cls}">{val}</div>'
        f'<div class="lbl">{label}</div>'
        '</div>'
    )


def log_html(lines):
    inner = "\n".join(lines[-80:])
    return f'<div class="log-box">{inner}</div>'


def excel_download_button(df_dict, filename, label="Download Excel"):
    """Create an in-memory Excel workbook and return a download button."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in df_dict.items():
            if df is not None and not df.empty:
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    buf.seek(0)
    st.download_button(
        label=label,
        data=buf.read(),
        file_name=filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def file_download_button(path, label="Download File"):
    """Offer a file for download by path."""
    with open(path, "rb") as f:
        data = f.read()
    ext  = Path(path).suffix.lower()
    mime = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if ext in (".xlsx", ".xlsm") else "application/octet-stream"
    )
    st.download_button(label=label, data=data,
                       file_name=Path(path).name, mime=mime)


# ---------------------------------------------------------------------------
# Progress-aware wrapper for build_master_mapping
# ---------------------------------------------------------------------------

def run_build_with_progress(spec_paths, sponsor_paths, existing_master,
                             out_path, config_path, study_dates):
    """
    Wrap build_master_mapping with real-time Streamlit progress feedback.
    Yields (pct, message) via st.progress + st.status updates.
    """
    import master_builder as mb

    log_lines = []
    progress   = st.progress(0, text="Starting master build...")
    status_box = st.empty()

    steps = []
    if existing_master:
        steps.append(("Loading existing master", 5))
    for sp in spec_paths:
        steps.append((f"Reading study spec: {Path(sp).name}", 15))
    for sp in (sponsor_paths or []):
        steps.append((f"Reading sponsor spec: {Path(sp).name}", 15))
    steps.append(("Consolidating groups & confidence scores", 20))
    steps.append(("Writing master_mapping.xlsx", 10))

    total_weight = sum(w for _, w in steps)
    cumulative   = 0

    def tick(msg, weight):
        nonlocal cumulative
        cumulative += weight
        pct = min(int(cumulative / total_weight * 100), 99)
        progress.progress(pct, text=msg)
        log_lines.append(f"  {msg}")
        status_box.markdown(log_html(log_lines), unsafe_allow_html=True)
        time.sleep(0.05)

    # Patch the module's logger to capture output
    import logging, io as _io

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg = self.format(record)
            # strip timestamp prefix
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        tick("Initialising...", 0)

        orig_process = mb.process_spec_file
        proc_count   = [0]

        def patched_process(spec_path, cfg, study_date, is_sponsor, log):
            proc_count[0] += 1
            prefix = "Sponsor std" if is_sponsor else f"Study {proc_count[0]}"
            tick(f"{prefix}: {Path(spec_path).name}", 15)
            return orig_process(spec_path, cfg, study_date, is_sponsor, log)

        mb.process_spec_file = patched_process

        master_df = mb.build_master_mapping(
            spec_paths=spec_paths,
            sponsor_paths=sponsor_paths,
            existing_master=existing_master,
            out_path=out_path,
            config_path=config_path,
            study_dates=study_dates,
        )

        mb.process_spec_file = orig_process
        tick("Complete!", 10)
        progress.progress(100, text="Master mapping built successfully")
        return master_df, log_lines

    except Exception as exc:
        mb.process_spec_file = orig_process
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_map_with_progress(master_path, raw_path, spec_path,
                           out_path, config_path):
    """Wrap mapper.run with real-time progress."""
    import mapper as mp
    import logging

    log_lines = []
    progress   = st.progress(0, text="Starting variable mapping...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    # Patch run_mapping to emit per-domain progress
    orig_run_mapping = mp.run_mapping
    domains_seen = [0]

    def patched_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log):
        total_vars = len(sdtm_vars_df)
        pct_per_var = 60 / max(total_vars, 1)

        orig_find = mp.find_best_group
        var_count = [0]

        def patched_find(sdtm_var, domain, *args, **kwargs):
            var_count[0] += 1
            pct = 20 + int(var_count[0] * pct_per_var)
            progress.progress(
                min(pct, 80),
                text=f"Mapping {domain}.{sdtm_var}  [{var_count[0]}/{total_vars}]",
            )
            return orig_find(sdtm_var, domain, *args, **kwargs)

        mp.find_best_group = patched_find
        result = orig_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log)
        mp.find_best_group = orig_find
        return result

    mp.run_mapping = patched_run_mapping

    try:
        progress.progress(5,  text="Loading master mapping...")
        time.sleep(0.1)
        progress.progress(10, text="Loading raw catalog...")
        time.sleep(0.1)
        progress.progress(15, text="Building TF-IDF label index...")

        results = mp.run(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=str(spec_path) if spec_path else None,
            out_path=out_path,
            config_path=config_path,
        )

        mp.run_mapping = orig_run_mapping
        progress.progress(90, text="Writing results Excel...")
        time.sleep(0.2)
        progress.progress(100, text="Mapping complete!")
        return results, log_lines

    except Exception as exc:
        mp.run_mapping = orig_run_mapping
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_writeback_with_progress(spec_path, results_path, out_path,
                                 highlight_review, populate_origin,
                                 populate_action, dry_run, config_path):
    """Wrap spec_writeback.write_back with progress."""
    import spec_writeback as sw
    import logging

    log_lines = []
    progress   = st.progress(0, text="Preparing write-back...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        progress.progress(10, text="Loading mapping results...")
        time.sleep(0.1)
        progress.progress(25, text="Opening spec workbook...")
        time.sleep(0.1)
        progress.progress(35, text="Writing Input Variables, Origin, Mapping Action...")

        result = sw.write_back(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
            highlight_review=highlight_review,
            populate_origin=populate_origin,
            populate_action=populate_action,
            dry_run=dry_run,
            config_path=str(config_path),
        )

        progress.progress(90, text="Appending change-log sheet...")
        time.sleep(0.15)
        progress.progress(100, text="Write-back complete!")
        return result, log_lines

    except Exception as exc:
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


# ---------------------------------------------------------------------------
# Coverage chart (pure matplotlib -> PNG bytes)
# ---------------------------------------------------------------------------

def coverage_chart_bytes(coverage_df):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        domains = coverage_df["DOMAIN"].tolist()
        direct  = coverage_df["DIRECT"].astype(int).tolist()
        review  = coverage_df["REVIEW"].astype(int).tolist()
        unres   = coverage_df["UNRESOLVED"].astype(int).tolist()

        x     = range(len(domains))
        width = 0.25

        fig, ax = plt.subplots(figsize=(max(7, len(domains) * 1.2), 4), facecolor="#0d1117")
        ax.set_facecolor("#161b22")

        bars_d = ax.bar([i - width for i in x], direct,  width, label="Direct",     color="#3fb950", alpha=0.9)
        bars_r = ax.bar([i         for i in x], review,  width, label="Review",     color="#e3b341", alpha=0.9)
        bars_u = ax.bar([i + width for i in x], unres,   width, label="Unresolved", color="#f85149", alpha=0.9)

        ax.set_xticks(list(x))
        ax.set_xticklabels(domains, color="#e6edf3", fontsize=11)
        ax.tick_params(colors="#8b949e")
        ax.spines["bottom"].set_color("#30363d")
        ax.spines["left"].set_color("#30363d")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_ylabel("Variables", color="#8b949e", fontsize=10)
        ax.set_title("Mapping Coverage by Domain", color="#e6edf3", fontsize=12, pad=10)
        ax.yaxis.label.set_color("#8b949e")
        ax.tick_params(axis="y", colors="#8b949e")
        ax.grid(axis="y", color="#30363d", linewidth=0.5, linestyle="--")

        legend = ax.legend(
            facecolor="#161b22", edgecolor="#30363d",
            labelcolor="#e6edf3", fontsize=9,
        )

        # Value labels on bars
        for bars in (bars_d, bars_r, bars_u):
            for bar in bars:
                h = bar.get_height()
                if h > 0:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2, h + 0.1,
                        str(int(h)), ha="center", va="bottom",
                        color="#e6edf3", fontsize=8,
                    )

        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                    facecolor="#0d1117")
        plt.close(fig)
        buf.seek(0)
        return buf.read()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown(
        '<div class="main-header"><h1>SDTM Mapper</h1>'
        '<p>Master Mapping System v3</p></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-section">Navigation</div>', unsafe_allow_html=True)

    page = st.radio(
        "Select phase",
        options=["Build Master", "Map New Study", "Write Back to Spec", "View Master", "Help"],
        label_visibility="collapsed",
    )

    st.markdown('<div class="sidebar-section">Settings</div>', unsafe_allow_html=True)

    cfg_path_input = st.text_input(
        "config.yaml path",
        value=str(APP_DIR / "src" / "config.yaml"),
        help="Path to config.yaml. Edit thresholds and weights there.",
    )

    st.markdown('<div class="sidebar-section">About</div>', unsafe_allow_html=True)
    st.caption(
        "Each completed study fed into Build Master improves "
        "matching accuracy for all future studies."
    )


# ---------------------------------------------------------------------------
# Main header
# ---------------------------------------------------------------------------

st.markdown(
    '<div class="main-header">'
    '<h1>SDTM Master Mapping System</h1>'
    '<p>Build a cross-study master mapping knowledge base from completed SDTM specs, '
    'then automatically map new study raw variables to SDTM with confidence-scored '
    'outputs and direct spec write-back.</p>'
    '</div>',
    unsafe_allow_html=True,
)


# ===========================================================================
# PAGE: Build Master
# ===========================================================================

if page == "Build Master":
    st.markdown("## Phase 1 - Build Master Mapping")
    st.info(
        "Upload completed study spec Excel files. Each study added improves "
        "accuracy for future mappings. Sponsor standard specs get a confidence "
        "priority boost and supersede conflicting study mappings.",
    )

    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Completed Study Specs</div>', unsafe_allow_html=True)
        study_files = st.file_uploader(
            "Upload one or more completed study spec Excel files",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="study_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Sponsor Standard Specs (optional)</div>', unsafe_allow_html=True)
        sponsor_files = st.file_uploader(
            "Upload sponsor standard / template spec(s). These take priority over study mappings.",
            type=["xlsx", "xlsm"],
            accept_multiple_files=True,
            key="sponsor_specs",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Existing Master (Append Mode)</div>', unsafe_allow_html=True)
        existing_master_file = st.file_uploader(
            "Optional: upload an existing master_mapping.xlsx to append new studies",
            type=["xlsx"],
            key="existing_master",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Study Dates (optional)</div>', unsafe_allow_html=True)
        st.caption("Older studies get a recency decay. Format: filename=YYYY-MM-DD (one per line)")
        dates_text = st.text_area(
            "Study dates",
            placeholder="study_a.xlsx=2022-06-01\nstudy_b.xlsx=2023-11-15\nsponsor_std.xlsx=2024-01-01",
            height=120,
            label_visibility="collapsed",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Conflict Strategy</div>', unsafe_allow_html=True)
        conflict_strategy = st.selectbox(
            "How to resolve conflicting mappings across studies",
            options=["sponsor_priority", "most_frequent"],
            index=0,
            help="sponsor_priority: sponsor standard wins. most_frequent: highest N_STUDIES wins.",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    run_build = st.button(
        "Build Master Mapping",
        disabled=(not study_files and not sponsor_files),
    )

    if run_build:
        try:
            import yaml, re
            with open(cfg_path_input) as f:
                cfg_data = yaml.safe_load(f)
            cfg_data["master_build"]["conflict_strategy"] = conflict_strategy
            # Write temp config
            tmp_cfg = Path(tempfile.mkdtemp()) / "config.yaml"
            import yaml as _yaml
            with open(tmp_cfg, "w") as f:
                _yaml.dump(cfg_data, f, default_flow_style=False, allow_unicode=False)

            with tempfile.TemporaryDirectory() as tmpdir:
                spec_paths    = [save_upload(f, tmpdir) for f in (study_files or [])]
                sponsor_paths = [save_upload(f, tmpdir) for f in (sponsor_files or [])]
                existing_path = None
                if existing_master_file:
                    existing_path = save_upload(existing_master_file, tmpdir)

                study_dates = {}
                for line in dates_text.strip().splitlines():
                    line = line.strip()
                    if "=" in line:
                        fn, date = line.split("=", 1)
                        study_dates[fn.strip()] = date.strip()

                out_master = Path(tmpdir) / "master_mapping.xlsx"

                st.markdown("### Building...")
                master_df, log_lines = run_build_with_progress(
                    spec_paths=spec_paths,
                    sponsor_paths=sponsor_paths,
                    existing_master=existing_path,
                    out_path=out_master,
                    config_path=tmp_cfg,
                    study_dates=study_dates,
                )

                if master_df is not None and not master_df.empty:
                    st.success(
                        f"Master mapping built: {len(master_df):,} rows | "
                        f"{master_df['SDTM_VARIABLE'].nunique()} SDTM variables | "
                        f"{master_df['DOMAIN'].nunique()} domains"
                    )

                    # Metrics
                    top_df = master_df[master_df["IS_TOP_GROUP"]]
                    high_n = int((top_df["MASTER_CONFIDENCE"] >= 0.82).sum())
                    mid_n  = int(((top_df["MASTER_CONFIDENCE"] >= 0.55) & (top_df["MASTER_CONFIDENCE"] < 0.82)).sum())
                    low_n  = int((top_df["MASTER_CONFIDENCE"] < 0.55).sum())

                    pills = (
                        '<div class="metric-row">'
                        + metric_html(master_df["SDTM_VARIABLE"].nunique(), "SDTM Variables")
                        + metric_html(master_df["DOMAIN"].nunique(), "Domains", "")
                        + metric_html(int((master_df["IS_SPONSOR_STD"] == True).sum()), "Sponsor-Std Rows", "purple")
                        + metric_html(high_n, "High Conf (>=82%)", "green")
                        + metric_html(mid_n,  "Medium Conf",       "amber")
                        + metric_html(low_n,  "Low Conf (<55%)",   "red")
                        + '</div>'
                    )
                    st.markdown(pills, unsafe_allow_html=True)

                    # Domain summary table
                    st.markdown("#### Domain Summary")
                    dom_sum = (
                        top_df.groupby("DOMAIN")
                        .agg(
                            SDTM_VARS=("SDTM_VARIABLE", "nunique"),
                            AVG_CONF=("MASTER_CONFIDENCE", "mean"),
                            HIGH_CONF=("MASTER_CONFIDENCE", lambda x: int((x >= 0.82).sum())),
                        )
                        .reset_index()
                        .round({"AVG_CONF": 3})
                    )
                    st.dataframe(dom_sum, use_container_width=True, hide_index=True)

                    # Download
                    st.markdown("#### Download")
                    file_download_button(out_master, "Download master_mapping.xlsx")

                    # Store in session state for next phase
                    st.session_state["master_xlsx_bytes"] = out_master.read_bytes()
                    st.session_state["master_built"]      = True

        except Exception as exc:
            st.error(f"Build failed: {exc}")
            st.code(traceback.format_exc(), language="text")


# ===========================================================================
# PAGE: Map New Study
# ===========================================================================

elif page == "Map New Study":
    st.markdown("## Phase 2 - Map New Study Raw Variables")
    st.info(
        "Upload the new study raw variable catalog (PROC CONTENTS output or "
        "Excel variable registry). Optionally upload the new study SDTM spec "
        "to map its specific variable list."
    )

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">Master Mapping</div>', unsafe_allow_html=True)
        master_source = st.radio(
            "Master source",
            ["Upload master_mapping.xlsx", "Use master built in Phase 1 (this session)"],
            label_visibility="collapsed",
        )
        if master_source == "Upload master_mapping.xlsx":
            master_upload = st.file_uploader(
                "master_mapping.xlsx",
                type=["xlsx"],
                key="master_for_map",
            )
        else:
            master_upload = None
            if st.session_state.get("master_built"):
                st.success("Phase 1 master mapping is ready.")
            else:
                st.info(
                    "No master built in this session yet. "
                    "Go to Build Master (Phase 1) first, or upload a "
                    "master_mapping.xlsx from a previous run."
                )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Raw Variable Catalog</div>', unsafe_allow_html=True)
        raw_upload = st.file_uploader(
            "PROC CONTENTS output or variable registry Excel/CSV",
            type=["xlsx", "csv"],
            key="raw_catalog",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">New Study SDTM Spec (optional)</div>', unsafe_allow_html=True)
        spec_upload = st.file_uploader(
            "New study spec Excel. If provided, maps the spec variable list. "
            "If not, maps all variables in the master.",
            type=["xlsx", "xlsm"],
            key="new_spec",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Threshold Overrides</div>', unsafe_allow_html=True)
        auto_thresh = st.slider("Auto-accept threshold", 0.50, 0.98, 0.82, 0.01,
                                help="Score >= this is written directly to spec")
        review_thresh = st.slider("Review threshold", 0.30, 0.80, 0.55, 0.01,
                                  help="Score >= this is flagged for human review")
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    master_ready = (
        (master_source == "Upload master_mapping.xlsx" and master_upload is not None)
        or (master_source != "Upload master_mapping.xlsx" and st.session_state.get("master_built"))
    )
    run_map = st.button("Run Mapping", disabled=(not master_ready or raw_upload is None))

    if run_map:
        try:
            import yaml
            with open(cfg_path_input) as f:
                cfg_data = yaml.safe_load(f)
            cfg_data["matching"]["thresholds"]["auto_accept"] = auto_thresh
            cfg_data["matching"]["thresholds"]["review"]       = review_thresh
            tmp_cfg = Path(tempfile.mkdtemp()) / "config.yaml"
            import yaml as _yaml
            with open(tmp_cfg, "w") as f:
                _yaml.dump(cfg_data, f, default_flow_style=False, allow_unicode=False)

            with tempfile.TemporaryDirectory() as tmpdir:
                # Save master
                if master_upload is not None:
                    master_path = save_upload(master_upload, tmpdir)
                else:
                    master_path = Path(tmpdir) / "master_mapping.xlsx"
                    master_path.write_bytes(st.session_state["master_xlsx_bytes"])

                raw_path  = save_upload(raw_upload, tmpdir)
                spec_path = save_upload(spec_upload, tmpdir) if spec_upload else None
                out_path  = Path(tmpdir) / "mapping_results.xlsx"

                st.markdown("### Mapping...")
                results, log_lines = run_map_with_progress(
                    master_path, raw_path, spec_path, out_path, tmp_cfg,
                )

                if results:
                    direct_df  = results.get("direct",     pd.DataFrame())
                    review_df  = results.get("review",     pd.DataFrame())
                    unres_df   = results.get("unresolved", pd.DataFrame())
                    unmapped   = results.get("unmapped_raw", pd.DataFrame())
                    coverage   = results.get("coverage",   pd.DataFrame())

                    d_n = len(direct_df)
                    r_n = len(review_df)
                    u_n = len(unres_df)
                    total = d_n + r_n + u_n

                    st.success(
                        f"Mapping complete: {d_n} direct | {r_n} review | "
                        f"{u_n} unresolved | {total} total"
                    )

                    pills = (
                        '<div class="metric-row">'
                        + metric_html(d_n, "Auto-Accepted", "green")
                        + metric_html(r_n, "Needs Review",  "amber")
                        + metric_html(u_n, "Unresolved",    "red")
                        + metric_html(
                            f"{round(100*d_n/total)}%" if total else "0%",
                            "Auto-Accept Rate", "green"
                          )
                        + metric_html(len(unmapped), "Unmapped Raw Vars", "")
                        + '</div>'
                    )
                    st.markdown(pills, unsafe_allow_html=True)

                    # Coverage chart
                    if not coverage.empty:
                        chart_bytes = coverage_chart_bytes(coverage)
                        if chart_bytes:
                            st.image(chart_bytes, use_container_width=True)

                        st.markdown("#### Coverage by Domain")
                        display_cols = [
                            c for c in
                            ["DOMAIN","TOTAL","DIRECT","REVIEW","UNRESOLVED",
                             "AUTO_PCT","TOTAL_COVERAGE_PCT",
                             "N_DERIVED","N_TIMING","N_RESULT"]
                            if c in coverage.columns
                        ]
                        st.dataframe(coverage[display_cols], use_container_width=True, hide_index=True)

                    # Tabbed results
                    t1, t2, t3, t4 = st.tabs(["Direct", "Review", "Unresolved", "Unmapped Raw"])
                    with t1:
                        if not direct_df.empty:
                            st.dataframe(direct_df, use_container_width=True, hide_index=True)
                        else:
                            st.info("No direct matches.")
                    with t2:
                        if not review_df.empty:
                            st.dataframe(review_df, use_container_width=True, hide_index=True)
                        else:
                            st.info("No review items.")
                    with t3:
                        if not unres_df.empty:
                            st.dataframe(unres_df, use_container_width=True, hide_index=True)
                        else:
                            st.info("No unresolved items.")
                    with t4:
                        if not unmapped.empty:
                            st.dataframe(unmapped, use_container_width=True, hide_index=True)
                        else:
                            st.info("All raw variables were mapped.")

                    # Download
                    st.markdown("#### Download")
                    file_download_button(out_path, "Download mapping_results.xlsx")
                    st.session_state["results_xlsx_bytes"] = out_path.read_bytes()
                    st.session_state["map_done"] = True

        except Exception as exc:
            st.error(f"Mapping failed: {exc}")
            st.code(traceback.format_exc(), language="text")


# ===========================================================================
# PAGE: Write Back to Spec
# ===========================================================================

elif page == "Write Back to Spec":
    st.markdown("## Phase 3 - Write Back to Spec")
    st.info(
        "Populate Input Variables, Mapping Action, and Origin columns in your "
        "SDTM spec Excel. All original formatting is preserved. "
        "Review-tier rows are amber-highlighted. A change-log sheet is appended."
    )

    col_l, col_r = st.columns([1, 1])

    with col_l:
        st.markdown('<div class="card"><div class="card-title">New Study Spec</div>', unsafe_allow_html=True)
        wb_spec_upload = st.file_uploader(
            "New study SDTM spec Excel (blank Input Variables)",
            type=["xlsx", "xlsm"],
            key="wb_spec",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Mapping Results</div>', unsafe_allow_html=True)
        results_source = st.radio(
            "Results source",
            ["Upload mapping_results.xlsx", "Use results from Phase 2"],
            label_visibility="collapsed",
        )
        if results_source == "Upload mapping_results.xlsx":
            wb_results_upload = st.file_uploader(
                "mapping_results.xlsx from Phase 2",
                type=["xlsx"],
                key="wb_results",
            )
        else:
            wb_results_upload = None
            if st.session_state.get("map_done"):
                st.success("Phase 2 mapping results are ready.")
            else:
                st.warning("No mapping results in this session. Run Phase 2 first.")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_r:
        st.markdown('<div class="card"><div class="card-title">Write-Back Options</div>', unsafe_allow_html=True)
        populate_origin  = st.checkbox("Populate Origin column",         value=True)
        populate_action  = st.checkbox("Populate Mapping Action (blank only)", value=True)
        highlight_review = st.checkbox("Highlight review rows (amber)",  value=True)
        dry_run_mode     = st.checkbox(
            "Dry-run mode (preview changes without writing)",
            value=False,
            help="Shows what would change without modifying the spec file",
        )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">Origin Priority</div>', unsafe_allow_html=True)
        st.markdown(
            '<div style="font-size:12px;color:#8b949e;line-height:1.7">'
            '<span class="badge badge-direct">CRF</span> &nbsp;Priority 1 - highest<br>'
            '<span class="badge badge-info">Derived</span> &nbsp;Priority 2<br>'
            '<span class="badge badge-info">Protocol</span> &nbsp;Priority 3<br>'
            '<span class="badge badge-review">eDT</span> &nbsp;Priority 4<br>'
            '<span class="badge badge-unres">Assigned</span> &nbsp;Priority 5<br>'
            '<small>An origin is only overwritten by a higher-priority value.</small>'
            '</div>',
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    results_ready = (
        (results_source == "Upload mapping_results.xlsx" and wb_results_upload is not None)
        or (results_source != "Upload mapping_results.xlsx" and st.session_state.get("map_done"))
    )
    run_wb = st.button(
        "Dry-Run Preview" if dry_run_mode else "Write Back to Spec",
        disabled=(wb_spec_upload is None or not results_ready),
    )

    if run_wb:
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                spec_path = save_upload(wb_spec_upload, tmpdir)

                if wb_results_upload is not None:
                    results_path = save_upload(wb_results_upload, tmpdir)
                else:
                    results_path = Path(tmpdir) / "mapping_results.xlsx"
                    results_path.write_bytes(st.session_state["results_xlsx_bytes"])

                out_path = Path(tmpdir) / ("spec_preview.xlsx" if dry_run_mode else "spec_mapped.xlsx")

                st.markdown("### Writing...")
                result_path, log_lines = run_writeback_with_progress(
                    spec_path=spec_path,
                    results_path=results_path,
                    out_path=out_path,
                    highlight_review=highlight_review,
                    populate_origin=populate_origin,
                    populate_action=populate_action,
                    dry_run=dry_run_mode,
                    config_path=cfg_path_input,
                )

                if dry_run_mode:
                    st.warning(
                        "Dry-run complete. Check the log above for a preview of changes. "
                        "Uncheck Dry-run mode and re-run to apply changes."
                    )
                else:
                    st.success(
                        "Spec updated successfully. "
                        "Review rows are highlighted amber. "
                        "A change-log sheet has been appended."
                    )
                    file_download_button(out_path, "Download Updated Spec Excel")

        except Exception as exc:
            st.error(f"Write-back failed: {exc}")
            st.code(traceback.format_exc(), language="text")


# ===========================================================================
# PAGE: View Master
# ===========================================================================

elif page == "View Master":
    st.markdown("## View Master Mapping")

    col_l, col_r = st.columns([2, 1])
    with col_l:
        master_view_file = st.file_uploader(
            "Upload master_mapping.xlsx to explore",
            type=["xlsx"],
            key="master_view",
        )
    with col_r:
        if st.session_state.get("master_built"):
            if st.button("Load master from Phase 1"):
                st.session_state["master_view_bytes"] = st.session_state["master_xlsx_bytes"]

    view_bytes = None
    if master_view_file:
        view_bytes = master_view_file.read()
    elif st.session_state.get("master_view_bytes"):
        view_bytes = st.session_state["master_view_bytes"]

    if view_bytes:
        try:
            master_all = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_all",
                                       engine="openpyxl", dtype=object)
            master_top = pd.read_excel(io.BytesIO(view_bytes), sheet_name="master_top",
                                       engine="openpyxl", dtype=object)

            if "MASTER_CONFIDENCE" in master_all.columns:
                master_all["MASTER_CONFIDENCE"] = pd.to_numeric(
                    master_all["MASTER_CONFIDENCE"], errors="coerce"
                )

            # Metrics
            pills = (
                '<div class="metric-row">'
                + metric_html(master_all["SDTM_VARIABLE"].nunique() if not master_all.empty else 0, "SDTM Variables")
                + metric_html(master_all["DOMAIN"].nunique()        if not master_all.empty else 0, "Domains")
                + metric_html(len(master_all), "Total Rows")
                + metric_html(
                    int((master_all["MASTER_CONFIDENCE"] >= 0.82).sum()) if "MASTER_CONFIDENCE" in master_all.columns else 0,
                    "High Conf (>=82%)", "green"
                  )
                + '</div>'
            )
            st.markdown(pills, unsafe_allow_html=True)

            st.markdown("---")

            # Filter controls
            fc1, fc2, fc3 = st.columns([1, 1, 2])
            with fc1:
                domains = sorted(master_all["DOMAIN"].dropna().unique().tolist()) if not master_all.empty else []
                domain_filter = st.multiselect("Filter by Domain", options=domains, default=domains)
            with fc2:
                tier_filter = st.multiselect(
                    "Confidence tier",
                    options=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                    default=["High (>=82%)", "Medium (55-82%)", "Low (<55%)"],
                )
            with fc3:
                search_var = st.text_input("Search SDTM Variable", placeholder="e.g. AESTDTC")

            filtered = master_top.copy() if not master_top.empty else master_all.copy()
            if "DOMAIN" in filtered.columns and domain_filter:
                filtered = filtered[filtered["DOMAIN"].isin(domain_filter)]
            if search_var and "SDTM_VARIABLE" in filtered.columns:
                filtered = filtered[
                    filtered["SDTM_VARIABLE"].str.contains(search_var.upper(), na=False)
                ]
            if "MASTER_CONFIDENCE" in filtered.columns:
                conf = pd.to_numeric(filtered["MASTER_CONFIDENCE"], errors="coerce")
                masks = []
                if "High (>=82%)"    in tier_filter: masks.append(conf >= 0.82)
                if "Medium (55-82%)" in tier_filter: masks.append((conf >= 0.55) & (conf < 0.82))
                if "Low (<55%)"      in tier_filter: masks.append(conf < 0.55)
                if masks:
                    import functools
                    combined = functools.reduce(lambda a, b: a | b, masks)
                    filtered = filtered[combined]

            st.markdown(f"**{len(filtered)} rows shown**")
            display_cols = [
                c for c in
                ["DOMAIN","SDTM_VARIABLE","SDTM_LABEL","INPUT_VARIABLES",
                 "MAPPING_ACTION","ORIGIN","N_STUDIES","MASTER_CONFIDENCE",
                 "IS_SPONSOR_STD","SOURCE_FILES"]
                if c in filtered.columns
            ]
            st.dataframe(filtered[display_cols], use_container_width=True, hide_index=True)

        except Exception as exc:
            st.error(f"Could not read master mapping: {exc}")

    else:
        st.info("Upload a master_mapping.xlsx or build one in Phase 1.")


# ===========================================================================
# PAGE: Help
# ===========================================================================

elif page == "Help":
    st.markdown("## Help & Quick Reference")

    tab1, tab2, tab3, tab4 = st.tabs(["Workflow", "File Formats", "Thresholds", "CLI Usage"])

    with tab1:
        st.markdown("""
### Three-Phase Workflow

**Phase 1 - Build Master**

Upload every completed and QC-approved SDTM spec Excel file from previous studies.
The system extracts all `DOMAIN | SDTM_VARIABLE | Input Variables` mappings and
builds a frequency-weighted, recency-decayed confidence score for each.
Sponsor standard specs receive a 3x study-count boost so they always take priority.

Add studies incrementally using Append Mode - no need to rebuild from scratch each time.

---

**Phase 2 - Map New Study**

Upload the new study's raw variable catalog (typically a SAS PROC CONTENTS output
exported to Excel or CSV). The system:

1. Builds a group-aware index of the master mapping
2. Builds a TF-IDF label similarity index over raw variable labels
3. Scores every SDTM variable using a 4-signal composite scorer:
   - Name exact match (35%)
   - Name fuzzy similarity (20%)
   - Label TF-IDF cosine (25%)
   - Master confidence / frequency (20%)
4. Classifies each result as Direct, Review, or Unresolved

---

**Phase 3 - Write Back**

Upload the new study SDTM spec (blank Input Variables). The results from Phase 2
are written into the correct cells while preserving all original formatting.
Origin is written using priority: CRF > Derived > Protocol > eDT > Assigned.
Review rows are amber-highlighted for programmer attention.
        """)

    with tab2:
        st.markdown("""
### Expected File Formats

**Completed Study Spec (Phase 1 input)**
- Excel workbook with one sheet per SDTM domain
- Must have a TOC sheet with Dataset and Active columns
- Only domains where Active = Y/YES are processed
- Trial domains (TA TE TI TV TS TD) always excluded even if Active=Y
- Required columns per domain sheet: Variable, Input Variables, Mapping Action
- Optional columns: Label, Origin, Codelist, Core, SAS Type, SAS Length

**Raw Variable Catalog (Phase 2 input)**
- PROC CONTENTS output exported to Excel or CSV
- Required columns: MEMNAME (dataset), NAME (variable)
- Optional: LABEL, FORMAT, TYPE

**New Study Spec (Phase 3 input)**
- Same format as completed study spec
- Input Variables, Mapping Action, Origin columns should be blank
- The write-back populates them based on Phase 2 results
        """)

    with tab3:
        st.markdown("""
### Confidence Score & Thresholds

The composite score (0 to 1.0) combines four signals:

| Signal | Default Weight | Description |
|---|---|---|
| Name exact | 35% | Exact slug match between SDTM var name and raw var name |
| Name fuzzy | 20% | Best of seq_ratio / token_sort / token_set similarity |
| Label TF-IDF | 25% | Cosine similarity of variable labels |
| Master freq | 20% | Historical confidence from master_mapping |

**Thresholds (configurable in config.yaml and UI sliders):**

| Tier | Default | Action |
|---|---|---|
| Direct | >= 0.82 | Written to spec immediately; green in results |
| Review | >= 0.55 | Flagged for human review; amber in spec |
| Unresolved | < 0.55 | Not written; top-5 candidates listed |

**Partial-group penalty:** If a multi-token group (e.g. date+time) has only
some tokens found in the raw catalog, the group score is penalised proportionally.
Default penalty factor: 0.70 (configurable).
        """)

    with tab4:
        st.markdown("""
### CLI Usage (without the UI)

All phases are also available as standalone Python scripts:

```bash
# Phase 1: Build master from completed studies
python pipeline.py build \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --out     master_mapping.xlsx

# Append a new study to existing master
python pipeline.py build \\
    --specs    studies/study_c.xlsx \\
    --existing master_mapping.xlsx \\
    --out      master_mapping.xlsx

# Phase 2: Map new study
python pipeline.py map \\
    --master master_mapping.xlsx \\
    --raw    new_study/proc_contents.xlsx \\
    --spec   new_study/sdtm_spec.xlsx \\
    --out    new_study/mapping_results.xlsx

# Phase 3: Write-back
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx

# Dry-run preview
python pipeline.py writeback \\
    --spec    new_study/sdtm_spec.xlsx \\
    --results new_study/mapping_results.xlsx \\
    --out     new_study/sdtm_spec_mapped.xlsx \\
    --dry-run

# Full pipeline (all three phases)
python pipeline.py full \\
    --specs   studies/study_a.xlsx studies/study_b.xlsx \\
    --sponsor studies/sponsor_std_v3.xlsx \\
    --raw     new_study/proc_contents.xlsx \\
    --spec    new_study/sdtm_spec.xlsx
```
        """)
