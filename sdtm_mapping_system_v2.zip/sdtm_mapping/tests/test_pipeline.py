"""
tests/test_pipeline.py
======================
Integration tests for the SDTM Master Mapping System.
Covers all 6 core scenarios validated during development.

Run from the project root:
    python tests/test_pipeline.py
    python -m pytest tests/test_pipeline.py -v
"""

import sys
import os
import math
import tempfile
import unittest
from pathlib import Path
from openpyxl import Workbook

# Add src to path
SRC_DIR = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(SRC_DIR))

SAMPLE_DIR = Path(__file__).parent.parent / "sample_data"
CONFIG     = SRC_DIR / "config.yaml"


# ---------------------------------------------------------------------------
# Helpers to create test spec Excel files
# ---------------------------------------------------------------------------

def make_spec(path, domains_data, toc_extra=None):
    """Create a minimal spec Excel with TOC and domain sheets."""
    wb = Workbook()
    ws_toc = wb.active
    ws_toc.title = "TOC"
    ws_toc.append(["Dataset", "Active"])
    for dom in domains_data:
        ws_toc.append([dom, "Y"])
    if toc_extra:
        for row in toc_extra:
            ws_toc.append(row)
    for dom, rows in domains_data.items():
        ws = wb.create_sheet(dom)
        ws.append(["Dataset", "Variable", "Label", "Input Variables",
                   "Mapping Action", "Origin", "Core"])
        for r in rows:
            ws.append(r)
    wb.save(path)


def make_raw_catalog(path):
    """Create a minimal raw catalog (PROC CONTENTS style)."""
    import pandas as pd
    rows = [
        {"MEMNAME": "AE", "NAME": "AETERM",   "LABEL": "AE Term",          "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "AE", "NAME": "MDRSOC",   "LABEL": "System Organ Class","FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "AE", "NAME": "AESTDAT",  "LABEL": "Start Date",        "FORMAT": "DATE9.", "TYPE": "N"},
        {"MEMNAME": "AE", "NAME": "AESTTIM",  "LABEL": "Start Time",        "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "AE", "NAME": "AESEV",    "LABEL": "Severity",          "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "AE", "NAME": "AESER",    "LABEL": "Serious",           "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "DM", "NAME": "SUBJID",   "LABEL": "Subject ID",        "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "DM", "NAME": "SITEID",   "LABEL": "Site ID",           "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "DM", "NAME": "SEX",      "LABEL": "Sex",               "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "LB", "NAME": "LBTESTCD", "LABEL": "Test Code",         "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "LB", "NAME": "LBORRES",  "LABEL": "Original Result",   "FORMAT": "", "TYPE": "C"},
        {"MEMNAME": "LB", "NAME": "LBDAT",    "LABEL": "Lab Date",          "FORMAT": "DATE9.", "TYPE": "N"},
    ]
    pd.DataFrame(rows).to_excel(path, index=False)


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

class TestMasterBuilder(unittest.TestCase):
    """Tests for master_builder.py"""

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp    = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def _make_study_spec(self, name, include_trial=False):
        """Create a minimal study spec with AE and DM domains."""
        toc_extra = [["TA", "Y"], ["TE", "N"]] if include_trial else None
        path = self.tmp / name
        make_spec(path, {
            "DM": [
                ["DM", "STUDYID", "Study ID", "", "HARDCODE", "Assigned", "Required"],
                ["DM", "SUBJID",  "Subject",  "RAW.DM.SUBJID", "ASSIGN", "CRF", "Required"],
                ["DM", "SEX",     "Sex",      "RAW.DM.SEX",    "ASSIGN", "CRF", "Required"],
            ],
            "AE": [
                ["AE", "AETERM",  "AE Term",   "RAW.AE.AETERM",  "ASSIGN",          "CRF", "Required"],
                ["AE", "AESTDTC", "Start DTC", "RAW.AE.AESTDAT,RAW.AE.AESTTIM",
                 "ISO8601_DATETIME", "CRF", "Required"],
                ["AE", "AESEV",   "Severity",  "RAW.AE.AESEV",   "ASSIGN", "CRF", "Required"],
            ],
        }, toc_extra=toc_extra)
        return path

    def test_basic_build(self):
        """Master builds successfully from one study spec."""
        from master_builder import build_master_mapping
        spec  = self._make_study_spec("study1.xlsx")
        out   = self.tmp / "master.xlsx"
        master = build_master_mapping(
            spec_paths=[spec], out_path=out,
            config_path=CONFIG,
        )
        self.assertFalse(master.empty)
        self.assertIn("AE", master["DOMAIN"].values)
        self.assertIn("DM", master["DOMAIN"].values)

    def test_trial_domains_excluded(self):
        """Trial domains (TA, TE) are excluded even when Active=Y in TOC."""
        from master_builder import build_master_mapping
        spec   = self._make_study_spec("study_trial.xlsx", include_trial=True)
        out    = self.tmp / "master.xlsx"
        master = build_master_mapping(
            spec_paths=[spec], out_path=out,
            config_path=CONFIG,
        )
        domains = master["DOMAIN"].unique().tolist()
        self.assertNotIn("TA", domains, "TA should be excluded")
        self.assertNotIn("TE", domains, "TE should be excluded")

    def test_multi_study_confidence(self):
        """Mapping seen in 2 studies gets higher confidence than seen in 1."""
        from master_builder import build_master_mapping
        s1 = self._make_study_spec("s1.xlsx")
        s2 = self._make_study_spec("s2.xlsx")
        out = self.tmp / "master.xlsx"
        master = build_master_mapping(
            spec_paths=[s1, s2], out_path=out,
            config_path=CONFIG,
        )
        aeterm = master[
            (master["DOMAIN"] == "AE") &
            (master["SDTM_VARIABLE"] == "AETERM") &
            (master["RAW_VARIABLE"].str.contains("AETERM", na=False))
        ]
        self.assertFalse(aeterm.empty)
        self.assertEqual(int(aeterm.iloc[0]["N_STUDIES"]), 2)
        conf_2 = float(aeterm.iloc[0]["MASTER_CONFIDENCE"])
        # Single-study confidence
        out2 = self.tmp / "master2.xlsx"
        m2 = build_master_mapping(spec_paths=[s1], out_path=out2, config_path=CONFIG)
        single = m2[
            (m2["DOMAIN"] == "AE") & (m2["SDTM_VARIABLE"] == "AETERM")
        ]
        conf_1 = float(single.iloc[0]["MASTER_CONFIDENCE"]) if not single.empty else 0.0
        self.assertGreater(conf_2, conf_1, "2-study confidence should exceed 1-study")

    def test_group_aware_storage(self):
        """Multi-token Input Variables cell stored as a group."""
        from master_builder import build_master_mapping
        spec   = self._make_study_spec("s_group.xlsx")
        out    = self.tmp / "master.xlsx"
        master = build_master_mapping(
            spec_paths=[spec], out_path=out,
            config_path=CONFIG,
        )
        aestdtc = master[
            (master["DOMAIN"] == "AE") & (master["SDTM_VARIABLE"] == "AESTDTC")
        ]
        # Should have exactly 2 rows (date + time tokens)
        self.assertEqual(len(aestdtc), 2, "AESTDTC group should have 2 token rows")
        self.assertEqual(aestdtc.iloc[0]["GROUP_COUNT"], 2)
        # GROUP_SIG should be same for both rows
        self.assertEqual(
            aestdtc.iloc[0]["GROUP_SIG"],
            aestdtc.iloc[1]["GROUP_SIG"],
        )

    def test_append_mode(self):
        """Append mode grows the master without full rebuild."""
        from master_builder import build_master_mapping
        s1  = self._make_study_spec("s1.xlsx")
        out = self.tmp / "master.xlsx"
        m1  = build_master_mapping(spec_paths=[s1], out_path=out, config_path=CONFIG)

        # Create a second study with a new domain
        s2_path = self.tmp / "s2.xlsx"
        make_spec(s2_path, {
            "MH": [
                ["MH", "MHTERM", "MH Term", "RAW.MH.MHTERM", "ASSIGN", "CRF", "Required"],
            ]
        })
        out2 = self.tmp / "master2.xlsx"
        m2 = build_master_mapping(
            spec_paths=[s2_path],
            existing_master=out,
            out_path=out2,
            config_path=CONFIG,
        )
        self.assertGreater(len(m2), len(m1), "Appended master should be larger")
        self.assertIn("MH", m2["DOMAIN"].values, "MH domain should be present")

    def test_sponsor_priority(self):
        """Sponsor spec mapping appears first (IS_TOP_GROUP) over study mapping."""
        from master_builder import build_master_mapping
        # Study maps AETERM to RAW.AE.AETERMSTUDY
        s_path = self.tmp / "study.xlsx"
        make_spec(s_path, {
            "AE": [
                ["AE", "AETERM", "AE Term", "RAW.AE.AETERMSTUDY", "ASSIGN", "CRF", "Required"],
            ]
        })
        # Sponsor maps AETERM to RAW.AE.AETERM (canonical)
        sp_path = self.tmp / "sponsor.xlsx"
        make_spec(sp_path, {
            "AE": [
                ["AE", "AETERM", "AE Term", "RAW.AE.AETERM", "ASSIGN", "CRF", "Required"],
            ]
        })
        out = self.tmp / "master.xlsx"
        master = build_master_mapping(
            spec_paths=[s_path],
            sponsor_paths=[sp_path],
            out_path=out,
            config_path=CONFIG,
        )
        top = master[
            (master["DOMAIN"] == "AE") &
            (master["SDTM_VARIABLE"] == "AETERM") &
            (master["IS_TOP_GROUP"] == True)
        ]
        self.assertFalse(top.empty)
        # Sponsor mapping should be on top
        self.assertTrue(
            bool(top.iloc[0]["IS_SPONSOR_STD"]),
            "Top group should be from sponsor standard",
        )


class TestMapper(unittest.TestCase):
    """Tests for mapper.py"""

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp    = Path(self.tmpdir.name)
        # Build a reusable master
        from master_builder import build_master_mapping
        spec_path = self.tmp / "study.xlsx"
        make_spec(spec_path, {
            "DM": [
                ["DM", "STUDYID", "Study ID", "", "HARDCODE", "Assigned", "Required"],
                ["DM", "SUBJID",  "Subject",  "RAW.DM.SUBJID", "ASSIGN", "CRF", "Required"],
                ["DM", "SEX",     "Sex",      "RAW.DM.SEX",    "ASSIGN", "CRF", "Required"],
                ["DM", "AGE",     "Age",      "",              "DERIVE", "Derived", "Required"],
            ],
            "AE": [
                ["AE", "AETERM",  "AE Term",  "RAW.AE.AETERM", "ASSIGN", "CRF", "Required"],
                ["AE", "AEBODSYS","SOC",       "RAW.AE.MDRSOC", "ASSIGN", "CRF", "Required"],
                ["AE", "AESTDTC", "Start DTC","RAW.AE.AESTDAT,RAW.AE.AESTTIM",
                 "ISO8601_DATETIME", "CRF", "Required"],
                ["AE", "AESEQ",   "Sequence", "", "SEQNUM", "Derived", "Required"],
            ],
            "LB": [
                ["LB", "LBTESTCD","Test Code","RAW.LB.LBTESTCD","ASSIGN","eDT","Required"],
                ["LB", "LBORRES", "Result",   "RAW.LB.LBORRES", "ASSIGN","eDT","Required"],
                ["LB", "LBDTC",   "Lab DTC",  "RAW.LB.LBDAT,RAW.LB.LBTIM",
                 "ISO8601_DATETIME","eDT","Required"],
            ],
        })
        self.master_path = self.tmp / "master.xlsx"
        build_master_mapping(
            spec_paths=[spec_path], out_path=self.master_path,
            config_path=CONFIG,
        )
        # Build raw catalog
        self.raw_path = self.tmp / "raw.xlsx"
        make_raw_catalog(self.raw_path)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_direct_matches_returned(self):
        """Exact-name matches are classified as direct."""
        from mapper import run
        out = self.tmp / "results.xlsx"
        results = run(self.master_path, self.raw_path,
                      config_path=CONFIG, out_path=out)
        self.assertIn("direct", results)
        self.assertGreater(len(results["direct"]), 0)

    def test_protocol_vars_have_no_raw(self):
        """Protocol variables (STUDYID) should have empty RAW_VARIABLES_ASSIGNED."""
        from mapper import run
        out = self.tmp / "results.xlsx"
        results = run(self.master_path, self.raw_path,
                      config_path=CONFIG, out_path=out)
        direct = results["direct"]
        if not direct.empty:
            studyid_rows = direct[direct["SDTM_VARIABLE"] == "STUDYID"]
            if not studyid_rows.empty:
                self.assertEqual(
                    studyid_rows.iloc[0]["RAW_VARIABLES_ASSIGNED"], "",
                    "STUDYID should have no raw source",
                )

    def test_derived_vars_classified_direct(self):
        """Always-derived variables (AESEQ) should be in direct tier."""
        from mapper import run
        out = self.tmp / "results.xlsx"
        results = run(self.master_path, self.raw_path,
                      config_path=CONFIG, out_path=out)
        direct = results["direct"]
        if not direct.empty:
            aeseq = direct[direct["SDTM_VARIABLE"] == "AESEQ"]
            self.assertFalse(aeseq.empty, "AESEQ should be in direct tier")
            self.assertEqual(aeseq.iloc[0]["ORIGIN"], "Derived")

    def test_coverage_dataframe_returned(self):
        """Coverage dataframe has expected columns and one row per domain."""
        from mapper import run
        out = self.tmp / "results.xlsx"
        results = run(self.master_path, self.raw_path,
                      config_path=CONFIG, out_path=out)
        cov = results["coverage"]
        self.assertFalse(cov.empty)
        for col in ["DOMAIN", "TOTAL", "DIRECT", "REVIEW", "UNRESOLVED", "AUTO_PCT"]:
            self.assertIn(col, cov.columns)

    def test_output_excel_written(self):
        """Results Excel is written with expected sheets."""
        from mapper import run
        out = self.tmp / "results.xlsx"
        run(self.master_path, self.raw_path, config_path=CONFIG, out_path=out)
        self.assertTrue(out.exists(), "mapping_results.xlsx should be created")
        import pandas as pd
        xl = pd.ExcelFile(out, engine="openpyxl")
        for sheet in ["direct", "review", "unresolved", "unmapped_raw", "coverage"]:
            self.assertIn(sheet, xl.sheet_names)


class TestSpecWriteback(unittest.TestCase):
    """Tests for spec_writeback.py"""

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp    = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def _make_blank_spec(self):
        path = self.tmp / "blank_spec.xlsx"
        make_spec(path, {
            "AE": [
                ["AE", "AETERM",  "AE Term",   "", "", "", "Required"],
                ["AE", "AESTDTC", "Start DTC", "", "", "", "Required"],
                ["AE", "AESEQ",   "Sequence",  "", "", "", "Required"],
            ]
        })
        return path

    def _make_results(self):
        """Create a minimal mapping_results.xlsx."""
        import pandas as pd
        path = self.tmp / "results.xlsx"
        direct = pd.DataFrame([
            {
                "DOMAIN": "AE",
                "SDTM_VARIABLE": "AETERM",
                "SDTM_LABEL": "AE Term",
                "VAR_CLASS": "free_text",
                "RAW_VARIABLES_ASSIGNED": "RAW.AE.AETERM",
                "MAPPING_ACTION": "ASSIGN",
                "ORIGIN": "CRF",
                "ORIGIN_CONFIDENCE": 0.95,
                "COMPOSITE_SCORE": 0.92,
                "MATCH_TIER": "direct",
                "MATCH_PATH": "master_guided",
                "GROUP_COUNT": 1,
                "MASTER_CONF": 0.88,
                "LABEL_SIM": 0.71,
                "PARTIAL_FRAC": 1.0,
                "TOP_CANDIDATES": "",
            },
            {
                "DOMAIN": "AE",
                "SDTM_VARIABLE": "AESEQ",
                "SDTM_LABEL": "Sequence",
                "VAR_CLASS": "sequence",
                "RAW_VARIABLES_ASSIGNED": "",
                "MAPPING_ACTION": "DERIVE",
                "ORIGIN": "Derived",
                "ORIGIN_CONFIDENCE": 0.90,
                "COMPOSITE_SCORE": 1.0,
                "MATCH_TIER": "direct",
                "MATCH_PATH": "derived_rule",
                "GROUP_COUNT": 0,
                "MASTER_CONF": "",
                "LABEL_SIM": "",
                "PARTIAL_FRAC": "",
                "TOP_CANDIDATES": "",
            },
        ])
        review = pd.DataFrame([
            {
                "DOMAIN": "AE",
                "SDTM_VARIABLE": "AESTDTC",
                "SDTM_LABEL": "Start DTC",
                "VAR_CLASS": "timing",
                "RAW_VARIABLES_ASSIGNED": "RAW.AE.AESTDAT",
                "MAPPING_ACTION": "ISO8601_DATE",
                "ORIGIN": "CRF",
                "ORIGIN_CONFIDENCE": 0.85,
                "COMPOSITE_SCORE": 0.65,
                "MATCH_TIER": "review",
                "MATCH_PATH": "domain_fuzzy",
                "GROUP_COUNT": 1,
                "MASTER_CONF": 0.0,
                "LABEL_SIM": 0.55,
                "PARTIAL_FRAC": 1.0,
                "TOP_CANDIDATES": "",
            }
        ])
        with pd.ExcelWriter(path, engine="openpyxl") as w:
            direct.to_excel(w, sheet_name="direct", index=False)
            review.to_excel(w, sheet_name="review", index=False)
            pd.DataFrame().to_excel(w, sheet_name="unresolved", index=False)
        return path

    def test_dry_run_returns_none(self):
        """Dry-run mode returns None and writes no file."""
        from spec_writeback import write_back
        spec    = self._make_blank_spec()
        results = self._make_results()
        out     = self.tmp / "out.xlsx"
        result  = write_back(spec, results, out, dry_run=True,
                             config_path=str(CONFIG))
        self.assertIsNone(result, "Dry-run should return None")
        self.assertFalse(out.exists(), "Dry-run should not create output file")

    def test_actual_writeback_creates_file(self):
        """Write-back creates the output file."""
        from spec_writeback import write_back
        spec    = self._make_blank_spec()
        results = self._make_results()
        out     = self.tmp / "out.xlsx"
        result  = write_back(spec, results, out, dry_run=False,
                             config_path=str(CONFIG))
        self.assertIsNotNone(result)
        self.assertTrue(out.exists())

    def test_input_variables_populated(self):
        """Input Variables column is populated in the output spec."""
        import pandas as pd
        from spec_writeback import write_back
        spec    = self._make_blank_spec()
        results = self._make_results()
        out     = self.tmp / "out.xlsx"
        write_back(spec, results, out, dry_run=False, config_path=str(CONFIG))
        df = pd.read_excel(out, sheet_name="AE", engine="openpyxl", dtype=object)
        aeterm = df[df["Variable"] == "AETERM"]
        self.assertFalse(aeterm.empty)
        self.assertIn(
            "RAW.AE.AETERM",
            str(aeterm.iloc[0]["Input Variables"]),
        )

    def test_origin_populated(self):
        """Origin column is populated with CRF for AETERM."""
        import pandas as pd
        from spec_writeback import write_back
        spec    = self._make_blank_spec()
        results = self._make_results()
        out     = self.tmp / "out.xlsx"
        write_back(spec, results, out, dry_run=False,
                   populate_origin=True, config_path=str(CONFIG))
        df = pd.read_excel(out, sheet_name="AE", engine="openpyxl", dtype=object)
        aeterm = df[df["Variable"] == "AETERM"]
        if not aeterm.empty:
            self.assertEqual(str(aeterm.iloc[0].get("Origin", "")), "CRF")

    def test_changelog_sheet_appended(self):
        """A change-log sheet is appended to the updated workbook."""
        import pandas as pd
        from spec_writeback import write_back
        spec    = self._make_blank_spec()
        results = self._make_results()
        out     = self.tmp / "out.xlsx"
        write_back(spec, results, out, dry_run=False, config_path=str(CONFIG))
        xl = pd.ExcelFile(out, engine="openpyxl")
        changelog_sheets = [s for s in xl.sheet_names if s.startswith("_Writeback_")]
        self.assertGreater(len(changelog_sheets), 0, "Change-log sheet should be appended")


class TestSDTMKnowledge(unittest.TestCase):
    """Tests for sdtm_knowledge.py"""

    def test_classify_identifier(self):
        from sdtm_knowledge import classify_variable
        self.assertEqual(classify_variable("STUDYID", "DM"), "identifier")
        self.assertEqual(classify_variable("USUBJID", "DM"), "identifier")

    def test_classify_sequence(self):
        from sdtm_knowledge import classify_variable
        self.assertEqual(classify_variable("AESEQ",  "AE"), "sequence")
        self.assertEqual(classify_variable("LBSEQ",  "LB"), "sequence")

    def test_classify_timing(self):
        from sdtm_knowledge import classify_variable
        self.assertEqual(classify_variable("AESTDTC", "AE"), "timing")
        self.assertEqual(classify_variable("AEENDTC", "AE"), "timing")

    def test_classify_derived(self):
        from sdtm_knowledge import classify_variable
        self.assertEqual(classify_variable("CHG",  "LB"), "derived")
        self.assertEqual(classify_variable("PCHG", "LB"), "derived")

    def test_expand_label(self):
        from sdtm_knowledge import expand_sdtm_label
        result = expand_sdtm_label("AESTDTC", "AE")
        self.assertIn("adverse event", result)
        self.assertIn("start", result)
        self.assertIn("datetime", result)

    def test_infer_origin_crf(self):
        from sdtm_knowledge import infer_origin
        origin, conf = infer_origin(
            "AETERM", "AE", "ASSIGN",
            ["RAW.AE.AETERM"],
            crf_var_set={"AETERM"},
            als_var_set=set(),
            raw_dataset_set={"AE"},
        )
        self.assertEqual(origin, "CRF")
        self.assertGreater(conf, 0.90)

    def test_infer_origin_derived(self):
        from sdtm_knowledge import infer_origin
        origin, conf = infer_origin(
            "AESEQ", "AE", "SEQNUM",
            [],
            crf_var_set=set(), als_var_set=set(),
            raw_dataset_set={"AE"},
        )
        self.assertEqual(origin, "Derived")

    def test_infer_origin_protocol(self):
        from sdtm_knowledge import infer_origin
        origin, conf = infer_origin(
            "STUDYID", "DM", "HARDCODE",
            [],
            crf_var_set=set(), als_var_set=set(),
            raw_dataset_set={"DM"},
        )
        self.assertEqual(origin, "Protocol")

    def test_normalize_action(self):
        from sdtm_knowledge import normalize_action
        self.assertEqual(normalize_action("Assign"),           "ASSIGN")
        self.assertEqual(normalize_action("ISO 8601"),         "ISO8601_DATETIME")
        self.assertEqual(normalize_action("Drop"),             "DROP")
        self.assertEqual(normalize_action("Not Applicable"),   "DROP")
        self.assertEqual(normalize_action("Derive"),           "DERIVE")
        self.assertEqual(normalize_action("Hard Code"),        "HARDCODE")
        self.assertEqual(normalize_action(float("nan")),       "")


# ---------------------------------------------------------------------------
# End-to-end integration test
# ---------------------------------------------------------------------------

class TestEndToEnd(unittest.TestCase):
    """Full pipeline integration test using sample_data files."""

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp    = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_full_pipeline_with_sample_data(self):
        """
        Run all three phases using the bundled sample data files.
        Validates that the pipeline produces output without errors.
        """
        if not SAMPLE_DIR.exists():
            self.skipTest("sample_data directory not found")

        required = [
            SAMPLE_DIR / "study_a_with_trial.xlsx",
            SAMPLE_DIR / "study_b_spec.xlsx",
            SAMPLE_DIR / "sponsor_std_v3.xlsx",
            SAMPLE_DIR / "new_study_raw.xlsx",
            SAMPLE_DIR / "new_study_spec.xlsx",
        ]
        for f in required:
            if not f.exists():
                self.skipTest(f"Missing sample file: {f.name}")

        from master_builder import build_master_mapping
        from mapper         import run as map_run
        from spec_writeback import write_back

        # Phase 1
        master_path = self.tmp / "master.xlsx"
        master_df   = build_master_mapping(
            spec_paths=[
                SAMPLE_DIR / "study_a_with_trial.xlsx",
                SAMPLE_DIR / "study_b_spec.xlsx",
            ],
            sponsor_paths=[SAMPLE_DIR / "sponsor_std_v3.xlsx"],
            out_path=master_path,
            config_path=CONFIG,
        )
        self.assertFalse(master_df.empty)
        domains = master_df["DOMAIN"].unique().tolist()
        for trial in ["TA", "TE", "TI", "TV", "TS", "TD"]:
            self.assertNotIn(trial, domains, f"Trial domain {trial} should be excluded")

        # Phase 2
        results_path = self.tmp / "results.xlsx"
        results = map_run(
            master_path=master_path,
            raw_path=SAMPLE_DIR / "new_study_raw.xlsx",
            spec_path=str(SAMPLE_DIR / "new_study_spec.xlsx"),
            out_path=results_path,
            config_path=CONFIG,
        )
        self.assertIn("direct", results)
        self.assertGreater(len(results["direct"]), 0,
                           "Should have at least one direct match")
        self.assertTrue(results_path.exists())

        # Phase 3
        spec_out = self.tmp / "spec_out.xlsx"
        result   = write_back(
            spec_path=SAMPLE_DIR / "new_study_spec.xlsx",
            results_path=results_path,
            out_path=spec_out,
            dry_run=False,
            config_path=str(CONFIG),
        )
        self.assertIsNotNone(result)
        self.assertTrue(spec_out.exists())

        # Phase 3 dry-run
        dry_result = write_back(
            spec_path=SAMPLE_DIR / "new_study_spec.xlsx",
            results_path=results_path,
            out_path=self.tmp / "dry.xlsx",
            dry_run=True,
            config_path=str(CONFIG),
        )
        self.assertIsNone(dry_result, "Dry-run should return None")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Run with verbose output
    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    for cls in [
        TestSDTMKnowledge,
        TestMasterBuilder,
        TestMapper,
        TestSpecWriteback,
        TestEndToEnd,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
