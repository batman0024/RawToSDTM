"""
pipeline.py
===========
Single entry-point for the SDTM Master Mapping System.

Three commands:
  build      Build or update master_mapping.xlsx from completed study specs.
             Every completed study fed in improves future mapping accuracy.
  map        Map a new study raw catalog against the master.
  writeback  Write mapping results into the new study spec (format preserved).
  full       Run all three phases in sequence.

Quick-start examples:

  # Build master from two completed studies + sponsor standard
  python pipeline.py build \\
      --specs   studies/study_a.xlsx studies/study_b.xlsx \\
      --sponsor studies/sponsor_std_v3.xlsx \\
      --out     master_mapping.xlsx

  # Add one more completed study (incremental)
  python pipeline.py build \\
      --specs    studies/study_c.xlsx \\
      --existing master_mapping.xlsx \\
      --out      master_mapping.xlsx

  # Map new study
  python pipeline.py map \\
      --master master_mapping.xlsx \\
      --raw    new_study/proc_contents.xlsx \\
      --spec   new_study/sdtm_spec.xlsx \\
      --out    new_study/mapping_results.xlsx

  # Write-back into spec
  python pipeline.py writeback \\
      --spec    new_study/sdtm_spec.xlsx \\
      --results new_study/mapping_results.xlsx \\
      --out     new_study/sdtm_spec_mapped.xlsx

  # Write-back dry-run (preview only)
  python pipeline.py writeback \\
      --spec    new_study/sdtm_spec.xlsx \\
      --results new_study/mapping_results.xlsx \\
      --out     new_study/sdtm_spec_mapped.xlsx \\
      --dry-run

  # Full pipeline
  python pipeline.py full \\
      --specs   studies/study_a.xlsx studies/study_b.xlsx \\
      --sponsor studies/sponsor_std_v3.xlsx \\
      --raw     new_study/proc_contents.xlsx \\
      --spec    new_study/sdtm_spec.xlsx
"""

from __future__ import annotations

import sys
import argparse
import datetime as dt
from pathlib import Path

import pandas as pd

from logger import get_logger


# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------

def cmd_build(args, log):
    from master_builder import build_master_mapping
    dates = dict(
        item.split("=", 1) for item in (args.study_dates or []) if "=" in item
    )
    return build_master_mapping(
        spec_paths=args.specs or [],
        sponsor_paths=args.sponsor or [],
        existing_master=Path(args.existing) if args.existing else None,
        out_path=Path(args.master_out),
        config_path=Path(args.config),
        study_dates=dates,
    )


def cmd_map(args, log):
    from mapper import run
    return run(
        master_path=Path(args.master),
        raw_path=Path(args.raw),
        spec_path=args.spec,
        out_path=Path(args.results_out),
        config_path=Path(args.config),
    )


def cmd_writeback(args, log):
    from spec_writeback import write_back
    return write_back(
        spec_path=Path(args.spec),
        results_path=Path(args.results),
        out_path=Path(args.spec_out),
        highlight_review=not getattr(args, "no_highlight", False),
        populate_origin=not getattr(args, "no_origin",    False),
        populate_action=not getattr(args, "no_action",    False),
        dry_run=getattr(args, "dry_run", False),
        config_path=args.config,
    )


def cmd_full(args, log):
    """Run build -> map -> writeback in sequence."""
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")

    # Resolve output paths
    args.master_out  = getattr(args, "master_out",  None) or "master_mapping.xlsx"
    args.results_out = getattr(args, "results_out", None) or ("mapping_results_" + ts + ".xlsx")

    log.info("=" * 60)
    log.info("PHASE 1 - BUILD MASTER MAPPING")
    log.info("=" * 60)
    cmd_build(args, log)

    args.master = args.master_out

    log.info("=" * 60)
    log.info("PHASE 2 - MAP RAW VARIABLES")
    log.info("=" * 60)
    results = cmd_map(args, log)

    if args.spec:
        args.results = args.results_out
        stem         = Path(args.spec).stem
        args.spec_out = str(
            Path(args.spec).parent / (stem + "_mapped_" + ts + ".xlsx")
        )
        log.info("=" * 60)
        log.info("PHASE 3 - WRITE BACK TO SPEC")
        log.info("=" * 60)
        cmd_writeback(args, log)

    # Final summary
    direct_n = len(results.get("direct",     pd.DataFrame()))
    review_n = len(results.get("review",     pd.DataFrame()))
    unres_n  = len(results.get("unresolved", pd.DataFrame()))
    total    = direct_n + review_n + unres_n

    log.info("=" * 60)
    log.info("PIPELINE COMPLETE")
    log.info("=" * 60)
    if total:
        log.info("  Auto-accepted (direct): %5d  (%d%%)", direct_n, round(100 * direct_n / total))
        log.info("  Needs review:           %5d  (%d%%)", review_n, round(100 * review_n / total))
        log.info("  Unresolved:             %5d  (%d%%)", unres_n,  round(100 * unres_n  / total))
        log.info("  Total SDTM variables:   %5d",          total)
    log.info("  master_mapping:    %s", args.master_out)
    log.info("  mapping_results:   %s", args.results_out)
    if args.spec:
        log.info("  updated spec:      %s", args.spec_out)


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        prog="pipeline",
        description="SDTM Master Mapping System",
    )
    ap.add_argument("--config", default="config.yaml")

    sub = ap.add_subparsers(dest="command", required=True)

    # build
    pb = sub.add_parser("build", help="Build master mapping from completed study specs")
    pb.add_argument("--specs",       nargs="+", required=True)
    pb.add_argument("--sponsor",     nargs="*", default=[])
    pb.add_argument("--existing",    default=None)
    pb.add_argument("--master-out",  dest="master_out", default="master_mapping.xlsx")
    pb.add_argument("--study-dates", nargs="*", dest="study_dates", default=[])

    # map
    pm = sub.add_parser("map", help="Map new study raw catalog to SDTM")
    pm.add_argument("--master",      required=True)
    pm.add_argument("--raw",         required=True)
    pm.add_argument("--spec",        default=None)
    pm.add_argument("--results-out", dest="results_out", default="mapping_results.xlsx")

    # writeback
    pw = sub.add_parser("writeback", help="Write mapping results into spec Excel")
    pw.add_argument("--spec",         required=True)
    pw.add_argument("--results",      required=True)
    pw.add_argument("--spec-out",     dest="spec_out", required=True)
    pw.add_argument("--no-origin",    action="store_true")
    pw.add_argument("--no-action",    action="store_true")
    pw.add_argument("--no-highlight", action="store_true")
    pw.add_argument("--dry-run",      action="store_true")

    # full
    pf = sub.add_parser("full", help="Run complete pipeline (build + map + writeback)")
    pf.add_argument("--specs",        nargs="+", required=True)
    pf.add_argument("--sponsor",      nargs="*", default=[])
    pf.add_argument("--existing",     default=None)
    pf.add_argument("--raw",          required=True)
    pf.add_argument("--spec",         default=None)
    pf.add_argument("--master-out",   dest="master_out",  default="master_mapping.xlsx")
    pf.add_argument("--results-out",  dest="results_out", default=None)
    pf.add_argument("--study-dates",  nargs="*", dest="study_dates", default=[])
    pf.add_argument("--no-origin",    action="store_true")
    pf.add_argument("--no-action",    action="store_true")
    pf.add_argument("--no-highlight", action="store_true")
    pf.add_argument("--dry-run",      action="store_true")

    args = ap.parse_args()

    log = get_logger()

    dispatch = {
        "build":     cmd_build,
        "map":       cmd_map,
        "writeback": cmd_writeback,
        "full":      cmd_full,
    }
    dispatch[args.command](args, log)


if __name__ == "__main__":
    main()
