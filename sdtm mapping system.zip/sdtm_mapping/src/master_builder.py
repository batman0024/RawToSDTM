"""
master_builder.py
=================
Build or incrementally update master_mapping.xlsx from completed study specs.

Key design points:
  - TOC-first: only processes sheets where Active = Y/YES in TOC sheet
  - Trial domains (TA TE TI TV TS TD) excluded even if Active = Y
  - Group-aware: multi-variable Input Variable cells are stored as
    ordered groups (GROUP_SIG, GROUP_POSITION, GROUP_TOKENS)
  - Conflict resolution: sponsor_priority (newest sponsor standard version
    wins) or most_frequent (N_STUDIES wins, sponsor gets spon_boost_factor)
  - Sponsor versioning: higher VERSION_NUM in sponsor spec supersedes lower
  - Incremental append: pass --existing to add studies without full rebuild
  - All strings are plain ASCII; no Unicode in output or source

Usage:
    python master_builder.py \\
        --specs   studies/study_a.xlsx studies/study_b.xlsx \\
        --sponsor studies/sponsor_std_v3.xlsx \\
        --out     master_mapping.xlsx \\
        --config  config.yaml

    # Append mode: add a new completed study to existing master
    python master_builder.py \\
        --specs   studies/study_c.xlsx \\
        --existing master_mapping.xlsx \\
        --out     master_mapping.xlsx
"""

from __future__ import annotations

import re
import sys
import math
import hashlib
import warnings
import datetime as dt
import argparse
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yaml
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from sdtm_knowledge import normalize_action
from logger import get_logger


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _norm(s):
    """Uppercase, collapse whitespace, return empty string for null."""
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip()).upper()


def _slug(s):
    """Alphanumeric uppercase only - used as comparison key."""
    return re.sub(r"[^A-Z0-9]", "", _norm(s))


def _load_cfg(p):
    with open(p) as f:
        return yaml.safe_load(f)


def _resolve_col(df, aliases):
    """Return first DataFrame column that matches any alias (case-insensitive)."""
    lc = {c.lower(): c for c in df.columns}
    for a in aliases:
        if a.lower() in lc:
            return lc[a.lower()]
    for a in aliases:
        for col_lower, col_orig in lc.items():
            if a.lower() in col_lower:
                return col_orig
    return None


def split_raw_inputs(cell_value):
    """
    Parse an Input Variables cell into an ordered list of raw variable tokens.
    Preserves position (position 1 = date, position 2 = time, etc.).
    Strips leading RAW. prefix; stores as DATASET.VARIABLE or bare VARIABLE.
    Returns: list of strings, deduplicated, order preserved.
    """
    if cell_value is None or (isinstance(cell_value, float) and math.isnan(cell_value)):
        return []
    s = str(cell_value).strip()
    if not s or _norm(s) in ("N/A", "NA", "NONE", "-", "."):
        return []

    parts = re.split(r"[,;\|\+\n\r]+", s)
    result = []
    seen   = set()
    for p in parts:
        p = p.strip()
        if not p:
            continue
        up = p.upper()
        if up.startswith("SDTM."):
            tok = up
        elif up.startswith("RAW."):
            tok = up[4:]
        else:
            tok = up
        if tok and tok not in seen:
            seen.add(tok)
            result.append(tok)
    return result


# ---------------------------------------------------------------------------
# TOC reader
# ---------------------------------------------------------------------------

# Sheet names recognised as the TOC (all lowercase for comparison)
TOC_SHEET_NAMES = {
    "toc", "table of contents", "index", "overview",
    "datasets", "domain list", "domain summary", "contents",
    "dataset list", "domain overview",
}

# Column name aliases for the Dataset/Domain column in the TOC
TOC_DATASET_ALIASES = [
    "Dataset", "Domain", "SDTM Dataset", "SDTM Domain",
    "Table", "Datasets", "Dataset Name", "Domain Name",
    "Target Dataset", "SDTM Datasets", "Study Dataset",
]

# Column name aliases for the Active/Include column in the TOC
TOC_ACTIVE_ALIASES = [
    "Active", "Include", "Included", "Planned", "Flag",
    "Y/N", "Status", "In Scope", "Produce", "Generate",
    "Active Flag", "Included Flag", "In-Scope", "Produce Dataset",
    "Active?", "Include?",
]

# Values (normalised upper) treated as Active = True
ACTIVE_TRUTHY = (
    "Y", "YES", "TRUE", "1", "X",
    "ACTIVE", "INCLUDE", "PLANNED", "PRODUCE",
    "IN SCOPE", "IN-SCOPE", "INCLUDED", "GENERATE",
)


def read_toc_active_domains(xl, dataset_aliases, trial_domains, log):
    """
    Locate and parse the TOC sheet; return active non-trial domain names.

    Returns:
        active_domains (set of uppercase domain strings),
        toc_found      (bool)
    """
    toc_sheet = None
    for sn in xl.sheet_names:
        sn_l = sn.strip().lower()
        if sn_l in TOC_SHEET_NAMES:
            toc_sheet = sn
            break
    if toc_sheet is None:
        for sn in xl.sheet_names:
            sn_l = sn.strip().lower()
            if any(tok in sn_l for tok in ("toc", "table of content", "domain list")):
                toc_sheet = sn
                break

    if toc_sheet is None:
        return set(), False

    try:
        tdf = xl.parse(toc_sheet, dtype=object)
    except Exception as exc:
        log.warning("Cannot read TOC sheet '%s': %s", toc_sheet, exc)
        return set(), True

    if tdf.empty:
        return set(), True

    all_ds_aliases = list(dict.fromkeys(dataset_aliases + TOC_DATASET_ALIASES))
    ds_col  = _resolve_col(tdf, all_ds_aliases)
    act_col = _resolve_col(tdf, TOC_ACTIVE_ALIASES)

    if ds_col is None:
        log.warning(
            "TOC sheet '%s' found but no Dataset/Domain column detected. "
            "Columns present: %s",
            toc_sheet, tdf.columns.tolist(),
        )
        return set(), True

    active_domains   = set()
    skipped_inactive = []
    skipped_trial    = []

    for _, row in tdf.iterrows():
        domain = _norm(row.get(ds_col))
        if not domain:
            continue

        if act_col is not None:
            flag = _norm(row.get(act_col))
            is_active = any(
                flag == prefix or flag.startswith(prefix + " ")
                for prefix in ACTIVE_TRUTHY
            )
        else:
            is_active = True

        if not is_active:
            skipped_inactive.append(domain)
            continue

        if domain in trial_domains:
            skipped_trial.append(domain)
            continue

        active_domains.add(domain)

    msg_parts = [
        "TOC '%s': %d active domains" % (toc_sheet, len(active_domains))
    ]
    if skipped_inactive:
        msg_parts.append("inactive: %s" % skipped_inactive)
    if skipped_trial:
        msg_parts.append("trial (excluded): %s" % skipped_trial)
    log.info("    " + " | ".join(msg_parts))

    return active_domains, True


# ---------------------------------------------------------------------------
# Sheet reader
# ---------------------------------------------------------------------------

def read_spec_sheet(xl, sheet_name, domain_name, aliases,
                    source_file, study_date, is_sponsor):
    """
    Read one domain sheet from a spec workbook.
    Returns a DataFrame with one row per raw variable token, grouped.
    """
    try:
        df = xl.parse(sheet_name, dtype=object)
    except Exception as exc:
        return pd.DataFrame()

    if df.empty or len(df) < 1:
        return pd.DataFrame()

    # Detect header row: check column names first, then scan data rows
    var_aliases_lower = [a.lower() for a in aliases.get("variable", ["variable"])]
    col_names_lower   = [str(c).strip().lower() for c in df.columns]

    if any(a in col_names_lower for a in var_aliases_lower):
        pass  # header is already row 0
    else:
        hdr = None
        for i in range(min(15, len(df))):
            rv = [str(v).strip().lower() for v in df.iloc[i].values if pd.notna(v)]
            if any(a in rv for a in var_aliases_lower):
                hdr = i
                break
        if hdr is None:
            return pd.DataFrame()
        df = xl.parse(sheet_name, header=hdr, dtype=object)
        if df is None or df.empty:
            return pd.DataFrame()

    def rc(key):
        return _resolve_col(df, aliases.get(key, [key]))

    var_col = rc("variable")
    if var_col is None:
        return pd.DataFrame()

    rows = []
    for _, r in df.iterrows():
        var = _norm(r.get(var_col))
        if not var:
            continue

        ds_c   = rc("dataset")
        domain = _norm(r.get(ds_c)) if ds_c else domain_name.upper()
        if not domain:
            domain = domain_name.upper()

        # Skip trial domains at row level as well (belt-and-suspenders)
        if domain in {"TA", "TE", "TI", "TV", "TS", "TD"}:
            continue

        lbl_c  = rc("label")
        act_c  = rc("mapping_action")
        inp_c  = rc("input_variable")
        orig_c = rc("origin")
        cl_c   = rc("codelist")
        core_c = rc("core")
        st_c   = rc("sas_type")
        sl_c   = rc("sas_length")

        action_raw  = r.get(act_c) if act_c else None
        action      = normalize_action(action_raw)
        raw_tokens  = split_raw_inputs(r.get(inp_c) if inp_c else None)

        base = {
            "DOMAIN":          domain,
            "SDTM_VARIABLE":   var,
            "SDTM_LABEL":      _norm(r.get(lbl_c)) if lbl_c else "",
            "MAPPING_ACTION":  action,
            "ACTION_ORIGINAL": _norm(action_raw),
            "ORIGIN":          _norm(r.get(orig_c)) if orig_c else "",
            "CODELIST":        _norm(r.get(cl_c)) if cl_c else "",
            "CORE":            _norm(r.get(core_c)) if core_c else "",
            "SAS_TYPE":        _norm(r.get(st_c)) if st_c else "",
            "SAS_LENGTH":      _norm(r.get(sl_c)) if sl_c else "",
            "SOURCE_FILE":     source_file,
            "SOURCE_SHEET":    sheet_name,
            "STUDY_DATE":      study_date,
            "IS_SPONSOR_STD":  is_sponsor,
        }

        if raw_tokens:
            n          = len(raw_tokens)
            group_sig  = "|".join(sorted(raw_tokens))
            group_hash = hashlib.md5(
                (domain + "|" + var + "|" + group_sig).encode("ascii", errors="replace")
            ).hexdigest()[:8]
            tokens_str = "|".join(raw_tokens)  # ordered, pipe-separated

            for pos, tok in enumerate(raw_tokens, start=1):
                rows.append(dict(
                    base,
                    RAW_VARIABLE=tok,
                    GROUP_SIG=group_sig,
                    GROUP_HASH=group_hash,
                    GROUP_POSITION=pos,
                    GROUP_COUNT=n,
                    GROUP_TOKENS=tokens_str,
                ))
        else:
            rows.append(dict(
                base,
                RAW_VARIABLE="",
                GROUP_SIG="",
                GROUP_HASH="",
                GROUP_POSITION=0,
                GROUP_COUNT=0,
                GROUP_TOKENS="",
            ))

    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Spec file processor
# ---------------------------------------------------------------------------

def process_spec_file(spec_path, cfg, study_date, is_sponsor, log):
    """
    Process one spec Excel workbook.
    Returns a DataFrame of all extracted mapping rows.
    """
    log.info("  Processing: %s", spec_path.name)
    bc         = cfg.get("master_build", {})
    aliases    = bc.get("column_aliases", {})
    skip_lower = {s.lower() for s in bc.get("skip_sheets", [])}

    TRIAL_DOMAINS = {"TA", "TE", "TI", "TV", "TS", "TD"}
    extra_excl    = {d.upper() for d in bc.get("exclude_domains", [])}
    all_excluded  = TRIAL_DOMAINS | extra_excl

    try:
        xl = pd.ExcelFile(spec_path, engine="openpyxl")
    except Exception as exc:
        log.error("    Cannot open %s: %s", spec_path.name, exc)
        return pd.DataFrame()

    # Step 1: read TOC to get Active=Y domains
    active_domains, toc_found = read_toc_active_domains(
        xl,
        dataset_aliases=aliases.get("dataset", ["Dataset"]),
        trial_domains=all_excluded,
        log=log,
    )

    if not toc_found:
        log.warning(
            "    No TOC sheet found in %s. "
            "Processing all non-excluded sheets.",
            spec_path.name,
        )

    # Step 2: decide which sheets to process
    sheets_to_process = []
    for sn in xl.sheet_names:
        sn_clean = sn.strip()
        sn_upper = sn_clean.upper()
        sn_lower = sn_clean.lower()

        if sn_lower in skip_lower:
            continue
        if sn_upper in all_excluded:
            continue

        if toc_found:
            slug_sn = _slug(sn_upper)
            matched = next(
                (dom for dom in active_domains if _slug(dom) == slug_sn),
                None,
            )
            if matched is None:
                continue
            domain = matched
        else:
            domain = sn_upper

        sheets_to_process.append((sn_clean, domain))

    log.info(
        "    Sheets approved: %s",
        [s[1] for s in sheets_to_process],
    )

    # Step 3: read each approved sheet
    frames = []
    for sn, domain in sheets_to_process:
        frame = read_spec_sheet(
            xl, sn, domain, aliases, spec_path.name, study_date, is_sponsor,
        )
        if not frame.empty:
            frames.append(frame)
            rwr = frame[frame["RAW_VARIABLE"] != ""]
            log.info(
                "    [%-8s] %3d vars | %3d groups | %3d raw tokens",
                domain,
                frame["SDTM_VARIABLE"].nunique(),
                rwr["GROUP_HASH"].nunique(),
                len(rwr),
            )
        else:
            log.info("    [%-8s] no rows extracted", domain)

    if not frames:
        log.warning("    Nothing extracted from %s", spec_path.name)
        return pd.DataFrame()

    return pd.concat(frames, ignore_index=True)


# ---------------------------------------------------------------------------
# Master consolidation
# ---------------------------------------------------------------------------

def _freq_weight(n, max_n):
    if max_n == 0:
        return 0.0
    return math.log1p(n) / math.log1p(max_n)


def _recency_weight(date_str, decay_y, decay_f):
    try:
        age = (
            dt.datetime.now() - dt.datetime.strptime(date_str, "%Y-%m-%d")
        ).days / 365.25
        return decay_f ** max(0.0, age - decay_y)
    except Exception:
        return 0.80


def build_master(raw_df, cfg):
    """
    Consolidate all extracted rows into the master mapping table.
    Groups (multi-token inputs) are identified by GROUP_SIG.
    Confidence is computed at the group level.
    """
    if raw_df.empty:
        return pd.DataFrame()

    bc       = cfg.get("master_build", {})
    strategy = bc.get("conflict_strategy", "sponsor_priority")
    decay_y  = bc.get("recency_decay_years", 3)
    decay_f  = bc.get("recency_decay_factor", 0.85)
    spon_b   = bc.get("sponsor_boost_factor", 3.0)

    df = raw_df.copy()
    df["IS_SPONSOR_STD"] = df["IS_SPONSOR_STD"].fillna(False).astype(bool)

    # Aggregate at group level: (DOMAIN, SDTM_VARIABLE, GROUP_SIG)
    group_keys = ["DOMAIN", "SDTM_VARIABLE", "GROUP_SIG"]

    def agg_group(g):
        files    = g["SOURCE_FILE"].dropna().unique().tolist()
        dates    = g["STUDY_DATE"].dropna().tolist()
        actions  = g["MAPPING_ACTION"].dropna().tolist()
        origins  = g["ORIGIN"].dropna().tolist()
        labels   = g["SDTM_LABEL"].dropna().tolist()
        spon     = bool(g["IS_SPONSOR_STD"].any())
        n_studies = g["SOURCE_FILE"].nunique()

        rec_vals = [_recency_weight(d, decay_y, decay_f) for d in dates if d]
        rec_w    = float(np.mean(rec_vals)) if rec_vals else 0.80

        # Reconstruct ordered token list from position info
        tok_rows   = g.sort_values("GROUP_POSITION")
        raw_toks   = tok_rows["RAW_VARIABLE"].tolist()

        # Deduplicate preserving order
        seen_t, deduped_t = set(), []
        for t in raw_toks:
            if t is None or (isinstance(t, float) and math.isnan(t)):
                continue
            ts = str(t).strip()
            if ts and ts not in seen_t:
                seen_t.add(ts)
                deduped_t.append(ts)

        group_count = max(int(g["GROUP_COUNT"].max() or 0), len(deduped_t))
        tokens_str  = "|".join(deduped_t)

        action_vote = (
            pd.Series(actions).value_counts().index[0]
            if actions else ""
        )

        return pd.Series({
            "SDTM_LABEL":      labels[0] if labels else "",
            "MAPPING_ACTION":  action_vote,
            "ACTION_VOTES":    "|".join(sorted(set(str(a) for a in actions))),
            "ORIGIN":          origins[0] if origins else "",
            "GROUP_COUNT":     group_count,
            "GROUP_TOKENS":    tokens_str,
            "N_STUDIES":       n_studies,
            "N_TOTAL":         len(g["SOURCE_FILE"].unique()),
            "AVG_RECENCY_WT":  round(rec_w, 4),
            "IS_SPONSOR_STD":  spon,
            "SOURCE_FILES":    "|".join(sorted(files)),
        })

    grouped = df.groupby(group_keys, dropna=False).apply(agg_group).reset_index()

    # Carry forward scalar columns from first matching row
    for col in ["CODELIST", "CORE", "SAS_TYPE", "SAS_LENGTH"]:
        fv = df.groupby(group_keys, dropna=False)[col].first().reset_index()
        grouped = grouped.merge(fv, on=group_keys, how="left")

    # Frequency and recency confidence
    max_n = int(grouped["N_STUDIES"].max() or 1)
    grouped["FREQ_WEIGHT"] = grouped["N_STUDIES"].apply(
        lambda n: _freq_weight(n, max_n)
    )

    n_equiv = (
        grouped["N_STUDIES"]
        + grouped["IS_SPONSOR_STD"].apply(lambda x: spon_b if x else 0.0)
    )
    max_eq  = float(n_equiv.max() or 1)
    grouped["FREQ_WEIGHT_BOOSTED"] = n_equiv.apply(
        lambda n: _freq_weight(n, max_eq)
    )

    grouped["MASTER_CONFIDENCE"] = (
        grouped["FREQ_WEIGHT_BOOSTED"] * 0.60
        + grouped["AVG_RECENCY_WT"]    * 0.25
        + (grouped["N_STUDIES"] / (grouped["N_STUDIES"] + 5)) * 0.15
    ).clip(0.0, 1.0).round(4)

    # Sort: sponsor_priority puts sponsor rows on top for same SDTM var
    if strategy == "sponsor_priority":
        grouped["_sort"] = (
            grouped["IS_SPONSOR_STD"].astype(int) * 10.0
            + grouped["MASTER_CONFIDENCE"]
        )
        grouped = grouped.sort_values(
            ["DOMAIN", "SDTM_VARIABLE", "_sort"],
            ascending=[True, True, False],
        ).drop(columns=["_sort"])
    else:
        grouped = grouped.sort_values(
            ["DOMAIN", "SDTM_VARIABLE", "MASTER_CONFIDENCE"],
            ascending=[True, True, False],
        )
    grouped = grouped.reset_index(drop=True)

    # IS_TOP_GROUP: best group per SDTM variable
    grouped["IS_TOP_GROUP"] = False
    top_idx = grouped.groupby(["DOMAIN", "SDTM_VARIABLE"])["MASTER_CONFIDENCE"].idxmax()
    grouped.loc[top_idx, "IS_TOP_GROUP"] = True

    # Expand back to one row per raw variable token
    # (groups stay linked by GROUP_SIG for mapper lookups)
    expanded = []
    for _, gr in grouped.iterrows():
        tokens = [t for t in (gr["GROUP_TOKENS"] or "").split("|") if t]
        if not tokens:
            expanded.append(dict(gr.to_dict(), RAW_VARIABLE="", GROUP_POSITION=0))
        else:
            for pos, tok in enumerate(tokens, start=1):
                expanded.append(dict(gr.to_dict(), RAW_VARIABLE=tok, GROUP_POSITION=pos))

    result = pd.DataFrame(expanded)
    result["MAP_ID"] = (
        result["DOMAIN"]         + "|"
        + result["SDTM_VARIABLE"] + "|"
        + result["GROUP_SIG"]     + "|"
        + result["GROUP_POSITION"].astype(str)
    )

    col_order = [
        "DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL",
        "RAW_VARIABLE", "GROUP_SIG", "GROUP_POSITION", "GROUP_COUNT", "GROUP_TOKENS",
        "MAPPING_ACTION", "ACTION_VOTES", "ORIGIN",
        "CODELIST", "CORE", "SAS_TYPE", "SAS_LENGTH",
        "N_STUDIES", "N_TOTAL", "FREQ_WEIGHT", "AVG_RECENCY_WT",
        "MASTER_CONFIDENCE", "IS_TOP_GROUP", "IS_SPONSOR_STD",
        "SOURCE_FILES", "MAP_ID",
    ]
    return result[[c for c in col_order if c in result.columns]]


# ---------------------------------------------------------------------------
# Writer
# ---------------------------------------------------------------------------

def write_master(master_df, raw_df, out_path, log):
    """Write master_mapping.xlsx with styled multi-sheet workbook."""
    top_raw = (
        master_df[master_df["IS_TOP_GROUP"]]
        .groupby(["DOMAIN", "SDTM_VARIABLE"])
        .apply(lambda g: pd.Series({
            "SDTM_LABEL":        g["SDTM_LABEL"].iloc[0],
            "INPUT_VARIABLES":   ", ".join(
                ("RAW." + t if not t.startswith("SDTM.") else t)
                for t in g.sort_values("GROUP_POSITION")["RAW_VARIABLE"].tolist()
                if t
            ),
            "GROUP_COUNT":       int(g["GROUP_COUNT"].iloc[0]),
            "MAPPING_ACTION":    g["MAPPING_ACTION"].iloc[0],
            "ORIGIN":            g["ORIGIN"].iloc[0],
            "N_STUDIES":         int(g["N_STUDIES"].iloc[0]),
            "MASTER_CONFIDENCE": float(g["MASTER_CONFIDENCE"].iloc[0]),
            "IS_SPONSOR_STD":    bool(g["IS_SPONSOR_STD"].iloc[0]),
            "SOURCE_FILES":      g["SOURCE_FILES"].iloc[0],
        }))
        .reset_index()
    )

    dom_sum = (
        master_df[master_df["IS_TOP_GROUP"]]
        .groupby("DOMAIN")
        .agg(
            SDTM_VARS        =("SDTM_VARIABLE", "nunique"),
            MULTI_INPUT_VARS =("GROUP_COUNT", lambda x: int((x > 1).sum())),
            AVG_CONF         =("MASTER_CONFIDENCE", "mean"),
            HIGH_CONF_ROWS   =("MASTER_CONFIDENCE", lambda x: int((x >= 0.70).sum())),
        )
        .reset_index()
        .round({"AVG_CONF": 3})
    )

    overall = pd.DataFrame([
        {"Metric": "Total SDTM Variables",    "Value": master_df["SDTM_VARIABLE"].nunique()},
        {"Metric": "Total Groups",             "Value": master_df[["DOMAIN", "SDTM_VARIABLE", "GROUP_SIG"]].drop_duplicates().shape[0]},
        {"Metric": "Multi-token Groups",       "Value": int(master_df[master_df["GROUP_COUNT"] > 1]["GROUP_SIG"].nunique())},
        {"Metric": "Domains Covered",          "Value": master_df["DOMAIN"].nunique()},
        {"Metric": "Source Studies",           "Value": raw_df["SOURCE_FILE"].nunique()},
        {"Metric": "High Confidence (>=0.70)", "Value": int((master_df["MASTER_CONFIDENCE"] >= 0.70).sum())},
        {"Metric": "Sponsor-Std Rows",         "Value": int((master_df["IS_SPONSOR_STD"] == True).sum())},
    ])

    log_cols = [
        "DOMAIN", "SDTM_VARIABLE", "RAW_VARIABLE",
        "GROUP_SIG", "GROUP_POSITION", "GROUP_COUNT", "GROUP_TOKENS",
        "MAPPING_ACTION", "SOURCE_FILE", "SOURCE_SHEET",
        "STUDY_DATE", "IS_SPONSOR_STD",
    ]
    extr_log = raw_df[[c for c in log_cols if c in raw_df.columns]].copy()

    fill_h = PatternFill("solid", fgColor="1F3864")
    font_h = Font(bold=True, color="FFFFFF", size=10)
    f_green = PatternFill("solid", fgColor="E2EFDA")
    f_amber = PatternFill("solid", fgColor="FFF2CC")
    f_red   = PatternFill("solid", fgColor="FFE0E0")

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        top_raw.to_excel(writer,   sheet_name="master_top",      index=False)
        master_df.to_excel(writer, sheet_name="master_all",      index=False)
        dom_sum.to_excel(writer,   sheet_name="domain_summary",  index=False)
        overall.to_excel(writer,   sheet_name="overall_summary", index=False)
        extr_log.to_excel(writer,  sheet_name="extraction_log",  index=False)

        wb = writer.book
        for sn in ["master_top", "master_all"]:
            if sn not in wb.sheetnames:
                continue
            ws = wb[sn]
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = fill_h
                cell.font = font_h
                cell.alignment = Alignment(horizontal="center")

            conf_ci = next(
                (i for i, c in enumerate(ws[1], 1) if str(c.value) == "MASTER_CONFIDENCE"),
                None,
            )
            if conf_ci:
                for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
                    try:
                        v = float(row[conf_ci - 1].value or 0)
                        row[conf_ci - 1].fill = (
                            f_green if v >= 0.82 else f_amber if v >= 0.55 else f_red
                        )
                    except (TypeError, ValueError):
                        pass

            for ci in range(1, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(ci)].width = min(
                    max(
                        10,
                        max(
                            (len(str(ws.cell(r, ci).value or ""))
                             for r in range(1, min(ws.max_row + 1, 200))),
                            default=8,
                        ) + 2,
                    ),
                    55,
                )

    log.info(
        "  Saved -> %s  |  %d SDTM vars  |  %d domains  |  %d source studies",
        out_path,
        master_df["SDTM_VARIABLE"].nunique(),
        master_df["DOMAIN"].nunique(),
        raw_df["SOURCE_FILE"].nunique(),
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_master_mapping(
    spec_paths,
    sponsor_paths=None,
    existing_master=None,
    out_path=Path("master_mapping.xlsx"),
    config_path=Path("config.yaml"),
    study_dates=None,
):
    """
    Build or update master_mapping.xlsx.

    Args:
        spec_paths:      list of completed study spec Excel paths
        sponsor_paths:   list of sponsor standard spec paths (get confidence boost)
        existing_master: path to existing master (append mode)
        out_path:        output path
        config_path:     config.yaml path
        study_dates:     dict mapping filename -> 'YYYY-MM-DD'

    Returns:
        master DataFrame
    """
    cfg         = _load_cfg(config_path)
    log_cfg     = cfg.get("logging", {})
    log         = get_logger(log_cfg.get("log_file", ""), log_cfg.get("level", "INFO"))
    study_dates = study_dates or {}
    all_frames  = []

    # Append mode: reload existing extraction log
    if existing_master and Path(existing_master).exists():
        log.info("[APPEND] Loading existing master: %s", Path(existing_master).name)
        try:
            ex = pd.read_excel(
                existing_master, sheet_name="extraction_log",
                engine="openpyxl", dtype=object,
            )
            if not ex.empty:
                ex["IS_SPONSOR_STD"] = ex["IS_SPONSOR_STD"].fillna(False)
                all_frames.append(ex)
                log.info("  %d existing rows loaded", len(ex))
        except Exception as exc:
            log.warning("  Could not load existing extraction log: %s", exc)

    log.info("[BUILD] Processing %d study spec(s)...", len(spec_paths or []))
    for sp in (spec_paths or []):
        sp = Path(sp)
        if not sp.exists():
            log.warning("  [SKIP] Not found: %s", sp)
            continue
        date  = study_dates.get(sp.name, study_dates.get(str(sp), ""))
        frame = process_spec_file(sp, cfg, date, is_sponsor=False, log=log)
        if not frame.empty:
            all_frames.append(frame)

    if sponsor_paths:
        log.info("[BUILD] Processing %d sponsor standard spec(s)...", len(sponsor_paths))
        for sp in sponsor_paths:
            sp = Path(sp)
            if not sp.exists():
                log.warning("  [SKIP] Not found: %s", sp)
                continue
            date  = study_dates.get(sp.name, study_dates.get(str(sp), ""))
            frame = process_spec_file(sp, cfg, date, is_sponsor=True, log=log)
            if not frame.empty:
                all_frames.append(frame)

    if not all_frames:
        log.error("[BUILD] No mappings extracted from any file.")
        return pd.DataFrame()

    raw_df = pd.concat(all_frames, ignore_index=True)
    log.info("[BUILD] Consolidating %d raw rows...", len(raw_df))
    master_df = build_master(raw_df, cfg)
    write_master(master_df, raw_df, out_path, log)
    return master_df


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Build SDTM master mapping from completed study specs.")
    ap.add_argument("--specs",       nargs="+", required=True, help="Completed study spec Excel files")
    ap.add_argument("--sponsor",     nargs="*", default=[],    help="Sponsor standard spec(s)")
    ap.add_argument("--existing",    default=None,             help="Existing master (append mode)")
    ap.add_argument("--out",         default="master_mapping.xlsx")
    ap.add_argument("--config",      default="config.yaml")
    ap.add_argument("--dates",       nargs="*", default=[],
                    help="Study dates as filename=YYYY-MM-DD pairs")
    args   = ap.parse_args()
    dates  = dict(item.split("=", 1) for item in args.dates if "=" in item)
    build_master_mapping(
        spec_paths=args.specs,
        sponsor_paths=args.sponsor,
        existing_master=Path(args.existing) if args.existing else None,
        out_path=Path(args.out),
        config_path=Path(args.config),
        study_dates=dates,
    )
