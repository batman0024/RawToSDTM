"""
mapper.py
=========
Map a new study raw variable catalog to SDTM variables using
the master mapping knowledge base.

Key improvements over previous version:
  - Group-aware index: build_index() stores GROUP_TOKENS so the mapper
    retrieves all tokens of the best group, not individual tokens
  - Partial-group scoring: if group has N tokens and only K are found
    in the raw catalog, confidence is penalised proportionally
  - SUPPQUAL handling: QNAM/QLABEL variables get special triplet logic
  - Coverage breakdown includes var-class split (CRF vs Derived vs Protocol)
  - All strings are plain ASCII; no Unicode

4-signal composite scorer:
  1. name_exact   exact slug match between SDTM var and raw var
  2. name_fuzzy   best of seq_ratio / token_sort / token_set similarity
  3. label_tfidf  TF-IDF cosine on lowercased variable labels
  4. master_freq  MASTER_CONFIDENCE from master_mapping

Three-tier output:
  direct      score >= auto_accept  -> written to spec immediately
  review      score >= review       -> amber-flagged for human check
  unresolved  score < review        -> top-5 candidates listed only

Usage:
    python mapper.py \\
        --master master_mapping.xlsx \\
        --raw    new_study_raw.xlsx \\
        --spec   new_study_spec.xlsx \\
        --out    mapping_results.xlsx \\
        --config config.yaml
"""

from __future__ import annotations

import re
import sys
import math
import warnings
import datetime as dt
import argparse
from pathlib import Path
from difflib import SequenceMatcher
from typing import Optional

import numpy as np
import pandas as pd
import yaml
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

from sdtm_knowledge import (
    classify_variable,
    expand_sdtm_label,
    infer_origin,
    is_date_variable,
    PROTOCOL_VARS,
    ALWAYS_DERIVED,
)
from logger import get_logger


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

def _norm(s):
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return ""
    return re.sub(r"\s+", " ", str(s).strip()).upper()


def _slug(s):
    return re.sub(r"[^A-Z0-9]", "", _norm(s))


def _token_set(s):
    return set(re.split(r"[^A-Z0-9]+", _slug(s))) - {""}


def seq_ratio(a, b):
    a, b = _slug(a), _slug(b)
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def token_sort(a, b):
    def ts(s):
        return " ".join(sorted(_token_set(s)))
    return SequenceMatcher(None, ts(a), ts(b)).ratio()


def token_set_sim(a, b):
    sa, sb = _token_set(a), _token_set(b)
    if not sa or not sb:
        return 0.0
    inter = " ".join(sorted(sa & sb))
    ra    = " ".join(sorted(sa - sb))
    rb    = " ".join(sorted(sb - sa))
    t1    = (inter + " " + ra).strip()
    t2    = (inter + " " + rb).strip()
    return max(
        SequenceMatcher(None, inter, t1).ratio(),
        SequenceMatcher(None, inter, t2).ratio(),
        SequenceMatcher(None, t1, t2).ratio(),
    )


def name_sim(a, b):
    return max(seq_ratio(a, b), token_sort(a, b), token_set_sim(a, b))


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def load_cfg(p):
    # If the given path does not exist, try resolving relative to this module
    p = Path(p)
    if not p.exists():
        module_dir = Path(__file__).parent
        candidate  = module_dir / p.name
        if candidate.exists():
            p = candidate
    with open(p) as f:
        return yaml.safe_load(f)


def get_thresholds(cfg, domain):
    m    = cfg.get("matching", {})
    th   = m.get("thresholds", {})
    auto = th.get("auto_accept", 0.82)
    rev  = th.get("review", 0.55)
    ov   = m.get("domain_overrides", {}).get(domain.upper(), {})
    return ov.get("auto_accept", auto), ov.get("review", rev)


def get_weights(cfg):
    dfl = {"name_exact": 0.35, "name_fuzzy": 0.20, "label_tfidf": 0.25, "master_freq": 0.20}
    w   = cfg.get("matching", {}).get("weights", dfl)
    tot = sum(w.values())
    return {k: v / tot for k, v in w.items()} if tot else dfl


def class_mod(cfg, vc):
    return cfg.get("matching", {}).get("class_modifiers", {}).get(vc, 1.0)


def partial_group_penalty(cfg):
    return cfg.get("matching", {}).get("partial_group_penalty", 0.70)


# ---------------------------------------------------------------------------
# Raw catalog reader
# ---------------------------------------------------------------------------

def read_sas_files(sas_paths, log):
    """
    Read one or more SAS datasets (.xpt or .sas7bdat) directly.
    Extracts variable names, labels, formats, and types.
    Each file becomes one RAW_DATASET entry (named from the file stem).
    Returns a catalog DataFrame in the same format as read_raw_catalog().
    """
    rows = []
    for p in sas_paths:
        p = Path(p)
        dataset_name = p.stem.upper()
        ext = p.suffix.lower()
        try:
            if ext == ".xpt":
                df_sas = pd.read_sas(str(p), format="xport", encoding="latin-1")
            elif ext in (".sas7bdat", ".sas"):
                df_sas = pd.read_sas(str(p), format="sas7bdat", encoding="latin-1")
            else:
                log.warning("Unsupported SAS file type: %s", p.name)
                continue

            # Extract metadata from column attributes
            for col in df_sas.columns:
                label  = getattr(df_sas[col], "label",  "") or ""
                fmt    = getattr(df_sas[col], "format", "") or ""
                dtype  = str(df_sas[col].dtype)
                var_type = "Num" if "float" in dtype or "int" in dtype else "Char"
                rows.append({
                    "RAW_DATASET": dataset_name,
                    "VARIABLE":    col.upper(),
                    "LABEL":       str(label).strip(),
                    "FORMAT":      str(fmt).strip(),
                    "TYPE":        var_type,
                })
            log.info("  SAS file %s: %d variables", p.name, len(df_sas.columns))
        except Exception as exc:
            log.error("  Cannot read SAS file %s: %s", p.name, exc)

    if not rows:
        return pd.DataFrame(columns=["RAW_DATASET","VARIABLE","LABEL","FORMAT","TYPE","RAW_KEY","VAR_SLUG"])

    out = pd.DataFrame(rows)
    out["VARIABLE"]  = out["VARIABLE"].apply(_norm)
    out["RAW_KEY"]   = out["RAW_DATASET"] + "." + out["VARIABLE"]
    out["VAR_SLUG"]  = out["VARIABLE"].apply(_slug)
    out = out[out["VARIABLE"] != ""].drop_duplicates("RAW_KEY").reset_index(drop=True)
    return out


def read_raw_catalog(raw_path, cfg, log):
    """
    Read the new study raw variable catalog.
    Accepts: CSV, Excel (PROC CONTENTS output or variable registry),
             or SAS XPT / SAS7BDAT files directly.
    Returns DataFrame with: RAW_DATASET, VARIABLE, LABEL, FORMAT, TYPE
    """
    aliases = cfg.get("raw_catalog", {}).get("column_aliases", {})
    ext = raw_path.suffix.lower()

    # Route SAS files to dedicated reader
    if ext in (".xpt", ".sas7bdat", ".sas"):
        out = read_sas_files([raw_path], log)
        if not out.empty:
            log.info(
                "  Raw catalog (SAS): %d variables in %d datasets",
                len(out), out["RAW_DATASET"].nunique(),
            )
        return out

    def rc(df, key):
        lc = {c.lower(): c for c in df.columns}
        for a in aliases.get(key, [key]):
            if a.lower() in lc:
                return lc[a.lower()]
        for a in aliases.get(key, [key]):
            for col_l, col_o in lc.items():
                if a.lower() in col_l:
                    return col_o
        return None

    if ext == ".csv":
        df = pd.read_csv(raw_path, dtype=object)
    else:
        xl    = pd.ExcelFile(raw_path, engine="openpyxl")
        sheet = xl.sheet_names[0]
        for sn in xl.sheet_names:
            if any(k in sn.lower() for k in ["var", "col", "catalog", "field", "contents", "proc"]):
                sheet = sn
                break
        df = xl.parse(sheet, dtype=object)

    var_col = rc(df, "variable")
    if var_col is None:
        raise ValueError(
            "Cannot find variable column in %s. Expected: %s"
            % (raw_path.name, aliases.get("variable", ["NAME"]))
        )

    ds_col  = rc(df, "dataset")
    lbl_col = rc(df, "label")
    fmt_col = rc(df, "format")
    typ_col = rc(df, "type")

    out = pd.DataFrame()
    out["VARIABLE"]    = df[var_col].apply(_norm)
    out["RAW_DATASET"] = df[ds_col].apply(_norm)  if ds_col  else "UNKNOWN"
    out["LABEL"]       = df[lbl_col].apply(_norm) if lbl_col else ""
    out["FORMAT"]      = df[fmt_col].apply(_norm) if fmt_col else ""
    out["TYPE"]        = df[typ_col].apply(_norm) if typ_col else ""
    out["RAW_KEY"]     = out["RAW_DATASET"] + "." + out["VARIABLE"]
    out["VAR_SLUG"]    = out["VARIABLE"].apply(_slug)
    out = (
        out[out["VARIABLE"] != ""]
        .drop_duplicates("RAW_KEY")
        .reset_index(drop=True)
    )

    log.info(
        "  Raw catalog: %d variables in %d datasets",
        len(out), out["RAW_DATASET"].nunique(),
    )
    return out


# ---------------------------------------------------------------------------
# TF-IDF label index
# ---------------------------------------------------------------------------

class LabelIndex:
    """
    TF-IDF cosine similarity over raw variable labels.
    Operates on lowercased labels so that the standard word tokenizer works.
    Gracefully disabled when fewer than 3 labeled variables are present.
    """

    def __init__(self, raw_df):
        self._ok = False
        labeled  = raw_df[raw_df["LABEL"].str.strip() != ""].copy()
        if len(labeled) < 3:
            return
        self._keys = labeled["RAW_KEY"].tolist()
        corpus     = labeled["LABEL"].str.lower().tolist()
        try:
            self._vec    = TfidfVectorizer(
                analyzer="word",
                ngram_range=(1, 2),
                min_df=1,
                sublinear_tf=True,
            )
            self._matrix = self._vec.fit_transform(corpus)
            self._ok     = True
        except Exception:
            pass

    def scores(self, query, keys):
        """Return {raw_key: cosine_score} for the requested keys."""
        if not self._ok or not (query or "").strip():
            return {k: 0.0 for k in keys}
        try:
            q_vec  = self._vec.transform([query.lower()])
            ki     = {k: i for i, k in enumerate(self._keys)}
            result = {}
            for k in keys:
                if k in ki:
                    result[k] = float(
                        cosine_similarity(q_vec, self._matrix[ki[k]])[0][0]
                    )
                else:
                    result[k] = 0.0
            return result
        except Exception:
            return {k: 0.0 for k in keys}


# ---------------------------------------------------------------------------
# Composite scorer
# ---------------------------------------------------------------------------

def composite(sdtm_var, sdtm_label_exp, raw_key, raw_var,
              master_conf, label_sim, weights, modifier):
    """
    Compute composite match score (0-1) for one (SDTM_VAR, RAW_KEY) pair.
    """
    raw_bare  = raw_key.split(".")[-1] if "." in raw_key else raw_key
    exact     = 1.0 if _slug(sdtm_var) == _slug(raw_bare) else 0.0
    fuzzy     = name_sim(sdtm_var, raw_bare)
    raw_score = (
        weights["name_exact"]  * exact
        + weights["name_fuzzy"]  * fuzzy
        + weights["label_tfidf"] * label_sim
        + weights["master_freq"] * master_conf
    )
    return min(raw_score * modifier, 1.0)


# ---------------------------------------------------------------------------
# Group-aware master index
# ---------------------------------------------------------------------------

def build_index(master_df):
    """
    Build lookup structures from master_mapping for fast candidate retrieval.

    Structures:
        by_sdtm:  {(DOMAIN, SDTM_VARIABLE): list of group dicts}
                  Each group dict contains GROUP_SIG, GROUP_TOKENS,
                  GROUP_COUNT, MASTER_CONFIDENCE etc.
                  One entry per unique GROUP_SIG (not per raw token row).
        by_raw:   {bare_var_slug: [(DOMAIN, SDTM_VAR, confidence, group_dict)]}
    """
    by_sdtm  = {}
    by_raw   = {}
    seen_groups = set()  # (DOMAIN, SDTM_VARIABLE, GROUP_SIG) already added

    for _, r in master_df.iterrows():
        domain   = str(r.get("DOMAIN",         "")).strip()
        var      = str(r.get("SDTM_VARIABLE",  "")).strip()
        group_sig= str(r.get("GROUP_SIG",       "")).strip()
        conf     = float(r.get("MASTER_CONFIDENCE", 0.0))

        group_key = (domain, var, group_sig)
        if group_key not in seen_groups:
            seen_groups.add(group_key)
            entry = {
                "DOMAIN":            domain,
                "SDTM_VARIABLE":     var,
                "SDTM_LABEL":        str(r.get("SDTM_LABEL",        "") or ""),
                "GROUP_SIG":         group_sig,
                "GROUP_TOKENS":      str(r.get("GROUP_TOKENS",       "") or ""),
                "GROUP_COUNT":       int(r.get("GROUP_COUNT",  0)   or 0),
                "MAPPING_ACTION":    str(r.get("MAPPING_ACTION",     "") or ""),
                "MASTER_CONFIDENCE": conf,
                "IS_SPONSOR_STD":    bool(r.get("IS_SPONSOR_STD", False)),
                "SOURCE_FILES":      str(r.get("SOURCE_FILES",       "") or ""),
            }
            by_sdtm.setdefault((domain, var), []).append(entry)

            # Index each token in the group for reverse lookup
            for tok in (entry["GROUP_TOKENS"] or "").split("|"):
                if tok:
                    bare_slug = _slug(tok.split(".")[-1])
                    by_raw.setdefault(bare_slug, []).append(
                        (domain, var, conf, entry)
                    )

    return {"by_sdtm": by_sdtm, "by_raw": by_raw}


# ---------------------------------------------------------------------------
# Partial-group scorer
# ---------------------------------------------------------------------------

def score_group_against_raw(group_entry, raw_df, sdtm_var, sdtm_label_exp,
                             label_idx, weights, modifier, penalty):
    """
    Score a master group against the new study raw catalog.

    For each token in the group, find its best match in raw_df.
    Partial group present (some tokens found, some not) applies
    the partial_group_penalty multiplier.

    Returns:
        best_score       float
        resolved_tokens  list of (raw_dataset, raw_variable) in group order
        found_fraction   float (tokens_found / group_count)
        label_sims_avg   float
    """
    group_tokens = [t for t in (group_entry["GROUP_TOKENS"] or "").split("|") if t]
    if not group_tokens:
        return 0.0, [], 0.0, 0.0

    resolved   = []
    token_scores = []

    for tok in group_tokens:
        bare_var  = tok.split(".")[-1] if "." in tok else tok
        hint_ds   = tok.split(".")[-2] if tok.count(".") >= 1 else ""
        bare_slug = _slug(bare_var)

        # Exact slug match in raw catalog
        hits = raw_df[raw_df["VAR_SLUG"] == bare_slug]

        if hits.empty:
            # Fuzzy fallback: best name similarity in domain-filtered pool
            ds_pool = raw_df[
                raw_df["RAW_DATASET"].apply(
                    lambda d: (
                        _slug(hint_ds)[:2] == _slug(d)[:2]
                        if hint_ds else False
                    )
                )
            ] if hint_ds else pd.DataFrame()

            if ds_pool.empty:
                ds_pool = raw_df

            best_sim = 0.0
            best_row = None
            for _, rr in ds_pool.iterrows():
                sim = name_sim(bare_var, rr["VARIABLE"])
                if sim > best_sim:
                    best_sim, best_row = sim, rr

            if best_row is not None and best_sim >= 0.60:
                rk = best_row["RAW_KEY"]
                ls = label_idx.scores(sdtm_label_exp, [rk]).get(rk, 0.0)
                sc = composite(
                    sdtm_var, sdtm_label_exp, rk, best_row["VARIABLE"],
                    group_entry["MASTER_CONFIDENCE"], ls, weights, modifier,
                )
                resolved.append((best_row["RAW_DATASET"], best_row["VARIABLE"], sc))
                token_scores.append(sc)
            else:
                resolved.append(("", "", 0.0))
                token_scores.append(0.0)
        else:
            # Prefer dataset matching the domain hint
            if hint_ds:
                hint_hits = hits[
                    hits["RAW_DATASET"].apply(
                        lambda d: _slug(hint_ds)[:2] == _slug(d)[:2]
                    )
                ]
                if not hint_hits.empty:
                    hits = hint_hits

            batch_keys = hits["RAW_KEY"].tolist()
            lbl_sims   = label_idx.scores(sdtm_label_exp, batch_keys)

            best_sc  = 0.0
            best_rk  = None
            best_hit = None
            for _, rr in hits.iterrows():
                rk = rr["RAW_KEY"]
                sc = composite(
                    sdtm_var, sdtm_label_exp, rk, rr["VARIABLE"],
                    group_entry["MASTER_CONFIDENCE"],
                    lbl_sims.get(rk, 0.0),
                    weights, modifier,
                )
                if sc > best_sc:
                    best_sc, best_rk, best_hit = sc, rk, rr

            if best_hit is not None:
                resolved.append((best_hit["RAW_DATASET"], best_hit["VARIABLE"], best_sc))
                token_scores.append(best_sc)
            else:
                resolved.append(("", "", 0.0))
                token_scores.append(0.0)

    found_count   = sum(1 for _, _, sc in resolved if sc > 0.0)
    total_count   = len(group_tokens)
    found_fraction = found_count / total_count if total_count else 0.0

    if not token_scores:
        return 0.0, resolved, 0.0, 0.0

    avg_score  = float(np.mean(token_scores))
    full_score = avg_score

    # Apply partial-group penalty when not all tokens were matched
    if found_fraction < 1.0:
        full_score = full_score * (penalty + (1.0 - penalty) * found_fraction)

    return full_score, resolved, found_fraction, float(np.mean(
        [sc for _, _, sc in resolved if sc > 0.0] or [0.0]
    ))


# ---------------------------------------------------------------------------
# Candidate finder (group-level)
# ---------------------------------------------------------------------------

def find_best_group(sdtm_var, domain, sdtm_label_exp,
                    raw_df, idx, label_idx, cfg, weights, modifier):
    """
    Find the best-scoring group from the master index for a given SDTM variable.

    Returns:
        best_group_result dict or None
        alt_summaries     list of short string summaries for top-3 alternates
    """
    penalty  = partial_group_penalty(cfg)
    min_sc   = cfg.get("matching", {}).get("candidate_min_score", 0.35)
    top_k    = cfg.get("matching", {}).get("top_k_candidates", 5)

    master_groups = idx["by_sdtm"].get((domain, sdtm_var), [])

    # Also look up by individual raw token reverse-index
    extra_groups = []
    sdtm_slug = _slug(sdtm_var)
    for bare_slug, entries in idx["by_raw"].items():
        if name_sim(sdtm_var, bare_slug) >= min_sc:
            for (dom, var, conf, entry) in entries:
                if (dom, var) != (domain, sdtm_var):
                    continue
                if entry not in master_groups and entry not in extra_groups:
                    extra_groups.append(entry)

    all_groups = master_groups + extra_groups

    # Score every group
    scored = []
    for ge in all_groups:
        sc, resolved, frac, avg_ls = score_group_against_raw(
            ge, raw_df, sdtm_var, sdtm_label_exp,
            label_idx, weights, modifier, penalty,
        )
        if sc >= min_sc:
            scored.append({
                "group":     ge,
                "score":     sc,
                "resolved":  resolved,
                "frac":      frac,
                "avg_ls":    avg_ls,
            })

    # Apply cross-domain penalty: raw vars from a different dataset domain
    # get a 0.35x score multiplier. Same-domain matches always take precedence.
    # This prevents e.g. CM.SUBJID being mapped to AE.USUBJID when AE.SUBJID exists.
    CROSS_DOMAIN_PENALTY = 0.35
    penalised_scored = []
    for item in scored:
        # Check each resolved token's dataset against the SDTM domain
        resolved = item["resolved"]
        adjusted_sc = item["score"]
        if resolved:
            rds_list = [rds for rds, rv, sc2 in resolved if rds and rds.strip()]
            if rds_list:
                # If ANY resolved dataset matches the SDTM domain prefix -> no penalty
                dom_slug = _slug(domain)[:2]
                same_domain = any(
                    _slug(rds)[:2] == dom_slug
                    for rds in rds_list
                )
                if not same_domain:
                    adjusted_sc = adjusted_sc * CROSS_DOMAIN_PENALTY
        penalised_scored.append({**item, "score": adjusted_sc})

    # Re-sort after penalty
    scored = sorted(penalised_scored, key=lambda x: -x["score"])

    # Fallback: global fuzzy if no master groups found
    if not scored:
        # Try same-domain raw datasets first
        ds_pool = raw_df[
            raw_df["RAW_DATASET"].apply(
                lambda d: _slug(domain)[:2] == _slug(d)[:2]
                         or _slug(domain) in _slug(d)
            )
        ]
        if ds_pool.empty:
            ds_pool = raw_df

        lbl_sims = label_idx.scores(sdtm_label_exp, ds_pool["RAW_KEY"].tolist())
        cands = []
        for _, rr in ds_pool.iterrows():
            rk = rr["RAW_KEY"]
            sc = composite(
                sdtm_var, sdtm_label_exp, rk, rr["VARIABLE"],
                0.0, lbl_sims.get(rk, 0.0), weights, modifier,
            )
            if sc >= min_sc:
                cands.append((rk, rr["RAW_DATASET"], rr["VARIABLE"], sc))

        cands.sort(key=lambda x: -x[3])
        for rk, rds, rv, sc in cands[:top_k]:
            pseudo_group = {
                "DOMAIN":            domain,
                "SDTM_VARIABLE":     sdtm_var,
                "SDTM_LABEL":        sdtm_label_exp,
                "GROUP_SIG":         "",
                "GROUP_TOKENS":      rds + "." + rv,
                "GROUP_COUNT":       1,
                "MAPPING_ACTION":    "",
                "MASTER_CONFIDENCE": 0.0,
                "IS_SPONSOR_STD":    False,
                "SOURCE_FILES":      "",
            }
            scored.append({
                "group":    pseudo_group,
                "score":    sc,
                "resolved": [(rds, rv, sc)],
                "frac":     1.0,
                "avg_ls":   lbl_sims.get(rk, 0.0),
            })

    if not scored:
        return None, []

    scored.sort(key=lambda x: -x["score"])
    best   = scored[0]
    alts   = [
        "%s.%s:%.3f" % (r["group"]["DOMAIN"], r["group"]["SDTM_VARIABLE"], r["score"])
        for r in scored[1:4]
    ]

    # Build resolved token strings
    raw_tokens = []
    for rds, rv, sc in best["resolved"]:
        if rds and rv and sc > 0.0:
            raw_tokens.append("RAW." + rds + "." + rv)

    return {
        "raw_tokens":        raw_tokens,
        "score":             best["score"],
        "frac":              best["frac"],
        "master_conf":       best["group"]["MASTER_CONFIDENCE"],
        "label_sim":         best["avg_ls"],
        "match_path":        "master_guided" if best["group"]["GROUP_SIG"] else "global_fuzzy",
        "group_count":       best["group"]["GROUP_COUNT"],
        "mapping_action":    best["group"]["MAPPING_ACTION"],
        "is_sponsor_std":    best["group"]["IS_SPONSOR_STD"],
    }, alts


# ---------------------------------------------------------------------------
# Spec variable reader
# ---------------------------------------------------------------------------

def read_spec_variables(spec_path, cfg, log):
    """
    Read the new study SDTM spec to get the list of variables to map.
    Returns DataFrame with: DOMAIN, SDTM_VARIABLE, SDTM_LABEL, MAPPING_ACTION, CORE
    """
    bc         = cfg.get("master_build", {})
    aliases    = bc.get("column_aliases", {})
    skip_lower = {s.lower() for s in bc.get("skip_sheets", [])}
    excl       = {d.upper() for d in bc.get("exclude_domains", [])}

    def rc(df, key):
        lc = {c.lower(): c for c in df.columns}
        for a in aliases.get(key, [key]):
            if a.lower() in lc:
                return lc[a.lower()]
        return None

    xl     = pd.ExcelFile(spec_path, engine="openpyxl")
    frames = []

    for sn in xl.sheet_names:
        if sn.lower() in skip_lower or sn.upper() in excl:
            continue
        try:
            df = xl.parse(sn, dtype=object)
            if df.empty:
                continue
            var_al_lower = [a.lower() for a in aliases.get("variable", ["variable"])]
            col_l        = [str(c).strip().lower() for c in df.columns]
            if any(a in col_l for a in var_al_lower):
                hdr = 0
            else:
                hdr = None
                for i in range(min(15, len(df))):
                    rv = [str(v).strip().lower() for v in df.iloc[i].values if pd.notna(v)]
                    if any(a in rv for a in var_al_lower):
                        hdr = i
                        break
            if hdr is None:
                continue
            if hdr > 0:
                df = xl.parse(sn, header=hdr, dtype=object)

            var_c  = rc(df, "variable")
            ds_c   = rc(df, "dataset")
            lbl_c  = rc(df, "label")
            act_c  = rc(df, "mapping_action")
            core_c = rc(df, "core")
            if var_c is None:
                continue

            for _, r in df.iterrows():
                var = _norm(r.get(var_c))
                if not var:
                    continue
                dom = _norm(r.get(ds_c)) if ds_c else sn.upper()
                if not dom:
                    dom = sn.upper()
                if dom in excl:
                    continue
                frames.append({
                    "DOMAIN":         dom,
                    "SDTM_VARIABLE":  var,
                    "SDTM_LABEL":     _norm(r.get(lbl_c)) if lbl_c else "",
                    "MAPPING_ACTION": _norm(r.get(act_c)) if act_c else "",
                    "CORE":           _norm(r.get(core_c)) if core_c else "",
                })
        except Exception as exc:
            log.warning("  Sheet '%s': %s", sn, exc)

    if not frames:
        return pd.DataFrame()
    return (
        pd.DataFrame(frames)
        .drop_duplicates(["DOMAIN", "SDTM_VARIABLE"])
        .reset_index(drop=True)
    )


# ---------------------------------------------------------------------------
# Main mapping loop
# ---------------------------------------------------------------------------

def run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log):
    """
    Core mapping loop. For every SDTM variable in sdtm_vars_df,
    find the best group from the master and resolve against raw_df.
    """
    weights = get_weights(cfg)

    log.info("[MAP] Building group-aware master index...")
    idx = build_index(master_df)

    log.info("[MAP] Building TF-IDF label index...")
    lbl_idx = LabelIndex(raw_df)
    log.info("  Label TF-IDF: %s", "enabled" if lbl_idx._ok else "disabled (no labels)")

    raw_ds_set      = set(raw_df["RAW_DATASET"].tolist())
    crf_var_set     = set()   # populated by acrf_parser if available
    als_var_set     = set()
    mapped_raw_keys = set()

    direct_rows = []
    review_rows = []
    unres_rows  = []
    total       = len(sdtm_vars_df)

    log.info("[MAP] Mapping %d SDTM variables...", total)

    for i, (_, sv) in enumerate(sdtm_vars_df.iterrows()):
        if (i + 1) % 50 == 0 or (i + 1) == total:
            log.info(
                "  [%4d/%d]  direct=%d  review=%d  unres=%d",
                i + 1, total, len(direct_rows), len(review_rows), len(unres_rows),
            )

        domain = str(sv.get("DOMAIN",         "")).strip()
        var    = str(sv.get("SDTM_VARIABLE",  "")).strip()
        label  = str(sv.get("SDTM_LABEL",     "")).strip()
        action = str(sv.get("MAPPING_ACTION", "")).strip()
        core   = str(sv.get("CORE",           "")).strip()

        auto_t, rev_t = get_thresholds(cfg, domain)
        vc  = classify_variable(var, domain)
        mod = class_mod(cfg, vc)

        base = {
            "DOMAIN":         domain,
            "SDTM_VARIABLE":  var,
            "SDTM_LABEL":     label,
            "VAR_CLASS":      vc,
        }

        # Hard rules: skip DROP, map Protocol and Derived without raw source
        if action == "DROP":
            continue

        if var in PROTOCOL_VARS:
            direct_rows.append(dict(
                base,
                RAW_VARIABLES_ASSIGNED="",
                MAPPING_ACTION="HARDCODE",
                ORIGIN="Protocol",
                ORIGIN_CONFIDENCE=0.92,
                COMPOSITE_SCORE=1.0,
                MATCH_TIER="direct",
                MATCH_PATH="protocol_rule",
                GROUP_COUNT=0,
                MASTER_CONF="",
                LABEL_SIM="",
                PARTIAL_FRAC="",
                TOP_CANDIDATES="",
            ))
            continue

        if var in ALWAYS_DERIVED and vc in ("derived", "sequence", "flag"):
            direct_rows.append(dict(
                base,
                RAW_VARIABLES_ASSIGNED="",
                MAPPING_ACTION=action or "DERIVE",
                ORIGIN="Derived",
                ORIGIN_CONFIDENCE=0.90,
                COMPOSITE_SCORE=1.0,
                MATCH_TIER="direct",
                MATCH_PATH="derived_rule",
                GROUP_COUNT=0,
                MASTER_CONF="",
                LABEL_SIM="",
                PARTIAL_FRAC="",
                TOP_CANDIDATES="",
            ))
            continue

        # Expand SDTM label with abbreviation knowledge
        sdtm_label_exp = (label + " " + expand_sdtm_label(var, domain)).strip()

        # Find best group from master
        result, alts = find_best_group(
            var, domain, sdtm_label_exp,
            raw_df, idx, lbl_idx, cfg, weights, mod,
        )
        alt_str = " | ".join(alts)

        if result is None:
            unres_rows.append(dict(
                base,
                RAW_VARIABLES_ASSIGNED="",
                MAPPING_ACTION=action,
                ORIGIN="",
                ORIGIN_CONFIDENCE=0.0,
                COMPOSITE_SCORE=0.0,
                MATCH_TIER="unresolved",
                MATCH_PATH="none",
                GROUP_COUNT=0,
                MASTER_CONF="",
                LABEL_SIM="",
                PARTIAL_FRAC="",
                TOP_CANDIDATES="",
            ))
            continue

        score        = result["score"]
        raw_tokens   = result["raw_tokens"]
        raw_assigned = ", ".join(raw_tokens)

        # Register mapped raw keys
        for tok in raw_tokens:
            parts = tok.split(".")
            if len(parts) >= 3:
                rk = parts[-2] + "." + parts[-1]
                mapped_raw_keys.add(rk)

        # Infer origin
        origin, oconf = infer_origin(
            var, domain, action, raw_tokens,
            crf_var_set, als_var_set, raw_ds_set,
        )

        req_direct = set(cfg.get("output", {}).get("require_direct", []))
        if var in req_direct and result["match_path"] != "master_guided":
            tier = "review_needs_direct"
        elif score >= auto_t:
            tier = "direct"
        elif score >= rev_t:
            tier = "review"
        else:
            tier = "unresolved"
            raw_tokens   = []
            raw_assigned = ""

        row = dict(
            base,
            RAW_VARIABLES_ASSIGNED=raw_assigned,
            MAPPING_ACTION=action or (result["mapping_action"] or ("ASSIGN" if raw_tokens else "DERIVE")),
            ORIGIN=origin,
            ORIGIN_CONFIDENCE=round(oconf, 3),
            COMPOSITE_SCORE=round(score, 4),
            MATCH_TIER=tier,
            MATCH_PATH=result["match_path"],
            GROUP_COUNT=result["group_count"],
            MASTER_CONF=round(result["master_conf"], 4),
            LABEL_SIM=round(result["label_sim"], 4),
            PARTIAL_FRAC=round(result["frac"], 3),
            TOP_CANDIDATES=alt_str,
        )

        if tier in ("direct",):
            direct_rows.append(row)
        elif tier in ("review", "review_needs_direct"):
            review_rows.append(row)
        else:
            unres_rows.append(row)

    # Unmapped raw variables
    unmapped = raw_df[~raw_df["RAW_KEY"].isin(mapped_raw_keys)].copy()
    unmapped = unmapped[["RAW_DATASET", "VARIABLE", "LABEL", "FORMAT"]].copy()
    unmapped.columns = ["RAW_DATASET", "RAW_VARIABLE", "LABEL", "FORMAT"]

    direct_df  = pd.DataFrame(direct_rows)
    review_df  = pd.DataFrame(review_rows)
    unres_df   = pd.DataFrame(unres_rows)

    # Coverage per domain with var-class breakdown
    cov_rows = []
    for dom in sdtm_vars_df["DOMAIN"].unique():
        dom_vars = sdtm_vars_df[sdtm_vars_df["DOMAIN"] == dom]
        tot  = len(dom_vars)
        d_n  = int((direct_df["DOMAIN"]  == dom).sum()) if not direct_df.empty  else 0
        r_n  = int((review_df["DOMAIN"]  == dom).sum()) if not review_df.empty  else 0
        u_n  = int((unres_df["DOMAIN"]   == dom).sum()) if not unres_df.empty   else 0

        # Var-class breakdown across all result tiers for this domain
        all_dom = pd.concat(
            [df for df in [direct_df, review_df, unres_df] if not df.empty]
        )
        all_dom = all_dom[all_dom["DOMAIN"] == dom] if not all_dom.empty else pd.DataFrame()
        class_counts = (
            all_dom["VAR_CLASS"].value_counts().to_dict()
            if not all_dom.empty and "VAR_CLASS" in all_dom.columns
            else {}
        )

        cov_rows.append({
            "DOMAIN":              dom,
            "TOTAL":               tot,
            "DIRECT":              d_n,
            "REVIEW":              r_n,
            "UNRESOLVED":          u_n,
            "AUTO_PCT":            round(d_n / tot * 100, 1) if tot else 0.0,
            "TOTAL_COVERAGE_PCT":  round((d_n + r_n) / tot * 100, 1) if tot else 0.0,
            "N_DERIVED":           class_counts.get("derived", 0)
                                   + class_counts.get("sequence", 0),
            "N_IDENTIFIER":        class_counts.get("identifier", 0),
            "N_TIMING":            class_counts.get("timing", 0),
            "N_RESULT":            class_counts.get("result", 0),
            "N_CODELIST":          class_counts.get("codelist", 0),
            "N_GENERAL":           class_counts.get("general", 0)
                                   + class_counts.get("free_text", 0),
        })

    coverage = pd.DataFrame(cov_rows).sort_values("DOMAIN").reset_index(drop=True)

    log.info(
        "[MAP]  Direct: %d  |  Review: %d  |  Unresolved: %d  |  Unmapped raw: %d",
        len(direct_rows), len(review_rows), len(unres_rows), len(unmapped),
    )

    return {
        "direct":       direct_df,
        "review":       review_df,
        "unresolved":   unres_df,
        "unmapped_raw": unmapped,
        "coverage":     coverage,
    }


# ---------------------------------------------------------------------------
# Output writer
# ---------------------------------------------------------------------------

def write_results(results, out_path, log):
    """Write all mapping results to a styled multi-sheet Excel workbook."""
    from openpyxl.styles import PatternFill, Font, Alignment
    from openpyxl.utils import get_column_letter

    fill_h     = PatternFill("solid", fgColor="1F3864")
    font_h     = Font(bold=True, color="FFFFFF", size=10)
    fill_green = PatternFill("solid", fgColor="E2EFDA")
    fill_amber = PatternFill("solid", fgColor="FFF2CC")
    fill_red   = PatternFill("solid", fgColor="FFE0E0")
    fill_blue  = PatternFill("solid", fgColor="DDEEFF")

    sheets = [
        ("direct",       results["direct"],       fill_green),
        ("review",       results["review"],       fill_amber),
        ("unresolved",   results["unresolved"],   fill_red),
        ("unmapped_raw", results["unmapped_raw"], fill_blue),
        ("coverage",     results["coverage"],     None),
    ]

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        for sn, df, _ in sheets:
            data = df if (df is not None and not df.empty) else pd.DataFrame({"(empty)": []})
            data.to_excel(writer, sheet_name=sn, index=False)

        wb = writer.book
        for sn, df, row_fill in sheets:
            if sn not in wb.sheetnames:
                continue
            ws = wb[sn]
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.fill = fill_h
                cell.font = font_h
                cell.alignment = Alignment(horizontal="center")

            if row_fill and sn in ("direct", "review") and df is not None and not df.empty:
                sci = next(
                    (i for i, c in enumerate(ws[1], 1) if str(c.value) == "COMPOSITE_SCORE"),
                    None,
                )
                if sci:
                    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
                        try:
                            v = float(row[sci - 1].value or 0)
                            f = fill_green if v >= 0.82 else fill_amber if v >= 0.55 else fill_red
                            for cell in row:
                                cell.fill = f
                        except (TypeError, ValueError):
                            pass

            for ci in range(1, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(ci)].width = min(
                    max(
                        10,
                        max(
                            (len(str(ws.cell(r, ci).value or ""))
                             for r in range(1, min(ws.max_row + 1, 200))),
                            default=8,
                        ) + 2,
                    ),
                    60,
                )

    log.info("  Results -> %s", out_path)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run(master_path, raw_path, spec_path=None, out_path=None, config_path=None):
    """Main callable API for the mapper."""
    cfg        = load_cfg(config_path or Path("config.yaml"))
    log_cfg    = cfg.get("logging", {})
    log        = get_logger(log_cfg.get("log_file", ""), log_cfg.get("level", "INFO"))
    out_path   = out_path or Path("mapping_results.xlsx")

    log.info("[MAP] Loading master: %s", master_path.name)
    master_df = pd.read_excel(
        master_path, sheet_name="master_all", engine="openpyxl", dtype=object,
    )
    master_df["MASTER_CONFIDENCE"] = pd.to_numeric(
        master_df.get("MASTER_CONFIDENCE", 0), errors="coerce",
    ).fillna(0.0)

    log.info("[MAP] Loading raw catalog: %s", raw_path.name)
    raw_df = read_raw_catalog(raw_path, cfg, log)

    sdtm_vars_df = None
    if spec_path and Path(spec_path).exists():
        log.info("[MAP] Loading SDTM spec: %s", Path(spec_path).name)
        sdtm_vars_df = read_spec_variables(Path(spec_path), cfg, log)
        if sdtm_vars_df is not None and not sdtm_vars_df.empty:
            log.info("  Spec variables to map: %d", len(sdtm_vars_df))

    if sdtm_vars_df is None or sdtm_vars_df.empty:
        log.info("[MAP] No spec provided - deriving variable list from master_top")
        sdtm_vars_df = pd.read_excel(
            master_path, sheet_name="master_top", engine="openpyxl", dtype=object,
        )
        sdtm_vars_df = (
            sdtm_vars_df[["DOMAIN", "SDTM_VARIABLE", "SDTM_LABEL", "MAPPING_ACTION"]]
            .drop_duplicates(["DOMAIN", "SDTM_VARIABLE"])
            .reset_index(drop=True)
        )
        sdtm_vars_df["CORE"] = ""

    results = run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log)
    write_results(results, out_path, log)
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Map new study raw vars to SDTM.")
    ap.add_argument("--master", required=True)
    ap.add_argument("--raw",    required=True)
    ap.add_argument("--spec",   default=None)
    ap.add_argument("--out",    default="mapping_results.xlsx")
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()
    run(
        master_path=Path(args.master),
        raw_path=Path(args.raw),
        spec_path=args.spec,
        out_path=Path(args.out),
        config_path=Path(args.config),
    )
