@echo off
setlocal EnableDelayedExpansion

:: ============================================================
:: SDTM Master Mapping System v24 - Windows Launcher
:: ============================================================
:: Runs directly with system Python — no venv created.
:: Usage:
::   launch.bat              - Start app (installs missing packages if needed)
::   launch.bat --install    - Force reinstall all packages from requirements.txt
::   SET PORT=8502 && launch.bat  - Override Streamlit port
:: ============================================================

title SDTM Mapping System v26

if not defined PORT     set PORT=8501
if not defined API_PORT set API_PORT=8000

set ROOT_DIR=%~dp0
set REQUIREMENTS=%ROOT_DIR%requirements.txt
set APP_ENTRY=%ROOT_DIR%app.py

echo.
echo ============================================================
echo   SDTM Master Mapping System v24
echo ============================================================
echo   Streamlit:  http://localhost:%PORT%
echo ============================================================
echo.

:: ── Step 1: Check Python ─────────────────────────────────────────────────────
echo [1/3] Checking Python...
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Python not found on PATH.
    echo        Download from https://python.org (3.9+^)
    pause
    exit /b 1
)
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo        Python %PYVER% found

:: ── Step 2: Check / install packages ─────────────────────────────────────────
echo [2/3] Checking packages...
set FORCE_INSTALL=0
if "%1"=="--install" set FORCE_INSTALL=1

if %FORCE_INSTALL%==0 (
    python -c "import streamlit, pandas, sklearn, openpyxl, yaml" >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        echo        Required packages missing - installing from requirements.txt...
        set FORCE_INSTALL=1
    ) else (
        echo        Packages OK
    )
)

if %FORCE_INSTALL%==1 (
    echo        Running: pip install -r requirements.txt
    pip install -r "%REQUIREMENTS%"
    if %ERRORLEVEL% neq 0 (
        echo ERROR: pip install failed. Check your internet connection and try again.
        pause
        exit /b 1
    )
    echo        Packages installed.
)

:: ── Step 3: Launch ───────────────────────────────────────────────────────────
if not exist "%ROOT_DIR%tmp" mkdir "%ROOT_DIR%tmp"

echo [3/3] Starting Streamlit...
echo.
echo        Open browser: http://localhost:%PORT%
echo        Press Ctrl+C to stop.
echo ============================================================
echo.

python -m streamlit run "%APP_ENTRY%" ^
    --server.port %PORT% ^
    --server.headless true ^
    --browser.gatherUsageStats false ^
    --server.fileWatcherType none

set EXIT_CODE=%ERRORLEVEL%
echo.
echo ============================================================
if %EXIT_CODE% neq 0 (
    echo   Streamlit exited with error code %EXIT_CODE%
    echo   Common fix: port %PORT% already in use.
    echo   Run:  SET PORT=8502 ^&^& launch.bat
) else (
    echo   Streamlit stopped normally.
)
echo ============================================================
echo.
pause
endlocal
exit /b %EXIT_CODE%
