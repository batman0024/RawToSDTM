"""
app.py
======
SDTM Master Mapping System v18 — Streamlit entry point.
Only UI orchestration here. All logic lives in services/ and src/.

Run:
    streamlit run app.py
"""
from __future__ import annotations

import sys
from pathlib import Path

APP_DIR = Path(__file__).parent.resolve()
SRC_DIR = APP_DIR / "src"
sys.path.insert(0, str(SRC_DIR))
sys.path.insert(0, str(APP_DIR))

import streamlit as st

st.set_page_config(
    page_title="SDTM Master Mapping System",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

from ui.styles import apply_theme
apply_theme()

from ui.session import init_session_state
init_session_state()

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(
        '<div class="main-header"><h1>SDTM Mapper</h1>'
        '<p>Master Mapping System v25</p></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-section">Navigation</div>', unsafe_allow_html=True)

    page = st.radio(
        "Select phase",
        options=[
            "Build Master", "Map New Study", "Review & Approve",
            "Write Back to Spec", "Compare Specs",
            "CDM Variable Filter", "View Master",
            "Knowledge Graph", "Help",
        ],
        label_visibility="collapsed",
    )

    st.markdown('<div class="sidebar-section">Settings</div>', unsafe_allow_html=True)
    cfg_path_input = st.text_input(
        "config.yaml path",
        value=str(APP_DIR / "src" / "config.yaml"),
        help="Edit thresholds and weights in config.yaml.",
    )
    st.session_state["cfg_path_input"] = cfg_path_input

    st.markdown('<div class="sidebar-section">Reset</div>', unsafe_allow_html=True)
    st.caption("Phase 1 & 2 master mapping is preserved across resets.")
    _rc1, _rc2 = st.columns(2)
    with _rc1:
        if st.button("🗑 Raw Data", help="Clear raw catalog and mapping results"):
            for _k in (
                "results_xlsx_bytes", "map_done", "raw_bytes", "spec_bytes",
                "map_master_bytes", "mapping_results_dict",
                "direct_df_cache", "review_df_cache",
            ):
                st.session_state.pop(_k, None)
            st.success("Cleared.")
    with _rc2:
        if st.button("🗑 Writeback", help="Clear write-back spec data"):
            st.session_state.pop("wb_spec_bytes", None)
            st.success("Cleared.")

    st.markdown('<div class="sidebar-section">About</div>', unsafe_allow_html=True)
    st.caption("Feed more completed studies into Build Master to improve accuracy.")

# ── Page header ────────────────────────────────────────────────────────────────
st.markdown(
    '<div class="main-header">'
    '<h1>SDTM Master Mapping System v25</h1>'
    '<p>Build a cross-study master mapping knowledge base, then automatically '
    'map new study raw variables to SDTM with confidence-scored outputs and '
    'direct spec write-back.</p>'
    '</div>',
    unsafe_allow_html=True,
)

# ── Page routing ───────────────────────────────────────────────────────────────
if page == "Build Master":
    from ui.pages.build_master import render; render()
elif page == "Map New Study":
    from ui.pages.map_study import render; render()
elif page == "Review & Approve":
    from ui.pages.review_approve import render; render()
elif page == "Write Back to Spec":
    from ui.pages.writeback import render; render()
elif page == "Compare Specs":
    from ui.pages.compare import render; render()
elif page == "CDM Variable Filter":
    from ui.pages.cdm_filter import render; render()
elif page == "View Master":
    from ui.pages.view_master import render; render()
elif page == "Knowledge Graph":
    from ui.pages.graphrag_page import render; render()
elif page == "Help":
    from ui.pages.help_page import render; render()
