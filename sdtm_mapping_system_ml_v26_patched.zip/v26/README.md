# SDTM Master Mapping System v26

Production-grade CDISC SDTM mapping system with ML-enhanced scoring,
GraphRAG knowledge graph, FastAPI REST layer, and magic-link authentication.

---

## What's New in v26

### Critical Fixes
| # | Issue | Fix |
|---|-------|-----|
| 1 | **`crf_var_set` always empty** | `_build_origin_sets()` populates from raw catalog type/format signals and master ORIGIN overrides — ORIGIN values now correct |
| 2 | **AGE/AGEU/VISITNUM wrongly in ALWAYS_DERIVED** | Moved to `COMMONLY_DERIVED`; Phase 1 raw matching now runs for these variables |
| 3 | **ML training contaminated by HARDCODE/DERIVE rows** | `_is_valid_training_positive()` filter excludes non-CRF rows from training positives |
| 4 | **ML scores uncalibrated** | Platt scaling (`CalibratedClassifierCV`) applied post-fit; thresholds now calibrated |
| 5 | **Context features defaulted to 0.85-0.90 when unknown** | Changed to 0.5 (maximum uncertainty); known mismatch = 0.3 (negative signal) |
| 6 | **QVAL hardcoded instead of raw-matched** | SUPP variable semantic split: QVAL now goes through Phase 1 raw matching |
| 7 | **DOMAIN_CLASS duplicated in 3 files** | Consolidated to `sdtm_knowledge.py`; all others import from there |

### New Capabilities
- **Per-token confidence in master** (`TOKEN_CONFIDENCE_MAP`) — canonical sources weighted above fallback sources
- **Label bridge** — when name matching fails, label TF-IDF similarity bridges master knowledge to new study
- **Collective group presence bonus** — finding all N historically-known sources of a variable boosts score
- **Master-silent vs bridge-failed distinction** — unresolved tier now explains WHY with historical hints
- **GxP audit trail** — `_Mapping_Audit` sheet in every results workbook for 21 CFR Part 11 compliance
- **ISO 8601 token roles** — date/time component roles preserved for datetime construction variables
- **Functional SDTMIG version registry** — real version change data for 3.1.2 through 3.4

### New Tests
- `tests/test_ml_scorer.py` — updated to verify training data filter and calibration
- `tests/test_pipeline.py` — TestAuditSheet validates _Mapping_Audit present and complete
- `tests/test_sdtm_knowledge.py` — tests for COMMONLY_DERIVED, SUPP semantic split, DOMAIN_CLASS import

---


## What's New in v26

### Critical Fixes
| # | Issue | Fix |
|---|-------|-----|
| 1 | **Data leakage in ML training** | `label_tfidf` is set to `0.0` during training; `LabelIndex` is never passed to `train()` — it is built from new-study raw labels and must not influence model fitting |
| 2 | **Model retrained on every run** | Trained model is serialised alongside the master as `<stem>_ml_model.pkl`; reloaded when master content hash (SHA-256) is unchanged |
| 3 | **Class imbalance ignored** | Switched from `GradientBoostingClassifier` to `HistGradientBoostingClassifier` with `class_weight={0: 1.0, 1: pos_weight}`; CV now reports ROC-AUC and Average Precision (not raw accuracy) |
| 4 | **`prefix_match` bug** | Old code summed all position-wise matches (non-contiguous); fixed to stop counting at the first differing character |
| 5 | **Feature vector length drift** | `build_feature_vector()` now asserts `len(result) == _N_FEATURES` to catch future misalignment at runtime |
| 6 | **Hard negatives missing** | Training negatives now include a third tier: same-domain pairs with `jaro_winkler > 0.55` that are not the correct match |
| 7 | **Path traversal in file upload** | `_save_upload()` now calls `Path(filename).name` to strip directory components before saving |

### New Tests
- `tests/test_ml_scorer.py` — 40+ unit and integration tests covering all ML fixes
- `tests/test_security.py` — path traversal sanitisation tests
- `TestReproducibility` in `test_pipeline.py` — N_RUNS=3 back-to-back executions of every pipeline phase asserting identical output (guards RNG seeding, sort stability, file-handle leaks)

---

## Architecture

```
sdtm_mapping_v26/
├── app.py                    # Streamlit entry point (UI only)
├── api/                      # FastAPI layer (opt-in, ENABLE_FASTAPI=true)
│   ├── main.py               # App factory + exception handlers
│   ├── job_store.py          # Thread-safe in-memory job registry
│   ├── dependencies.py       # Dependency injection (auth, jobs)
│   └── routers/
│       ├── auth.py           # POST /auth/request-link, GET /auth/verify
│       ├── mapping.py        # POST /api/v1/mapping/run|build|writeback
│       └── health.py         # GET /health
├── auth/                     # Magic-link auth (no passwords)
│   ├── magic_link.py         # Token gen/validation, JWT issuance, rate limit
│   ├── email_sender.py       # SMTP + console dev sender
│   └── session_store.py      # Abstract store + in-memory default
├── services/                 # Business logic wrappers (no Streamlit)
│   ├── mapping_service.py    # Wraps src/mapper.py
│   ├── master_service.py     # Wraps src/master_builder.py
│   ├── writeback_service.py  # Wraps src/spec_writeback.py
│   └── validation_service.py # Wraps src/excel_validator.py
├── data/
│   ├── loaders.py            # Unified loader: CSV/Excel/JSON/Parquet/SAS
│   └── exporters.py          # Excel, JSON export helpers
├── models/                   # Pydantic contracts
│   ├── mapping_models.py
│   └── auth_models.py
├── config/
│   └── settings.py           # Pydantic BaseSettings, .env aware
├── exceptions/
│   └── domain_exceptions.py  # Typed custom exceptions
├── graphrag/                 # Knowledge graph layer
│   ├── graph/sdtm_kg.py      # NetworkX MultiDiGraph of raw->SDTM lineage
│   ├── ingestion/            # Master -> KG population
│   ├── extraction/search.py  # BM25 text retrieval
│   ├── mapping/sdtm_rules.py # Rule-based SDTM pattern matching
│   ├── rag.py                # GraphRAG answer engine
│   └── viz/d3_export.py      # D3.js graph export
├── logging_config/
│   └── setup.py              # Structured logging (text/JSON)
├── src/                      # Core mapping pipeline
│   ├── mapper.py             # Raw -> SDTM matching engine
│   ├── master_builder.py     # Master knowledge base builder
│   ├── ml_scorer.py          # ML scoring (HistGBT, v20 fixes)
│   ├── spec_writeback.py     # Excel write-back with highlighting
│   ├── sdtm_knowledge.py     # SDTM structural rules (pure Python)
│   ├── study_metadata.py     # SDTMIG version / TA / phase extraction
│   ├── pipeline.py           # CLI entry point (build/map/writeback/full)
│   ├── excel_validator.py    # Pre-flight spec validation
│   ├── cdm_filter.py         # CDM/SDTM variable filter
│   ├── config.yaml           # Thresholds, weights, domain overrides
│   └── utils.py              # _norm(), _slug() primitives
├── ui/                       # Streamlit pages
│   ├── pages/map_study.py
│   ├── pages/build_master.py
│   ├── pages/graphrag_page.py
│   └── ...
├── tests/
│   ├── conftest.py
│   ├── test_pipeline.py      # Integration tests + TestReproducibility (v20)
│   ├── test_ml_scorer.py     # ML unit tests (v20 NEW)
│   ├── test_security.py      # Security tests (v20 NEW)
│   ├── test_services.py
│   └── test_api.py
├── sample_data/              # Bundled demo files
├── docs/                     # HTML process flow and API docs
├── launch.bat                # Windows launcher
├── .env.example
└── requirements.txt
```

---

## Prerequisites

- Python 3.9 or newer
- Windows 10/11 (for `launch.bat`), or any OS for manual setup

---

## Quick Start — Windows

```bat
:: 1. Copy environment template
copy .env.example .env

:: 2. Edit .env — set JWT_SECRET for production

:: 3. Launch (creates venv + installs deps on first run)
launch.bat

:: Force reinstall of dependencies
launch.bat --install

:: Custom port
SET PORT=8502 && launch.bat

:: Enable FastAPI alongside Streamlit
SET ENABLE_FASTAPI=true && launch.bat
```

---

## Quick Start — Manual (any OS)

```bash
# 1. Create and activate virtual environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows CMD

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables
cp .env.example .env
# Edit .env — set JWT_SECRET for production

# 4. Run Streamlit
streamlit run app.py

# 5. Run FastAPI (optional, separate terminal)
ENABLE_FASTAPI=true uvicorn api.main:app --reload --port 8000
```

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `JWT_SECRET` | — | **Required for auth.** 32+ char random secret |
| `ENVIRONMENT` | `development` | `development` / `staging` / `production` |
| `ENABLE_FASTAPI` | `false` | Set `true` to start the REST API |
| `ENABLE_AUTH` | `false` | Set `true` to enforce JWT auth on API |
| `SMTP_HOST` | `localhost` | SMTP server host |
| `SMTP_PORT` | `587` | SMTP server port |
| `SMTP_USER` | — | SMTP username |
| `SMTP_PASSWORD` | — | SMTP password |
| `EMAIL_FROM` | `noreply@sdtm-mapper.local` | From address |
| `BASE_URL` | `http://localhost:8000` | Public API base URL (used in magic links) |
| `ALLOWED_EMAIL_DOMAINS` | `[]` | Whitelist of email domains (empty = allow all) |
| `MAGIC_LINK_TTL_MINUTES` | `15` | Token expiry |
| `JWT_EXPIRY_HOURS` | `8` | JWT session length |
| `LOG_LEVEL` | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |
| `LOG_FORMAT` | `text` | `text` or `json` |
| `TEMP_DIR` | `./tmp` | Temp directory for uploaded files |

In **development mode** (`ENVIRONMENT=development`), magic link emails are
printed to the console instead of sent — no SMTP configuration required.

---

## ML Scoring — v20 Architecture

The `MLScorer` class in `src/ml_scorer.py` trains a
`HistGradientBoostingClassifier` on historical (raw_variable → sdtm_variable)
pairs from the master mapping and predicts match probability for new pairs.

### Features (21 signals)

| Group | Feature | Description |
|---|---|---|
| Name | `jaro_winkler` | Jaro-Winkler similarity (prefix-weighted) |
| Name | `char_3gram` | Jaccard overlap of 3-character n-grams |
| Name | `prefix_match` | True leading-character prefix fraction (stops at first diff) |
| Name | `token_set` | Jaccard of uppercase token sets |
| Label | `label_tfidf` | TF-IDF cosine between raw and SDTM labels (inference only; 0.0 during training) |
| Label | `label_token_overlap` | Token Jaccard between raw and SDTM labels |
| Format | `format_is_date` | Raw FORMAT contains DATE/YYMMDD/DDMMYY |
| Format | `format_is_time` | Raw FORMAT contains TIME/TOD/HH |
| Format | `type_num` | Raw TYPE is numeric |
| SDTM | `sdtm_is_timing` | SDTM var ends in DT/TM/DTC/DTM |
| SDTM | `sdtm_is_datetime` | SDTM var ends in DTC or DTM |
| Domain | `domain_match_exact` | Raw dataset slug == SDTM domain slug |
| Domain | `domain_match_prefix2` | First two characters match |
| Master | `master_conf` | MASTER_CONFIDENCE from master mapping |
| Master | `is_sponsor_std` | Pair seen in sponsor standard |
| Master | `in_master` | Exact pair present in master |
| Class | `var_class_derived` | SDTM var is always-derived |
| Class | `var_class_timing` | SDTM var is timing class |
| Context | `sdtmig_version_match` | SDTMIG version similarity weight |
| Context | `ta_match` | Therapeutic area match |
| Context | `study_phase_match` | Study phase match |

### Negative Sampling Strategy

Training negatives are generated in three tiers per positive pair:

1. **Cross-domain** (2 per positive) — easy negatives from different SDTM domains
2. **Same-domain random** (1 per positive) — medium difficulty wrong pairs
3. **Hard negatives** (1 per positive) — same-domain pairs with `jaro_winkler > 0.55`
   that are not the correct match; these teach the model to separate confusable
   variable names like `AESTDTC` vs `AEENDTC`

### Model Persistence

On first run, the trained model is saved as `<master_stem>_ml_model.pkl`
alongside the master file.  On subsequent runs the model is loaded from disk
if the master content hash (SHA-256 over key columns) is unchanged —
avoiding redundant training on large masters.

### Evaluation Metrics

Training emits `StratifiedKFold` cross-validation results with:
- **ROC-AUC** — area under receiver operating curve (threshold-independent)
- **Average Precision** — area under precision-recall curve (imbalance-aware)
- **F1** — harmonic mean of precision and recall

Raw accuracy is not reported because with a 1:4 positive:negative training
ratio, a trivial model predicting "no match" would achieve 80% accuracy.

---

## Pipeline Phases

### Phase 1 — Build Master Mapping

```bash
python src/pipeline.py build \
    --specs   studies/study_a.xlsx studies/study_b.xlsx \
    --sponsor studies/sponsor_std_v3.xlsx \
    --out     master_mapping.xlsx

# Incremental append (add one study without full rebuild)
python src/pipeline.py build \
    --specs    studies/study_c.xlsx \
    --existing master_mapping.xlsx \
    --out      master_mapping.xlsx
```

### Phase 2 — Map New Study

```bash
python src/pipeline.py map \
    --master master_mapping.xlsx \
    --raw    new_study/proc_contents.xlsx \
    --spec   new_study/sdtm_spec.xlsx \
    --out    new_study/mapping_results.xlsx
```

Three-tier output:
- **direct** (score ≥ 0.82) — auto-accepted, written to spec immediately
- **review** (0.55 ≤ score < 0.82) — amber-flagged for programmer sign-off
- **unresolved** (score < 0.55) — top-5 candidates listed, no auto-write

### Phase 3 — Write Back to Spec

```bash
python src/pipeline.py writeback \
    --spec     new_study/sdtm_spec.xlsx \
    --results  new_study/mapping_results.xlsx \
    --spec-out new_study/sdtm_spec_mapped.xlsx

# Dry-run (preview only, no files written)
python src/pipeline.py writeback --dry-run ...
```

### Full Pipeline

```bash
python src/pipeline.py full \
    --specs   studies/study_a.xlsx studies/study_b.xlsx \
    --sponsor studies/sponsor_std_v3.xlsx \
    --raw     new_study/proc_contents.xlsx \
    --spec    new_study/sdtm_spec.xlsx
```

---

## API Usage

### 1. Request a magic link

```bash
curl -X POST http://localhost:8000/auth/request-link \
  -H "Content-Type: application/json" \
  -d '{"email": "analyst@yourcompany.com"}'
```

Check console output (dev mode) or email inbox for the login link.

### 2. Verify token and get JWT

```bash
curl "http://localhost:8000/auth/verify?token=<TOKEN_FROM_EMAIL>"
# Returns: {"access_token": "...", "token_type": "bearer", ...}
```

### 3. Run mapping

```bash
curl -X POST http://localhost:8000/api/v1/mapping/run \
  -H "Authorization: Bearer <JWT>" \
  -F "master=@master_mapping.xlsx" \
  -F "raw=@proc_contents.xlsx" \
  -F "spec=@new_study_spec.xlsx"
# Returns: {"job_id": "...", "status": "pending"}
```

### 4. Poll status

```bash
curl http://localhost:8000/api/v1/mapping/status/<JOB_ID> \
  -H "Authorization: Bearer <JWT>"
```

### 5. Download results

```bash
curl http://localhost:8000/api/v1/mapping/results/<JOB_ID> \
  -H "Authorization: Bearer <JWT>" \
  --output mapping_results.xlsx
```

Full interactive API docs: **http://localhost:8000/docs**

---

## Running Tests

```bash
# All tests
pytest tests/ -v

# ML scorer unit tests (new in v20)
pytest tests/test_ml_scorer.py -v

# Security tests (new in v20)
pytest tests/test_security.py -v

# Reproducibility tests (new in v20)
pytest tests/test_pipeline.py::TestReproducibility -v

# Full pipeline integration tests
pytest tests/test_pipeline.py -v

# Services only (fast, no API)
pytest tests/test_services.py -v

# API endpoint tests
pytest tests/test_api.py -v

# Run with coverage report
pytest tests/ --cov=src --cov-report=term-missing -v
```

Expected test counts:
- `test_ml_scorer.py` — ~40 tests
- `test_security.py` — ~8 tests
- `test_pipeline.py` — ~26 original + 6 reproducibility tests
- `test_services.py` — ~8 tests
- `test_api.py` — ~6 tests

---

## GxP / Audit Compliance Notes

- All mapping decisions are deterministic and traceable to master knowledge base entries
- No LLM dependencies — every match is based on explicit rules or historical records
- All auth events (request, send, verify, reuse attempt) are logged at INFO/WARNING level
- Magic link tokens are single-use and expire after 15 minutes
- Stack traces are never exposed to API consumers or the UI — logged server-side only
- `config.yaml` thresholds are version-controlled; any change is auditable via Git
- v20 reproducibility test suite (`TestReproducibility`) provides N_RUNS=3 regression
  coverage of the full pipeline for determinism assurance required in validated environments

---

## Known Limitations (Future Work)

- `SDTMIG_VERSION_CHANGES` dict covers only two variable/domain pairs; a full
  CDISC NCI thesaurus diff import is recommended for complete version-change detection
- `JobStore` is in-memory only; on Uvicorn restart, job statuses are lost.
  Redis or SQLite persistence is recommended for production deployments
- The `_Mapping_Audit` sheet (21 CFR Part 11 full audit trail with user, timestamp,
  model version, and master hash per auto-accepted mapping) is planned for v21
