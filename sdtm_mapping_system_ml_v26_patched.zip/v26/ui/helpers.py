"""
ui/helpers.py
=============
Shared helper functions used across all page modules.
"""
from __future__ import annotations
import io
import os
import sys
import time
import math
import shutil
import tempfile
import traceback
import zipfile
import hashlib
import datetime as dt
import threading
from pathlib import Path

import pandas as pd
import streamlit as st

# ── path setup ────────────────────────────────────────────────────────────
APP_DIR = Path(__file__).parent.parent.resolve()
SRC_DIR = APP_DIR / "src"
sys.path.insert(0, str(SRC_DIR))
sys.path.insert(0, str(APP_DIR))


def _make_tmpdir():
    """Create a temp dir — safe on Windows (no spaces, no TemporaryDirectory cleanup issues)."""
    return tempfile.mkdtemp(prefix='sdtm_')


def _rm_tmpdir(path):
    """Remove temp dir, ignoring errors (openpyxl may still hold file handles)."""
    try:
        shutil.rmtree(str(path), ignore_errors=True)
    except Exception:
        pass


def save_upload(uploaded_file, dest_dir):
    """Save a Streamlit UploadedFile to dest_dir; return Path."""
    dest = Path(dest_dir) / uploaded_file.name
    dest.write_bytes(uploaded_file.getbuffer())
    return dest


def bytes_to_upload_mock(content_bytes, filename, dest_dir):
    """Write raw bytes to a file; return Path."""
    dest = Path(dest_dir) / filename
    dest.write_bytes(content_bytes)
    return dest


def _bytes_to_file(name_bytes_tuple):
    """Wrap cached (name, bytes) tuple as a file-like object for uploaders that expect files."""
    import io as _io
    if name_bytes_tuple is None:
        return None
    name, bdata = name_bytes_tuple
    buf = _io.BytesIO(bdata)
    buf.name = name
    return buf


def metric_html(val, label, color=""):
    cls = "val " + color if color else "val"
    return (
        '<div class="metric-pill">'
        f'<div class="{cls}">{val}</div>'
        f'<div class="lbl">{label}</div>'
        '</div>'
    )


def log_html(lines):
    inner = "\n".join(lines[-120:])
    uid = "logbox_" + str(abs(hash(inner)) % 99999)
    # Auto-scroll to bottom using a tiny inline script
    scroll_js = f"""<script>
(function(){{
  var el=document.getElementById('{uid}');
  if(el){{el.scrollTop=el.scrollHeight;}}
  setTimeout(function(){{var e=document.getElementById('{uid}');if(e)e.scrollTop=e.scrollHeight;}},80);
}})();
</script>"""
    return f'<div class="log-box" id="{uid}">{inner}</div>{scroll_js}'



def _render_xai_bar(xai_str: str) -> str:
    """Convert a SCORE_BREAKDOWN string to a compact HTML score bar."""
    import ast
    try:
        if not xai_str or str(xai_str).lower() in ("", "nan", "{}"):
            return ""
        d = ast.literal_eval(str(xai_str))
        if not d:
            return ""
        # Use raw signal values (0-1) scaled to % of total for bar width
        # Fall back to weighted values if raw not available
        name_e  = float(d.get("name_exact",  d.get("w_name_exact",  0)) or 0)
        name_f  = float(d.get("name_fuzzy",  d.get("w_name_fuzzy",  0)) or 0)
        lbl_t   = float(d.get("label_tfidf", d.get("w_label_tfidf", 0)) or 0)
        hist    = float(d.get("master_freq", d.get("w_master_freq", 0)) or 0)
        total   = float(d.get("composite",   0) or 0)

        signals = [
            ("Exact Match",    name_e,  "#58a6ff"),
            ("Fuzzy Name",     name_f,  "#bc8cff"),
            ("Label Semantic", lbl_t,   "#e3b341"),
            ("History/Freq",   hist,    "#3fb950"),
        ]
        bars = ""
        for name, val, color in signals:
            pct = min(max(float(val) * 100, 0), 100)
            bars += (
                f'<div style="display:flex;align-items:center;gap:6px;margin:3px 0">'
                f'<span style="width:90px;font-size:10px;color:#8b949e;flex-shrink:0">{name}</span>'
                f'<div style="flex:1;background:#21262d;border-radius:3px;height:10px">'
                f'<div style="width:{pct:.0f}%;background:{color};height:10px;border-radius:3px;min-width:{2 if pct>0 else 0}px"></div>'
                f'</div>'
                f'<span style="width:38px;font-size:10px;color:{color};text-align:right;font-family:monospace">{val:.2f}</span>'
                f'</div>'
            )
        color_t = "#3fb950" if total >= 0.82 else "#e3b341" if total >= 0.55 else "#f85149"
        return (
            f'<div style="font-size:11px;color:{color_t};font-weight:700;margin-bottom:6px">'
            f'Score: {total:.3f}</div>' + bars
        )
    except Exception:
        return ""


def excel_download_button(df_dict, filename, label="Download Excel"):
    """Create an in-memory Excel workbook and return a download button."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in df_dict.items():
            if df is not None and not df.empty:
                df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    buf.seek(0)
    st.download_button(
        label=label,
        data=buf.read(),
        file_name=filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


def file_download_button(path, label="Download File"):
    """Offer a file for download by path."""
    with open(path, "rb") as f:
        data = f.read()
    ext  = Path(path).suffix.lower()
    mime = (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        if ext in (".xlsx", ".xlsm") else "application/octet-stream"
    )
    st.download_button(label=label, data=data,
                       file_name=Path(path).name, mime=mime)


# ---------------------------------------------------------------------------
# Progress-aware wrapper for build_master_mapping
# ---------------------------------------------------------------------------

def run_build_with_progress(spec_paths, sponsor_paths, existing_master,
                             out_path, config_path, study_dates):
    """
    Wrap build_master_mapping with real-time Streamlit progress feedback.
    Yields (pct, message) via st.progress + st.status updates.
    """
    import master_builder as mb

    log_lines = []
    progress   = st.progress(0, text="Starting master build...")
    status_box = st.empty()

    steps = []
    if existing_master:
        steps.append(("Loading existing master", 5))
    for sp in spec_paths:
        steps.append((f"Reading study spec: {Path(sp).name}", 15))
    for sp in (sponsor_paths or []):
        steps.append((f"Reading sponsor spec: {Path(sp).name}", 15))
    steps.append(("Consolidating groups & confidence scores", 20))
    steps.append(("Writing master_mapping.xlsx", 10))

    total_weight = sum(w for _, w in steps)
    cumulative   = 0

    def tick(msg, weight):
        nonlocal cumulative
        cumulative += weight
        pct = min(int(cumulative / total_weight * 100), 99)
        progress.progress(pct, text=msg)
        log_lines.append(f"  {msg}")
        status_box.markdown(log_html(log_lines), unsafe_allow_html=True)
        time.sleep(0.05)

    # Patch the module's logger to capture output
    import logging, io as _io

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg = self.format(record)
            # strip timestamp prefix
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        tick("Initialising...", 0)

        orig_process = mb.process_spec_file
        proc_count   = [0]

        def patched_process(spec_path, cfg, study_date, is_sponsor, log):
            proc_count[0] += 1
            prefix = "Sponsor std" if is_sponsor else f"Study {proc_count[0]}"
            tick(f"{prefix}: {Path(spec_path).name}", 15)
            return orig_process(spec_path, cfg, study_date, is_sponsor, log)

        mb.process_spec_file = patched_process

        master_df = mb.build_master_mapping(
            spec_paths=spec_paths,
            sponsor_paths=sponsor_paths,
            existing_master=existing_master,
            out_path=out_path,
            config_path=config_path,
            study_dates=study_dates,
        )

        mb.process_spec_file = orig_process
        tick("Complete!", 10)
        progress.progress(100, text="Master mapping built successfully")
        return master_df, log_lines

    except Exception as exc:
        mb.process_spec_file = orig_process
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_map_with_progress(master_path, raw_path, spec_path,
                           out_path, config_path):
    """Wrap mapper.run with real-time progress."""
    import mapper as mp
    import logging

    log_lines = []
    progress   = st.progress(0, text="Starting variable mapping...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    # Patch run_mapping to emit per-domain progress
    orig_run_mapping = mp.run_mapping
    domains_seen = [0]

    def patched_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log, master_path=None):
        total_vars = len(sdtm_vars_df)
        pct_per_var = 60 / max(total_vars, 1)

        orig_find = mp.find_best_group
        var_count = [0]

        def patched_find(sdtm_var, domain, *args, **kwargs):
            var_count[0] += 1
            pct = 20 + int(var_count[0] * pct_per_var)
            progress.progress(
                min(pct, 80),
                text=f"Mapping {domain}.{sdtm_var}  [{var_count[0]}/{total_vars}]",
            )
            return orig_find(sdtm_var, domain, *args, **kwargs)

        mp.find_best_group = patched_find
        result = orig_run_mapping(master_df, raw_df, sdtm_vars_df, cfg, log, master_path=master_path)
        mp.find_best_group = orig_find
        # FIX: _ml_scorer key must be preserved so run() can retrieve it
        return result

    mp.run_mapping = patched_run_mapping

    try:
        progress.progress(5,  text="Loading master mapping...")
        time.sleep(0.1)
        progress.progress(10, text="Loading raw catalog...")
        time.sleep(0.1)
        progress.progress(15, text="Building TF-IDF label index...")

        results = mp.run(
            master_path=master_path,
            raw_path=raw_path,
            spec_path=str(spec_path) if spec_path else None,
            out_path=out_path,
            config_path=config_path,
        )

        mp.run_mapping = orig_run_mapping
        progress.progress(90, text="Writing results Excel...")
        time.sleep(0.2)
        progress.progress(100, text="Mapping complete!")
        return results, log_lines

    except Exception as exc:
        mp.run_mapping = orig_run_mapping
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


def run_writeback_with_progress(spec_path, results_path, out_path,
                                 highlight_review, populate_origin,
                                 populate_action, dry_run, config_path):
    """Wrap spec_writeback.write_back with progress."""
    import spec_writeback as sw
    import logging

    log_lines = []
    progress   = st.progress(0, text="Preparing write-back...")
    status_box = st.empty()

    class ListHandler(logging.Handler):
        def emit(self, record):
            msg   = self.format(record)
            parts = msg.split("  ", 2)
            clean = parts[-1] if len(parts) >= 2 else msg
            log_lines.append(clean)
            status_box.markdown(log_html(log_lines), unsafe_allow_html=True)

    lh = ListHandler()
    lh.setFormatter(logging.Formatter("%(levelname)-7s  %(message)s"))
    pkg_logger = logging.getLogger("sdtm_pipeline")
    pkg_logger.addHandler(lh)

    try:
        progress.progress(10, text="Loading mapping results...")
        time.sleep(0.1)
        progress.progress(25, text="Opening spec workbook...")
        time.sleep(0.1)
        progress.progress(35, text="Writing Input Variables, Origin, Mapping Action...")

        wb_result = sw.write_back(
            spec_path=spec_path,
            results_path=results_path,
            out_path=out_path,
            highlight_review=highlight_review,
            populate_origin=populate_origin,
            populate_action=populate_action,
            dry_run=dry_run,
            config_path=str(config_path),
        )
        # write_back returns (path, validation_report, changelog_bytes)
        if isinstance(wb_result, tuple) and len(wb_result) == 3:
            result_path, validation_report, changelog_bytes = wb_result
        elif isinstance(wb_result, tuple) and len(wb_result) == 2:
            result_path, validation_report = wb_result
            changelog_bytes = b""
        else:
            result_path, validation_report, changelog_bytes = wb_result, None, b""

        progress.progress(90, text="Running post-writeback validation...")
        time.sleep(0.15)
        progress.progress(100, text="Write-back complete!")
        return result_path, validation_report, changelog_bytes, log_lines

    except Exception as exc:
        pkg_logger.removeHandler(lh)
        progress.empty()
        raise exc
    finally:
        pkg_logger.removeHandler(lh)


# ---------------------------------------------------------------------------
# Coverage chart (pure matplotlib -> PNG bytes)
# ---------------------------------------------------------------------------

def coverage_chart_bytes(coverage_df):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches

        domains = coverage_df["DOMAIN"].tolist()
        direct  = coverage_df["DIRECT"].astype(int).tolist()
        review  = coverage_df["REVIEW"].astype(int).tolist()
        unres   = coverage_df["UNRESOLVED"].astype(int).tolist()

        x     = range(len(domains))
        width = 0.25

        fig, ax = plt.subplots(figsize=(max(7, len(domains) * 1.2), 4), facecolor="#0d1117")
        ax.set_facecolor("#161b22")

        bars_d = ax.bar([i - width for i in x], direct,  width, label="Direct",     color="#3fb950", alpha=0.9)
        bars_r = ax.bar([i         for i in x], review,  width, label="Review",     color="#e3b341", alpha=0.9)
        bars_u = ax.bar([i + width for i in x], unres,   width, label="Unresolved", color="#f85149", alpha=0.9)

        ax.set_xticks(list(x))
        ax.set_xticklabels(domains, color="#e6edf3", fontsize=11)
        ax.tick_params(colors="#8b949e")
        ax.spines["bottom"].set_color("#30363d")
        ax.spines["left"].set_color("#30363d")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_ylabel("Variables", color="#8b949e", fontsize=10)
        ax.set_title("Mapping Coverage by Domain", color="#e6edf3", fontsize=12, pad=10)
        ax.yaxis.label.set_color("#8b949e")
        ax.tick_params(axis="y", colors="#8b949e")
        ax.grid(axis="y", color="#30363d", linewidth=0.5, linestyle="--")

        legend = ax.legend(
            facecolor="#161b22", edgecolor="#30363d",
            labelcolor="#e6edf3", fontsize=9,
        )

        # Value labels on bars
        for bars in (bars_d, bars_r, bars_u):
            for bar in bars:
                h = bar.get_height()
                if h > 0:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2, h + 0.1,
                        str(int(h)), ha="center", va="bottom",
                        color="#e6edf3", fontsize=8,
                    )

        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                    facecolor="#0d1117")
        plt.close(fig)
        buf.seek(0)
        return buf.read()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Review & Approve panel
# ---------------------------------------------------------------------------
def _render_review_panel():
    """Interactive mapping review panel - tick to approve or drop each mapping."""
    direct_cache = st.session_state.get("direct_df_cache", [])
    review_cache = st.session_state.get("review_df_cache", [])

    if not direct_cache and not review_cache:
        st.info("Run Phase 2 mapping first to see results here.")
        return

    st.markdown("### 🔍 Review & Approve Mappings")
    st.caption(
        "Approve (✅) or Drop (❌) each proposed mapping. "
        "Approved rows go to Write Back; dropped rows are excluded."
    )

    # Filters
    fc1, fc2, fc3, fc4 = st.columns([2, 2, 2, 2])
    with fc1:
        filt_domain = st.text_input("Filter Domain", placeholder="e.g. DM, AE", key="rv_dom")
    with fc2:
        filt_var    = st.text_input("Filter Variable", placeholder="e.g. USUBJID", key="rv_var")
    with fc3:
        filt_tier   = st.multiselect("Tier", ["AUTO", "REVIEW"], default=["AUTO", "REVIEW"], key="rv_tier")
    with fc4:
        filt_score_min = st.slider("Min Score", 0.0, 1.0, 0.0, 0.01, key="rv_sc")

    all_rows = []
    for r in direct_cache:
        r2 = dict(r); r2["_tier_label"] = "AUTO"; all_rows.append(r2)
    for r in review_cache:
        r2 = dict(r); r2["_tier_label"] = "REVIEW"; all_rows.append(r2)

    def _matches(r):
        dom = str(r.get("DOMAIN","")).upper()
        var = str(r.get("SDTM_VARIABLE","")).upper()
        sc  = float(r.get("COMPOSITE_SCORE", 0) or 0)
        if filt_domain and filt_domain.upper() not in dom:   return False
        if filt_var    and filt_var.upper()    not in var:   return False
        if r.get("_tier_label") not in filt_tier:            return False
        if sc < filt_score_min:                              return False
        return True

    filtered = [r for r in all_rows if _matches(r)]
    st.caption(f"Showing {len(filtered)} of {len(all_rows)} mappings")

    if not filtered:
        st.info("No mappings match the current filters.")
        return

    if "mapping_approvals" not in st.session_state:
        st.session_state["mapping_approvals"] = {}

    bc1, bc2, _ = st.columns([1, 1, 4])
    with bc1:
        if st.button("✅ Approve All Shown", key="rv_approve_all"):
            for r in filtered:
                k = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
                st.session_state["mapping_approvals"][k] = "approve"
    with bc2:
        if st.button("❌ Drop All Shown", key="rv_drop_all"):
            for r in filtered:
                k = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
                st.session_state["mapping_approvals"][k] = "drop"

    approved_count = dropped_count = 0
    st.markdown('<hr style="margin:4px 0;border-color:#30363d">', unsafe_allow_html=True)

    # Column headers
    hc = st.columns([0.6, 1.2, 1.8, 2.8, 1.8, 0.7, 0.6])
    hc[0].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>TIER</span>", unsafe_allow_html=True)
    hc[1].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>SDTM VAR</span>", unsafe_allow_html=True)
    hc[2].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>RAW DATASET</span>", unsafe_allow_html=True)
    hc[3].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>SDTM LABEL / RAW VARIABLES</span>", unsafe_allow_html=True)
    hc[4].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>INPUT VARS</span>", unsafe_allow_html=True)
    hc[5].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>SCORE</span>", unsafe_allow_html=True)
    hc[6].markdown("<span style='font-size:11px;color:#8b949e;font-weight:700'>DEC</span>", unsafe_allow_html=True)
    st.markdown('<hr style="margin:2px 0;border-color:#30363d">', unsafe_allow_html=True)

    for i, r in enumerate(filtered[:300]):
        key = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
        current = st.session_state["mapping_approvals"].get(key, "approve")
        sc_val  = float(r.get("COMPOSITE_SCORE", 0) or 0)
        sc_col  = "#3fb950" if sc_val >= 0.82 else "#e3b341" if sc_val >= 0.55 else "#f85149"

        raw_assigned = str(r.get("RAW_VARIABLES_ASSIGNED","") or "")
        # Parse all tokens for display
        all_toks = [t.strip() for t in raw_assigned.split(",") if t.strip()]
        # First token details
        first_tok = all_toks[0] if all_toks else ""
        pts = first_tok.split(".")
        raw_ds  = pts[-2] if len(pts) >= 2 else ""
        raw_var = pts[-1] if pts else ""

        # Collect unique datasets
        all_ds = []
        for tok in all_toks:
            p = tok.split(".")
            if len(p) >= 2:
                ds = p[-2]
                if ds not in all_ds:
                    all_ds.append(ds)

        tier_icon = "🟢" if r.get("_tier_label") == "AUTO" else "🟡"
        sdtm_var_full  = f"{r.get('DOMAIN','')}.{r.get('SDTM_VARIABLE','')}"
        sdtm_label_full = str(r.get("SDTM_LABEL",""))
        ds_display = ", ".join(all_ds) if all_ds else ""
        n_extra = len(all_toks) - 1

        cols = st.columns([0.6, 1.2, 1.8, 2.8, 1.8, 0.7, 0.6])
        cols[0].markdown(
            f"<span style='font-size:12px'>{tier_icon}</span>",
            unsafe_allow_html=True
        )
        cols[1].markdown(
            f"<span style='font-size:11px;font-weight:600;color:#e6edf3'>{sdtm_var_full}</span>",
            unsafe_allow_html=True
        )
        cols[2].markdown(
            f"<span style='font-size:11px;color:#8b949e'>{ds_display}</span>",
            unsafe_allow_html=True
        )
        # Label + raw variable count in one cell
        label_html = (
            f"<span style='font-size:11px;color:#e6edf3'>{sdtm_label_full}</span>"
        )
        if n_extra > 0:
            label_html += (
                f"<br><span style='font-size:10px;color:#58a6ff'>+{n_extra} more raw vars</span>"
            )
        cols[3].markdown(label_html, unsafe_allow_html=True)
        # Raw variable(s) column — show first var + count
        raw_var_html = f"<span style='font-size:11px;color:#8b949e'>{raw_var}</span>"
        if len(all_toks) > 1:
            raw_var_html += f"<br><span style='font-size:10px;color:#58a6ff'>{len(all_toks)} total</span>"
        cols[4].markdown(raw_var_html, unsafe_allow_html=True)
        cols[5].markdown(
            f"<span style='color:{sc_col};font-family:monospace;font-size:12px'>{sc_val:.3f}</span>",
            unsafe_allow_html=True
        )
        decision = cols[6].radio(
            f"dec_{i}", ["✅", "❌"],
            index=0 if current == "approve" else 1,
            horizontal=True,
            label_visibility="collapsed",
            key=f"rv_dec_{i}_{key}",
        )
        st.session_state["mapping_approvals"][key] = "approve" if decision == "✅" else "drop"
        if decision == "✅": approved_count += 1
        else:                dropped_count  += 1

    st.markdown(f"**{approved_count} approved · {dropped_count} dropped**")
    if len(filtered) > 300:
        st.caption(f"Showing first 300 of {len(filtered)} — use filters to narrow down.")
    st.info("After reviewing, go to **Write Back to Spec** — only approved mappings will be written.")


# Re-export session utilities so pages can import everything from ui.helpers
from ui.session import _file_hash, _scan_watch_folder  # noqa: F401
