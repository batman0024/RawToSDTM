"""
sdtm_knowledge.py
=================
SDTM structural knowledge base.
Pure domain logic: no file I/O, no external dependencies beyond stdlib.
All strings use straight ASCII quotes. No Unicode decorators.

v26 changes (IMP-002, IMP-010, IMP-011, IMP-013):
  IMP-002  ALWAYS_DERIVED split: AGE/AGEU/VISITNUM moved to COMMONLY_DERIVED
  IMP-010  DOMAIN_CLASS added here as canonical source; removed from mapper.py etc.
  IMP-011  SUPP variable semantics: SUPP_STRUCTURAL_VARS, SUPP_CODELIST_VARS, SUPP_MAPPED_VARS
  IMP-013  SDTMIG_VERSION_CHANGES replaced with functional registry + variable_version_score()
"""

import re
import math


# ---------------------------------------------------------------------------
# Variable class rules - first match wins
# ---------------------------------------------------------------------------

VAR_CLASS_RULES = [
    ("identifier", [
        r"^STUDYID$", r"^DOMAIN$", r"^USUBJID$", r"^SUBJID$",
        r"^SITEID$",  r"^INVID$",  r"^POOLID$",
    ]),
    ("sequence", [
        r"SEQ$",
    ]),
    ("timing", [
        r"(ST|EN|OC|DC|RF)(DT|TM|DTC|DTM)$",
        r"^(RFSTDTC|RFENDTC|RFICDTC|RFPENDTC|RFXSTDTC|RFXENDTC)$",
        r"DY$",
        r"^VISITNUM$", r"^VISITDY$", r"^EPOCH$",
        r"(START|END)(DATE|TIME|DT|TM|DTC)$",
    ]),
    ("result", [
        r"ORRES(U?)$", r"STRESC$", r"STRESN$", r"STRESU$",
        r"TESTCD$",    r"^TEST$",  r"NRLO$",   r"NRHI$",
    ]),
    ("flag", [
        r"FL$", r"IND$",
    ]),
    ("derived", [
        r"CHG$",  r"PCHG$", r"^BASE$", r"SHIFT$",
        r"ANRIND$", r"BNRIND$", r"ANL\d+FL$",
        r"^(TRTP|TRTA|TRTPN|TRTAN)$",
    ]),
    ("codelist", [
        r"SEV$",  r"SCAT$", r"REAS$", r"ACN$",  r"REL$",
        r"OUT$",  r"TOXGR$", r"GRADE$", r"STAT$",
        r"REASND$", r"DTHFL$", r"DCSREAS$",
    ]),
    ("free_text", [
        r"DECOD$", r"MODIFY$", r"VERBATIM$", r"OTH$",
        r"SPEC$",  r"DTHCAUS$",
    ]),
]

# ---------------------------------------------------------------------------
# IMP-010: DOMAIN_CLASS — canonical single source of truth
# Import from here in mapper.py, excel_validator.py, graphrag/mapping/sdtm_rules.py
# ---------------------------------------------------------------------------

DOMAIN_CLASS: dict[str, str] = {
    "AE": "Events",  "CE": "Events",  "DS": "Events",  "DV": "Events",
    "HO": "Events",  "MH": "Events",
    "CM": "Interventions", "EC": "Interventions", "EX": "Interventions",
    "ML": "Interventions", "PR": "Interventions", "SU": "Interventions",
    "EG": "Findings", "IE": "Findings", "IS": "Findings", "LB": "Findings",
    "MB": "Findings", "MI": "Findings", "MK": "Findings", "MS": "Findings",
    "NV": "Findings", "OE": "Findings", "PC": "Findings", "PE": "Findings",
    "PP": "Findings", "QS": "Findings", "RE": "Findings", "RS": "Findings",
    "SC": "Findings", "TR": "Findings", "TU": "Findings", "UR": "Findings",
    "VS": "Findings",
    "DM": "Special", "SE": "Special", "SM": "Special",
    "SV": "Special", "CO": "Special",
    "TA": "Trial",  "TE": "Trial",  "TI": "Trial",
    "TV": "Trial",  "TS": "Trial",  "TD": "Trial",
}

# ---------------------------------------------------------------------------
# Protocol / RF timing vars
# ---------------------------------------------------------------------------

PROTOCOL_VARS = frozenset({
    "STUDYID", "DOMAIN", "ARM",    "ACTARM",  "ARMCD",  "ACTARMCD",
    "EPOCH",   "TRTPN",  "TRTAN",  "TRTP",    "TRTA",
})

RF_TIMING_VARS = frozenset({
    "RFSTDTC", "RFENDTC", "RFICDTC", "RFPENDTC", "RFXSTDTC", "RFXENDTC",
})

# ---------------------------------------------------------------------------
# IMP-002: ALWAYS_DERIVED vs COMMONLY_DERIVED
# ---------------------------------------------------------------------------

# Variables that are ALWAYS programmatically derived — never have a raw CRF source.
# Phase 2 hard rule skips raw assignment entirely for these.
ALWAYS_DERIVED = frozenset({
    "USUBJID",                                           # concatenated identifier
    "AESEQ", "CMSEQ", "LBSEQ", "VSSEQ", "EXSEQ",       # sequence counters
    "MHSEQ", "DSSEQ", "EGSEQ", "PESEQ", "PCSEQ", "SUSEQ",
    "ADY", "AEDUR",                                      # derived calculations
})

# Variables that are COMMONLY derived but MAY have a raw CRF source.
# Phase 1 raw matching runs normally; Phase 2 derived rule fires only as fallback.
COMMONLY_DERIVED = frozenset({
    "AGE",      # often derived from BRTHDTC but sometimes CRF-collected
    "AGEU",     # companion to AGE — same source decision
    "VISITNUM", # often from visit schedule but may be raw visit number field
})

# ---------------------------------------------------------------------------
# IMP-011: SUPPQUAL variable semantics
# ---------------------------------------------------------------------------

# Truly structural — no raw source, correctly hardcoded
SUPP_STRUCTURAL_VARS = frozenset({
    "IDVAR", "IDVARVAL", "QORIG", "QEVAL",
})

# Sponsor-defined codelist values — controlled but study-specific; manual population
SUPP_CODELIST_VARS = frozenset({
    "QNAM", "QLABEL",
})

# Non-standard collected value — MUST map to a raw CRF variable
SUPP_MAPPED_VARS = frozenset({
    "QVAL",
})

# ---------------------------------------------------------------------------
# Abbreviation expansion / origin helpers
# ---------------------------------------------------------------------------

SDTM_ABBREV = {
    "AE": "adverse event",     "CM": "concomitant medication",
    "DM": "demographics",      "DS": "disposition",
    "EX": "exposure",          "LB": "laboratory",
    "MH": "medical history",   "PE": "physical examination",
    "VS": "vital signs",       "EG": "electrocardiogram",
    "PC": "pharmacokinetics",  "SU": "substance use",
    "DT": "date",              "TM": "time",
    "DTC": "datetime",         "ST": "start",
    "EN": "end",               "OR": "original",
    "STR": "standard",         "STRES": "standard result",
    "ORRES": "original result","DECOD": "decoded",
    "SEV": "severity",         "SER": "serious",
    "REL": "relationship",     "ACN": "action",
    "OUT": "outcome",          "REAS": "reason",
    "VERBATIM": "verbatim",    "TERM": "term",
    "BODSYS": "body system",   "HLT": "high level term",
    "LLT": "low level term",   "SOC": "system organ class",
    "PT": "preferred term",    "SEQ": "sequence",
    "FL": "flag",              "IND": "indicator",
    "CHG": "change",           "BASE": "baseline",
    "PCHG": "percent change",  "STAT": "status",
    "GRAD": "grade",           "TOX": "toxicity",
}

EDT_PREFIXES = frozenset({"LB", "EG", "PC", "PE", "VS", "MB", "MS", "PF"})

CRF_DATASET_PREFIXES = frozenset({
    "AE", "CM", "DS", "DV", "MH", "HO",
    "EX", "SU", "PR",
    "IE", "SC", "QS", "RS",
    "DM",
})

DOMAIN_SORT_KEYS = {
    "DM": ["STUDYID", "USUBJID"],
    "AE": ["STUDYID", "USUBJID", "AESEQ"],
    "CM": ["STUDYID", "USUBJID", "CMSEQ"],
    "LB": ["STUDYID", "USUBJID", "LBSEQ"],
    "VS": ["STUDYID", "USUBJID", "VSSEQ"],
    "EX": ["STUDYID", "USUBJID", "EXSEQ"],
    "MH": ["STUDYID", "USUBJID", "MHSEQ"],
    "DS": ["STUDYID", "USUBJID", "DSSEQ"],
    "EG": ["STUDYID", "USUBJID", "EGSEQ"],
    "PC": ["STUDYID", "USUBJID", "PCSEQ"],
    "SU": ["STUDYID", "USUBJID", "SUSEQ"],
}

PARAM_DOMAINS = {
    "LB": "LBTESTCD", "VS": "VSTESTCD", "EG": "EGTESTCD",
    "PC": "PCTESTCD", "PE": "PETESTCD", "MB": "MBTESTCD", "MS": "MSTESTCD",
}

# ---------------------------------------------------------------------------
# IMP-013: SDTMIG version changes — functional registry
# ---------------------------------------------------------------------------

SDTMIG_VERSION_CHANGES: dict[tuple, dict] = {
    ("EPOCH",    "AE"): {"3.1.2": "O", "3.1.3": "O", "3.2": "O", "3.3": "O", "3.4": "O"},
    ("EPOCH",    "CM"): {"3.1.2": "O", "3.1.3": "O", "3.2": "O", "3.3": "O", "3.4": "O"},
    ("EPOCH",    "EX"): {"3.1.2": "O", "3.1.3": "O", "3.2": "O", "3.3": "O", "3.4": "O"},
    ("EPOCH",    "LB"): {"3.1.2": "O", "3.1.3": "O", "3.2": "O", "3.3": "O", "3.4": "O"},
    ("EPOCH",    "VS"): {"3.1.2": "O", "3.1.3": "O", "3.2": "O", "3.3": "O", "3.4": "O"},
    ("AEHLTCD",  "AE"): {"3.1.2": None,"3.1.3": None,"3.2": None,"3.3": None,"3.4": "O"},
    ("AEHLT",    "AE"): {"3.1.2": None,"3.1.3": None,"3.2": None,"3.3": None,"3.4": "O"},
    ("AELLT",    "AE"): {"3.1.2": "O", "3.1.3": "O", "3.2": "O", "3.3": "O", "3.4": "O"},
    ("AELLTCD",  "AE"): {"3.1.2": None,"3.1.3": None,"3.2": None,"3.3": None,"3.4": "O"},
    ("RFXSTDTC", "DM"): {"3.1.2": None,"3.1.3": None,"3.2": "O", "3.3": "O", "3.4": "O"},
    ("RFXENDTC", "DM"): {"3.1.2": None,"3.1.3": None,"3.2": "O", "3.3": "O", "3.4": "O"},
    ("RFICDTC",  "DM"): {"3.1.2": None,"3.1.3": None,"3.2": "O", "3.3": "O", "3.4": "O"},
    ("DTYPE",    "LB"): {"3.1.2": None,"3.1.3": None,"3.2": None,"3.3": "O", "3.4": "O"},
    ("DTYPE",    "VS"): {"3.1.2": None,"3.1.3": None,"3.2": None,"3.3": "O", "3.4": "O"},
    ("DTYPE",    "EG"): {"3.1.2": None,"3.1.3": None,"3.2": None,"3.3": "O", "3.4": "O"},
}


def variable_version_score(sdtm_var: str, domain: str,
                            study_version: str, master_version: str) -> float:
    """
    Confidence modifier based on SDTMIG version compatibility.
    1.0 = present in both, 0.7 = new in study version, 0.0 = not in study version.
    """
    key = (sdtm_var.upper().strip(), domain.upper().strip())
    if key not in SDTMIG_VERSION_CHANGES:
        return 1.0
    changes = SDTMIG_VERSION_CHANGES[key]
    study_status  = changes.get(str(study_version).strip())
    master_status = changes.get(str(master_version).strip())
    if study_status is None:
        return 0.0
    if master_status is None:
        return 0.7
    return 1.0


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

def classify_variable(sdtm_var, domain=""):
    v = sdtm_var.upper().strip()
    for class_name, patterns in VAR_CLASS_RULES:
        for pat in patterns:
            if re.search(pat, v):
                return class_name
    return "general"


def expand_sdtm_label(sdtm_var, domain=""):
    v   = sdtm_var.upper().strip()
    dom = domain.upper().strip()
    stem = v[len(dom):] if (dom and v.startswith(dom)) else v
    tokens    = []
    remaining = stem
    abbrevs   = sorted(SDTM_ABBREV.keys(), key=len, reverse=True)
    while remaining:
        matched = False
        for abbr in abbrevs:
            if remaining.startswith(abbr):
                tokens.append(SDTM_ABBREV[abbr])
                remaining = remaining[len(abbr):]
                matched   = True
                break
        if not matched:
            tokens.append(remaining[0].lower())
            remaining = remaining[1:]
    domain_exp = SDTM_ABBREV.get(dom, dom.lower())
    return (domain_exp + " " + " ".join(tokens)).strip()


def is_date_variable(sdtm_var):
    return bool(re.search(r"(DT|DTC|DTM)$", sdtm_var.upper()))


def infer_origin(sdtm_var, domain, mapping_action,
                 raw_inputs, crf_var_set, als_var_set, raw_dataset_set):
    v      = sdtm_var.upper().strip()
    action = str(mapping_action).upper().strip() if mapping_action else ""

    raw_basenames = set()
    raw_ds_names  = set()
    for tok in (raw_inputs or []):
        parts = str(tok).upper().split(".")
        raw_basenames.add(parts[-1])
        if len(parts) >= 2:
            raw_ds_names.add(parts[-2])

    # Priority 1: CRF
    if raw_basenames & (crf_var_set | als_var_set):
        conf = 0.95 if (raw_basenames & crf_var_set) else 0.85
        return ("CRF", conf)

    raw_ds_prefixes = {ds[:2] for ds in raw_ds_names if len(ds) >= 2}
    if raw_ds_prefixes & CRF_DATASET_PREFIXES and not (raw_ds_prefixes & EDT_PREFIXES):
        return ("CRF", 0.80)

    # Priority 2: Derived
    derive_kws = {
        "COMPUTE", "CALCULATE", "DERIVE", "ISO8601", "CONCATENATE",
        "BASE", "CHG", "PCHG", "SEQNUM", "LOOKUP", "ISO 8601",
    }
    var_class = classify_variable(v, domain)
    if (var_class in ("derived", "flag", "sequence")
            or any(kw in action for kw in derive_kws)
            or v in ALWAYS_DERIVED):
        return ("Derived", 0.90)

    # Priority 3: Protocol
    if v in PROTOCOL_VARS or var_class == "identifier":
        return ("Protocol", 0.92)

    # Priority 4: eDT
    raw_input_prefixes = set()
    for tok in (raw_inputs or []):
        parts = str(tok).upper().split(".")
        if len(parts) >= 2:
            raw_input_prefixes.add(parts[-2][:2])
    if raw_input_prefixes & EDT_PREFIXES:
        return ("eDT", 0.75)

    # Priority 5: Assigned
    assigned_actions = {"ASSIGN", "HARDCODE", "HARD CODE", "CDISC CT"}
    conf = 0.88 if action in assigned_actions or action.startswith('"') else 0.55
    return ("Assigned", conf)


def normalize_action(raw_action):
    if not raw_action:
        return ""
    if isinstance(raw_action, float) and math.isnan(raw_action):
        return ""
    t = re.sub(r"\s+", " ", str(raw_action).strip()).upper()
    mapping = {
        "ASSIGN":           ["ASSIGN", "DIRECT", "AS IS", "COPY", "TRANSFER", "VERBATIM"],
        "DROP":             ["DROP", "NOT APPLICABLE", "N/A", "EXCLUDE", "NOT USED",
                             "NOT MAPPED", "NA"],
        "DERIVE":           ["DERIVE", "DERIVED", "COMPUTE", "CALCULATE", "COMPUTED",
                             "ALGORITHM", "LOGIC"],
        "ISO8601_DATETIME": ["ISO8601", "ISO 8601", "DATETIME", "DATE TIME", "DATE/TIME"],
        "ISO8601_DATE":     ["ISO8601 DATE", "ISO 8601 DATE", "DATE CONVERT", "DATE FORMAT"],
        "CONCATENATE":      ["CONCAT", "CONCATENATE", "JOIN", "COMBINE", "CAT"],
        "HARDCODE":         ["HARD CODE", "HARDCODE", "CONSTANT", "FIXED", "LITERAL"],
        "CODELIST_MAP":     ["DECODE", "RECODE", "MAP", "LOOKUP", "CT", "CDISC CT",
                             "CONTROLLED TERM"],
        "SEQNUM":           ["SEQ", "SEQUENCE", "COUNTER", "SEQUENTIAL"],
    }
    for canonical, variants in mapping.items():
        for v in variants:
            if v in t:
                return canonical
    return t
