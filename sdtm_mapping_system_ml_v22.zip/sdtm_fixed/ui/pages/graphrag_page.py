"""
ui/pages/graphrag_page.py
==========================
GraphRAG Knowledge Graph page for the SDTM Mapping System.
Provides: interactive graph view, natural-language query, domain explorer,
raw variable lineage, and unmapped variable report.
"""
from __future__ import annotations

import sys
import traceback
from pathlib import Path

APP_DIR = Path(__file__).parent.parent.parent.resolve()
sys.path.insert(0, str(APP_DIR / "src"))
sys.path.insert(0, str(APP_DIR))

import streamlit as st


def render() -> None:
    st.markdown("## 🕸 Knowledge Graph — Raw → SDTM Lineage")
    st.info(
        "Build a GraphRAG knowledge graph from your master mapping to explore "
        "raw-to-SDTM relationships, run natural-language queries, and visualise "
        "the full mapping topology interactively."
    )

    # ── Dependency check ──────────────────────────────────────────────────────
    try:
        import networkx  # noqa: F401
    except ImportError:
        st.error(
            "**networkx is required for GraphRAG.**\n\n"
            "Install it with: `pip install networkx`\n\n"
            "Then restart the Streamlit app."
        )
        return

    # ── Session state init ────────────────────────────────────────────────────
    if "kg" not in st.session_state:
        st.session_state["kg"] = None
    if "rag" not in st.session_state:
        st.session_state["rag"] = None
    if "kg_chunks" not in st.session_state:
        st.session_state["kg_chunks"] = []

    # ── Build Graph section ───────────────────────────────────────────────────
    with st.expander("📂 Build Knowledge Graph", expanded=st.session_state["kg"] is None):
        col1, col2 = st.columns([2, 1])
        with col1:
            master_upload = st.file_uploader(
                "master_mapping.xlsx",
                type=["xlsx"],
                key="kg_master_upload",
                help="Upload your master_mapping.xlsx built in Phase 1.",
            )
            # Show availability of session data
            has_session_master = bool(st.session_state.get("master_built") and
                                       st.session_state.get("master_xlsx_bytes"))
            has_session_results = bool(st.session_state.get("map_done") and
                                        st.session_state.get("mapping_results_dict"))

            if master_upload is None and has_session_master:
                st.success("✓ Phase 1 master mapping available — will be used automatically.")
            elif master_upload is None:
                st.info("Upload master_mapping.xlsx or build one in Phase 1 first.")

            if has_session_results:
                st.success("✓ Phase 2 mapping results available — will overlay on graph.")
            else:
                st.caption("Run Phase 2 mapping to overlay live results on the graph.")

        with col2:
            st.markdown("&nbsp;")
            if st.button("🔨 Build Graph", type="primary", use_container_width=True):
                _build_graph(master_upload)

    if st.session_state["kg"] is None:
        st.markdown(
            '<div style="color:#7a93b4;text-align:center;padding:40px">'
            "Upload master_mapping.xlsx and click Build Graph to begin.</div>",
            unsafe_allow_html=True,
        )
        return

    # ── Graph is built: show tabs ─────────────────────────────────────────────
    kg  = st.session_state["kg"]
    rag = st.session_state["rag"]
    stats = kg.stats()

    # Stats bar
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Nodes", stats["total_nodes"])
    c2.metric("Total Edges", stats["total_edges"])
    c3.metric("Raw Vars", stats["node_kinds"].get("raw_var", 0))
    c4.metric("SDTM Vars", stats["node_kinds"].get("sdtm_var", 0))
    c5.metric("MAPS_TO", stats["edge_types"].get("MAPS_TO", 0))

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🔍 Query", "🗺 Graph View", "📊 Domain Explorer",
        "🔗 Raw Lineage", "⚠ Unmapped",
    ])

    with tab1:
        _render_query_tab(rag)

    with tab2:
        _render_graph_view_tab(kg)

    with tab3:
        _render_domain_tab(rag)

    with tab4:
        _render_lineage_tab(rag)

    with tab5:
        _render_unmapped_tab(rag)


# ── Build handler ─────────────────────────────────────────────────────────────

def _build_graph(master_upload) -> None:
    import tempfile, shutil
    from services.graphrag_service import build_graph

    tmpdir = Path(tempfile.mkdtemp(prefix="sdtm_kg_"))

    try:
        # Resolve master path — prefer upload, then Phase 1 session bytes
        if master_upload is not None:
            mp = tmpdir / master_upload.name
            mp.write_bytes(master_upload.getbuffer())
        elif st.session_state.get("master_built") and st.session_state.get("master_xlsx_bytes"):
            master_data = st.session_state["master_xlsx_bytes"]
            # master_xlsx_bytes is stored as plain bytes (not a tuple)
            if isinstance(master_data, (bytes, bytearray)):
                mp = tmpdir / "master_mapping.xlsx"
                mp.write_bytes(master_data)
            else:
                # fallback: might be a tuple (name, bytes) in some versions
                name, data = master_data
                mp = tmpdir / name
                mp.write_bytes(data)
        else:
            st.error("No master_mapping.xlsx available. Upload one or build one in Phase 1 first.")
            return

        # Optional: include mapping results from Phase 2 session
        results = st.session_state.get("mapping_results_dict")

        with st.spinner("Building knowledge graph…"):
            kg, rag, chunks = build_graph(
                master_path=mp,
                mapping_results=results,
            )

        st.session_state["kg"]        = kg
        st.session_state["rag"]       = rag
        st.session_state["kg_chunks"] = chunks
        s = kg.stats()
        overlay_msg = f" · Phase 2 overlay: {len(results)} tiers" if results else ""
        st.success(
            f"Graph built: {s['total_nodes']} nodes · "
            f"{s['total_edges']} edges · {len(chunks)} indexed chunks{overlay_msg}"
        )
        st.rerun()

    except Exception as exc:
        st.error(f"Graph build failed: {exc}")
        import traceback as _tb
        st.code(_tb.format_exc(), language="text")
    finally:
        shutil.rmtree(str(tmpdir), ignore_errors=True)


# ── Tab renderers ─────────────────────────────────────────────────────────────

def _render_query_tab(rag) -> None:
    st.markdown("### Natural-Language Query")
    st.caption(
        "Ask questions about your raw→SDTM mapping knowledge base. "
        "Examples: *What raw variables map to AESTDTC?* · "
        "*Show lab result mappings* · *How is USUBJID derived?*"
    )

    question = st.text_input(
        "Query",
        placeholder="e.g. What raw variables map to AESTDTC in domain AE?",
        key="kg_query_input",
    )

    if st.button("🔍 Search", key="kg_search_btn") and question:
        from services.graphrag_service import query_graph
        with st.spinner("Traversing graph…"):
            result = query_graph(rag, question)
        _display_query_result(result)

    # Quick presets
    st.markdown("**Quick queries:**")
    presets = [
        "What raw variables map to AESTDTC?",
        "Show all lab test result mappings",
        "Which SDTM variables have the most raw sources?",
        "Show demographic variable mappings",
        "What raw variables map to VSTERM?",
    ]
    cols = st.columns(len(presets))
    for i, preset in enumerate(presets):
        if cols[i].button(f"Q{i+1}", help=preset, key=f"preset_{i}"):
            from services.graphrag_service import query_graph
            with st.spinner("Querying…"):
                result = query_graph(rag, preset)
            st.markdown(f"**Query:** *{preset}*")
            _display_query_result(result)


def _display_query_result(result: dict) -> None:
    import pandas as pd

    rule = result.get("matched_rule")
    if rule:
        st.markdown(
            f'<div style="background:#0d1422;border:1px solid #253550;border-left:'
            f'3px solid #f97316;border-radius:6px;padding:10px 14px;margin:8px 0">'
            f'<b style="color:#f97316">SDTM Rule Match:</b> {rule.get("id","")}'
            f' — {rule.get("desc","")}'
            f'</div>',
            unsafe_allow_html=True,
        )

    ctx = result.get("graph_context", {})
    if ctx.get("raw_sources"):
        st.markdown("**Raw Sources (from graph):**")
        df = pd.DataFrame(ctx["raw_sources"])
        st.dataframe(df, use_container_width=True, hide_index=True)

    hc = result.get("high_confidence_mappings", [])
    if hc:
        st.markdown("**High-Confidence Mappings:**")
        df2 = pd.DataFrame(hc)
        st.dataframe(df2, use_container_width=True, hide_index=True)

    evid = result.get("evidence", [])
    if evid:
        with st.expander(f"📄 {len(evid)} evidence chunks"):
            for e in evid:
                st.markdown(
                    f'**{e.get("header","")}** (score: {e.get("score",0):.2f})<br>'
                    f'<span style="color:#8b949e">{e.get("text","")[:180]}…</span>',
                    unsafe_allow_html=True,
                )


def _render_graph_view_tab(kg) -> None:
    import tempfile, base64
    from services.graphrag_service import export_graph_html

    st.markdown("### Interactive Graph Visualisation")
    st.caption("Full D3.js interactive graph — click, drag, filter, search nodes.")

    col1, col2 = st.columns([3, 1])
    with col2:
        domain_filter = st.selectbox(
            "Filter by domain",
            ["All"] + sorted(set(
                d.get("domain", "")
                for _, d in kg.G.nodes(data=True)
                if d.get("kind") == "sdtm_domain" and d.get("domain")
            )),
            key="kg_domain_filter",
        )

    with col1:
        if st.button("🖥 Open Full Graph in New Tab", use_container_width=True):
            tmpdir = Path(tempfile.mkdtemp(prefix="sdtm_viz_"))
            out = tmpdir / "kg.html"
            export_graph_html(
                kg if domain_filter == "All"
                else kg.get_subgraph_for_domain(domain_filter),
                out,
            )
            html_b64 = base64.b64encode(out.read_bytes()).decode()
            st.markdown(
                f'<a href="data:text/html;base64,{html_b64}" download="sdtm_kg.html" '
                f'target="_blank">📥 Download graph HTML</a>',
                unsafe_allow_html=True,
            )

    # Inline preview (sampled for performance)
    try:
        from graphrag.viz.d3_export import generate_d3_html
        view_kg = (
            kg.get_subgraph_for_domain(domain_filter)
            if domain_filter != "All" else kg
        )
        html_str = generate_d3_html(
            view_kg,
            title=f"SDTM KG{' — '+domain_filter if domain_filter != 'All' else ''}",
        )
        st.components.v1.html(html_str, height=600, scrolling=False)
    except Exception as exc:
        st.error(f"Graph render error: {exc}")


def _render_domain_tab(rag) -> None:
    import pandas as pd

    st.markdown("### Domain Mapping Coverage")
    from services.graphrag_service import get_domain_summary
    from graphrag.mapping.sdtm_rules import DOMAIN_CLASS

    domains = sorted(set(
        d.get("domain", "")
        for _, d in rag.kg.G.nodes(data=True)
        if d.get("kind") == "sdtm_domain" and d.get("domain")
    ))

    if not domains:
        st.info("No SDTM domain nodes found in graph.")
        return

    sel_domain = st.selectbox("Select SDTM Domain", domains, key="kg_domain_sel")

    if sel_domain:
        summary = get_domain_summary(rag, sel_domain)
        dom_class = DOMAIN_CLASS.get(sel_domain, "Special")

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total SDTM Vars", summary["total_sdtm_vars"])
        c2.metric("Mapped", summary["mapped_count"], delta=f"{summary['coverage_pct']}%")
        c3.metric("Unmapped", summary["unmapped_count"])
        c4.metric("Domain Class", dom_class)

        col_a, col_b = st.columns(2)
        with col_a:
            if summary["mapped_vars"]:
                st.markdown("**Mapped Variables**")
                st.dataframe(
                    pd.DataFrame(summary["mapped_vars"]),
                    use_container_width=True, hide_index=True,
                )
        with col_b:
            if summary["unmapped_vars"]:
                st.markdown("**Unmapped Variables**")
                st.dataframe(
                    pd.DataFrame(summary["unmapped_vars"]),
                    use_container_width=True, hide_index=True,
                )


def _render_lineage_tab(rag) -> None:
    import pandas as pd
    from services.graphrag_service import get_raw_var_lineage

    st.markdown("### Raw Variable Mapping Lineage")
    st.caption("Enter a raw dataset and variable name to trace its full SDTM mapping history.")

    col1, col2, col3 = st.columns([2, 2, 1])
    with col1:
        dataset = st.text_input("Raw Dataset", value="AE", key="kg_raw_ds").upper()
    with col2:
        variable = st.text_input("Raw Variable", value="AETERM", key="kg_raw_var").upper()
    with col3:
        st.markdown("&nbsp;")
        search = st.button("🔍 Trace", use_container_width=True)

    if search and dataset and variable:
        result = get_raw_var_lineage(rag, dataset, variable)

        if not result.get("found_in_graph"):
            st.warning(
                f"{dataset}.{variable} not found in knowledge graph. "
                "Showing BM25 suggestions:"
            )
            sugg = result.get("bm25_suggestions", [])
            if sugg:
                st.dataframe(pd.DataFrame(sugg), use_container_width=True, hide_index=True)
            return

        targets = result.get("sdtm_targets", [])
        if targets:
            st.markdown(f"**SDTM Targets for {dataset}.{variable}:**")
            df = pd.DataFrame(targets).drop(columns=["node"], errors="ignore")
            st.dataframe(
                df.style.background_gradient(subset=["score"], cmap="RdYlGn"),
                use_container_width=True, hide_index=True,
            )
        else:
            st.info(f"{dataset}.{variable} is in the graph but has no MAPS_TO edges yet.")

        co = result.get("co_mapped_vars", [])
        if co:
            st.markdown(f"**Co-mapped variables (appear in same input groups):**")
            st.write(", ".join(co[:20]))


def _render_unmapped_tab(rag) -> None:
    import pandas as pd
    from services.graphrag_service import get_unmapped_variables

    st.markdown("### SDTM Variables With No Raw Source")
    st.caption(
        "These SDTM variables exist in the spec but have no raw variable "
        "mapped to them in the master knowledge base. Review to identify gaps."
    )

    unmapped = get_unmapped_variables(rag)

    if not unmapped:
        st.success("All SDTM variables have at least one raw source in the knowledge graph.")
        return

    df = pd.DataFrame(unmapped)

    # Filter controls
    col1, col2 = st.columns(2)
    with col1:
        dom_filter = st.multiselect(
            "Filter by domain",
            sorted(df["domain"].unique()),
            key="kg_unmapped_dom",
        )
    with col2:
        class_filter = st.multiselect(
            "Filter by var class",
            sorted(df["var_class"].unique()),
            key="kg_unmapped_class",
        )

    if dom_filter:
        df = df[df["domain"].isin(dom_filter)]
    if class_filter:
        df = df[df["var_class"].isin(class_filter)]

    st.metric("Unmapped Variables", len(df))
    st.dataframe(df, use_container_width=True, hide_index=True)

    # Download
    import io
    buf = io.BytesIO()
    df.to_excel(buf, index=False)
    buf.seek(0)
    st.download_button(
        "📥 Download Unmapped Report",
        data=buf.read(),
        file_name="unmapped_sdtm_vars.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
