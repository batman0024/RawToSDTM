"""
ui/session.py
=============
Session state initialisation and file-watcher utilities.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import streamlit as st
from cdm_filter import DEFAULT_CDM_VARIABLES, DEFAULT_CDM_DATASETS, DEFAULT_CDM_SUFFIXES


def init_session_state():
    """Initialise all required session state keys with safe defaults."""
    from cdm_filter import DEFAULT_CDM_VARIABLES, DEFAULT_CDM_DATASETS, DEFAULT_CDM_SUFFIXES
    if "cdm_filter_dict" not in st.session_state:
        st.session_state["cdm_filter_dict"] = {
            "cdm_variables":   sorted(DEFAULT_CDM_VARIABLES),
            "cdm_datasets":    sorted(DEFAULT_CDM_DATASETS),
            "cdm_suffixes":    list(DEFAULT_CDM_SUFFIXES),
            "custom_patterns": [],
        }

    _SS_DEFAULTS = {
        "watch_hashes":          {},
        "watch_folder":          "",
        "auto_update_log":       [],
        # Phase 1
        "master_xlsx_bytes":     None,
        "master_built":          False,
        # Phase 2
        "raw_bytes":             None,
        "spec_bytes":            None,
        "results_xlsx_bytes":    None,
        "map_done":              False,
        "mapping_results_dict":  None,
        # Phase 3 / Write Back
        "wb_spec_bytes":         None,
        "wb_results_bytes":      None,
        # Compare
        "cmp_orig_bytes":        None,
        "cmp_mapped_bytes":      None,
        # Validation
        "last_val_report":       None,
        # Review & Approve
        "direct_df_cache":       [],
        "review_df_cache":       [],
        "mapping_approvals":     {},
        # Knowledge Graph
        "kg":                    None,
        "rag":                   None,
        "kg_chunks":             [],
        # Settings
        "cfg_path_input":        "",
    }
    for _k, _v in _SS_DEFAULTS.items():
        if _k not in st.session_state:
            st.session_state[_k] = _v


def _file_hash(path):
    """Return SHA1 hex of a file for change detection."""
    try:
        h = hashlib.sha1()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def _scan_watch_folder(folder):
    """Return {filename: hash} for all xlsx/xlsm files in folder."""
    result = {}
    try:
        for p in Path(folder).glob("*.xls*"):
            result[p.name] = _file_hash(p)
    except Exception:
        pass
    return result
