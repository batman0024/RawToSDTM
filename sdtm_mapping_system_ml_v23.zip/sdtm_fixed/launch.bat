@echo off
setlocal EnableDelayedExpansion

:: ============================================================
:: SDTM Master Mapping System v21 - Windows Launcher
:: ============================================================
:: Usage:
::   launch.bat              - Start app (skips venv/install if already set up)
::   launch.bat --install    - Force reinstall of all dependencies
::   launch.bat --novenv     - Run directly with system Python (no venv)
::   SET PORT=8502 && launch.bat      - Override Streamlit port
::   SET API_PORT=8001 && launch.bat  - Override FastAPI port
::
:: To skip venv creation permanently, add to .env:
::   USE_VENV=false
:: ============================================================

title SDTM Mapping System v21

:: ── Configurable ports ────────────────────────────────────────────────────────
if not defined PORT     set PORT=8501
if not defined API_PORT set API_PORT=8000

set ROOT_DIR=%~dp0
set VENV_DIR=%ROOT_DIR%venv
set REQUIREMENTS=%ROOT_DIR%requirements.txt
set APP_ENTRY=%ROOT_DIR%app.py
set API_ENTRY=api.main:app
set ENV_FILE=%ROOT_DIR%.env

echo.
echo ============================================================
echo   SDTM Master Mapping System v21
echo ============================================================
echo   Root:       %ROOT_DIR%
echo   Streamlit:  http://localhost:%PORT%
echo ============================================================
echo.

:: ── Step 1: Check Python ─────────────────────────────────────────────────────
echo [1/4] Checking Python...
python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Python not found on PATH.
    echo        Download from https://python.org ^(3.9+^)
    echo.
    pause
    exit /b 1
)
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo        Python %PYVER% OK

:: ── Step 2: Load .env ──────────────────────────────────────────────────────────
echo [2/4] Loading environment...
set USE_VENV=true
if exist "%ENV_FILE%" (
    for /f "usebackq tokens=1,* delims==" %%a in ("%ENV_FILE%") do (
        set LINE=%%a
        if not "!LINE:~0,1!"=="#" if not "%%a"=="" set %%a=%%b
    )
    echo        Loaded .env
) else (
    echo        No .env found ^(optional^)
)

:: --novenv flag overrides .env
if "%1"=="--novenv" set USE_VENV=false

:: ── Step 3: Venv + dependencies ───────────────────────────────────────────────
set FORCE_INSTALL=0
if "%1"=="--install" set FORCE_INSTALL=1

if /I "%USE_VENV%"=="false" (
    echo [3/4] Skipping venv ^(USE_VENV=false^) - using system Python
    goto :launch
)

echo [3/4] Checking environment...
if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo        Creating venv...
    python -m venv "%VENV_DIR%"
    if %ERRORLEVEL% neq 0 (
        echo ERROR: Could not create venv.
        pause & exit /b 1
    )
    set FORCE_INSTALL=1
    echo        Venv created.
) else (
    echo        Venv exists. OK
)

call "%VENV_DIR%\Scripts\activate.bat"
if %ERRORLEVEL% neq 0 (
    echo ERROR: Could not activate venv.
    pause & exit /b 1
)

:: Check if streamlit is already installed (fast path — skip pip if present)
if %FORCE_INSTALL%==0 (
    "%VENV_DIR%\Scripts\streamlit.exe" --version >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        echo        streamlit not found - installing dependencies...
        set FORCE_INSTALL=1
    ) else (
        echo        Dependencies already installed. Skipping pip.
    )
)

if %FORCE_INSTALL%==1 (
    echo        Installing from requirements.txt...
    pip install -r "%REQUIREMENTS%"
    if %ERRORLEVEL% neq 0 (
        echo ERROR: pip install failed.
        pause & exit /b 1
    )
    echo        Dependencies installed.
)

:launch
:: ── Step 4: Launch ───────────────────────────────────────────────────────────
if not exist "%ROOT_DIR%tmp" mkdir "%ROOT_DIR%tmp"

echo [4/4] Starting services...

set START_API=0
if /I "%ENABLE_FASTAPI%"=="true" set START_API=1
if /I "%ENABLE_FASTAPI%"=="1"    set START_API=1

if %START_API%==1 (
    echo        Starting FastAPI on port %API_PORT%...
    start "SDTM API" cmd /k "cd /d %ROOT_DIR% && call %VENV_DIR%\Scripts\activate.bat && uvicorn %API_ENTRY% --host 0.0.0.0 --port %API_PORT% --reload"
) else (
    echo        FastAPI disabled ^(ENABLE_FASTAPI=true to enable^)
)

echo.
echo        Open browser: http://localhost:%PORT%
echo        Press Ctrl+C to stop.
echo ============================================================
echo.

:: Run streamlit - works whether venv active or using system Python
streamlit run "%APP_ENTRY%" ^
    --server.port %PORT% ^
    --server.headless true ^
    --browser.gatherUsageStats false ^
    --server.fileWatcherType none

set EXIT_CODE=%ERRORLEVEL%
echo.
echo ============================================================
if %EXIT_CODE% neq 0 (
    echo   Streamlit exited with error code %EXIT_CODE%
    echo   Common fix: port %PORT% in use - set PORT=8502 and retry
) else (
    echo   Streamlit stopped normally.
)
echo ============================================================
echo.
pause
endlocal
exit /b %EXIT_CODE%
